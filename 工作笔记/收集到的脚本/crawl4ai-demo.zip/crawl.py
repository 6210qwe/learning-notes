import requests
import json
import asyncio
import os
import re
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode
from crawl4ai.content_filter_strategy import PruningContentFilter
from crawl4ai.markdown_generation_strategy import DefaultMarkdownGenerator

# 示例函数，演示如何调用爬虫
async def crawl_demo(urls, threshold=0.7, threshold_type="dynamic"):
    """
    爬取URL列表中的内容，并返回爬取结果
    参数:
        urls (list): 需要爬取的URL列表
        threshold (float): 可选。重要度阈值，默认为0.7
        threshold_type (str): 可选。重要度阈值类型，默认为"dynamic"
    返回:
        dict: 爬取结果，包括成功和失败的URL及内容
    """
    # 浏览器配置
    browser_config = BrowserConfig(
        headless=True, # 是否无头模式，True：不打开浏览器
        viewport_width=1280, # 视口宽度
        viewport_height=720, # 视口高度
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", # 用户代理
        text_mode=True, # 文本模式,禁用图片加载
    )  
    # 爬虫运行配置
    run_config = CrawlerRunConfig(
        cache_mode=CacheMode.DISABLED, # 禁用缓存模式，获取最新内容
        stream=False, # 确保返回列表而不是异步生成器
        page_timeout=5000, # 设置页面超时时间为5秒
        markdown_generator = DefaultMarkdownGenerator(
            content_filter=PruningContentFilter(
                threshold = threshold, # 丢掉重要度低于阈值的块,越高过滤越严格
                threshold_type = threshold_type, # 重要度阈值类型，fixed：固定值，dynamic：相对值
            ),
            options = {
                "ignore_links": True, # 是否在最终markdown中移除所有超链接
                "ignore_images": True, # 是否在最终markdown中移除所有图片
            }
        )
    )  # 爬虫运行配置

    async with AsyncWebCrawler(config=browser_config) as crawler:
        try:
            results = await crawler.arun_many(
                urls=urls,
                config=run_config
            )
        except Exception as e:
            print(f"爬取错误：{e}")
            return {
                "error": "爬取失败",
                "detail": str(e)
            }
        
        results_list = []
        failed_urls = []
        success_urls = []
        try:
            for result in results:
                # 检查爬取是否成功
                if result.markdown is None or len(result.markdown.fit_markdown) < 10:
                    print(f"跳过失败的URL: {result.url}")
                    failed_urls.append({
                        "url": result.url,
                        "error": "内容为空或过短"
                    })
                    continue
                results_list.append({
                    "url": result.url,
                    "content": result.markdown.fit_markdown
                })
                success_urls.append(result.url)
        except Exception as e:
            print(f"处理结果错误：{e}")
            return {
                "error": "处理爬取结果失败",
                "detail": str(e)
            }
        return {
            "success_urls": success_urls,
            "markdown_results": results_list, 
            "success_count": len(results_list),
            "failed_urls": failed_urls,
            "failed_count": len(failed_urls),
            "total_urls": len(results_list) + len(failed_urls)
        }

# 示例用法
if __name__ == "__main__":
    urls = [
        "https://www.icourse163.org/course/bit-268001",
        "http://www.runoob.com/python/python-tutorial.html",
        "https://www.w3schools.com/python/",
    ]
    # 运行demo
    result = asyncio.run(crawl_demo(urls))

    print(result)

