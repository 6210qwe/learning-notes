import json
import re
import time
import tu_hy
import random

import requests
import execjs
from pprint import pprint



requests = requests.session()
class JYHK:
    def __init__(self):
        self.one = "http://www.geetest.com/demo/gt/register-slide-official"
        self.two = "http://api.geetest.com/gettype.php"
        self.three = "http://api.geevisit.com/ajax.php"  # 第三次和最后一次请求的网址
        self.four = "http://api.geevisit.com/get.php"
        self.execjs_w = execjs.compile(open("JY滑块.js", mode="r", encoding="utf-8").read())
        self.ts = str(int(time.time() * 1000))
        self.headers = {
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Referer': 'http://www.hnhbrcw.cn/login.shtml',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest',
        }
        self.cookies = {
            'ASP.NET_SessionId': '2ib5umgcpggtwpvhqsuiwzt0',
            'goeasyNode': '9',
        }
        self.red = random.random()

    def __ease_out_expo(self, sep):
        if sep == 1:
            return 1
        else:
            return 1 - pow(2, -10 * sep)

    def get_slide_track(self, distance):
        """
        根据滑动距离生成滑动轨迹
        :param distance: 需要滑动的距离
        :return: 滑动轨迹<type 'list'>: [[x,y,t], ...]
            x: 已滑动的横向距离
            y: 已滑动的纵向距离, 除起点外, 均为0
            t: 滑动过程消耗的时间, 单位: 毫秒
        """
        # print(distance)
        distance = distance[0]
        if not isinstance(distance, int) or distance < 0:
            raise ValueError(f"distance类型必须是大于等于0的整数: distance: {distance}, type: {type(distance)}")
        # 初始化轨迹列表
        slide_track = [
            [random.randint(-50, -10), random.randint(-50, -10), 0],
            [0, 0, 0],
        ]
        # 共记录count次滑块位置信息
        count = 30 + int(distance / 2)
        # 初始化滑动时间
        t = random.randint(50, 100)
        # 记录上一次滑动的距离
        _x = 0
        _y = 0
        tt = 0
        for i in range(count):
            # 已滑动的横向距离
            x = round(self.__ease_out_expo(i / count) * distance)
            # 滑动过程消耗的时间
            t += random.randint(10, 20)
            if x == _x:
                continue
            slide_track.append([x, _y, t])
            _x = x
            tt = t
        slide_track.append(slide_track[-1])
        return slide_track
    def requests_one(self):
        requests.get('http://www.hnhbrcw.cn/login.shtml', cookies=self.cookies, headers=self.headers, verify=False)
        params = {
            'action': 'GeeTestCaptcha',
            't': str(self.red),
        }
        resp = requests.get('http://xinxiangrcw.com/ashx/User.ashx', params=params, cookies=self.cookies, headers=self.headers, verify=False).json()
        challenge = resp['data']['challenge']
        gt = resp['data']['gt']
        return {
            "challenge": challenge,
            "gt": gt
        }
    def requests_two(self, challenge_gt):
        url = "http://api.geetest.com/gettype.php"
        params = {
            "gt": "{}".format(challenge_gt['gt']),
        }
        requests.get(url, headers=self.headers, params=params, cookies=self.cookies)
        params = {
            "gt": "{}".format(challenge_gt['gt']),
            "challenge": "{}".format(challenge_gt['challenge']),
            "lang": "zh-cn",
            "pt": "0",
            "client_type": "web",
            "w": "",
        }
        requests.get(url=self.three, headers=self.headers, params=params, cookies=self.cookies)
        params = {
            "is_next": "true",
            "type": "slide3",
            "gt": "{}".format(challenge_gt['gt']),
            "challenge": "{}".format(challenge_gt['challenge']),
            "lang": "zh-cn",
            "https": "false",
            "protocol": "http://",
            "offline": "false",
            "product": "embed",
            "api_server": "api.geevisit.com",
            'timeout': '5000',
            "isPC": "true",
            "autoReset": "true",
            "width": "100%",
        }
        response = requests.get(url=self.four, headers=self.headers, params=params, cookies=self.cookies).text
        res_re =  re.findall(r'{new Geetest(\(.*?),true\).', response)[0]
        response_info = json.loads(res_re.replace("(", ""))
        #  获取 c 和 s 的值, 还有图片地址 | 在次从这里面获取新的 gt 和 challenge 的值
        get_challenge = response_info["challenge"]
        get_gt = response_info["gt"]
        get_c = response_info["c"]
        get_s = response_info["s"]
        fullbg_wan = "http://static.geetest.com/" + response_info["fullbg"]  # 完整图
        bg_wan = "http://static.geetest.com/" + response_info["bg"]  # 缺口图
        slice_wan = "http://static.geetest.com/" + response_info["slice"]  # 滑块
        return {
            "get_challenge": get_challenge,
            "get_gt": get_gt,
            "get_c": get_c,
            "get_s": get_s,
            "fullbg_wan": fullbg_wan,
            "bg_wan": bg_wan,
            "slice_wan": slice_wan
        }

    def requests_tu(self, data_info):
        resp_wan = requests.get(url=data_info['fullbg_wan']).content
        resp_que = requests.get(url=data_info['bg_wan']).content
        resp_kuai = requests.get(url=data_info['slice_wan']).content
        with open("完整图片.png", mode="wb") as f:
            f.write(resp_wan)
        with open("缺口图片.png", mode="wb") as f:
            f.write(resp_que)
        with open("滑块图.png", mode="wb") as f:
            f.write(resp_kuai)
        tu_hy.restore_picture("缺口图片.png", "完整图片.png")
        return_clack = tu_hy.base64_api("缺口图.png")
        print("识别后的值: ", return_clack)
        # get_slide_track 传入打码平台识别后的滑块距离
        clack_list = self.get_slide_track([int(return_clack)])
        return {
            "return_clack": return_clack,
            "clack_list": clack_list
        }

    def requests_three(self, data_info, resp_data):
        # 不稳定 轨迹的问题, 导致生成的 cookie 长度不对
        """
        c42f2fc881c6e701d3e13c00d70f1fbb b17ca7ce4284f89e34dcccc099d52f7ab7 [12, 58, 98, 36, 43, 95, 62, 15, 12] 4e295a7e 92 [[-37, -21, 0], [0, 0, 0], [8, 0, 128], [15, 0, 143], [22, 0, 161], [28, 0, 173], [34, 0, 186], [39, 0, 203], [43, 0, 223], [48, 0, 237], [52, 0, 255], [55, 0, 268], [58, 0, 287], [61, 0, 302], [64, 0, 318], [66, 0, 334], [69, 0, 354], [71, 0, 365], [72, 0, 376], [74, 0, 386], [76, 0, 399], [77, 0, 411], [78, 0, 431], [80, 0, 450], [81, 0, 463], [82, 0, 480], [83, 0, 495], [84, 0, 521], [85, 0, 538], [86, 0, 576], [87, 0, 592], [88, 0, 634], [89, 0, 666], [90, 0, 732], [91, 0, 831], [92, 0, 1013], [92, 0, 1013]]
        """
        # print(int(resp_data['return_clack']), data_info['get_c'], data_info['get_s'], resp_data['clack_list'], data_info['get_gt'], data_info['get_challenge'])
        w = self.execjs_w.call("get_W", int(resp_data['return_clack']), data_info['get_c'], data_info['get_s'], resp_data['clack_list'], data_info['get_challenge'], data_info['get_gt'])
        print(w)

        params = {
            "gt": "{}".format(data_info['get_gt']),
            "challenge": "{}".format(data_info['get_challenge']),
            "lang": "zh-cn",
            "$_BCN": "0",
            "client_type": "web",
            "w": "{}".format(w['w']),
        }
        # time.sleep(2)
        response = requests.get(url=self.three, headers=self.headers, params=params, cookies=self.cookies).text
        validate_resp = json.loads(response.replace("(", "").replace(")", ""))
        print(validate_resp)
        # print(data_info['get_challenge'])
        # if validate_resp['message'] == "success":
        #     validate = validate_resp['validate']
        #     print(validate)
        #     data = {
        #         'action': 'GeeTestVerifySendMobileCode',
        #         'mobile': "18567226521",
        #         'geetest_challenge': str(data_info['get_challenge']),  # 不是第一次请求的返回
        #         'geetest_validate': str(validate),
        #         'geetest_seccode': str(validate),
        #     }
        #     pprint(data)
        #     response = requests.post('http://www.hnhbrcw.cn/ashx/User.ashx', cookies=self.cookies, headers=self.headers, data=data)
        #     # {"status":10001,"msg":"短信发送成功"}
        #     print(response.json())

    def main(self):
        challenge_gt = self.requests_one()
        data_info = self.requests_two(challenge_gt)
        resp_data = self.requests_tu(data_info)
        self.requests_three(data_info, resp_data)

if __name__ == '__main__':
    jyhk = JYHK()
    jyhk.main()






































