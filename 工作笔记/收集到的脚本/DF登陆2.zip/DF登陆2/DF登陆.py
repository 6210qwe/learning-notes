

# from curl_cffi import requests
from pprint import pprint
import Track_restore
import ddddocr
import requests
import execjs
import random
import time
import json
import re


requests = requests.Session()

class JY:
    Time_ts = lambda: int(round(time.time() * 1000))
    def __init__(self):
        self.URL_ecaliapi = 'http://ecaliapi.ceair.com/ecunionlogin/api/sso/register'
        self.URL_gettype = 'http://api.geetest.com/gettype.php'
        self.URL_ajax = 'http://api.geevisit.com/ajax.php'  # 校验也是走的这个接口
        self.URL_get = 'http://api.geevisit.com/get.php'
        self.gt = None
        self.challenge = None
        self.Execjs_JY = None
        self.Execjs_OPen = None
        self.Execjs_OPens = None
        self.det = ddddocr.DdddOcr(det=False, ocr=False, show_ad=False)
        self.headers = {
            "Accept": "*/*",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Pragma": "no-cache",
            "Referer": "https://sso.ceair.com/",
            "Sec-Fetch-Dest": "script",
            "Sec-Fetch-Mode": "no-cors",
            "Sec-Fetch-Site": "cross-site",
            "Sec-Fetch-Storage-Access": "active",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
        }

    #　轨迹函数
    def __ease_out_expo(self, sep):
        if sep == 1:
            return 1
        else:
            return 1 - pow(2, -10 * sep)

    # 　轨迹函数
    def get_slide_track(self, distance):
        """
        根据滑动距离生成滑动轨迹
        :param distance: 需要滑动的距离
        :return: 滑动轨迹<type 'list'>: [[x,y,t], ...]
            x: 已滑动的横向距离
            y: 已滑动的纵向距离, 除起点外, 均为0
            t: 滑动过程消耗的时间, 单位: 毫秒
        """
        # print(distance)
        distance = distance[0]
        if not isinstance(distance, int) or distance < 0:
            raise ValueError(f"distance类型必须是大于等于0的整数: distance: {distance}, type: {type(distance)}")
        # 初始化轨迹列表
        slide_track = [
            [random.randint(-50, -10), random.randint(-50, -10), 0],
            [0, 0, 0],
        ]
        # 共记录count次滑块位置信息
        count = 30 + int(distance / 2)
        # 初始化滑动时间
        t = random.randint(50, 100)
        # 记录上一次滑动的距离
        _x = 0
        _y = 0
        tt = 0
        for i in range(count):
            # 已滑动的横向距离
            x = round(self.__ease_out_expo(i / count) * distance)
            # 滑动过程消耗的时间
            t += random.randint(10, 20)
            if x == _x:
                continue
            slide_track.append([x, _y, t])
            _x = x
            tt = t
        slide_track.append(slide_track[-1])
        return slide_track

    #
    def Image_recognition(self, Params_Data):
        Notch_diagram = requests.get(url=Params_Data['bg_wan']).content  # 缺口图
        Slider_diagram = requests.get(url=Params_Data['slice_wan']).content  # 滑块图
        with open("缺口图片.png", mode="wb") as f:
            f.write(Notch_diagram)
        with open("滑块图.png", mode="wb") as f:
            f.write(Slider_diagram)

        Track_restore.restore_picture("缺口图片.png", "缺口图片.png")
        return_clack = Track_restore.base64_api("缺口图片.png")
        print("识别后的值: ", return_clack)
        clack_list = self.get_slide_track([int(return_clack)])
        return {
            "get_X": return_clack,
            "Track_X": clack_list,
        }


    # 前置函数, 项目运行前要提前运行的代码
    def Preposition_functon(self):
        with open("JY滑块.js", mode="r", encoding="utf-8") as file:
            self.Execjs_JY = file.read()
            self.Execjs_OPen = execjs.compile(self.Execjs_JY)

        # with open("滑块 w 只生成.js", mode="r", encoding="utf-8") as file:
        #     self.Execjs_JYs = file.read()
        #     self.Execjs_OPens = execjs.compile(self.Execjs_JYs)

    # 第一次请求, 获取值 gt、challenge
    def Ecunionlogin_now(self):
        self.headers['ssoUserId'] = self.Execjs_OPen.call("guid")
        params = {
            't': str(JY.Time_ts()),
        }
        response = requests.get(url=self.URL_ecaliapi, params=params, headers=self.headers)
        if response.status_code == 200:
            self.gt = response.json()['gt']
            self.challenge = response.json()['challenge']
        else:
            print("第一次请求状态吗不等于200!!!", self.URL_ecaliapi)

        params = {
            'gt': self.gt,
            'callback': 'geetest_{}'.format(str(JY.Time_ts())),
        }
        response = requests.get(url=self.URL_gettype, params=params, headers=self.headers)
        if response.status_code == 200:
            # print(response.text)
            pass

        else:
            print("第二次请求状态吗不等于200!!!", self.URL_gettype)

    def Ajax_verify(self):
        params = {
            "gt": self.gt,
            "challenge": self.challenge,
            "lang": "zh-cn",
            "pt": "0",
            "client_type": "web",
            "w": '',   # 也要逆向, 防止通过率过低
            "callback": "geetest_{}".format(str(JY.Time_ts()))
        }
        response = requests.get(url=self.URL_ajax, headers=self.headers, params=params)
        if response.status_code == 200:
            Resp = json.loads(re.findall(r'geetest_.*?(\(.*?)\)', response.text)[0].replace("(", ""))
            print(Resp)
        else:
            print("第三次请求状态吗不等于200!!!", self.URL_ajax)

        params = {
            'is_next': 'true',
            'type': 'slide3',
            'gt': self.gt,
            'challenge': self.challenge,
            'lang': 'zh-cn',
            'https': 'false',
            'protocol': 'https://',
            'offline': 'false',
            'product': 'embed',
            'api_server': 'api.geevisit.com',
            'isPC': 'true',
            'autoReset': 'true',
            'width': '100%',
            'callback': 'geetest_{}'.format(str(JY.Time_ts())),
        }
        response = requests.get(url=self.URL_get, params=params, headers=self.headers)
        if response.status_code == 200:
            Resp = json.loads(re.findall(r'geetest_.*?(\(.*?)\)', response.text)[0].replace("(", ""))
            #  获取 c 和 s 的值, 还有图片地址 | 在次从这里面获取新的 gt 和 challenge 的值
            self.gt = Resp["gt"]
            get_gt = Resp["gt"]
            self.challenge = Resp["challenge"]
            get_challenge = Resp["challenge"]
            get_c = Resp["c"]
            get_s = Resp["s"]
            fullbg_wan = "http://static.geetest.com/" + Resp["fullbg"]  # 完整图
            bg_wan = "http://static.geetest.com/" + Resp["bg"]  # 缺口图
            slice_wan = "http://static.geetest.com/" + Resp["slice"]  # 中通快递查询(滑块).txt
            return {
                "get_gt": get_gt,
                "get_challenge": get_challenge,
                "get_c": get_c,
                "get_s": get_s,
                "fullbg_wan": fullbg_wan,
                "bg_wan": bg_wan,
                "slice_wan": slice_wan
            }

        else:
            print("第四次请求状态吗不等于200!!!", self.URL_get)

    # 校验接口
    def Verification_interface(self, Params_get, Params_Track):
        # self.gt 和 self.challenge这连个参数在请求图片的那个包里面又刷新了一遍

        """
        :param Params_get:
                Params_get['get_c']  // [12, 58, 98, 36, 43, 95, 62, 15, 12]
                Params_get['get_s']  // 49386c4e
                其他的不重要

        :param Params_Track:
                Params_Track['get_X']  // 72  滑塊X軸
                Params_Track['Track_X']  // [[-26, -25, 0], [0, 0, 0], [7, 0, 123], [14, 0, 139], [19, 0, 154], [25, 0, 174], [29, 0, 186], [34, 0, 205], [37, 0, 220], [41, 0, 231], [44, 0, 247], [47, 0, 262], [49, 0, 273], [52, 0, 289], [54, 0, 303], [55, 0, 322], [57, 0, 334], [59, 0, 345], [60, 0, 360], [61, 0, 378], [62, 0, 388], [63, 0, 408], [64, 0, 423], [65, 0, 437], [66, 0, 450], [67, 0, 480], [68, 0, 507], [69, 0, 543], [70, 0, 579], [71, 0, 651], [72, 0, 825], [72, 0, 825]]}  滑塊軌跡
        :return:
        """
        w = self.Execjs_OPen.call("get_W", int(Params_Track['get_X']), Params_get['get_c'], Params_get['get_s'], Params_Track['Track_X'], Params_get['get_challenge'], Params_get['get_gt'])
        # w = self.Execjs_OPens.call("get_w", self.gt, self.challenge, Params_get['get_c'], Params_get['get_s'], int(Params_Track['get_X']), Params_Track['Track_X'])
        print(int(Params_Track['get_X']), Params_get['get_c'], Params_get['get_s'], Params_Track['Track_X'], Params_get['get_challenge'], Params_get['get_gt'])
        print(w)

        """
        w = self.execjs_w.call("get_w", data_info['get_gt'], data_info['get_challenge'], data_info['get_c'], data_info['get_s'],
                               resp_data['return_clack'], resp_data['clack_list'])
        """

        time.sleep(2)
        params = {
            "gt": self.gt,
            "challenge": self.challenge,
            "lang": "zh-cn",
            "%24_BCm": "0",
            "client_type": "web",
            "w": w['w'],  # 需要逆向
            "callback": "geetest_{}".format(JY.Time_ts())
        }

        response = requests.get(url=self.URL_ajax, headers=self.headers, params=params)
        if response.status_code == 200:
            Resp = json.loads(re.findall(r'geetest_.*?(\(.*?)\)', response.text)[0].replace("(", ""))
            print(Resp)

        else:
            print("校验接口状态吗不等于200!!!", self.URL_ajax)

    def main(self):
        self.Preposition_functon()
        self.Ecunionlogin_now()
        Ajax_verify_return = self.Ajax_verify()
        Track = self.Image_recognition(Ajax_verify_return)
        self.Verification_interface(Ajax_verify_return, Track)


if __name__ == '__main__':
    jy = JY()
    jy.main()

















