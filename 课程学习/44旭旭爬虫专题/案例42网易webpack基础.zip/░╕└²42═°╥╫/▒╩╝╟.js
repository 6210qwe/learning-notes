
window.code += `"${e}"` + ':' + a[e] + ',\r\n';false

xuxu(7598).emj2code(["爱心", "女孩", "惊恐", "大笑"])


(0,
                    i.asrsea)(JSON.stringify(g), (0,
                    i.emj2code)(["流泪", "强"]), i.BASE_CODE, (0,
                    i.emj2code)(["爱心", "女孩", "惊恐", "大笑"]))


var i = xuxu(7598);
i.asrsea(JSON.stringify({
    "actShopId": 40402
}), i.emj2code(["流泪", "强"]), i.BASE_CODE, i.emj2code(["爱心", "女孩", "惊恐", "大笑"]))