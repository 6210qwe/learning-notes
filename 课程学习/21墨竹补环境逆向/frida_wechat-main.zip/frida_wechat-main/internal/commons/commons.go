package commons

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sync"
	"time"

	"WeChatOpenDevTools/internal/colors"
	"WeChatOpenDevTools/internal/wechatutils"
	// TODO: Uncomment when frida-go is properly installed
	// "github.com/frida/frida-go/frida"
)

// Temporary mock types for Frida (remove when real Frida is available)
type mockDevice struct{}
type mockSession struct{}
type mockMessage struct {
	Type        string
	Payload     interface{}
	Description string
}

func (m *mockDevice) Attach(pid int, options interface{}) (*mockSession, error) {
	colors.PrintColored(fmt.Sprintf("[MOCK] Attaching to PID %d", pid), colors.Yellow)
	return &mockSession{}, nil
}

func (m *mockDevice) Spawn(path string, options interface{}) (int, error) {
	colors.PrintColored(fmt.Sprintf("[MOCK] Spawning %s", path), colors.Yellow)
	return 12345, nil
}

func (m *mockDevice) Resume(pid int, options interface{}) error {
	colors.PrintColored(fmt.Sprintf("[MOCK] Resuming PID %d", pid), colors.Yellow)
	return nil
}

func (m *mockSession) CreateScript(code string, options interface{}) (*mockScript, error) {
	return &mockScript{}, nil
}

func (m *mockSession) Detach(options interface{}) error {
	return nil
}

func (m *mockSession) IsDetached() bool {
	return false
}

type mockScript struct{}

func (m *mockScript) On(event string, callback func(*mockMessage)) {}

func (m *mockScript) Load(options interface{}) error {
	colors.PrintColored("[MOCK] Script loaded successfully", colors.Green)
	return nil
}

func mockGetLocalDevice() (*mockDevice, error) {
	return &mockDevice{}, nil
}

// Commons handles Frida injection and session management
type Commons struct {
	wechatUtils    *wechatutils.WeChatUtils
	device         *mockDevice    // Changed from *frida.Device
	activeSessions []*mockSession // Changed from []*frida.Session
	sessionsMutex  sync.Mutex
	stopManagement chan bool
}

// NewCommons creates a new Commons instance
func NewCommons() *Commons {
	device, err := mockGetLocalDevice() // Changed from frida.GetLocalDevice()
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] Failed to get local device: %v", err), colors.Red)
		return nil
	}

	return &Commons{
		wechatUtils:    wechatutils.NewWeChatUtils(),
		device:         device,
		activeSessions: make([]*mockSession, 0), // Changed from []*frida.Session
		stopManagement: make(chan bool),
	}
}

// onMessage handles messages from Frida scripts
func (c *Commons) onMessage(message *mockMessage) { // Changed from *frida.Message
	switch message.Type {
	case "send": // Changed from frida.MessageTypeSend
		if payload, ok := message.Payload.(string); ok {
			colors.PrintColored(payload, colors.Green)
		}
	case "error": // Changed from frida.MessageTypeError
		colors.PrintColored(fmt.Sprintf("[-] Script error: %s", message.Description), colors.Red)
	}
}

// injectWeChatEx injects JavaScript code into a WeChat process
func (c *Commons) injectWeChatEx(pid int, code string) *mockSession { // Changed return type
	session, err := c.device.Attach(pid, nil)
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] 注入微信失败PID %d: %v", pid, err), colors.Red)
		return nil
	}

	script, err := session.CreateScript(code, nil)
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] 创建脚本失败PID %d: %v", pid, err), colors.Red)
		session.Detach(nil)
		return nil
	}

	script.On("message", c.onMessage)

	err = script.Load(nil)
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] 加载脚本失败PID %d: %v", pid, err), colors.Red)
		session.Detach(nil)
		return nil
	}

	colors.PrintColored(fmt.Sprintf("[+] 成功注入微信PID: %d", pid), colors.Green)
	return session
}

// injectWeChatDLL spawns and injects into WeChat executable
func (c *Commons) injectWeChatDLL(path, code string) error {
	pid, err := c.device.Spawn(path, nil)
	if err != nil {
		return fmt.Errorf("failed to spawn process: %v", err)
	}

	session, err := c.device.Attach(pid, nil)
	if err != nil {
		return fmt.Errorf("failed to attach to spawned process: %v", err)
	}
	defer session.Detach(nil)

	script, err := session.CreateScript(code, nil)
	if err != nil {
		return fmt.Errorf("failed to create script: %v", err)
	}

	script.On("message", c.onMessage)

	err = script.Load(nil)
	if err != nil {
		return fmt.Errorf("failed to load script: %v", err)
	}

	err = c.device.Resume(pid, nil)
	if err != nil {
		return fmt.Errorf("failed to resume process: %v", err)
	}

	// Wait for process to initialize
	time.Sleep(10 * time.Second)

	return nil
}

// LoadWeChatExConfigs loads and injects WeChat mini-program configurations
func (c *Commons) LoadWeChatExConfigs() {
	var wechatInstances []wechatutils.WeChatInstance

	if runtime.GOOS == "darwin" {
		wechatInstances = c.wechatUtils.GetWeChatPIDsAndVersions()
	} else {
		wechatInstances = c.wechatUtils.GetWeChatPIDsAndVersions()
	}

	if len(wechatInstances) == 0 {
		c.wechatUtils.PrintProcessNotFoundMessage()
		return
	}

	for _, instance := range wechatInstances {
		err := c.injectWeChatExInstance(instance.PID, instance.Version)
		if err != nil {
			colors.PrintColored(fmt.Sprintf("[-] 注入%d小程序版本失败！%v", instance.Version, err), colors.Red)
		} else {
			colors.PrintColored(fmt.Sprintf("[+] 成功注入%d小程序版本，PID: %d", instance.Version, instance.PID), colors.Green)
		}
	}

	// Start session management
	if len(c.activeSessions) > 0 {
		c.startSessionManagement()
	}
}

// injectWeChatExInstance injects code for a specific WeChat instance
func (c *Commons) injectWeChatExInstance(pid, version int) error {
	// Load hook.js
	currentPath, _ := os.Executable()
	hookPath := filepath.Join(filepath.Dir(currentPath), "scripts", "hook.js")

	hookCode, err := os.ReadFile(hookPath)
	if err != nil {
		return fmt.Errorf("failed to read hook.js: %v", err)
	}

	// Load address configuration
	addressConfig, err := c.wechatUtils.LoadAddressConfig(version)
	if err != nil {
		return fmt.Errorf("failed to load address config: %v", err)
	}

	// Convert address config to JSON
	addressJSON, err := json.Marshal(addressConfig)
	if err != nil {
		return fmt.Errorf("failed to marshal address config: %v", err)
	}

	// Combine address config with hook code
	finalCode := fmt.Sprintf("var address=%s;\n%s", string(addressJSON), string(hookCode))

	// Inject the code
	session := c.injectWeChatEx(pid, finalCode)
	if session != nil {
		c.sessionsMutex.Lock()
		c.activeSessions = append(c.activeSessions, session)
		c.sessionsMutex.Unlock()
	}

	return nil
}

// LoadWeChatEXEConfigs loads and injects WeChat built-in browser configurations
func (c *Commons) LoadWeChatEXEConfigs() {
	wechatInstances := c.wechatUtils.GetWeChatPIDsAndVersions()
	if len(wechatInstances) > 0 {
		colors.PrintColored("[-] 请退出所有微信实例后再执行该命令", colors.Red)
		return
	}

	wechatEXEPath := c.wechatUtils.FindInstallationPath("微信")
	if wechatEXEPath == "" {
		return
	}

	// Load hook code for built-in browser
	currentPath, _ := os.Executable()
	hookPath := filepath.Join(filepath.Dir(currentPath), "scripts", "WechatWin.dll", "hook.js")

	hookCode, err := os.ReadFile(hookPath)
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] 读取内置浏览器hook脚本失败: %v", err), colors.Red)
		return
	}

	err = c.injectWeChatDLL(wechatEXEPath, string(hookCode))
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] 注入内置浏览器失败: %v", err), colors.Red)
	} else {
		colors.PrintColored("[+] 成功注入内置浏览器", colors.Green)
	}
}

// LoadWeChatEXEAndWeChatEx loads both built-in browser and mini-program configurations
func (c *Commons) LoadWeChatEXEAndWeChatEx() {
	wechatInstances := c.wechatUtils.GetWeChatPIDsAndVersions()
	if len(wechatInstances) > 0 {
		colors.PrintColored("[-] 请关闭所有微信实例后再执行该命令", colors.Red)
		return
	}

	c.LoadWeChatEXEConfigs()
	c.LoadWeChatExConfigs()
}

// startSessionManagement starts managing active sessions
func (c *Commons) startSessionManagement() {
	go func() {
		ticker := time.NewTicker(5 * time.Second)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				c.manageSessions()
			case <-c.stopManagement:
				return
			}
		}
	}()

	// Keep the main thread alive while sessions are active
	for {
		c.sessionsMutex.Lock()
		sessionCount := len(c.activeSessions)
		c.sessionsMutex.Unlock()

		if sessionCount == 0 {
			break
		}

		time.Sleep(1 * time.Second)
	}
}

// manageSessions removes detached sessions from the active list
func (c *Commons) manageSessions() {
	c.sessionsMutex.Lock()
	defer c.sessionsMutex.Unlock()

	activeSessions := make([]*mockSession, 0) // Changed type
	for _, session := range c.activeSessions {
		if session.IsDetached() {
			colors.PrintColored(fmt.Sprintf("Session %p detached, removing from active sessions.", session), colors.Yellow)
		} else {
			activeSessions = append(activeSessions, session)
		}
	}
	c.activeSessions = activeSessions
}

// Stop stops session management and detaches all sessions
func (c *Commons) Stop() {
	close(c.stopManagement)

	c.sessionsMutex.Lock()
	defer c.sessionsMutex.Unlock()

	for _, session := range c.activeSessions {
		if !session.IsDetached() {
			session.Detach(nil)
		}
	}
	c.activeSessions = nil
}

// GetCPUArchitecture returns the CPU architecture string
func GetCPUArchitecture() string {
	switch runtime.GOOS {
	case "darwin":
		if runtime.GOARCH == "amd64" {
			return "MacOS x64"
		}
		return "MacOS " + runtime.GOARCH
	case "windows":
		return "Windows"
	default:
		return runtime.GOOS
	}
}
