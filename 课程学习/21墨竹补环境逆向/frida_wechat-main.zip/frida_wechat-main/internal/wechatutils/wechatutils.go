package wechatutils

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"

	"WeChatOpenDevTools/internal/colors"
)

// WeChatUtils handles WeChat process detection and utilities
type WeChatUtils struct {
	ConfigsPath string
	VersionList []int
}

// NewWeChatUtils creates a new WeChatUtils instance
func NewWeChatUtils() *WeChatUtils {
	wu := &WeChatUtils{}
	wu.ConfigsPath = wu.getConfigsPath()
	wu.VersionList = wu.getVersionList()

	// Debug information
	colors.PrintColored(fmt.Sprintf("[+] Configs path: %s", wu.ConfigsPath), colors.Green)
	colors.PrintColored(fmt.Sprintf("[+] Available versions: %v", wu.VersionList), colors.Green)

	return wu
}

// getConfigsPath returns the path to the configs directory
func (wu *WeChatUtils) getConfigsPath() string {
	// Try to find configs directory relative to executable
	currentPath, err := os.Executable()
	if err != nil {
		// Fallback to current working directory
		if wd, err := os.Getwd(); err == nil {
			return filepath.Join(wd, "configs")
		}
		return "configs"
	}

	exeDir := filepath.Dir(currentPath)

	// First try: configs in same directory as executable
	configsPath := filepath.Join(exeDir, "configs")
	if _, err := os.Stat(configsPath); err == nil {
		return configsPath
	}

	// Second try: configs in parent directory (for development)
	configsPath = filepath.Join(filepath.Dir(exeDir), "configs")
	if _, err := os.Stat(configsPath); err == nil {
		return configsPath
	}

	// Third try: configs in current working directory
	if wd, err := os.Getwd(); err == nil {
		configsPath = filepath.Join(wd, "configs")
		if _, err := os.Stat(configsPath); err == nil {
			return configsPath
		}
	}

	// Fallback: return the first attempt path even if it doesn't exist
	return filepath.Join(exeDir, "configs")
}

// getVersionList reads available version configurations
func (wu *WeChatUtils) getVersionList() []int {
	var versions []int

	// Check if configs directory exists
	if _, err := os.Stat(wu.ConfigsPath); os.IsNotExist(err) {
		colors.PrintColored(fmt.Sprintf("[-] Configs directory does not exist: %s", wu.ConfigsPath), colors.Red)
		return versions
	}

	err := filepath.WalkDir(wu.ConfigsPath, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}

		if !d.IsDir() && strings.HasPrefix(d.Name(), "address_") && strings.HasSuffix(d.Name(), "_x64.json") {
			// Extract version number from filename like "address_9193_x64.json"
			parts := strings.Split(d.Name(), "_")
			if len(parts) >= 2 {
				if version, err := strconv.Atoi(parts[1]); err == nil {
					versions = append(versions, version)
				}
			}
		}
		return nil
	})

	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] Error reading configs directory: %v", err), colors.Red)
	}

	if len(versions) == 0 {
		colors.PrintColored("[-] No version configuration files found", colors.Red)
	}

	return versions
}

// WeChatInstance represents a WeChat process instance
type WeChatInstance struct {
	PID     int
	Version int
}

// isWeChatExProcess checks if a process is a WeChatAppEx process
func (wu *WeChatUtils) isWeChatExProcess(cmdline string) bool {
	return strings.Contains(cmdline, "WeChatAppEx") && !strings.Contains(cmdline, "--type=")
}

// GetWeChatPIDsAndVersions returns all WeChat process instances with their versions
func (wu *WeChatUtils) GetWeChatPIDsAndVersions() []WeChatInstance {
	var instances []WeChatInstance

	if runtime.GOOS == "darwin" {
		return wu.getWeChatPIDsAndVersionsMac()
	}

	// Windows implementation - get all WeChatAppEx processes first
	cmd := exec.Command("tasklist", "/fi", "IMAGENAME eq WeChatAppEx.exe", "/fo", "csv")
	output, err := cmd.Output()
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] Error getting process list: %v", err), colors.Red)
		return instances
	}

	lines := strings.Split(string(output), "\n")
	for i, line := range lines {
		// Skip header line and empty lines
		if i == 0 || strings.TrimSpace(line) == "" {
			continue
		}

		// Parse CSV line to get PID
		fields := strings.Split(line, ",")
		if len(fields) >= 2 {
			pidStr := strings.Trim(fields[1], "\"")
			if pid, err := strconv.Atoi(pidStr); err == nil {
				// Check if this is a main process (not a child process with --type=)
				if wu.isMainWeChatProcess(pid) {
					// Get command line to extract version
					if version := wu.extractVersionFromPID(pid); version != 0 {
						if wu.isVersionSupported(version) {
							instances = append(instances, WeChatInstance{PID: pid, Version: version})
						}
					}
				}
			}
		}
	}

	return instances
}

// isMainWeChatProcess checks if a PID corresponds to a main WeChat process (not child process)
func (wu *WeChatUtils) isMainWeChatProcess(pid int) bool {
	// Use wmic to get command line for the PID
	cmd := exec.Command("wmic", "process", "where", fmt.Sprintf("ProcessId=%d", pid), "get", "CommandLine", "/format:list")
	output, err := cmd.Output()
	if err != nil {
		return false
	}

	cmdline := string(output)
	// Main process should contain WeChatAppEx but NOT contain --type= (which indicates child processes)
	return strings.Contains(cmdline, "WeChatAppEx") && !strings.Contains(cmdline, "--type=")
}

// getWeChatPIDsAndVersionsMac returns WeChat instances on macOS
func (wu *WeChatUtils) getWeChatPIDsAndVersionsMac() []WeChatInstance {
	var instances []WeChatInstance

	// Get PIDs
	pidCmd := "ps aux | grep 'WeChatAppEx' | grep -v 'grep' | grep ' --client_version' | grep '-user-agent=' | awk '{print $2}'"
	pidOutput, err := exec.Command("sh", "-c", pidCmd).Output()
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] Error getting MacOS WeChat PIDs: %v", err), colors.Red)
		return instances
	}

	// Get versions
	versionCmd := "ps aux | grep 'WeChatAppEx' | grep -v 'grep' | grep ' --client_version' | grep '-user-agent=' | grep -oE 'MacWechat/([0-9]+\\.)+[0-9]+\\(0x\\d+\\)' | grep -oE '(0x\\d+)' | sed 's/0x//g'"
	versionOutput, err := exec.Command("sh", "-c", versionCmd).Output()
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] Error getting MacOS WeChat versions: %v", err), colors.Red)
		return instances
	}

	pids := strings.Fields(strings.TrimSpace(string(pidOutput)))
	versions := strings.Fields(strings.TrimSpace(string(versionOutput)))

	for i, pidStr := range pids {
		if i < len(versions) {
			if pid, err := strconv.Atoi(pidStr); err == nil {
				if version, err := strconv.Atoi(versions[i]); err == nil {
					if wu.isVersionSupported(version) {
						instances = append(instances, WeChatInstance{PID: pid, Version: version})
					}
				}
			}
		}
	}

	return instances
}

// extractVersionFromPID extracts version number from process command line
func (wu *WeChatUtils) extractVersionFromPID(pid int) int {
	// Use wmic to get command line for the PID
	cmd := exec.Command("wmic", "process", "where", fmt.Sprintf("ProcessId=%d", pid), "get", "CommandLine", "/format:list")
	output, err := cmd.Output()
	if err != nil {
		colors.PrintColored(fmt.Sprintf("[-] Error getting command line for PID %d: %v", pid, err), colors.Red)
		return 0
	}

	cmdline := string(output)

	// Try multiple regex patterns to extract version
	patterns := []string{
		`\\?"version\\?"\s*:\s*(\d+)`,                 // JSON with escaped quotes: \"version\": 8555
		`"version"\s*:\s*(\d+)`,                       // JSON format: "version": 8555 or "version":8555
		`"version":(\d+)`,                             // Compact JSON format: "version":8555
		`version["\s]*:[\s"]*(\d+)`,                   // Flexible version pattern
		`--wmpf_extra_config="[^"]*version[^"]*(\d+)`, // More specific pattern for wmpf config
	}

	for i, pattern := range patterns {
		re := regexp.MustCompile(pattern)
		matches := re.FindStringSubmatch(cmdline)
		if len(matches) > 1 {
			if version, err := strconv.Atoi(matches[1]); err == nil {
				colors.PrintColored(fmt.Sprintf("[+] Found version %d for PID %d using pattern %d", version, pid, i+1), colors.Green)
				return version
			}
		}
	}

	// Debug: print command line if no version found
	colors.PrintColored(fmt.Sprintf("[-] No version found for PID %d", pid), colors.Yellow)
	// Enable debugging to see the actual command line
	if strings.Contains(cmdline, "WeChatAppEx") {
		colors.PrintColored(fmt.Sprintf("Debug - Command line: %s", strings.ReplaceAll(cmdline, "\n", " ")), colors.Yellow)
	}

	return 0
}

// isVersionSupported checks if a version is in the supported list
func (wu *WeChatUtils) isVersionSupported(version int) bool {
	for _, v := range wu.VersionList {
		if v == version {
			return true
		}
	}
	return false
}

// GetWeChatPIDAndVersion returns the first WeChat instance found
func (wu *WeChatUtils) GetWeChatPIDAndVersion() (int, int) {
	instances := wu.GetWeChatPIDsAndVersions()
	if len(instances) > 0 {
		return instances[0].PID, instances[0].Version
	}
	return 0, 0
}

// PrintProcessNotFoundMessage prints error message when no WeChat process is found
func (wu *WeChatUtils) PrintProcessNotFoundMessage() {
	colors.PrintColored("[-] 未找到匹配版本的微信进程或微信未运行", colors.Red)
}

// FindInstallationPath finds WeChat installation path on Windows
func (wu *WeChatUtils) FindInstallationPath(programName string) string {
	if runtime.GOOS != "windows" {
		colors.PrintColored("[-] Installation path detection only supported on Windows", colors.Red)
		return ""
	}

	// Try common installation paths first
	commonPaths := []string{
		`C:\Program Files\Tencent\WeChat\WeChat.exe`,
		`C:\Program Files (x86)\Tencent\WeChat\WeChat.exe`,
	}

	for _, path := range commonPaths {
		if _, err := os.Stat(path); err == nil {
			colors.PrintColored(fmt.Sprintf("[+] 查找到%s的安装路径是：%s", programName, path), colors.Green)
			colors.PrintColored("[+] 正在尝试重启微信...", colors.Green)
			return path
		}
	}

	// If not found in common paths, try registry (would need additional Windows-specific implementation)
	colors.PrintColored(fmt.Sprintf("[-] 未找到%s的安装路径", programName), colors.Red)
	return ""
}

// AddressConfig represents the JSON structure of address configuration files
type AddressConfig struct {
	LaunchAppletBegin      string `json:"LaunchAppletBegin,omitempty"`
	MenuItemDevToolsString string `json:"MenuItemDevToolsString,omitempty"`
	SwitchVersion          string `json:"SwitchVersion,omitempty"`
	WechatAppHtml          string `json:"WechatAppHtml,omitempty"`
	WechatWebHtml          string `json:"WechatWebHtml,omitempty"`
	Version                int    `json:"Version"`
}

// LoadAddressConfig loads address configuration for a specific version
func (wu *WeChatUtils) LoadAddressConfig(version int) (*AddressConfig, error) {
	configFile := filepath.Join(wu.ConfigsPath, fmt.Sprintf("address_%d_x64.json", version))

	data, err := os.ReadFile(configFile)
	if err != nil {
		return nil, fmt.Errorf("failed to read config file: %v", err)
	}

	var config AddressConfig
	if err := json.Unmarshal(data, &config); err != nil {
		return nil, fmt.Errorf("failed to parse config file: %v", err)
	}

	return &config, nil
}
