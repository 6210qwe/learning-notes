package colors

// Color constants for terminal output
const (
	End    = "\033[0m"
	Red    = "\033[91m"
	Green  = "\033[92m"
	Yellow = "\033[93m"
	Blue   = "\033[94m"
	Cyan   = "\033[96m"
	Purple = "\033[95m"
)

// PrintColored prints a message with the specified color
func PrintColored(message, color string) {
	println(color + message + End)
}
