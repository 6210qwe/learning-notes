package utils

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
)

// WeChatUtils handles WeChat process detection and utilities
type WeChatUtils struct {
	ConfigsPath string
	VersionList []int
}

// NewWeChatUtils creates a new WeChatUtils instance
func NewWeChatUtils() *WeChatUtils {
	wu := &WeChatUtils{}
	wu.ConfigsPath = wu.getConfigsPath()
	wu.VersionList = wu.getVersionList()

	fmt.Printf("[+] Configs path: %s\n", wu.ConfigsPath)
	fmt.Printf("[+] Available versions: %v\n", wu.VersionList)

	return wu
}

// getConfigsPath returns the path to the configs directory
func (wu *WeChatUtils) getConfigsPath() string {
	// Try to find configs directory relative to executable
	currentPath, err := os.Executable()
	if err != nil {
		// Fallback to current working directory
		if wd, err := os.Getwd(); err == nil {
			return filepath.Join(wd, "configs")
		}
		return "configs"
	}

	exeDir := filepath.Dir(currentPath)

	// First try: configs in same directory as executable
	configsPath := filepath.Join(exeDir, "configs")
	if _, err := os.Stat(configsPath); err == nil {
		return configsPath
	}

	// Second try: configs in parent directory (for development)
	configsPath = filepath.Join(filepath.Dir(exeDir), "configs")
	if _, err := os.Stat(configsPath); err == nil {
		return configsPath
	}

	// Third try: configs in current working directory
	if wd, err := os.Getwd(); err == nil {
		configsPath = filepath.Join(wd, "configs")
		if _, err := os.Stat(configsPath); err == nil {
			return configsPath
		}
	}

	// Fallback: return the first attempt path even if it doesn't exist
	return filepath.Join(exeDir, "configs")
}

// getVersionList reads available version configurations
func (wu *WeChatUtils) getVersionList() []int {
	var versions []int

	// Check if configs directory exists
	if _, err := os.Stat(wu.ConfigsPath); os.IsNotExist(err) {
		fmt.Printf("[-] Configs directory does not exist: %s\n", wu.ConfigsPath)
		return versions
	}

	var suffix string
	if runtime.GOOS == "darwin" {
		suffix = "_arm.json"
	} else {
		suffix = "_x64.json"
	}

	err := filepath.WalkDir(wu.ConfigsPath, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}

		if !d.IsDir() && strings.HasPrefix(d.Name(), "address_") && strings.HasSuffix(d.Name(), suffix) {
			// Extract version number from filename like "address_9193_x64.json" or "address_9193_arm.json"
			parts := strings.Split(d.Name(), "_")
			if len(parts) >= 2 {
				if version, err := strconv.Atoi(parts[1]); err == nil {
					versions = append(versions, version)
				}
			}
		}
		return nil
	})

	if err != nil {
		fmt.Printf("[-] Error reading configs directory: %v\n", err)
	}

	if len(versions) == 0 {
		fmt.Printf("[-] No version configuration files found\n")
	}

	return versions
}

// GetWeChatPIDAndVersion returns the first available WeChat process PID and version
func (wu *WeChatUtils) GetWeChatPIDAndVersion() (int, string, error) {
	if runtime.GOOS == "darwin" {
		return wu.getWeChatPIDAndVersionMac()
	}
	return wu.getWeChatPIDAndVersionWindows()
}

// getWeChatPIDAndVersionWindows returns WeChat PID and version on Windows
func (wu *WeChatUtils) getWeChatPIDAndVersionWindows() (int, string, error) {
	// Get all WeChatAppEx processes
	cmd := exec.Command("tasklist", "/fi", "IMAGENAME eq WeChatAppEx.exe", "/fo", "csv")
	output, err := cmd.Output()
	if err != nil {
		return 0, "", fmt.Errorf("error getting process list: %v", err)
	}

	lines := strings.Split(string(output), "\n")
	for i, line := range lines {
		// Skip header line and empty lines
		if i == 0 || strings.TrimSpace(line) == "" {
			continue
		}

		// Parse CSV line to get PID
		fields := strings.Split(line, ",")
		if len(fields) >= 2 {
			pidStr := strings.Trim(fields[1], "\"")
			if pid, err := strconv.Atoi(pidStr); err == nil {
				// Check if this is a main process
				if wu.isMainWeChatProcess(pid) {
					// Get version from PID
					if version := wu.extractVersionFromPID(pid); version != 0 {
						if wu.isVersionSupported(version) {
							return pid, strconv.Itoa(version), nil
						}
					}
				}
			}
		}
	}

	return 0, "", fmt.Errorf("no supported WeChat process found")
}

// getWeChatPIDAndVersionMac returns WeChat PID and version on macOS
func (wu *WeChatUtils) getWeChatPIDAndVersionMac() (int, string, error) {
	// Get PIDs
	pidCmd := "ps aux | grep 'WeChatAppEx' | grep -v 'grep' | grep ' --client_version' | grep '-user-agent=' | awk '{print $2}'"
	pidOutput, err := exec.Command("sh", "-c", pidCmd).Output()
	if err != nil {
		return 0, "", fmt.Errorf("error getting MacOS WeChat PIDs: %v", err)
	}

	// Get versions
	versionCmd := "ps aux | grep 'WeChatAppEx' | grep -v 'grep' | grep ' --client_version' | grep '-user-agent=' | grep -oE 'MacWechat/([0-9]+\\.)+[0-9]+\\(0x\\d+\\)' | grep -oE '(0x\\d+)' | sed 's/0x//g'"
	versionOutput, err := exec.Command("sh", "-c", versionCmd).Output()
	if err != nil {
		return 0, "", fmt.Errorf("error getting MacOS WeChat versions: %v", err)
	}

	pidLines := strings.Split(strings.TrimSpace(string(pidOutput)), "\n")
	versionLines := strings.Split(strings.TrimSpace(string(versionOutput)), "\n")

	if len(pidLines) == 0 || len(versionLines) == 0 {
		return 0, "", fmt.Errorf("no WeChat process found")
	}

	// Take the first available process
	if pid, err := strconv.Atoi(pidLines[0]); err == nil {
		if versionHex := versionLines[0]; versionHex != "" {
			if version, err := strconv.ParseInt(versionHex, 16, 64); err == nil {
				versionStr := strconv.FormatInt(version, 10)
				if wu.isVersionSupported(int(version)) {
					return pid, versionStr, nil
				}
			}
		}
	}

	return 0, "", fmt.Errorf("no supported WeChat process found")
}

// isMainWeChatProcess checks if a PID corresponds to a main WeChat process
func (wu *WeChatUtils) isMainWeChatProcess(pid int) bool {
	cmd := exec.Command("wmic", "process", "where", fmt.Sprintf("ProcessId=%d", pid), "get", "CommandLine", "/format:list")
	output, err := cmd.Output()
	if err != nil {
		return false
	}

	cmdline := string(output)
	return strings.Contains(cmdline, "WeChatAppEx") && !strings.Contains(cmdline, "--type=")
}

// extractVersionFromPID extracts version from process command line
func (wu *WeChatUtils) extractVersionFromPID(pid int) int {
	cmd := exec.Command("wmic", "process", "where", fmt.Sprintf("ProcessId=%d", pid), "get", "CommandLine", "/format:list")
	output, err := cmd.Output()
	if err != nil {
		return 0
	}

	cmdline := string(output)
	// Look for version pattern in command line
	if strings.Contains(cmdline, "--client_version") {
		// Extract version from command line
		parts := strings.Split(cmdline, "--client_version")
		if len(parts) > 1 {
			versionPart := strings.TrimSpace(parts[1])
			if idx := strings.Index(versionPart, " "); idx > 0 {
				versionPart = versionPart[:idx]
			}
			if version, err := strconv.Atoi(versionPart); err == nil {
				return version
			}
		}
	}

	return 0
}

// isVersionSupported checks if a version is supported
func (wu *WeChatUtils) isVersionSupported(version int) bool {
	for _, v := range wu.VersionList {
		if v == version {
			return true
		}
	}
	return false
}

// GetWeChatVersion returns the WeChat version (simplified)
func (wu *WeChatUtils) GetWeChatVersion() (string, error) {
	_, version, err := wu.GetWeChatPIDAndVersion()
	return version, err
}

// AddressConfig represents the address configuration structure
type AddressConfig struct {
	LaunchAppletBegin      string `json:"LaunchAppletBegin,omitempty"`
	MenuItemDevToolsString string `json:"MenuItemDevToolsString,omitempty"`
	SwitchVersion          string `json:"SwitchVersion,omitempty"`
	WechatAppHtml          string `json:"WechatAppHtml,omitempty"`
	WechatWebHtml          string `json:"WechatWebHtml,omitempty"`
	Version                int    `json:"Version"`
}

// LoadAddressConfig loads address configuration for a specific version
func (wu *WeChatUtils) LoadAddressConfig(version string) (*AddressConfig, error) {
	var suffix string
	if runtime.GOOS == "darwin" {
		suffix = "_arm.json"
	} else {
		suffix = "_x64.json"
	}

	configPath := filepath.Join(wu.ConfigsPath, fmt.Sprintf("address_%s%s", version, suffix))

	data, err := os.ReadFile(configPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read config file %s: %v", configPath, err)
	}

	var config AddressConfig
	err = json.Unmarshal(data, &config)
	if err != nil {
		return nil, fmt.Errorf("failed to parse config file: %v", err)
	}

	return &config, nil
}
