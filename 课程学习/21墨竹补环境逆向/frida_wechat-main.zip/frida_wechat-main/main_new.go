package main

import (
	"flag"
	"fmt"
	"os"
	"os/signal"
	"strconv"
	"syscall"

	"WeChatOpenDevTools/utils"
)

func main() {
	helpText := `
请选择要执行的方法：         
                        [+] wechat-devtools -h        查看帮助
                        [+] wechat-devtools -x        开启小程序F12              
                        [+] wechat-devtools -pid <PID> 针对特定PID注入
                                     
`

	// Define flags
	var (
		showHelp    = flag.Bool("h", false, "查看帮助")
		miniProgram = flag.Bool("x", false, "开启小程序F12")
		pidFlag     = flag.String("pid", "", "针对特定PID注入")
	)

	flag.Parse()

	// Handle help flag
	if *showHelp {
		fmt.Println(helpText)
		return
	}

	// Initialize commons
	commons := utils.NewCommons()
	if commons == nil {
		fmt.Printf("[-] Failed to initialize commons\n")
		os.Exit(1)
	}
	defer commons.Close()

	// Set up graceful shutdown
	setupGracefulShutdown(commons)

	// Handle flags
	if *pidFlag != "" {
		// Handle specific PID injection
		pid, err := strconv.Atoi(*pidFlag)
		if err != nil {
			fmt.Printf("[-] Invalid PID: %s\n", *pidFlag)
			os.Exit(1)
		}

		fmt.Printf("[+] Injecting into PID: %d\n", pid)
		err = commons.LoadWeChatConfigsPID(pid)
		if err != nil {
			fmt.Printf("[-] Failed to inject into PID %d: %v\n", pid, err)
			os.Exit(1)
		}
	} else if *miniProgram {
		// Handle mini-program injection
		fmt.Printf("[+] Starting WeChat mini-program injection...\n")
		err := commons.LoadWeChatConfigs()
		if err != nil {
			fmt.Printf("[-] Failed to inject into WeChat: %v\n", err)
			os.Exit(1)
		}
	} else {
		fmt.Println(helpText)
	}
}

// setupGracefulShutdown sets up graceful shutdown handling
func setupGracefulShutdown(commons *utils.Commons) {
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)

	go func() {
		<-c
		fmt.Printf("\n[+] 正在优雅退出...\n")
		if commons != nil {
			commons.Close()
		}
		os.Exit(0)
	}()
}
