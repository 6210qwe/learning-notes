测试好用搜索不卡死

下载
https://github.com/tom-snow/wechat-windows-versions
微信版本3.9.10.19


进去小程序目录
![](https://demo-1305722691.cos.ap-nanjing.myqcloud.com/imgs/202506181053183.png)


回退目录
![](https://demo-1305722691.cos.ap-nanjing.myqcloud.com/imgs/202506181054211.png)

删除所有当前目录所有小程序版本文件
![](https://demo-1305722691.cos.ap-nanjing.myqcloud.com/imgs/202506181055606.png)

1. git clone https://github.com/Charles-Hello/frida_wechat.git
2. uv venv --python 3.13.2 .venv
3. .\.venv\Scripts\Activate.ps1
4. uv pip install -r .\requirements.txt
5. python main.py -x
6. 打开小程序即可完成开启devtool

![](https://demo-1305722691.cos.ap-nanjing.myqcloud.com/imgs/202506181058631.png)


## 鸣谢 (排名不分先后)
1. https://github.com/JaveleyQAQ/WeChatOpenDevTools-Python
2. 志远WeChatOpenDevTool开源
