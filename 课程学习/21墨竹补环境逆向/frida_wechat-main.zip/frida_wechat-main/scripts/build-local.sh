#!/bin/bash

# Local build script for WeChatOpenDevTools
# This script mimics the GitHub Actions build process

set -e

# Configuration
BINARY_NAME="wechat-devtools"
BUILD_DIR="build"
GO_VERSION="1.21"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_go_version() {
    if ! command -v go &> /dev/null; then
        log_error "Go is not installed"
        exit 1
    fi
    
    local go_version=$(go version | awk '{print $3}' | sed 's/go//')
    log_info "Go version: $go_version"
}

clean_build() {
    log_info "Cleaning previous builds..."
    rm -rf $BUILD_DIR
    mkdir -p $BUILD_DIR
}

run_tests() {
    log_info "Running tests..."
    go test -v ./... || {
        log_error "Tests failed"
        exit 1
    }
}

run_vet() {
    log_info "Running go vet..."
    go vet ./... || {
        log_error "go vet failed"
        exit 1
    }
}

check_formatting() {
    log_info "Checking code formatting..."
    local unformatted=$(gofmt -s -l .)
    if [ -n "$unformatted" ]; then
        log_error "Code is not formatted properly:"
        echo "$unformatted"
        log_info "Run 'go fmt ./...' to fix formatting"
        exit 1
    fi
}

download_deps() {
    log_info "Downloading dependencies..."
    go mod download
    go mod tidy
}

build_single() {
    local goos=$1
    local goarch=$2
    local suffix=$3
    
    log_info "Building for $goos/$goarch..."
    
    local output="$BUILD_DIR/${BINARY_NAME}-${goos}-${goarch}${suffix}"
    
    env GOOS=$goos GOARCH=$goarch CGO_ENABLED=1 \
        go build -ldflags "-s -w" -o "$output" .
    
    if [ -f "$output" ]; then
        log_info "✓ Built: $output"
        ls -lh "$output"
    else
        log_error "✗ Failed to build: $output"
        return 1
    fi
}

build_all_platforms() {
    log_info "Building for all platforms..."
    
    # Linux
    build_single "linux" "amd64" ""
    
    # Windows
    build_single "windows" "amd64" ".exe"
    
    # macOS (if on macOS)
    if [[ "$OSTYPE" == "darwin"* ]]; then
        build_single "darwin" "amd64" ""
        build_single "darwin" "arm64" ""
    else
        log_warn "Skipping macOS builds (not on macOS)"
    fi
}

build_current_platform() {
    log_info "Building for current platform..."
    go build -ldflags "-s -w" -o "$BUILD_DIR/$BINARY_NAME" .
    
    if [ -f "$BUILD_DIR/$BINARY_NAME" ]; then
        log_info "✓ Built: $BUILD_DIR/$BINARY_NAME"
        ls -lh "$BUILD_DIR/$BINARY_NAME"
    else
        log_error "✗ Failed to build for current platform"
        return 1
    fi
}

test_binary() {
    local binary="$BUILD_DIR/$BINARY_NAME"
    if [ -f "$binary" ]; then
        log_info "Testing binary..."
        chmod +x "$binary"
        "$binary" --help || {
            log_warn "Binary test failed (this might be expected if WeChat is not available)"
        }
    fi
}

show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

Options:
    -h, --help          Show this help message
    -a, --all           Build for all platforms
    -c, --current       Build for current platform only (default)
    -t, --test          Run tests only
    -f, --format        Check formatting only
    --no-test           Skip tests
    --no-clean          Don't clean build directory
    --mingw             Build Windows version with MinGW (Linux only)

Examples:
    $0                  # Build for current platform with tests
    $0 -a               # Build for all platforms
    $0 -t               # Run tests only
    $0 --no-test -c     # Build current platform without tests

EOF
}

# Main execution
main() {
    local build_all=false
    local build_current=true
    local run_tests_flag=true
    local clean_flag=true
    local mingw_build=false
    local test_only=false
    local format_only=false
    
    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -a|--all)
                build_all=true
                build_current=false
                shift
                ;;
            -c|--current)
                build_current=true
                build_all=false
                shift
                ;;
            -t|--test)
                test_only=true
                shift
                ;;
            -f|--format)
                format_only=true
                shift
                ;;
            --no-test)
                run_tests_flag=false
                shift
                ;;
            --no-clean)
                clean_flag=false
                shift
                ;;
            --mingw)
                mingw_build=true
                shift
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    log_info "Starting local build process..."
    
    # Check prerequisites
    check_go_version
    
    # Format check only
    if [ "$format_only" = true ]; then
        check_formatting
        log_info "Code formatting check completed"
        exit 0
    fi
    
    # Test only
    if [ "$test_only" = true ]; then
        download_deps
        run_tests
        run_vet
        check_formatting
        log_info "Tests completed successfully"
        exit 0
    fi
    
    # Full build process
    download_deps
    
    if [ "$run_tests_flag" = true ]; then
        run_tests
        run_vet
        check_formatting
    fi
    
    if [ "$clean_flag" = true ]; then
        clean_build
    fi
    
    if [ "$build_all" = true ]; then
        build_all_platforms
    elif [ "$build_current" = true ]; then
        build_current_platform
        test_binary
    fi
    
    # MinGW build (Linux only)
    if [ "$mingw_build" = true ]; then
        if [[ "$OSTYPE" == "linux-gnu"* ]]; then
            log_info "Building Windows version with MinGW..."
            if command -v x86_64-w64-mingw32-gcc &> /dev/null; then
                env GOOS=windows GOARCH=amd64 CGO_ENABLED=1 \
                    CC=x86_64-w64-mingw32-gcc CXX=x86_64-w64-mingw32-g++ \
                    go build -ldflags "-s -w" -o "$BUILD_DIR/${BINARY_NAME}-windows-mingw-amd64.exe" .
                log_info "✓ MinGW build completed"
            else
                log_error "MinGW not installed. Install with: sudo apt install gcc-mingw-w64-x86-64 g++-mingw-w64-x86-64"
            fi
        else
            log_warn "MinGW build only supported on Linux"
        fi
    fi
    
    log_info "Build process completed successfully!"
    log_info "Build artifacts:"
    ls -lh $BUILD_DIR/
}

# Run main function with all arguments
main "$@" 