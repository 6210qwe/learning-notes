# Local build script for WeChatOpenDevTools (PowerShell version)
# This script mimics the GitHub Actions build process

param(
    [switch]$All,
    [switch]$Current,
    [switch]$Test,
    [switch]$Format,
    [switch]$NoTest,
    [switch]$NoClean,
    [switch]$Help
)

# Configuration
$BINARY_NAME = "wechat-devtools"
$BUILD_DIR = "build"
$GO_VERSION = "1.21"

# Functions
function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

function Test-GoVersion {
    if (-not (Get-Command go -ErrorAction SilentlyContinue)) {
        Write-Error "Go is not installed or not in PATH"
        exit 1
    }
    
    $goVersion = (go version) -replace "go version go", "" -replace " .*", ""
    Write-Info "Go version: $goVersion"
}

function Clear-Build {
    Write-Info "Cleaning previous builds..."
    if (Test-Path $BUILD_DIR) {
        Remove-Item -Recurse -Force $BUILD_DIR
    }
    New-Item -ItemType Directory -Path $BUILD_DIR -Force | Out-Null
}

function Invoke-Tests {
    Write-Info "Running tests..."
    $result = go test -v ./...
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Tests failed"
        exit 1
    }
}

function Invoke-Vet {
    Write-Info "Running go vet..."
    $result = go vet ./...
    if ($LASTEXITCODE -ne 0) {
        Write-Error "go vet failed"
        exit 1
    }
}

function Test-Formatting {
    Write-Info "Checking code formatting..."
    $unformatted = gofmt -s -l .
    if ($unformatted) {
        Write-Error "Code is not formatted properly:"
        Write-Host $unformatted
        Write-Info "Run 'go fmt ./...' to fix formatting"
        exit 1
    }
}

function Get-Dependencies {
    Write-Info "Downloading dependencies..."
    go mod download
    go mod tidy
}

function Build-Single {
    param(
        [string]$GOOS,
        [string]$GOARCH,
        [string]$Suffix
    )
    
    Write-Info "Building for $GOOS/$GOARCH..."
    
    $output = "$BUILD_DIR\$BINARY_NAME-$GOOS-$GOARCH$Suffix"
    
    $env:GOOS = $GOOS
    $env:GOARCH = $GOARCH
    $env:CGO_ENABLED = "1"
    
    go build -ldflags "-s -w" -o $output .
    
    if (Test-Path $output) {
        Write-Info "✓ Built: $output"
        Get-Item $output | Select-Object Name, Length, LastWriteTime
    } else {
        Write-Error "✗ Failed to build: $output"
        return $false
    }
    
    return $true
}

function Build-AllPlatforms {
    Write-Info "Building for all platforms..."
    
    # Windows
    Build-Single "windows" "amd64" ".exe"
    
    # Linux
    Build-Single "linux" "amd64" ""
    
    # macOS
    Build-Single "darwin" "amd64" ""
    Build-Single "darwin" "arm64" ""
}

function Build-CurrentPlatform {
    Write-Info "Building for current platform..."
    go build -ldflags "-s -w" -o "$BUILD_DIR\$BINARY_NAME.exe" .
    
    $binaryPath = "$BUILD_DIR\$BINARY_NAME.exe"
    if (Test-Path $binaryPath) {
        Write-Info "✓ Built: $binaryPath"
        Get-Item $binaryPath | Select-Object Name, Length, LastWriteTime
    } else {
        Write-Error "✗ Failed to build for current platform"
        return $false
    }
    
    return $true
}

function Test-Binary {
    $binary = "$BUILD_DIR\$BINARY_NAME.exe"
    if (Test-Path $binary) {
        Write-Info "Testing binary..."
        try {
            & $binary --help
        } catch {
            Write-Warn "Binary test failed (this might be expected if WeChat is not available)"
        }
    }
}

function Show-Help {
    Write-Host @"
Usage: .\build-local.ps1 [OPTIONS]

Options:
    -All            Build for all platforms
    -Current        Build for current platform only (default)
    -Test           Run tests only
    -Format         Check formatting only
    -NoTest         Skip tests
    -NoClean        Don't clean build directory
    -Help           Show this help message

Examples:
    .\build-local.ps1                # Build for current platform with tests
    .\build-local.ps1 -All           # Build for all platforms
    .\build-local.ps1 -Test          # Run tests only
    .\build-local.ps1 -NoTest -Current # Build current platform without tests

"@
}

# Main execution
function Main {
    if ($Help) {
        Show-Help
        return
    }
    
    # Default to current platform build
    if (-not $All -and -not $Current -and -not $Test -and -not $Format) {
        $Current = $true
    }
    
    Write-Info "Starting local build process..."
    
    # Check prerequisites
    Test-GoVersion
    
    # Format check only
    if ($Format) {
        Test-Formatting
        Write-Info "Code formatting check completed"
        return
    }
    
    # Test only
    if ($Test) {
        Get-Dependencies
        Invoke-Tests
        Invoke-Vet
        Test-Formatting
        Write-Info "Tests completed successfully"
        return
    }
    
    # Full build process
    Get-Dependencies
    
    if (-not $NoTest) {
        Invoke-Tests
        Invoke-Vet
        Test-Formatting
    }
    
    if (-not $NoClean) {
        Clear-Build
    }
    
    if ($All) {
        Build-AllPlatforms
    } elseif ($Current) {
        if (Build-CurrentPlatform) {
            Test-Binary
        }
    }
    
    Write-Info "Build process completed successfully!"
    Write-Info "Build artifacts:"
    if (Test-Path $BUILD_DIR) {
        Get-ChildItem $BUILD_DIR | Select-Object Name, Length, LastWriteTime
    }
}

# Run main function
Main 