# GitHub Actions 工作流说明

本项目包含三个 GitHub Actions 工作流，用于不同的构建和发布场景。

## 工作流概览

### 1. CI (Continuous Integration) - `.github/workflows/ci.yml`

**触发条件：**
- 推送到 `main` 或 `develop` 分支
- 针对 `main` 分支的 Pull Request

**功能：**
- 运行单元测试
- 代码格式检查
- Go vet 静态分析
- 快速构建验证

**用途：** 日常开发中的代码质量检查，确保每次提交都能通过基本测试。

### 2. Build and Release - `.github/workflows/build.yml`

**触发条件：**
- 推送标签 `v*.*.*` (如 v1.0.0, v1.2.3)
- 推送到 `main` 或 `develop` 分支
- 针对 `main` 分支的 Pull Request

**功能：**
- 多平台构建 (Linux, Windows, macOS)
- 自动发布到 GitHub Releases
- 创建分发包
- 包含 MinGW 交叉编译的 Windows 版本

**支持平台：**
- Linux x86_64
- Windows x86_64 (标准构建)
- Windows x86_64 (MinGW 交叉编译)
- macOS x86_64
- macOS ARM64 (Apple Silicon)

### 3. Custom Frida Build - `.github/workflows/build-with-frida-core.yml`

**触发条件：**
- 推送标签 `v*.*.*-frida` (如 v1.0.0-frida)
- 手动触发 (workflow_dispatch)

**功能：**
- 从源码构建自定义 frida-core devkit
- 将自定义 frida-core 集成到 Go 项目中
- 创建增强版本的可执行文件
- 专门的测试和验证流程

**特殊用途：** 用于需要特定 Frida 版本或自定义 Frida 功能的场景。

## 使用指南

### 日常开发

1. **提交代码**：直接推送到 `develop` 分支，CI 工作流会自动运行
2. **Pull Request**：创建 PR 到 `main` 分支，会触发完整的测试流程

### 发布版本

#### 标准发布

```bash
# 创建并推送标签
git tag v1.0.0
git push origin v1.0.0
```

这会触发 `build.yml` 工作流，自动创建 GitHub Release 并上传所有平台的构建文件。

#### 自定义 Frida 发布

```bash
# 创建带 -frida 后缀的标签
git tag v1.0.0-frida
git push origin v1.0.0-frida
```

这会触发 `build-with-frida-core.yml` 工作流，构建包含自定义 frida-core 的版本。

### 手动触发自定义 Frida 构建

1. 访问 GitHub 仓库的 Actions 页面
2. 选择 "Build with Custom Frida-Core DevKit" 工作流
3. 点击 "Run workflow"
4. 可选择指定 Frida 版本（默认使用 main 分支）

## 构建产物

### 标准构建产物

- `wechat-devtools-linux-amd64`
- `wechat-devtools-windows-amd64.exe`
- `wechat-devtools-windows-mingw-amd64.exe`
- `wechat-devtools-darwin-amd64`
- `wechat-devtools-darwin-arm64`

### 自定义 Frida 构建产物

- `wechat-devtools-linux-amd64-custom-frida`
- `wechat-devtools-windows-amd64-custom-frida`
- `README-CUSTOM-FRIDA.md` (使用说明)

## 环境变量和配置

### 必需的 GitHub Secrets

- `GITHUB_TOKEN`：自动提供，用于创建 Release

### 可配置的环境变量

在工作流文件中可以修改：

```yaml
env:
  GO_VERSION: '1.21'        # Go 版本
  BINARY_NAME: 'wechat-devtools'  # 二进制文件名
```

## 故障排除

### 常见问题

1. **构建失败**
   - 检查 Go 版本兼容性
   - 确认依赖项是否正确

2. **发布失败**
   - 确认标签格式正确
   - 检查 GitHub Token 权限

3. **自定义 Frida 构建失败**
   - 通常是由于 frida-core 编译问题
   - 检查构建日志中的具体错误信息

### 调试技巧

1. **查看详细日志**：在 GitHub Actions 页面查看每个步骤的详细输出
2. **本地测试**：使用 `act` 工具在本地运行 GitHub Actions
3. **分步骤验证**：可以注释掉部分步骤来定位问题

## 自定义工作流

### 添加新平台支持

在 `build.yml` 的 matrix 中添加新的平台配置：

```yaml
- os: ubuntu-latest
  goos: freebsd
  goarch: amd64
  suffix: ''
```

### 修改构建选项

调整 `go build` 命令的参数：

```yaml
go build -ldflags "-s -w -X main.version=${{ github.ref_name }}" -o ...
```

### 添加额外测试

在相应的工作流中添加新的测试步骤：

```yaml
- name: Integration tests
  run: go test -tags=integration ./...
```

## 最佳实践

1. **版本标签**：使用语义化版本控制 (semver)
2. **分支策略**：`main` 用于稳定版本，`develop` 用于开发
3. **测试覆盖**：确保所有重要功能都有测试
4. **文档更新**：发布时同时更新 README 和 CHANGELOG

## 相关文档

- [GitHub Actions 官方文档](https://docs.github.com/en/actions)
- [Go 交叉编译指南](https://golang.org/doc/install/source#environment)
- [Frida 构建文档](https://frida.re/docs/building/) 