from PIL import Image, ImageFont, ImageDraw
import string
import random


def generate_captcha_image(text):
    width, height = 150, 50
    image = Image.new("RGB", (width, height), (255, 255, 255))
    font = ImageFont.load_default(40)
    draw = ImageDraw.Draw(image)
    draw.text((18, 0), " ".join(text), font=font, fill=(0, 0, 0))
    image.save("captcha_image.png")
    image.show()


def generate_random_text(length=4):
    characters = string.ascii_letters + string.digits
    text = "".join(random.choice(characters) for _ in range(length))
    return text


generate_captcha_image(generate_random_text(4))
