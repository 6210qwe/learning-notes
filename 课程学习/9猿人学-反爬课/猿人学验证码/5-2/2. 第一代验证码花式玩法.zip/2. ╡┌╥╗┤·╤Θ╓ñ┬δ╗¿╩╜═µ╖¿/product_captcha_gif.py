from PIL import Image, ImageFont, ImageDraw, ImageFilter
import string
import random


def generate_captcha_image(text):
    width, height = 150, 50
    image = Image.new("RGB", (width, height), (255, 255, 255))
    font = ImageFont.load_default(40)
    draw = ImageDraw.Draw(image)
    draw.text((18, 0), " ".join(text), font=font, fill=(0, 0, 0))

    for _ in range(10):
        x1, y1 = random.randint(0, width), random.randint(0, height)
        x2, y2 = random.randint(0, width), random.randint(0, height)
        draw.line([(x1, y1), (x2, y2)], fill=(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
    return image


def generate_random_text(length=4):
    characters = string.ascii_letters + string.digits
    text = "".join(random.choice(characters) for _ in range(length))
    return text

frames = []

for i in range(random.randint(5, 10)):
    _img = generate_captcha_image(generate_random_text(4))
    _img = _img.filter(ImageFilter.GaussianBlur(radius=random.randint(2, 10)))
    frames.append(_img)

captcha_img = generate_captcha_image(generate_random_text(4))

insert_position = random.randint(0, len(frames))
frames[insert_position:insert_position] = [captcha_img, captcha_img, captcha_img]


frames[0].save(
    "result.gif", save_all=True, append_images=frames[1:], duration=100, loop=0
)
