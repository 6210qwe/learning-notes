import cv2
import numpy as np


def crop_to_mask_shape(mask_image_path, target_image_path, offset_x, offset_y):
    """
    根据灰度遮罩（mask_image_path），在目标图像（target_image_path）上
    截取并保留遮罩形状的部分，并将其返回为 PNG 格式的 bytes。
    额外增加了在抠图边缘绘制一条灰色半透明的轮廓线。
    """
    # 1. 读取灰度遮罩图
    mask_gray = cv2.imread(mask_image_path, cv2.IMREAD_GRAYSCALE)
    if mask_gray is None:
        raise ValueError(f"Failed to read the mask image at {mask_image_path}")

    # 2. 二值化处理 (阈值 127)
    _, mask_binary = cv2.threshold(mask_gray, 127, 255, cv2.THRESH_BINARY)

    # 获取遮罩尺寸
    mask_h, mask_w = mask_binary.shape
    print(mask_h, mask_w)

    # 3. 读取目标图像
    target_image = cv2.imread(target_image_path, cv2.IMREAD_UNCHANGED)
    if target_image is None:
        raise ValueError(f"Failed to read the target image at {target_image_path}")

    # 如果目标图像只有 3 通道 (BGR)，则添加一个透明通道 (BGRA)
    if target_image.shape[2] == 3:
        target_image = cv2.cvtColor(target_image, cv2.COLOR_BGR2BGRA)

    # 4. 检查裁剪范围是否合法
    target_h, target_w = target_image.shape[:2]

    if (offset_x < 0 or offset_y < 0 or
            offset_x + mask_w > target_w or
            offset_y + mask_h > target_h):
        raise ValueError(
            f"The specified offset ({offset_x}, {offset_y}) "
            f"plus mask size ({mask_w}x{mask_h}) exceeds the target image boundary ({target_w}x{target_h})."
        )

    # 5. 从目标图像中裁剪指定区域
    cropped_region = target_image[offset_y:offset_y + mask_h, offset_x:offset_x + mask_w]

    # 6. 创建空白（全零）区域，用作结果区域，大小与裁剪区域相同
    # 形状 (mask_h, mask_w, 4)
    result_region = np.zeros_like(cropped_region, dtype=np.uint8)

    # 7. 将裁剪区域按遮罩“抠图”到结果区域
    for channel_idx in range(3):  # B, G, R 通道
        result_region[:, :, channel_idx] = cv2.bitwise_and(
            cropped_region[:, :, channel_idx],
            cropped_region[:, :, channel_idx],
            mask=mask_binary
        )
    # alpha 通道直接设置为遮罩的二值结果
    result_region[:, :, 3] = mask_binary

    # 8. 给抠图边缘增加灰色半透明轮廓
    # 8.1 对遮罩进行一次膨胀，获取外扩像素
    kernel = np.ones((3, 3), dtype=np.uint8)
    mask_dilated = cv2.dilate(mask_binary, kernel, iterations=2) # 膨胀系数，可以理解为边缘的宽度

    # 8.2 边缘 = 膨胀后 - 原二值掩膜
    #    这样只保留抠图外圈 1px 的区域
    boundary = cv2.bitwise_and(mask_dilated, cv2.bitwise_not(mask_binary))

    # 8.3 在边缘像素上画半透明线
    #    例如灰色 (128,128,128) + alpha=128
    outline_color = (128, 128, 128, 128)  # BGRA
    boundary_idx = np.where(boundary > 0)  # (y坐标数组, x坐标数组)
    result_region[boundary_idx[0], boundary_idx[1], :] = outline_color

    cv2.imwrite("output.png", result_region)
    # 9. 将最终图像编码为 PNG 格式的 bytes 并返回
    success, encoded_buffer = cv2.imencode(".png", result_region)
    if not success:
        raise ValueError("Failed to encode image into .png format.")

    # 转换为 bytes
    image_bytes = encoded_buffer.tobytes()
    return image_bytes


def crop_to_rgba_overlay(rgba_image_path, target_image_path, offset_x, offset_y):
    """
    读取一个带透明通道（RGBA）的图像（rgba_image_path），并将其混合叠加
    到目标图像（target_image_path）的指定位置，返回 PNG 格式的 bytes。
    """
    # 1. 读取带透明通道的图像，如果没有透明通道则添加
    rgba_image = cv2.imread(rgba_image_path, cv2.IMREAD_UNCHANGED)
    if rgba_image is None:
        raise ValueError(f"Failed to read the RGBA image at {rgba_image_path}")

    if rgba_image.shape[2] == 3:  # 如果没有 alpha 通道，就手动添加一层
        alpha_channel = np.full(rgba_image.shape[:2], 255, dtype=np.uint8)
        rgba_image = np.dstack((rgba_image, alpha_channel))

    # 2. 获取 RGBA 图像尺寸
    rgba_h, rgba_w = rgba_image.shape[:2]

    # 3. 读取目标图像，如果没有透明通道则添加
    target_image = cv2.imread(target_image_path, cv2.IMREAD_UNCHANGED)
    if target_image is None:
        raise ValueError(f"Failed to read the target image at {target_image_path}")

    if target_image.shape[2] == 3:
        target_image = cv2.cvtColor(target_image, cv2.COLOR_BGR2BGRA)

    # 4. 检查粘贴范围是否合法
    target_h, target_w = target_image.shape[:2]
    if (offset_x < 0 or offset_y < 0 or
            offset_x + rgba_w > target_w or
            offset_y + rgba_h > target_h):
        raise ValueError(
            f"The specified offset ({offset_x}, {offset_y}) "
            f"plus RGBA image size ({rgba_w}x{rgba_h}) exceeds the target image boundary ({target_w}x{target_h})."
        )

    # 5. 复制目标图像以便后续操作（避免直接修改原图）
    result_image = target_image.copy()

    # 6. 获取目标图像上需要被更新的区域 (ROI)
    roi = result_image[offset_y:offset_y + rgba_h, offset_x:offset_x + rgba_w]

    # 7. 计算混合权重（alpha 通道归一化到 0~1）
    alpha_rgba = rgba_image[:, :, 3] / 255.0  # RGBA 图像的 alpha 通道
    # 8. 对 B、G、R 通道进行混合（alpha 混合公式）
    for c in range(3):
        roi[:, :, c] = (alpha_rgba * rgba_image[:, :, c] +
                        (1 - alpha_rgba) * roi[:, :, c]).astype(np.uint8)
    # 更新目标图像的 alpha 通道
    roi[:, :, 3] = (alpha_rgba * 255 +
                    (1 - alpha_rgba) * roi[:, :, 3]).astype(np.uint8)


    # 9. 将最终结果编码为 PNG bytes 并返回
    cv2.imwrite("output2.png", result_image)
    success, encoded_buffer = cv2.imencode(".png", result_image)
    if not success:
        raise ValueError("Failed to encode image into .png format.")

    image_bytes = encoded_buffer.tobytes()
    return image_bytes


if __name__ == "__main__":
    # 使用示例
    mask_image_path = 'gap_resize.png'       # 灰度遮罩图片路径
    target_image_path = 'input.jpg'   # 目标图像

    offset_x, offset_y = 500, 200

    # 1. 根据灰度遮罩抠图，并在边缘添加一条灰色半透明描边
    masked_bytes = crop_to_mask_shape(
        mask_image_path,
        target_image_path,
        offset_x,
        offset_y
    )
    print("Masked image with outline (bytes length):", len(masked_bytes))

    # 2. 将带透明通道的图像叠加到目标图像
    overlay_bytes = crop_to_rgba_overlay(
        mask_image_path,
        target_image_path,
        offset_x,
        offset_y
    )
    print("Overlay image (bytes length):", len(overlay_bytes))


