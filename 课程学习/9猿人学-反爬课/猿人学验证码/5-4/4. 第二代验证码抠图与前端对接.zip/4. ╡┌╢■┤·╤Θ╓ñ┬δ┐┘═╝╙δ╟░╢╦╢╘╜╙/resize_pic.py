from PIL import Image

img = Image.open('gap.png')
img = img.resize((120, 100))

img.save("gap_resize.png")