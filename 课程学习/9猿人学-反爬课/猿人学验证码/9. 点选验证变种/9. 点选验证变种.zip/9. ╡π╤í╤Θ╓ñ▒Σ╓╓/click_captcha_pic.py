import random
import io
from PIL import Image
import os
import draw_pic

def add_images_to_image(background_img, overlay_path, num_images=4, base_size=24, max_rotation=75):
    """
    在背景图片上随机粘贴旋转的透明PNG图像

    参数：
    background_img: PIL.Image对象，背景图片
    overlay_path: str, 叠加图像的目录
    num_images: int, 要粘贴的图像数量
    base_size: int, 叠加图像的基础尺寸
    max_rotation: int, 最大旋转角度（度数）

    返回：
    bytes: 生成图片的字节流
    list: 图像位置信息
    """
    background = background_img.copy()

    positions = []
    num = 0

    for file_name in random.sample(os.listdir(overlay_path), num_images):

        try:
            overlay = Image.open(overlay_path + "/" + file_name).convert("RGBA")
        except FileNotFoundError:
            raise FileNotFoundError(f"叠加图像文件不存在于路径：{overlay_path + '/' + file_name}")

        # 调整基础尺寸
        overlay = overlay.resize((base_size, base_size))

        # 生成随机旋转角度
        rotation = random.randint(-max_rotation, max_rotation)

        # 旋转图像并保持透明度
        rotated_overlay = overlay.rotate(rotation, expand=True, fillcolor=(0, 0, 0, 0))
        r_width, r_height = rotated_overlay.size

        # 计算有效粘贴区域
        x_max = max(0, background.width - r_width)
        y_max = max(0, background.height - r_height)

        if x_max == 0 or y_max == 0:
            break  # 如果图片太小无法粘贴则跳过

        # 生成随机位置
        x = random.randint(0 + 60 * num, 300 - 24 - 60 * (4 - num))
        y = random.randint(0, 184 - 40)
        num += 1

        # 粘贴图像到背景
        background.paste(rotated_overlay, (x, y), rotated_overlay)

        positions.append({
            "x": x,
            "y": y,
            "rotation": rotation,
            "width": r_width,
            "height": r_height,
            "file_name": file_name,
        })

    # 生成返回字节流
    img_byte_arr = io.BytesIO()
    background.save(img_byte_arr, format='PNG')
    return img_byte_arr.getvalue(), positions


# 示例用法
if __name__ == "__main__":
    # 加载背景图片

    draw_pic.product_pic()
    background = Image.open("input.jpg")
    resized_bg = background.resize((300, 184), Image.Resampling.LANCZOS)

    # 添加叠加图像
    image_bytes, positions = add_images_to_image(
        background_img=resized_bg,
        overlay_path="./png",
        num_images=4,
        base_size=32,
        max_rotation=45
    )
    print(image_bytes, positions)


    # 保存结果
    with open("output.png", "wb") as f:
        f.write(image_bytes)
