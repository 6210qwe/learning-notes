from PIL import Image, ImageDraw, ImageFilter
import math
import random
import numpy as np

SIZE = 48
CENTER = (SIZE // 2 - 0.5, SIZE // 2 - 0.5)  # 精确中心点
ALPHA = 200  # 半透明程度（0-255）
BG_COLOR = (255, 255, 255, 0)  # 透明背景
PATH = "./png"


def adjust_alpha(color):
    """为颜色添加统一透明度"""
    if len(color) == 3:
        return color + (ALPHA,)
    return color[:3] + (ALPHA,)


def create_3d_circle():
    """精确居中的半透明圆形"""
    img = Image.new('RGBA', (SIZE, SIZE), BG_COLOR)

    # 添加透明度渐变
    mask = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    draw_mask = ImageDraw.Draw(mask)
    r = random.randint(50, 150)
    g = random.randint(50, 150)
    b = random.randint(50, 150)

    for y in range(SIZE):
        for x in range(SIZE):
            dx = x - CENTER[0]
            dy = y - CENTER[1]
            dist = math.sqrt(dx ** 2 + dy ** 2)
            alpha = max(0, ALPHA - int(dist * ALPHA / (SIZE / 2)))
            draw_mask.point((x, y), fill=(r, g, b, alpha))

    img.alpha_composite(mask)
    return img


def create_glossy_star():
    """修正位置的五角星"""
    base_color = adjust_alpha((random.randint(50, 150), random.randint(50, 150), random.randint(50, 150)))
    img = Image.new('RGBA', (SIZE, SIZE), BG_COLOR)
    draw = ImageDraw.Draw(img)

    # 修正的星形坐标计算
    def get_point(angle, r):
        return (
            CENTER[0] + r * math.cos(math.radians(angle)),
            CENTER[1] + r * math.sin(math.radians(angle))
        )

    coordinates = []
    outer_r = SIZE // 2 - 4
    inner_r = outer_r * 0.4
    for i in range(5):
        # 外点
        angle = 90 + i * 72
        coordinates.append(get_point(angle, outer_r))
        # 内点
        coordinates.append(get_point(angle + 36, inner_r))

    # 绘制星形
    draw.polygon(coordinates, fill=base_color)

    # 添加透明度渐变
    mask = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    draw_mask = ImageDraw.Draw(mask)
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)

    for y in range(SIZE):
        for x in range(SIZE):
            dx = x - CENTER[0]
            dy = y - CENTER[1]
            dist = math.sqrt(dx ** 2 + dy ** 2)
            alpha = max(0, ALPHA - int(dist * ALPHA / (SIZE / 2)))
            draw_mask.point((x, y), fill=(r, g, b, alpha))

    img.alpha_composite(mask)
    return img


def apply_global_transparency(img):
    """应用全局透明度"""
    alpha = img.split()[3]
    alpha = alpha.point(lambda p: min(p, ALPHA))
    img.putalpha(alpha)
    return img


def create_glossy_diamond():
    """修正位置的菱形（四角星）"""
    base_color = adjust_alpha((random.randint(50, 150), random.randint(50, 150), random.randint(50, 150)))
    img = Image.new('RGBA', (SIZE, SIZE), BG_COLOR)
    draw = ImageDraw.Draw(img)

    # 星形坐标计算
    def get_point(angle, r):
        return (
            CENTER[0] + r * math.cos(math.radians(angle)),
            CENTER[1] + r * math.sin(math.radians(angle))
        )

    coordinates = []
    outer_r = SIZE // 2 - 4
    inner_r = outer_r * 0.4
    for i in range(4):
        # 外点（90度间隔）
        angle = 90 + i * 90
        coordinates.append(get_point(angle, outer_r))
        # 内点（在外点基础上偏移45度）
        coordinates.append(get_point(angle + 45, inner_r))

    # 绘制星形
    draw.polygon(coordinates, fill=base_color)

    # 添加透明度渐变
    mask = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    draw_mask = ImageDraw.Draw(mask)

    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)

    for y in range(SIZE):
        for x in range(SIZE):
            dx = x - CENTER[0]
            dy = y - CENTER[1]
            dist = math.sqrt(dx ** 2 + dy ** 2)
            alpha = max(0, ALPHA - int(dist * ALPHA / (SIZE / 2)))
            draw_mask.point((x, y), fill=(r, g, b, alpha))

    img.alpha_composite(mask)
    return img


def create_glossy_gear():
    """带锯齿边缘的机械齿轮"""
    base_color = adjust_alpha((random.randint(50, 150), random.randint(50, 150), random.randint(50, 150)))
    img = Image.new('RGBA', (SIZE, SIZE), BG_COLOR)
    draw = ImageDraw.Draw(img)

    def get_point(angle, r):
        return (
            CENTER[0] + r * math.cos(math.radians(angle)),
            CENTER[1] + r * math.sin(math.radians(angle))
        )

    coordinates = []
    outer_r = SIZE // 2 - 8
    inner_r = outer_r * 0.6
    teeth = 12  # 齿数

    for i in range(teeth):
        # 外齿尖
        angle = i * (360 / teeth)
        coordinates.append(get_point(angle, outer_r))
        # 内凹点
        coordinates.append(get_point(angle + 180 / teeth, inner_r))

    # 绘制闭合路径
    draw.polygon(coordinates, fill=base_color)

    # 相同透明渐变处理
    mask = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    draw_mask = ImageDraw.Draw(mask)
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    for y in range(SIZE):
        for x in range(SIZE):
            dx = x - CENTER[0]
            dy = y - CENTER[1]
            dist = math.sqrt(dx ** 2 + dy ** 2)
            alpha = max(0, ALPHA - int(dist * ALPHA / (SIZE / 2)))
            draw_mask.point((x, y), fill=(r, g, b, alpha))

    img.alpha_composite(mask)
    return img


def create_glossy_cross():
    """带旋转扭曲效果的十字星"""
    base_color = adjust_alpha((random.randint(50, 150), random.randint(50, 150), random.randint(50, 150)))
    img = Image.new('RGBA', (SIZE, SIZE), BG_COLOR)
    draw = ImageDraw.Draw(img)

    def get_point(angle, r):
        twist = 15 * math.sin(math.radians(angle * 2))  # 添加正弦扭曲
        return (
            CENTER[0] + r * math.cos(math.radians(angle + twist)),
            CENTER[1] + r * math.sin(math.radians(angle + twist))
        )

    coordinates = []
    outer_r = SIZE // 2 - 6
    inner_r = outer_r * 0.3

    for i in range(8):  # 双十字结构
        angle = i * 45
        coordinates.append(get_point(angle, outer_r))
        coordinates.append(get_point(angle + 22.5, inner_r))

    draw.polygon(coordinates, fill=base_color)

    # 透明渐变复用
    mask = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    draw_mask = ImageDraw.Draw(mask)
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    for y in range(SIZE):
        for x in range(SIZE):
            dx = x - CENTER[0]
            dy = y - CENTER[1]
            dist = math.sqrt(dx ** 2 + dy ** 2)
            alpha = max(0, ALPHA - int(dist * ALPHA / (SIZE / 2)))
            draw_mask.point((x, y), fill=(r, g, b, alpha))

    img.alpha_composite(mask)
    return img


def create_glossy_snowflake():
    """科赫雪花变体图案"""
    base_color = adjust_alpha((random.randint(50, 150), random.randint(50, 150), random.randint(50, 150)))
    img = Image.new('RGBA', (SIZE, SIZE), BG_COLOR)
    draw = ImageDraw.Draw(img)

    def fractal_point(angle, r, depth):
        if depth == 0:
            return get_point(angle, r)
        # 分形递归计算
        new_r = r * 0.6
        return [
            fractal_point(angle - 30, new_r, depth - 1),
            get_point(angle, r),
            fractal_point(angle + 30, new_r, depth - 1)
        ]

    def get_point(angle, r):
        return (
            CENTER[0] + r * math.cos(math.radians(angle)),
            CENTER[1] + r * math.sin(math.radians(angle))
        )

    coordinates = []
    base_r = SIZE // 2 - 10
    for angle in range(0, 360, 60):  # 六边形基础
        # 生成三级分形
        coords = fractal_point(angle, base_r, 2)
        coordinates.extend([item for sublist in coords for item in sublist])

    draw.polygon(coordinates, fill=base_color)

    # 透明渐变
    mask = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    draw_mask = ImageDraw.Draw(mask)
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    for y in range(SIZE):
        for x in range(SIZE):
            dx = x - CENTER[0]
            dy = y - CENTER[1]
            dist = math.sqrt(dx ** 2 + dy ** 2)
            alpha = max(0, ALPHA - int(dist * ALPHA / (SIZE / 2)))
            draw_mask.point((x, y), fill=(r, g, b, alpha))

    img.alpha_composite(mask)
    return img

def product_pic():
    shapes = {
        "circle": apply_global_transparency(create_3d_circle()),
        "star": apply_global_transparency(create_glossy_star()),
        "diamond": apply_global_transparency(create_glossy_diamond()),
        "gear": apply_global_transparency(create_glossy_gear()),
        "cross": apply_global_transparency(create_glossy_cross()),
        "spider": apply_global_transparency(create_glossy_snowflake()),
    }

    for name, image in shapes.items():
        image.save(f"{PATH}/{name}.png", "PNG", optimize=True)
        print(f"已生成修正版：{name}.png")
