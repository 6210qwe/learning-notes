# 以贝塞尔曲线绘制验证码为例
import numpy as np
from PIL import Image, ImageDraw
import random

# 定义计算三次贝塞尔曲线上一点的函数
def cubic_bezier_point(t, p0, p1, p2, p3):
    """
    计算三次贝塞尔曲线上 t 对应的点
    参数:
        t: 参数值，取值范围 [0, 1]
        p0, p1, p2, p3: 控制点 (x, y)
    返回:
        计算得到的点 (x, y)
    """
    t1 = (1 - t)
    point = (t1**3 * np.array(p0) +
             3 * t1**2 * t * np.array(p1) +
             3 * t1 * t**2 * np.array(p2) +
             t**3 * np.array(p3))
    return tuple(point)

# 采样生成贝塞尔曲线上的一系列点
def generate_bezier_curve(p0, p1, p2, p3, num_points=100):
    """
    生成一个三次贝塞尔曲线的采样点列表
    参数:
        p0, p1, p2, p3: 控制点 (x, y)
        num_points: 采样点数量，决定曲线的平滑度
    返回:
        [(x1, y1), (x2, y2), ...]
    """
    points = []
    for i in range(num_points + 1):
        t = i / num_points
        points.append(cubic_bezier_point(t, p0, p1, p2, p3))
    return points



img = Image.open("input.jpg").convert("RGBA").resize((300, 184))

overlay = Image.new("RGBA", img.size, (255, 255, 255, 0))
draw = ImageDraw.Draw(overlay)

width, height = img.size

p0 = (random.randint(10, int(width/4)), random.randint(10, int(height/4)))  # 起点
p1 = (random.randint(0, width), random.randint(0, height))   # 控制点
p2 = (random.randint(0, width), random.randint(0, height))   # 控制点
p3 = (random.randint(int(width * 3 / 4), width - 10), random.randint(int(height * 3 / 4), height - 10))   # 终点

num_points = 50  # 贝塞尔曲线的点数
bezier_point = generate_bezier_curve(p0, p1, p2, p3, num_points=num_points)
print(bezier_point)

curve_color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255), 50)
draw.line(bezier_point, fill=curve_color, width=10, joint="curve")
result = Image.alpha_composite(img, overlay)

result.save("out_put.png")

