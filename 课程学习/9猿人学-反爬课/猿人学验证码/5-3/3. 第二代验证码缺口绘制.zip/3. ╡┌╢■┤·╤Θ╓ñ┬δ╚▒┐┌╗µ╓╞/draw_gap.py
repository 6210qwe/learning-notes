

import matplotlib
import matplotlib.pyplot as plt

from matplotlib.path import Path
from matplotlib.patches import PathPatch

matplotlib.use("Agg")


x = 2
y = 4

path_data = [
    (Path.MOVETO, (x, y)),
    # (Path.LINETO, (x+1, y)),  # 向右
    (Path.LINETO, (x+0.4, y)),

    (Path.CURVE3, (x+0.5, y - 0.2)),
    (Path.CURVE3, (x+0.6, y)),

    (Path.LINETO, (x+1, y)),# 向右

    (Path.LINETO, (x+1, y - 0.4)),

    (Path.CURVE3, (x+1 + 0.2, y - 0.5)),
    (Path.CURVE3, (x+1, y - 0.6)),

    (Path.LINETO, (x+1, y-1)),
    (Path.LINETO, (x, y-1)),
    (Path.CLOSEPOLY, (x, y))
]

codes, verts = zip(*path_data)

path = Path(verts, codes)
patch = PathPatch(path, facecolor="gray", edgecolor=None, alpha=0.6, lw=0)


fig, ax = plt.subplots(figsize=(4, 4))

ax.set_xlim(2, 3.2)
ax.set_ylim(3, 4)
ax.add_patch(patch)

ax.set_aspect('equal')

plt.axis("off")

# plt.show()
plt.savefig("gap.png", dpi=300, bbox_inches="tight", transparent=True)
plt.close()









