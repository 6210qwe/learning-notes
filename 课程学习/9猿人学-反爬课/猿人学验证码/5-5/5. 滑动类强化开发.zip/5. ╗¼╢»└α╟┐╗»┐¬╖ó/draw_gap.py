import matplotlib
import matplotlib.pyplot as plt
import random

from matplotlib.path import Path
from matplotlib.patches import PathPatch
from io import BytesIO

matplotlib.use("Agg")

def generate_random_gap():

    def generate_random_path_data(x_range, y_range, num_points):
        """
        生成随机路径数据。

        参数:
        - x_range: (float, float) x 轴的范围
        - y_range: (float, float) y 轴的范围
        - num_points: int 路径上的点数

        返回:
        - list: 随机路径数据
        """
        path_data = []
        x_start = random.uniform(*x_range)
        y_start = random.uniform(*y_range)

        # 起始点
        path_data.append((Path.MOVETO, (x_start, y_start)))

        for _ in range(num_points):
            x_next = random.uniform(*x_range)
            y_next = random.uniform(*y_range)

            # 随机选择是直线还是曲线
            if random.choice([True, False]):
                path_data.append((Path.LINETO, (x_next, y_next)))
            else:
                control_x = random.uniform(*x_range)
                control_y = random.uniform(*y_range)
                path_data.append((Path.CURVE3, (control_x, control_y)))
                path_data.append((Path.CURVE3, (x_next, y_next)))

        # 闭合路径
        path_data.append((Path.CLOSEPOLY, path_data[0][1]))
        return path_data


    # 配置参数
    x_range = (0, 1.2)  # 确保路径在 120 像素宽的比例内
    y_range = (0, 1.0)  # 确保路径在 100 像素高的比例内
    num_points = 10

    # 生成随机路径
    path_data = generate_random_path_data(x_range, y_range, num_points)

    # 绘制路径
    codes, verts = zip(*path_data)
    path = Path(verts, codes)
    patch = PathPatch(path, facecolor="gray", edgecolor=None, alpha=0.6, lw=0)

    # 设置画布大小为 120 × 100 像素
    fig_width_inches = 120 / 100  # 转换为英寸
    fig_height_inches = 100 / 100

    fig, ax = plt.subplots(figsize=(fig_width_inches, fig_height_inches), dpi=100)

    ax.set_xlim(0, 1.2)  # 与路径生成的 x_range 一致
    ax.set_ylim(0, 1.0)  # 与路径生成的 y_range 一致
    ax.add_patch(patch)

    ax.set_aspect('equal')
    plt.axis("off")

    img_bytes = BytesIO()
    plt.savefig(img_bytes, format='png')  # 将图像保存为 PNG 格式
    img_bytes.seek(0)  # 将指针移动到开始位置

    # 保存为图像
    plt.savefig(img_bytes, dpi=100, bbox_inches="tight", transparent=True)
    plt.close()

    return img_bytes.getvalue()




