import random


def bezier_curve(start_point, control_point, end_point):
    x_values = [i for i in range(261)]

    curve_points = []

    for x in x_values:
        t = x / 260
        y = (1 - t) ** 2 * start_point[1] + 2 * (1 - t) * t * control_point[1] + t ** 2 * end_point[1]
        curve_points.append((x, y))

    return curve_points


# Example usage
# start = (0, random.randint(0, 184))
# control = (random.randint(0, 300), random.randint(0, 184))
# end = (300, random.randint(0, 184))


start=(0,96)
control=(31,169)
end=(300,55)

points = bezier_curve(start, control, end)

print(start)
print(control)
print(end)
print(points)

for i in points:
    print(i[0], i[1])
# print(random.choice(points[20: 80]))

