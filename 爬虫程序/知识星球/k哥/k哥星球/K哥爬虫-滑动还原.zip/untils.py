import cv2
import numpy as np
import os

# -*- coding: utf-8 -*-

def process_image(image_bytes, direction, point):

    img = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), cv2.IMREAD_COLOR)

    height, width, _ = img.shape

    if direction == "down":
        split_size = -int(point)
    else:
        split_size = int(point)

    img_up = img[0:split_size, :]
    img_down = img[split_size:, :]

    if direction == "down":
        move_img = img_down.copy()
    else:
        move_img = img_up.copy()

    result = np.zeros((height, width, 3), dtype=np.uint8)
    min_diff = 1999999999999
    min_i = 0

    for i in range(width):
        shifted_img = np.roll(move_img, i * 1, axis=1)
        if direction == "down":
            result[:split_size, :] = img_up
            result[split_size:, :] = shifted_img
        else:
            result[:split_size, :] = shifted_img
            result[split_size:, :] = img_down

        gray = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)

        row1 = split_size
        row2 = split_size - 1

        pixels1 = gray[row1, :]
        pixels2 = gray[row2, :]
        diff = cv2.absdiff(pixels1, pixels2)

        if diff.sum() < min_diff:
            min_diff = diff.sum()
            min_i = i

    shifted_img = np.roll(move_img, min_i, axis=1)

    if direction == "down":
        result[:split_size, :] = img_up
        result[split_size:, :] = shifted_img
    else:
        result[:split_size, :] = shifted_img
        result[split_size:, :] = img_down

    print("Here is the desired result")
    print(min_i)

    # Display the image
    cv2.imshow("K", result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Save the result image to a specified folder
    save_folder = "output"
    os.makedirs(save_folder, exist_ok=True)
    image_path = os.path.join(save_folder, "result_image.png")
    cv2.imwrite(image_path, result)

    return result

