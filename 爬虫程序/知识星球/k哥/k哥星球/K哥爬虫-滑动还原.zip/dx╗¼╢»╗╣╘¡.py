from PIL import Image
import requests
from io import BytesIO
from untils import process_image
# 下载webp图像
import requests

for i  in range(1):
  url = 'https://cap.dingxiang-inc.com/api/a'

  headers = {
    "Accept": "*/*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-US;q=0.7",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Origin": "https://www.dingxiang-inc.com",
    "Pragma": "no-cache",
    "Referer": "https://www.dingxiang-inc.com/",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "sec-ch-ua-mobile": "?0"
  }

  params = {
    "w": "380",
    "h": "165",
    "s": "50",
    "ak": "baec4437098fa80aa3cd23259a49166b",
    "c": "65c4c3bdZ0LZKNwfpPJKOqYoHInox5tJ3RcmAHH1",
    "jsv": "5.1.47",
    "aid": "dx-1707394072700-88942028-4",
    "wp": "1",
    "de": "0",
    "uid": "",
    "lf": "0",
    "tpc": "",
    "cid": "06842206",
    "_r": "0.16763726014025582"
  }

  # 发送GET请求
  response = requests.get(url, headers=headers, params=params).json()
  print(response)
  url = "https://static.dingxiang-inc.com/picture" + response["p1"]
  direction = "top" if response["speed1"] != "" else "down"
  splite=response["y"]
  response = requests.get(url)

  #这里将图像转为png  保存到本地，  方便观察
  webp_image = Image.open(BytesIO(response.content))
  webp_image.save("demo.png", "PNG")

  #这里将拿到的字节集图片  与对应的图像信息 传入下面函数进行图像还原

  process_image(response.content,direction,splite)



