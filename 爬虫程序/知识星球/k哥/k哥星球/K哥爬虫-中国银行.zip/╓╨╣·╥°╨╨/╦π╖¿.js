window = {
    outerHeight: 1040,
    innerHeight: 953,
    outerWidth: 1920,
    innerWidth: 1920,
};

var ua = '';
var _ua = "";
var _sa = [];
var _ca = [];
var tm = Date.now();
// var tm = 1727666024448;
var counters = {
    "sa": 0,
    "mm": 0,
    "md": 0,
    "kd": 0,
    "fo": 0,
    "tc": 0,
    "tmv": 0,
    "mmInterval": 0,
    "tmvInterval": 0
};
option = {
    "token": "arg1", // 需要替换
    "form": "",
    "inputName": "ua",
    "maxMDLog": 10,
    "maxMMLog": 20,
    "maxSALog": 250,
    "maxKDLog": 10,
    "maxFocusLog": 6,
    "maxTCLog": 10,
    "maxTMVLog": 20,
    "MMInterval": 50,
    "TMVInterval": 50
};

function er(n, i, a) {
    var u = "ll";
    if (n) {
        var c = 0
            , f = n["length"];
        if (f === +f)
            for (; c < f && i["call"](a, n[c], c, n) !== false; c++)
                ;
        else
            for (c in n)
                if (n["hasOwnProperty"](c) && i[B + u](a, n[c], c, n) === false)
                    break
    }
}

Dt = {
    isString: function (r) {
        return {}["toString"]["call"](r) === "[object String]"
    },
    flatten: function (r) {
        var e = [];
        return er(r, function (r) {
            typeof r !== "undefined" && (Array.isArray(r) ? e = e["concat"](r) : e["push"](r))
        }),
            e
    },
    toStr: function (r) {
        return String["fromCharCode"]["apply"](String, r)
    },
    random: function (r, t) {
        return r + Math["floor"](Math["random"]() * (t - r + 1))
    },
    map: function (e, o, i) {
        for (var a = [], u = 0, c = e["length"]; u < c; u++)
            a["push"](o["call"](i, e[u], u, e));
        return a
    }
};

Ft = {
    encryptTM: function (i) {
        for (var a = "", u = 4, c = 15273, f = 0; f < i["length"]; f++) {
            var s = i["charCodeAt"](f)
                , h = s >> u
                , d = s << 8 - u
                , v = h + d + c & 255;
            a += String["fromCharCode"](v)
        }
        return a
    },
    encryptBR: function (n) {
        for (var i = "111100", a = "fromC", u = "de", c = "", f = 821, s = 7, h = f, d = 0; d < n["length"]; d++) {
            var v = h << 4 ^ h;
            h = (v & parseInt(i + "00", 2)) + (h >> s),
                c += String["fromCharCode"]((n["charCodeAt"](d) ^ h) & 255)
        }
        return c
    },
    encryptLO: function (i) {
        for (var f = "", s = 312, h = 2, d = 5, v = s, p = 0; p < i["length"]; p++) {
            var l = v << h ^ v;
            v = (l & 240) + (v >> d),
                f += String["fromCharCode"]((i["charCodeAt"](p) ^ v) & 255)
        }
        return f
    },
    encryptCF: function (e) {
        for (var c = "", f = 34313, s = 0; s < e["length"]; s++) {
            var h = e["charCodeAt"](s)
                , d = h ^ f;
            f = d,
                c += String["fromCharCode"](d & 255)
        }
        return c
    },
    encryptDI: function (i) {
        for (var a = "", c = 6, f = 4, s = 156, h = 0; h < i["length"]; h++) {
            var d = s << c ^ s;
            s = (d & 240) + (s >> f),
                a += String["fromCharCode"]((i["charCodeAt"](h) ^ s) & 255)
        }
        return a
    },
    encryptEM: function (r) {
        for (var i = "f", a = "0", u = "", c = 6, f = 3, s = 0; s < r["length"]; s++) {
            var h = r["charCodeAt"](s) - c & 255
                , d = f
                , v = h >> d
                , p = h << 8 - d
                , l = v + p & 255;
            u += String["fromCharCode"](l)
        }
        return u
    },
    encryptJSV: function (n) {
        for (var s = "", h = "VxMpoN86g7lA", d = 32, v = 0; v < n["length"]; v++) {
            var p = n["charCodeAt"](v);
            d = (d + 3) % h["length"],
                p ^= h["charCodeAt"](d),
                s += String["fromCharCode"](p & 255)
        }
        return s
    },
    encryptTK: function (i) {
        for (var a = "", u = 2422, c = 0; c < i["length"]; c++) {
            var f = i["charCodeAt"](c)
                , s = f ^ u;
            (u += 2) >= 2147483647 && (u = 2372),
                a += String["fromCharCode"](s & 255)
        }
        return a
    },
    encryptSA: function (o) {
        for (var i = "", a = parseInt("33265", 10), u = 0; u < o["length"]; u++) {
            var c = (o["charCodeAt"](u) ^ a) & parseInt("11111111", 2);
            i += String["fromCharCode"](c),
                a = c
        }
        return i
    },
    encryptSC: function (o) {
        for (var i = "", a = 43221, u = 24671, c = a, f = 0; f < o["length"]; f++) {
            var s = o["charCodeAt"](f)
                , h = s ^ c;
            c = c * f % 256 + u,
                i += String["fromCharCode"](h & 255)
        }
        return i
    },
    encryptTEMP: function (i) {
        for (var I = "", S = "C6Br4b6f7NgK", A = 44, _ = 0; _ < i["length"]; _++) {
            var y = i["charCodeAt"](_);
            A = (A + 4) % S["length"],
                y ^= S["charCodeAt"](A),
                I += String["fromCharCode"](y & 255)
        }
        return I
    },
    encryptMD: function (i) {
        for (var u = "", c = 131, f = 8, s = 7, h = c, d = 0; d < i["length"]; d++) {
            var v = h << f ^ h;
            h = (v & 240) + (h >> s),
                u += String["fromCharCode"]((i["charCodeAt"](d) ^ h) & 255)
        }
        return u
    },
    encryptMM: function (r) {
        for (var i = "", a = 84357, u = 0; u < r["length"]; u++) {
            var c = r["charCodeAt"](u) ^ a;
            a = c,
                i += String["fromCharCode"](c & 255)
        }
        return i
    }
};

function l(o) {
    if (!o)
        return "";
    var i = [];
    o = o.split(",");
    for (var a = 0; a < o.length; a++)
        i.push(String.fromCharCode(parseInt(o[a], 16)));
    return i.join("")
}

function v(r) {
    return [g(r, 8), g(r, 0)]
}


function g(o, i, a) {
    return o >> i & Math["pow"](2, (typeof a == "undefined" ? 1 : a) * 8) - 1
}

function p(o) {
    return v(g(o, parseInt("10000", 2), 2))["concat"](v(g(o, 0, 2)))
}

bs4 = p;
bs2 = v;

function bs8(t) {
    return p(t / Math["pow"](2, 32))["concat"](p(t, 2))
}

function bss(r) {
    var u = [];
    if (!r)
        return u;
    for (var c = 0; c < r["length"]; c++)
        u["push"](r["charCodeAt"](c));
    return u
}

// 有问题
function Lt(i) {
    b = "XmYj3u1PnvisIZUF8ThR/a6DfO+kW4JHrCELycAzSxleoQp02MtwV9Nd57qGgbKB="
    if (!i)
        return "";
    var v, x, E, M, R, T, L, j = "", D = 0;
    for (; D < i["length"];)
        v = i["charCodeAt"](D++),
            x = i["charCodeAt"](D++),
            E = i["charCodeAt"](D++),
            M = v >> 2,
            R = (v & 3) << 4 | x >> 4,
            T = (x & 15) << 2 | E >> 6,
            L = E & 63,
            isNaN(x) ? T = L = 64 : isNaN(E) && (L = 64),
            j = j + b["charAt"](M) + b["charAt"](R) + b["charAt"](T) + b["charAt"](L);
    return j
}

function app(i, a) {
    var h = Dt["toStr"]([i]["concat"](bs2(a["length"])));
    _ua += [h, a]["join"]("");
    ua = ['s_v3', "#", Lt(_ua)]["join"]("");
}

function process(i) {
    f = []["slice"]["call"](arguments)
    return i = f["length"] === 1 && Array.isArray(i) ? i : f,
        i = Dt["flatten"](i),
        Dt["toStr"](i)
}


function getTM() {
    var n = process(bs8(tm));
    app(1, Ft.encryptTM(n))
}

function getBR() {
    var a = 1
        , u = [1, '129']
        , c = u[0]
        , f = u[1]
        , s = process(a, c, bs2(f["length"]), bss(f));
    app(2, Ft["encryptBR"](s))
}

function getLO() {
    var i = ""
        // , a = "https://netc1.igtb.bankofchina.com/#/login-page"
        , a = "https://netc1.igtb.bankofchina.com/#/login-page?redirect=%2Findex" || ""
        , u = process(bs2(a["length"]), bss(a), bs2(i["length"]), bss(i));
    app(4, (0,
        Ft['encryptLO'])(u))
}

function getCF() {
    var f = [
            'function U(e){var i=o[37],a=r[14],u=n[31];if(!(this instanceof U))return new U(e);this[o[38]]=Z,this[r[39]]=[],this[o[39]]=[],this[i+"ue"]=r[40],this[d+a+v+p]=r[40],(o[20],k[t[38]])(e)&&e(z(this[l+u],this),z(this[t[39]],this))}',
            'function(){var i=o[233],a=o[66],u=o[234],c=e[187],f=e[2],s=[[t[245],new RegExp(e[242],"i")],[e[243],new RegExp(V(S+A),V(n[177]))],[8,new RegExp(r[241],r[236])],[parseInt(o[235],r[62]),new RegExp(t[246],n[53])],[parseInt(V(e[244]),t[116]),new RegExp(r[242],n[53])],[e[245],new RegExp("taobrowser\\\\/([\\\\d.]+)","i")],[parseInt("1100",o[44]),new RegExp(_+y,M(o[236]))],[parseInt(o[237],10),new RegExp(j(r[243]),t[16])],[t[12],new RegExp(r[244],e[9])],[parseInt(V(n[230]),r[62]),new RegExp(i+"([\\\\d.ab]+)",e[9])],[5,new RegExp(M(o[238]),M(t[247]))],[parseInt(a+u,r[69]),new RegExp(D(n[231]),j(e[9]))],[parseInt(t[162],e[162]),new RegExp(V(t[248]),n[53])],[n[3],new RegExp("chrome\\\\/([\\\\d.]+)",M(b+x))],[r[245],new RegExp(o[239],"i")],[3,new RegExp(V(r[246]),V(e[246]))]];return(0,R[V(n[232])])(s,function(n){var o=L[M(e[247])](n[r[28]]);if(o)return f=n[t[8]],c=o[e[19]]||j(r[102]),!1}),c=c["split"](n[233])[o[20]],[f,c]}',
            'function(){var i=n[238],a=t[253];return(r[6],m[function(r){if(!r)return"";for(var o=e[3],i=n[66],a=e[18],u=t[8];u<r.length;u++){var c=r.charCodeAt(u);a=(a+n[3])%i.length,c^=i.charCodeAt(a),o+=String.fromCharCode(c)}return o}(i+a+p)])(I,function(t){return(r[6],C[g("2sb")])(t()||o[20])})}',
            'function(r){for(var t=[],o=(r+=tr(n[2]))[Z+Q+G],i=e[2];i<o;i++)t["push"](r[tr("[_7G{X2PyC")](i));return t}'
        ],
        // s = Dt["random"](0, 3) // 暂时先固定为1
        s = 0 // 暂时先固定为0
        ,
        h = f[s]
        // h = f[3]
        // , d = Dt['random'](0, h.length - 10)
        , d = 212
        // , v = Dt['random'](2, 10)
        , v = 3
        , p = process(bs2(d), bs2(v), bss(h["substr"](d, v)));
    app(5, (0,
        Ft["encryptCF"])(p))
}

function getDI() {
    // s = "__IE_DEVTOOLBAR_CONSOLE_COMMAND_LINE" in window ? 4 : 1040 && 204 && window["outerHeight"] - window["innerHeight"] > 200 ? 8 : window["outerWidth"] && window["innerWidth"] && window["outerWidth"] - window["innerWidth"] > 200 ? 8 : 1;
    var s = 1;
    var h = process(s);
    app(6, Ft["encryptDI"](h))
}

function getEM() {
    var m = 0;
    var C = process(bs4(m));
    app(7, Ft['encryptEM'](C))
}

function getJSV() {
    var o = process(bs4(1));
    app(8, Ft["encryptJSV"](o))
}

function getTK() {
    // var  u = sid; // 请求图片返回的sid
    var u = option.token; // 请求图片返回的sid
    u && (u = process(bs2(u["length"]), bss(u)),
        app(9, Ft["encryptTK"](u)))
}

m = {
    map: function (e, o, i) {
        for (var a = [], u = 0, c = e["length"]; u < c; u++)
            a["push"](o["call"](i, e[u], u, e));
        return a
    },
}
I = [function () {
    return 1920
}
    , function () {
        return 1080
    }
    , function () {
        return 1920
    }
    , function () {
        return 1040
    }
    , function () {
        return Math["abs"](0)
    }
    , function () {
        return Math["abs"](0)
    }
    , function () {
        return window["innerWidth"]
    }
    , function () {
        return window["innerHeight"]
    }
    , function () {
        return window["outerWidth"]
    }
    , function () {
        return window['outerHeight']
    }
]

function getScreenInfo() {
    var i = "U"
        , a = "V";
    return m["map"](I, function (t) {
        return bs2(t() || 0)
    })
}

function getSC() {
    // var r = process(getScreenInfo());
    var r = [
        [
            7,
            128
        ],
        [
            4,
            56
        ],
        [
            7,
            128
        ],
        [
            4,
            16
        ],
        [
            0,
            0
        ],
        [
            0,
            0
        ],
        [
            7,
            128
        ],
        [
            0,
            204
        ],
        [
            7,
            128
        ],
        [
            4,
            16
        ]
    ]
    r = process(r)
    app(3, Ft["encryptSC"](r))
}


function getMD() {
    // s = "dx_captcha_basic_slider-img-hover_2";
    // // s = "";
    // h = 0;
    // d = 35466;  // 点击时间减去初始化时间
    // x = 1090; // x坐标，整数
    // y = 310;
    // l = process(bs4(d), bs2(x), bs2(y), h, bs2(s.length), bss(s))
    // app(12, Ft.encryptMD(l))
    var mosedown_info = [["dx_captcha_basic_slider-img-hover_2", 0, 84492387, 1279, 341], ["dx_captcha_basic_slider-img-hover_2", 0, 950821, 1279, 341], ["dx_captcha_basic_slider-img-hover_2", 0, 925315, 1279, 341], ["dx_captcha_basic_slider-img-hover_2", 0, 369144, 1279, 341], ["dx_captcha_basic_slider-img-hover_2", 0, 26385, 1279, 341], ["dx_captcha_basic_slider-img-hover_2", 0, 25464, 1279, 341]]
    for (var i = 0; i < mosedown_info.length; i++) {
        s = mosedown_info[i][0]
        h = mosedown_info[i][1]
        d = mosedown_info[i][2]
        x = mosedown_info[i][3]
        y = mosedown_info[i][4]
        l = process(bs4(d), bs2(x), bs2(y), h, bs2(s.length), bss(s))
        app(12, Ft.encryptMD(l))
    }
}

function sendTemp(o) {
    var i = process(bs2(o["length"]), bss(o));
    app(10, Ft["encryptTEMP"](i))
}


function getMoveInfo(moveinfoList) {
    moveinfoList = [
        ["", 364191, 868, 353], ["", 21781, 928, 346], ["", 20859, 928, 346], ["", 364847, 985, 326], ["", 22224, 1014, 331], ["", 21306, 1014, 331], ["", 365528, 1068, 299], ["", 22901, 1105, 298], ["", 21979, 1105, 298], ["", 366024, 1164, 311], ["", 23765, 1186, 317], ["", 22843, 1186, 317], ["", 367050, 1222, 322], ["", 24512, 1240, 323], ["", 23593, 1240, 323], ["dx_captcha_basic_slider-img-hover_2", 368058, 1266, 337]
    ]
    for (var i = 0; i < moveinfoList.length; i++) {
        moveinfo = moveinfoList[i]
        d = moveinfo[0]
        t = moveinfo[1]
        x = moveinfo[2]
        y = moveinfo[3]
        info = process(
            bs4(t), bs2(x), bs2(y), bs2(d.length), bss(d)
        )
        app(11, Ft.encryptMM(info))
    }
}


function start() {
    getTM()
    getBR()
    getLO()
    getCF()
    getDI()
    getEM()
    getJSV()
    getTK()
    getSC()
    getMoveInfo()
    getMD()
}

function get_ua(slidetrack, xy) {
    start()
    // getMoveInfo(slidetrack)
    for (var i = 0; i < slidetrack.length; i++) {
        x = slidetrack[i][1]
        y = slidetrack[i][2]
        t = slidetrack[i][3]
        app(17, Ft.encryptSA(process(bs4(t), bs2(x), bs2(y))))
    }
    sendTemp(xy)
    return ua
}

