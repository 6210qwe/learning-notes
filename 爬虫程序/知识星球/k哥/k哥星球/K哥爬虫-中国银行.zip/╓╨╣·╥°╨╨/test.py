import io
import json
import time

import cv2
import execjs
import requests
from PIL import Image
from ddddocr import DdddOcr
from guiji import get_trake, get_move_info
from fake_useragent import UserAgent

UA = UserAgent()
dddd = DdddOcr(show_ad=False)

IMG_WIDTH = 400
IMG_HEIGHT = 200
aid = f"dx-{int(time.time() * 1000)}-71230453-2"


def f(r, t):
    if hasattr(r, "__contains__"):  # Check if 'r' has a contains method (like list in JS)
        return t in r  # Equivalent to r.includes(t)
    for n in range(len(r)):
        if r[n] == t:
            return True
    return False


def get_img_list(r):
    t = []  # This will hold the resulting list
    for n in range(len(r)):
        e = ord(r[n])  # Get the Unicode code point of the character
        if n == int("20", 16):  # Check if index is 32 in decimal
            break
        while f(t, e % int("32", 10)):  # While the result of f is True
            e += 1  # Increment 'e'
        t.append(e % int("100000", 2))  # Append the result of the operation to 't'
    return t


def get_img():
    headers = {
        "Accept": "*/*",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Origin": "https://netc1.igtb.bankofchina.com",
        "Referer": "https://netc1.igtb.bankofchina.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        # "sec-ch-ua": "\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"",
        # "sec-ch-ua-mobile": "?0",
        # "sec-ch-ua-platform": "Windows"
    }
    url = "https://tap-immvs.bankofchina.com/api/a"
    params = {
        "tpc": "",
        "lf": "0",
        "uid": "",
        "de": "0",
        "wp": "1",
        "aid": aid,
        "jsv": "1.3.41.344",
        "c": "",
        "ak": "29f9da417dff9a531ad2f3f6852871b2",
        "s": "50",
        "h": "150",
        "w": "288",
        "_r": "0.6884336108477613"
    }
    response = requests.get(url, headers=headers, params=params)
    info = response.json()
    sid = info.get('sid')
    p1 = 'https://tap-immvs.bankofchina.com' + info.get('p1')
    p2 = 'https://tap-immvs.bankofchina.com' + info.get('p2')
    p3 = 'https://tap-immvs.bankofchina.com' + info.get('p3')
    o = info.get('o')
    y = info.get('y')
    # print(info)
    return sid, p1, p2, p3, o, y


def downloadBGImg(url: str):
    headers = {
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Origin": "https://netc1.igtb.bankofchina.com",
        "Referer": "https://netc1.igtb.bankofchina.com/",
        "Sec-Fetch-Dest": "image",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "sec-ch-ua": "\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\""
    }
    r = requests.get(url, headers=headers)
    with open('test.png', 'wb') as f:
        f.write(r.content)
    return spliceImg(Image.open(io.BytesIO(r.content)))


def downloadSliceImg(url: str):
    headers = {
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Origin": "https://netc1.igtb.bankofchina.com",
        "Referer": "https://netc1.igtb.bankofchina.com/",
        "Sec-Fetch-Dest": "image",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "sec-ch-ua": "\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\""
    }
    r = requests.get(url, headers=headers)
    slice_img = Image.open(io.BytesIO(r.content))
    slice_img.save('sliceimg.png')


def spliceImg(img: Image.Image):
    global IMG_SHUFFLE_ORDER
    # 创建一个图片对象
    newImg = Image.new('RGB', (IMG_WIDTH, IMG_HEIGHT))
    for i in range(len(IMG_SHUFFLE_ORDER)):
        x = IMG_SHUFFLE_ORDER[i] * 12
        # 根据刚才 JS 的逻辑，把图片裁剪出一小块儿
        cut = img.crop((x, 0, x + 12, 200))
        # 根据刚才的逻辑，确定新图片的位置
        # 把新图片拼接过去
        newImg.paste(cut, (i * 12, 0))
    # newImg = newImg.resize((288, 150))
    newImg.paste(img.crop((384, 0, 400, 200)), (384, 0))
    newImg.save('bg.png')
    return newImg


def first_c1():
    with open('c_params.js', 'r', encoding='utf-8') as f:
        js = f.read()

    context = execjs.compile(js)
    result = context.call('getC1Params')
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Origin": "https://netc1.igtb.bankofchina.com",
        "Param": result,
        "Referer": "https://netc1.igtb.bankofchina.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "sec-ch-ua": "\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\""
    }
    url = "https://tap-immvs.bankofchina.com/udid/c1"
    response = requests.get(url, headers=headers)
    info = response.json()
    return info.get('data')


def second_c1(c1_result):
    with open('c_params.js', 'r', encoding='utf-8') as f:
        js = f.read()
    context = execjs.compile(js)
    c2_result = context.call('getC2Params', c1_result)
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Origin": "https://netc1.igtb.bankofchina.com",
        "Param": c2_result,
        "Referer": "https://netc1.igtb.bankofchina.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "sec-ch-ua": "\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\""
    }
    url = "https://tap-immvs.bankofchina.com/udid/c1"
    response = requests.get(url, headers=headers)
    info = response.json()
    return info.get('data')


def getDistance():
    # det = dddd.DdddOcr(det=False, ocr=False, show_ad=False)
    with open('bg.png', 'rb') as f:
        bgBytes = f.read()
    with open('sliceimg.png', 'rb') as f:
        sliceBytes = f.read()
    res = dddd.slide_match(sliceBytes, bgBytes, simple_target=True)
    x1, y1, x2, y2 = res['target']
    im = cv2.imread("bg.png")
    im = cv2.rectangle(im, (x1, y1), (x2, y2), color=(0, 0, 255), thickness=2)
    cv2.imwrite("result.jpg", im)
    distance = int(res['target'][0] * 0.72) - 7
    move_info = get_move_info(distance)
    return move_info, distance


def get_ua(slidetrack, sid, distance, y):
    xy = f"x={distance}&y={y}"
    with open('算法.js', 'r', encoding='utf-8') as f:
        js = f.read().replace('arg1', sid)
    print(xy)
    ua = execjs.compile(js).call('get_ua', slidetrack, xy)

    # with open('补环境.js', 'r', encoding='utf-8') as f:
    #     js = f.read()
    # test = execjs.compile(js)
    # ua = test.call('getAc', distance, y, sid, slidetrack)
    print(ua)
    print(len(ua))
    return ua


def send_veryfy(x, y, sid, c, ac):
    headers = {
        "Accept": "*/*",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Content-type": "application/x-www-form-urlencoded",
        "Origin": "https://netc1.igtb.bankofchina.com",
        "Referer": "https://netc1.igtb.bankofchina.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "sec-ch-ua": "\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\""
    }
    url = "https://tap-immvs.bankofchina.com/api/v1"
    data = {
        "y": y,
        "x": x,
        "aid": aid,
        "sid": sid,
        "jsv": "1.3.41.344",
        "uid": "",
        "c": c,
        "ak": "29f9da417dff9a531ad2f3f6852871b2",
        "ac": ac
    }
    print(data)
    response = requests.post(url, headers=headers, data=data)
    info = response.json()
    print(info)


if __name__ == '__main__':
    sid, p1, p2, p3, o, y = get_img()
    c1_result = first_c1()
    c2_result = second_c1(c1_result)
    IMG_SHUFFLE_ORDER = get_img_list(o)
    downloadBGImg(p1)
    downloadSliceImg(p2)
    slidetrack, distance = getDistance()
    ua = get_ua(slidetrack, sid, distance, y)
    send_veryfy(distance, y, sid, c2_result, ua)
