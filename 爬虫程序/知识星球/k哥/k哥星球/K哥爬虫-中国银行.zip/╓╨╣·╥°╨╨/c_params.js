function f(r, t) {
    if (r["includes"])
        return r["includes"](t);
    for (var n = 0, e = r["length"]; n < e; n++)
        if (r[n] === t)
            return !0;
    return !1
}

function getImgList(r) {
    for (var t = [], n = 0; n < r["length"]; n++) {
        var e = r["charCodeAt"](n);
        if (n === parseInt("20", 16))
            break;
        for (; f(t, e % parseInt("32", 10));)
            e++;
        t["push"](e % parseInt("100000", 2))
    }
    return t
}


makeLoer = function () {
    for (u = 32, f = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", c = [], s = 0; s < u; s++)
        c[s] = f["charAt"](Math["floor"](Math.random() * f["length"]));
    return c["join"]("")
}


var e = {
    "type": "0",
    "value": (new Date).getTime() + (0,
        makeLoer)()
};

f = {
    "lid": e.value,
    "lidType": "0",
    "cache": true,
    "appKey": "29f9da417dff9a531ad2f3f6852871b2"
}


function encode(e, t) {
    var n = "At";
    if (!e)
        return "";
    for (var u, d, h, l, v, g, p, C = "", m = 0; m < e.length;)
        u = e["charCodeAt"](m++),
            d = e.charCodeAt(m++),
            h = e["charCodeAt"](m++),
            l = u >> 2,
            v = (u & 3) << 4 | d >> 4,
            g = (d & 15) << 2 | h >> 6,
            p = 63 & h,
            isNaN(d) ? g = p = 64 : isNaN(h) && (p = 64),
            C = C + t["char" + n](l) + t.charAt(v) + t["charAt"](g) + t["charAt"](p);
    return C

}

function R(r) {
    var e = "৙৐৅"
        , t = (0,
        encode)((0,
        JSON.stringify)(r), "S0DOZN9bBJyPV-qczRa3oYvhGlUMrdjW7m2CkE5_FuKiTQXnwe6pg8fs4HAtIL1x=");
    return t

}

function getC1Params() {
    return R(f)
}


function getC2Params(result) {
    info = {
        "lid": result,
        "lidType": 1,
        "pro": -1,
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        "np": "Win32",
        "dm": 8,
        "cc": "unknown",
        "hc": 12,
        "ce": 1,
        "cd": 24,
        "res": "1920;1080",
        "ar": "1920;1040",
        "to": -480,
        "pr": 1,
        "ls": 1,
        "ss": 1,
        "ind": 1,
        "ab": 0,
        "od": 0,
        "ts": "0;false;false",
        "web": "b3d50519a95f2ff403c9aa09cb0548f7",
        "gi": "Google Inc. (Intel);ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E92) Direct3D11 vs_5_0 ps_5_0, D3D11)",
        "hlb": false,
        "hlo": false,
        "hlr": false,
        "hll": false,
        "hl": 2,
        "vs": "1920;249",
        "ws": "1920;1040",
        "db": 1,
        "sm": 0,
        "ct": 350575,
        "appKey": "29f9da417dff9a531ad2f3f6852871b2"
    }
    return R(info)
}

moveinfoList = [
    [1347, 338, 35509],
    [1350, 341, 34962],
    [1350, 341, 39075],
    [1294, 338, 38526],
]


