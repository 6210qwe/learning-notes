import random
import time

import numpy as np


def get_trake(x):
    first = [1082, 310, 35466]
    distanceX = x
    guiji = []
    guiji.append(first)
    while guiji[-1][0] < distanceX + 1082:
        first = guiji[-1]
        guiji.append([first[0] + random.randint(1, 5), first[1],
                      random.randint(20000, 50000)])
        # print(guiji[-1][0])
    guiji[-1][0] = distanceX + 1090
    return guiji


def get_move_info(x):
    ttt = 27325
    y = 343
    move_x = 1295
    # move_info = [["dx_captcha_basic_slider-img-hover_2", 27325, 1295, 343], ["dx_captcha_basic_slider-img-hover_2",
    #                                                                          26404, 1295, 343], [
    #                  "dx_captcha_basic_slider-img-hover_2", 28301, 1376, 348], ["dx_captcha_basic_slider-img-hover_2",
    #                                                                             27380, 1376, 348]]
    move_info = []
    for i in range(0, 80):
        d = "dx_captcha_basic_slider-img-hover_2"
        move_x += random.randint(1, 5)
        time_date = ttt + random.randint(-100, 100)
        move_info.append([d, time_date, move_x, y])
        if move_x > x + 1295:
            move_info[-1][2] = move_x + x
            move_info.append([d, ttt + random.randint(-100, 100), move_x, y])
            return move_info
