

```
test.py为入口文件（没有成功过滑块， 不知道是轨迹还是加密的问题）
	get_img 获取图片，图片list等信息
	first_c1， second_c1 获取c值
	get_img_list 解get_img获取到的图片list
	downloadBGImg 下载背景图片并还原
	downloadSliceImg  下载滑动图片
	getDistance 识别距离生成轨迹
	get_ua 调用js生成ac信息
	send_veryfy 发送验证
	
算法.js 文件中是我跟js实现的（个人跟过一次并验证，感觉没啥问题）（调用的时候记得将arg1替换为sid）
	start 收集信息并加密添加到ua中
	get_ua 传入轨迹和xy，加密并添加到ua中
	sendTemp 加密xy加密并添加到ua中
	
补环境.js直接调用getAc方法
	getAc 传入x，y，sid，轨迹，返回ua


仅供学习！！！
```

