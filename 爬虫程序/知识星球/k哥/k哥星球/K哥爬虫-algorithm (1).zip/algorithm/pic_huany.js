// 用于处理图像的函数
const {createCanvas, loadImage} = require('canvas'); // 导入 canvas 模块
const fetch = require('node-fetch');  // 2.7.0

// 用于处理图像的函数
function huany(order, src) {
    // 创建一个 canvas
    const wid = 290;
    const hei = 167;
    const canvas = createCanvas(wid, hei); // 使用 canvas 库创建 canvas 对象
    const ctx = canvas.getContext('2d');  // 获取绘图上下文

    const can_width = Math.round(wid / 5);
    const can_height = Math.round(hei / 2);

    // 使用 node-fetch 下载图像
    const imageUrl = src;

    // 加载图像
    fetch(imageUrl)
        .then(response => response.buffer()) // 将响应转换为二进制数据
        .then(imageBuffer => loadImage(imageBuffer)) // 使用 canvas 的 loadImage 函数加载图像
        .then(image => {
            console.log("图片加载成功！");

            const width = Math.round(400 / 5);
            const height = Math.round(230 / 2);

            // 确保 order 是一个有效的字符串
            if (order.length !== 10) return;

            // 按照顺序处理图像
            for (let i = 0; i < 10; i++) {  // 假设 shunxu[0] 中只有 10 个字符
                const j = i < 5 ? i : i - 5;
                let cha_value = parseInt(order.charAt(i));

                if (cha_value < 5) {
                    // 处理第一部分的图像绘制
                    ctx.drawImage(image, j * width, i < 5 ? 0 : height, width, height, cha_value * can_width, 0, can_width, can_height);
                } else {
                    cha_value = cha_value - 5;
                    // 处理第二部分的图像绘制
                    ctx.drawImage(image, j * width, i < 5 ? 0 : height, width, height, cha_value * can_width, can_height, can_width, can_height);
                }
            }

            // 将生成的图像保存为 PNG 文件
            const fs = require('fs');
            const out = fs.createWriteStream('image.png');
            const stream = canvas.createPNGStream();
            stream.pipe(out);
            out.on('finish', () => console.log('图像已保存到 image.png'));
        })
        .catch(error => {
            console.error("图片加载失败！", error);
        });
}

// 执行函数，使用指定的顺序
huany("1523906784", "https://img-cn.vaptcha.net/vaptcha/9d64bb2c0c2b494c9881f40250caf252.jpg");