// const {createCanvas} = require('canvas');
const crypto = require('crypto');

function _0xa995c3() {
}

_0xa995c3['prototype']['GenerateFP'] = function (_0x557bcf) {
    var _0x593cf7 = this['getComplexCanvasFingerprint'](_0x557bcf);
    return this['extractCRC32FromBase64'](_0x593cf7);
};
_0xa995c3['prototype']['getComplexCanvasFingerprint'] = function (_0x12a8fa) {
    if (_0x12a8fa === void 0) {
        _0x12a8fa = '';
    }
    // var _0x2304ec = "BrowserLeaks,com <canvas> 1.0" + _0x12a8fa;
    // var _0x5b63f2 = createCanvas(220, 30);
    // var _0x12897d = _0x5b63f2['getContext']('2d');
    //
    // _0x12897d['textBaseline'] = 'top';
    // _0x12897d['font'] = "14px 'Arial'";
    // _0x12897d['textBaseline'] = 'alphabetic';
    // _0x12897d['fillStyle'] = '#f60';
    // _0x12897d['fillRect'](125, 1, 62, 20);
    // _0x12897d['fillStyle'] = '#069';
    // _0x12897d['fillText'](_0x2304ec, 2, 15);
    // _0x12897d['fillStyle'] = "rgba(102, 204, 0, 0.7)";
    // _0x12897d['fillText'](_0x2304ec, 4, 17);
    // return _0x5b63f2["toDataURL"]();
    return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHoAAABuCAYAAADoHgdpAAAAAXNSR0IArs4c6QAAGBBJREFUeF7tnQmYVMW1x3/VPTMwgxKUTVBAGOKggkmYmSRqNIqKxiDiEhWXGJfQaIx5RqN5WZ5kM8tL8vKMikOiRmM0iyZqTMyLUUlc48yAChoQGAQFRBF9yjJM93Rlzr3dMz3dt++te/v2InK+jw+0azl1/reqTp1z6pSijKQb9Gi6aEQxGU0DEcahGQ3sl4et5Wg2oHgJeBHNUmpoV8vVev3z9ol068nAFDSTUXofUHXAIPtvPcj+t0VbQW0Fvc3+t96GVq+gWAosIaqWqgsbVzZoPboLGhVM1tAQgXEad/40bFDY/GlYWgPty5VaX0YxW12rUjKgJ+oBJJmBZjqKI1wAdWcruR26t0L3NvvPHts047Xi/cAkIBpsVF3Aw8CjwFNRpV/as04xrA5G1MHwQbBnbbCGbdAXKvjrQPjjC0pJVyWlkgCtJ+gZwOyer/zMQKMTMBNv2aAm5U/cvZkPAAelQDfoUMD9I3CfV9naahguoNfBuCFYH0EwugO4s0Op+4NV91+raEDrA3QNnVwCzOkZVINv1pJdNriJ/4fE276rWxWGA83AR3NnuXwqt/V8C78GOoK1DnsPhn3fZ4O+W02QVpYDCwbCdcWe5aEDrdGKCXwZzeUohvoevYAbf9MGWSd9V3esIBPvYz3r8uEId9wI/Bx4K5zWoUp27yEwcQ/7b5+k4Q0FP+qA76GU9lndqHioQOt6/Rk084BxRr1nFopvhvgbwWevQYd37wHXToNXphoUDlpEZvmkoVC/Z5AW1vQAMm+VUr8IUtmtTihA6/G6AcUPAdmL/VF8UwrgLf7q+SgtS/N3U4qWVU0Utk8Aw3w04rfoXrtBw1BoCNTJ/RquWK2ULO2hUMFA63o9B811QLUvjmRp7toIieIBLPzc2XO0+AaQo76JZn5Cag/3xbjPwgL4B0YGWdLjCj6/SqkWnz06Fi8IaD1et6AsZcuckp02wF2bzOsELPnVlLLlWl2UtVkBO/BTTWa2AD5koJ9aPTshC1YrFfNVyaFwIKD1OD2KCHekzsLmPHS9Cjs2gk6Y1wlQ8rUeRes/elbnf5rWHQ+cBgw2rRCw3MAqG+wP7OWrATmDJ+CslwswvPgGWtdrsWLd5evIJOffHeuKqmilJfci8LkgRyY5islJf6QvDIIVFoXtI3v7PYcvV3DqKqXEeuebfAGtJ+qpJJFD/ijjnkTZ6lxX9Fks/DwPXNAD9OvGzGUVlBl9Ts/JVoywxSaZ3QK2P2VtQwRmrFRqkV/2jIFOzeS/GoMsZ2CZxV2ykBafZCZ/uhCQ0ywK2J8p0cyWPg8cYQMuZ3EzElv6dL8z2whoPUaPptoyA5tZuMQW3bm26Bp1Wi7yKZ0VZLnOJ1hZxmVp2N1M8gWXEs38Y2P92NKXd8ORa5TaYNq3GdDj9SPGipc4G7avhuQOUx4KLicGdGPFy7Q3UdAuNC0cQrnBA2DaeBiRdrC5tykK2mqljjTt2RNoX0eo7ndgqyyipSOjI1RQdkp19Mrkb8Z+MNpsKfFz9HIFWtfrGNoyDXuTGEC2rfIuF2IJMYZ8LcT2HJuSM7YAXkqaXg/7mtnMFcRWKbXAi728QKfMmkuMLF471sMO4+3Ciyej38WsKVbM4p7IU16vS4tsLnUaceMoaDRS/+MapniZS/MDPUGLi9bbdi1Wrs5XjMAJs9BnM23XYTbs1JbYxuXYVWo6eB+YYnSwv79DKTHo5iVHoFNeqFs8xyVn5O1rPIuFXeBu4MqwG/Vq75SeyIRier3y9f/xcUZnbQXnuXm9coBO+ZNXe7oaE2/CtsAuey+x5v1dnLUfB9YFbiFgxT2Ay0sdfJXi9ZgJMF4YcKU1HTA+nz87F+gJ+j+Ba1ybtI5QKyFZ9B0yh435YPlDy0LTU19ZqTuvrYLjJtpxa+70lQ6lxCObQ/2AtsJ/trPeNTJELF7bV5TMGJLJsUTUHQK86TXcYv0ukSpfDh58WBBbYlQ5/v2uFjSJVKmF0U5hSf2BnqC/2GMP+pErQ50vl8ysmc3HTZ5LTUGiNKt8PHCoWdHQS4m59NAxXs1e3qHUj7MLZQO9zNXMWSblK8300YAoD2UlMY+KD7Rc5K2cLe9QSs4J/agX6FRIrhypnElcjdtWlMQL5cSAGNrlSFURJEetHFGWiDPxeskS7h5qfEJ2KHEm0L9yjbsWkIOG3YYgg8tM4q5D6MeoCYkbl0CFcpH4sz8ptxXy0h0dSomfp5csoFMx2Pm9EBIZIj7lMpEoYfuXqe+83UogWlUZmRLXpkukSgQGrlSqF1Mb6AlazAESNZJLEuO1dXnZlmxh6C+pqJEyijW3a3GZHVhGjmQJn9ngFoN2aodSYluyyAbaLcivc01JAvncRFZUD1VQrMrh2crmVaJTRDlzoGzPVnpGS/xw7g3GMniknJiuCG07mzEJ1xbFodx0bH2+UOIXO5TqDRRR1tXVeB6L4rblZTGMZMpuY8pIUm55OvYvxhMz13Hx2BdDiizhDlQNe6ev7Co9Xp+AcrhIWOYzc5rvh1K39IonqQJaLucxK5PtPGdrDTNXK2UdmZXOZ9uugNksDJbVtu31DZTL9p3NV/5Z3Wv7FqDFHSlxj30kF94k7qsCSNyRvapjBfDTjwVxW8p5pRLoqPE5F/s03LpaKQtbWbpzA//KbBzJlFtRAv/CAmZCKlo0rPYKacfBiKJg4apUAKHM6P727QrRtNNjPibMMN5CBOlUt1I07zRvuRp4r+YtQPe/eC1LtizdFUL1FcJHXja+U0EMyp1sWcIzqEMp6wjdH2hJJ7H1+fAyDYQgg11A+xCi3PY47cB+aTacgZbrM+JvriDaBbRPMMRfLX7rFDkDXUFKWJpRX0CrN6FqA0TXQ/RViG6EtyXWPJ9DZm8YXA/dI6F7L+geDYlRoD3js/qkX0lLt3CVpZTlAi3+5q3/8vn5FL+4O9BxiD4L0aVQtQTUWkgmoSsJ3T4T3UQjUBOBSAT0WOg+CBIHQrf4JF2SOVQa0ALJyfv3+qtzgS5DEL7JZ+IIdNXzUPU4RB+EqIKkhng3dHUjKQIKIlFdaqJQHYWIgm4N3cdA4lAb+GyqRKAzgv8zgbYdGttXQTy0hEwFyTqzcp9DIwHVC6HmLxBd21dEAN7RbYMdJgnIA1KAp9vtHgtdx0FcAo4luVyZw4ryjVeu88i1HugNK1K6Xj+C5gi2POedkS9MQRq2dSaaf1b/Gar/AFVZieUE4B1FDjkeUGUDnkmJwRA/CfY5Hi70vKdoONIQi9VVw9kHyeLWe+NSLGO/QHeeyxbJF1BhVPUEV9bcyd1V4sPKoq1d9rJaCpLtYZBDZsCjR8IJs2G9BCFXGMkxa8jAX3QodZ5wZjs14puvqRTbtiWu6CaouR2qn3B2amzpCn+p9sJJlvLsNJBXABfJAnkILDkbNgfKKebVc7Df5a71xD0znBriptyx9j66Amf+CMZIvlpVf4eBLRCxl+QcN+X2hK14lYNEQZNbE2mSy6pHpf7jnSj8Yy6sk/27AujA4ehDx2a4KSXw4K1l66y0yOWm6puhViLE+qhf4IFo1Z1F3pO9ZCCxWqKVCz0J9Nkm7P/30HGw6nyvVor/+/BBVJ80qS/wQHrUk9qTbJJ0qOWizVBzPQyU69i5ZGneolVvi5d+yc5mR5ZwUXbqFfwtj7yemAJLJQlWoHygoYCwb1Tphy9s7M2Ao6zM9XfrFbSG0n6ARtZC7f9CdX7TqxUcKNq1aNmVQKKFn1sFbmfolWPg4S8AY8vC8Rk9B8DvRNX75SUBYUDplrZZPM8fkFThJacO2O2HEHFPF/mXpOZzomWXSMn2FIOsfdfXwKc8FsEtw+AO0djEcV1aur7nFYHj4CQVa7onDfTXSfBNri4tI7AWdv8eKO+coF2dCfaX/bmS6PdROMwggr9zGNwmUYSlndkSZFAN/6ViTd+ygb6x7TcoTuO3wLOlkuRmGPRdiBpmS9ga57LupPdTCKViX8zfl0RglmFC443j4F65dl6aPXsm8D8iC81v1dym01MzuvVxUIcgn8AvSySp2mug+hmzzkQJ29JlZbOruEt2Z9XAIEMd9sUPwsKvmI25wFI/A6ZZ6PK4mtMkbw9Ye/Ri4INW2z8JI8eiB5cDboUBfzIfSlwu3tvZtisikD/Tvj2tGiYap3aE1k/C4nPNxx6gpGgDD/bVe0bFmj6UBloywNlX8x4H/hygddMq1Y9B7bWmpe1ycm5O7c8VdxF+ShQONtinM0f84KWw2ppkRSFZMyS7ZYpWqliTha3SLe2vgN7b+kH0ne/1pPyRZ7/CpugbUHcJKJ9KlcxmmdWpLPoHV1Jqi30jMN1wn07Lc2tPVt8Hfgqb/b8r4wWJpKB7qr/3/FUVa7IyMcvSLSlB+tLU/b3nDozk8A2ban9i2a59U5bzoqwB/dkB+8MicLJPoEUA/zoEHg0/bULa9J4h4y0q1mRdGhKg5fpxH7dyVpUsJmFmhKl6AupEAQhA78j5ue8AXVHppwYoODfQe1dw7xdgY3jJUGRJljmarRqqWFMqCjQbaMFC0n6Hdj1CQ92l4ORqNME9C2ipUjEJ5WoUTOqZ1c/53I5kEHuNgplPh5a4zCmhnG5pvVrFmuXKvsPSnRa+HLXkyFUoVf8Jam8N3koev3NFpIgcquAUeWa0G9oDOFuOvgwmSJa6giknRaSe3zqPCF9TsWZLW+yvjGX2JwYrUZADfKx9zcSh7qLcyBA/48pQxjKrSc5CyQTl8Uqln56cy4qjKl/S10xlrK0bFvkEe9gQOFlOtwH2+QwhZyd9tUFWV4N6U8UaLSuN7NF9x6vsoYqjw7KUBqTqv0GtZ4Zh98YzjlfZBcuexjn7eNWagMU+Z8ZhX4L9xfkRjBTMzXwbqw9kq721KtZkpUTobzBx6kuADurZGnRF/0C+IGPJMJg4VS9q2guv9BVOBpOnE/CMD7CHjYGTxbHtn7LTV2SBLA0uVbGmKSmgUyZQt37kxU6/t2glJLfO0gMKo5QJ1K2Roty4NHlqIZ8J9J8JeNYH2DNuhNHeGbMzZZD91IIDyGLsflLFmq2Atj6nhpsk3wHELOUn2mhACwyQQKAQaGvcNSC/KI+nSJCI24NnIzycGk8lzLXxqcdDk68tbnkcpqUfPHMGOcep0fZ14JuecEhMj7yBavSUcxwGzQa5/RAGuezT6eZL/hySifnzyQQsMZjZIyNwosQHGJ3J+z2HlBdkWzAZbkoJPIA/GOGxPuXh8gI70ga7/cCoSaNCsnwbBB6U7IEz0cRn1YAcr7zoiQQsNQD7jPkw2DWJvvTU74EzD5ClfEbggYQSdesVXvz2/i4zW9Rdt2W85hYY+IBxk0YFDUOJSvJk4UFR+KgPZ8bjCXjeA+zDPwWTLC9yPur3ZKEByHJdqS+USFrVLa3bQZk/gyozWgIV8ilodZdDVcjXb30EBwZ6hFTc8yappGoVnFQNuxnM5kzIHkvACy5gjx0Hx4n7MJdE8UrCmekHzYxARneqWHNtujU7oVxL+9Og/T/643T0kquruxf8Cq7zV+0z3Nfo6OV1hMrm5JAqmJx1RcdoSepxqHuBfUEbRPu/RGtwhMrTu2pVscYPZwHdeh0oiU/1T3LGlkxW6Y81rGNVPk58BvDLLjPP6dmkIA+F10fhKB9LttMY3PbsT86HvXv3aXko/JLMN63MZnK6U329ijVfkgV0mxxFJY1zMBJzqWzJVkTaA1Dr/cBOsI5StXxeyRFzqTw0IeFIFkmubXk0y88NGlmqzzTSir2Hlu/oddRlUG/Zvu/vCaC6IvMtK38gWyycpWJNvbG99tL9s/b9SeoXvDn0KCFer8dautj+UEgScekvwCW7u/aAa6fBOr/PGqWdFwULKKMBBwvaiENm7Hh98o1i0pSDbC8FAFnudh+gPtvYm9mgLzF7S5vkfzB6Os11vFMvXknrpomINa3Y161Nr83KoycSvXM4yH0UeYPRmL2mKpgacE/2+jBSXi+J+pD3TudOHvNS5NCn+qUVCgQyrFexJjtqKEV9QN/Yeg9KnejFm+fvR3x6Pft1SiJZuE2uWBQ5UZjbRXgJ5BNl66O5L9t4sifa9Yej0FAkkFNh/Wcs7ubTrQnbf7XfsLfUkc/2JlAJCLIEatyr5jaLfcQB6F7XlieU7gVOOBVGZVnEZHMUhe2+AtvOVz07tYXEXR9k/u5FP/YE1wOjtmbt9whlODyJuxaVywrJFRK7uNjH942gjn3Z3k4LwSOpv6EuahYd1BHoDxHx/6R8zthO/xS8L88ZU6aRmL8fTT347NdRkk+Qsth9RIKWNYzshteT8IbP+ztDFfHRER7aL8qjQ5X1HnXY7B2WAtdRgRHr2aokatbLqiCQRUZJPVVd1CyO7lygra9oQdtf0UhWxuB03mnmfnSxbMgFSjFniVTlLVOxuOV7CVEAlTc5RZOQAGZJJS9OuOyrq8L9Oxo2pACXf1t/UsMSw8juyv4jipasQPLvLCome44CFoPKP+76hh00EJAUD6o5TRLG2I/6v3vV0irxuD8N2IVdzQ/QBXW0E1aWp05uFZNjIaQ/r2LN17kDffOSMcR3yGlY9NRg5LZ0B2vxvVPrLQ2//V0h491G9YBJ6vwpOfbn3EdIW1rvBCXXa4ORkzIWrKX3Xi3Zav7o/FiRmTD0r1WsebZT2VygFyyaiU7ea9awQ6mPn7OBhh3W7YBd5FMCLw5cz8LbgtsyVORENWeq49nGUT0uSCkTg0nTpok+h7iruEhg0dAVtM13faIur6DyKGHp8nmAXnQGOin+AP808atLmbZisv+Ku2rwyH7PseLbYgHwTyoyW82ZKuYpR8rrVNUL2h5DB3hAd0TLImY95Nea7H9gO2ONe45axGsx/7LLuAcdAOjW89FKQgL9Ud0jizl7vnUndxf5lMDtFy1m25H+Zaf0BWpO881uvbmGSQSb1W90Meei4nuvfMrwXVF8wfwuGOpPdgazWcbuAXRADfzos9cxoauf9+RdIehyMtlRs46/3e5fZi6aduZwPAOfdEv7TaD9pcLb51vLOH5JuZ7SLidcwfv+85RlvPJ1nzJTN6tYY0aCg/zdewN9U2sDCfWYr3iM6oWvct4N/YOfgovgvVHzlotfJX6EH5ltokp/TF3QLPnWPckTaGlBt7ReCer7nq31FojDibNBAtN3kbcENibhXjkZ+YlH01epWLNx8LwR0BbYfj1b+1/1HIetDnYm9BbNzlXi0fHP8a/vm8vKwzjiJBxzoOe3ir9aspuYhdTVLlzCOTdYN/l2kYcEfnnxErYfYSqrTST19Gx/s5eMjYG2Z7XPs/XMs9awV9z5yXIvzt4rv79avYb7fmUuI4Mzc0EzOl1Zt7T/FHRvvLArHiNuaWPWA03vFcwCjfOeT7Tx2nmGMlLXqVjj54P042tG24pZWx0KiUQxSKmTgE+c9TZjtNsF1CB87xx1XlZv88CvBhspYYrH0UxXsaZAWeB8A22BfeOiJlTy/lRgj7vQ97zpBU79vwN2DmRCHsVdx77A5gtMZLMRHZmh5k5tC8pBIKBtsNtPRmmDJFUapp39OhPjEny7i9ISWFn9Og/fPtzDOGmX1uoUNbfx94UILzDQtnK26Hx00tvxsdt9yzjzdp9Wn0KG9S6oe8fZy9gy01smKnKBmjPV1WFhMtqCgLb37NbLQP3Ys7MPf+5ZPvi6RFzvomeGP8vT1xvIQn9RxZpdL02bCrNgoC2wTYLNq15azulX1jPIl/nHdBzvnnJbSfCbH6wisW+DO9Nqnoo1hpDtx+4lFKDtZbz9JLR230eG/GYRp93t37H+7oHRm9PfnbKIN093l4FSJ6s5jWbpRrx7DBdoexlvOzLzdqojDxPnLWbaC/6d64YDquhiDx+wmJXzvMY+TcWaHgl7HKHN6DRjuqVNLsfIXev8Tz8fPGcZU97yVkTCHm0521syZBlPLnAbs7xoLnea5TZQ6BQ60NbMvqH9IKr0DfmNKpthxqVrGd1V2qdjQhefYYPra9Zy/7Vj8z6eIsaQhLpYXdz4nGGLvosVBejUMl5nuzbzmUvXwjlf2kitlttUOy9tVxv55X+PzP8ckroOxOUYzOJlKriiAd27lNuOEPFlO3i9OmD2V15j96TTNTnTMVRuuXcir3HnNSPyPHC2CaWv8grqC2twRQfamt3i4oyq7zvf1FwLh39tA5M6d67bHcsGbuAf3x7lOJMVD9Ktr/LraiwE9H8DS/2Y2JDkvzUAAAAASUVORK5CYII=";
};
_0xa995c3['prototype']['extractCRC32FromBase64'] = function (_0x13ff59) {
    _0x13ff59 = _0x13ff59['replace']('data:image/png;base64,', '');
    var _0x49c8a4 = atob(_0x13ff59);
    var _0x15374b = _0x49c8a4['slice'](-16, -12);
    return this['string2Hex'](_0x15374b['toString']());
};
_0xa995c3['prototype']['string2Hex'] = function (_0x3d0011) {
    var _0x509373 = '';
    for (var _0x42b50c = 0; _0x42b50c < _0x3d0011['length']; _0x42b50c++) {
        var _0x57c01a = _0x3d0011['charCodeAt'](_0x42b50c);
        if (_0x57c01a <= 15) {
            _0x509373 += '0';
        }
        _0x509373 += _0x57c01a['toString'](16)['toLocaleUpperCase']();
    }
    return _0x509373;
};

function _0xb28cc7(_0x1dbc38, _0x174243) {
    _0x1dbc38 = _0x1dbc38 || '';
    _0x174243 = _0x174243 || 0x0;
    var _0x5ed065 = _0x1dbc38['length'] % 0x10;
    var _0x48ba3a = _0x1dbc38['length'] - _0x5ed065;
    var _0x318e51 = [0x0, _0x174243];
    var _0x4449ed = [0x0, _0x174243];
    var _0x51c35e = [0x0, 0x0];
    var _0xfc6a78 = [0x0, 0x0];
    var _0xb3434d = [0x87c37b91, 0x114253d5];
    var _0x344f61 = [0x4cf5ad43, 0x2745937f];
    var _0x24f10f;
    for (_0x24f10f = 0x0; _0x24f10f < _0x48ba3a; _0x24f10f = _0x24f10f + 0x10) {
        _0x51c35e = [_0x1dbc38['charCodeAt'](_0x24f10f + 0x4) & 0xff | (_0x1dbc38['charCodeAt'](_0x24f10f + 0x5) & 0xff) << 0x8 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0x6) & 0xff) << 0x10 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0x7) & 0xff) << 0x18, _0x1dbc38['charCodeAt'](_0x24f10f) & 0xff | (_0x1dbc38['charCodeAt'](_0x24f10f + 0x1) & 0xff) << 0x8 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0x2) & 0xff) << 0x10 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0x3) & 0xff) << 0x18];
        _0xfc6a78 = [_0x1dbc38['charCodeAt'](_0x24f10f + 0xc) & 0xff | (_0x1dbc38['charCodeAt'](_0x24f10f + 0xd) & 0xff) << 0x8 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0xe) & 0xff) << 0x10 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0xf) & 0xff) << 0x18, _0x1dbc38['charCodeAt'](_0x24f10f + 0x8) & 0xff | (_0x1dbc38['charCodeAt'](_0x24f10f + 0x9) & 0xff) << 0x8 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0xa) & 0xff) << 0x10 | (_0x1dbc38['charCodeAt'](_0x24f10f + 0xb) & 0xff) << 0x18];
        _0x51c35e = _0xcea9ec(_0x51c35e, _0xb3434d);
        _0x51c35e = _0x135413(_0x51c35e, 0x1f);
        _0x51c35e = _0xcea9ec(_0x51c35e, _0x344f61);
        _0x318e51 = _0x20950c(_0x318e51, _0x51c35e);
        _0x318e51 = _0x135413(_0x318e51, 0x1b);
        _0x318e51 = _0x5e5dd7(_0x318e51, _0x4449ed);
        _0x318e51 = _0x5e5dd7(_0xcea9ec(_0x318e51, [0x0, 0x5]), [0x0, 0x52dce729]);
        _0xfc6a78 = _0xcea9ec(_0xfc6a78, _0x344f61);
        _0xfc6a78 = _0x135413(_0xfc6a78, 0x21);
        _0xfc6a78 = _0xcea9ec(_0xfc6a78, _0xb3434d);
        _0x4449ed = _0x20950c(_0x4449ed, _0xfc6a78);
        _0x4449ed = _0x135413(_0x4449ed, 0x1f);
        _0x4449ed = _0x5e5dd7(_0x4449ed, _0x318e51);
        _0x4449ed = _0x5e5dd7(_0xcea9ec(_0x4449ed, [0x0, 0x5]), [0x0, 0x38495ab5]);
    }
    _0x51c35e = [0x0, 0x0];
    _0xfc6a78 = [0x0, 0x0];
    switch (_0x5ed065) {
        case 0xf:
            _0xfc6a78 = _0x20950c(_0xfc6a78, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0xe)], 0x30));
        case 0xe:
            _0xfc6a78 = _0x20950c(_0xfc6a78, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0xd)], 0x28));
        case 0xd:
            _0xfc6a78 = _0x20950c(_0xfc6a78, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0xc)], 0x20));
        case 0xc:
            _0xfc6a78 = _0x20950c(_0xfc6a78, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0xb)], 0x18));
        case 0xb:
            _0xfc6a78 = _0x20950c(_0xfc6a78, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0xa)], 0x10));
        case 0xa:
            _0xfc6a78 = _0x20950c(_0xfc6a78, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x9)], 0x8));
        case 0x9:
            _0xfc6a78 = _0x20950c(_0xfc6a78, [0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x8)]);
            _0xfc6a78 = _0xcea9ec(_0xfc6a78, _0x344f61);
            _0xfc6a78 = _0x135413(_0xfc6a78, 0x21);
            _0xfc6a78 = _0xcea9ec(_0xfc6a78, _0xb3434d);
            _0x4449ed = _0x20950c(_0x4449ed, _0xfc6a78);
        case 0x8:
            _0x51c35e = _0x20950c(_0x51c35e, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x7)], 0x38));
        case 0x7:
            _0x51c35e = _0x20950c(_0x51c35e, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x6)], 0x30));
        case 0x6:
            _0x51c35e = _0x20950c(_0x51c35e, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x5)], 0x28));
        case 0x5:
            _0x51c35e = _0x20950c(_0x51c35e, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x4)], 0x20));
        case 0x4:
            _0x51c35e = _0x20950c(_0x51c35e, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x3)], 0x18));
        case 0x3:
            _0x51c35e = _0x20950c(_0x51c35e, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x2)], 0x10));
        case 0x2:
            _0x51c35e = _0x20950c(_0x51c35e, _0xaf3f19([0x0, _0x1dbc38['charCodeAt'](_0x24f10f + 0x1)], 0x8));
        case 0x1:
            _0x51c35e = _0x20950c(_0x51c35e, [0x0, _0x1dbc38['charCodeAt'](_0x24f10f)]);
            _0x51c35e = _0xcea9ec(_0x51c35e, _0xb3434d);
            _0x51c35e = _0x135413(_0x51c35e, 0x1f);
            _0x51c35e = _0xcea9ec(_0x51c35e, _0x344f61);
            _0x318e51 = _0x20950c(_0x318e51, _0x51c35e);
    }
    _0x318e51 = _0x20950c(_0x318e51, [0x0, _0x1dbc38['length']]);
    _0x4449ed = _0x20950c(_0x4449ed, [0x0, _0x1dbc38['length']]);
    _0x318e51 = _0x5e5dd7(_0x318e51, _0x4449ed);
    _0x4449ed = _0x5e5dd7(_0x4449ed, _0x318e51);
    _0x318e51 = _0x573ab2(_0x318e51);
    _0x4449ed = _0x573ab2(_0x4449ed);
    _0x318e51 = _0x5e5dd7(_0x318e51, _0x4449ed);
    _0x4449ed = _0x5e5dd7(_0x4449ed, _0x318e51);
    return ('00000000' + (_0x318e51[0x0] >>> 0x0)['toString'](0x10))['slice'](-0x8) + ('00000000' + (_0x318e51[0x1] >>> 0x0)['toString'](0x10))['slice'](-0x8) + ('00000000' + (_0x4449ed[0x0] >>> 0x0)['toString'](0x10))['slice'](-0x8) + ('00000000' + (_0x4449ed[0x1] >>> 0x0)['toString'](0x10))["\u0073\u006c\u0069\u0063\u0065"](-0x8);
};

function _0xcea9ec(_0x254488, _0x1b3d5f) {
    _0x254488 = [_0x254488[0x0] >>> 0x10, _0x254488[0x0] & 0xffff, _0x254488[0x1] >>> 0x10, _0x254488[0x1] & 0xffff];
    _0x1b3d5f = [_0x1b3d5f[0x0] >>> 0x10, _0x1b3d5f[0x0] & 0xffff, _0x1b3d5f[0x1] >>> 0x10, _0x1b3d5f[0x1] & 0xffff];
    var _0x50cb6e = [0x0, 0x0, 0x0, 0x0];
    _0x50cb6e[0x3] += _0x254488[0x3] * _0x1b3d5f[0x3];
    _0x50cb6e[0x2] += _0x50cb6e[0x3] >>> 0x10;
    _0x50cb6e[0x3] &= 0xffff;
    _0x50cb6e[0x2] += _0x254488[0x2] * _0x1b3d5f[0x3];
    _0x50cb6e[0x1] += _0x50cb6e[0x2] >>> 0x10;
    _0x50cb6e[0x2] &= 0xffff;
    _0x50cb6e[0x2] += _0x254488[0x3] * _0x1b3d5f[0x2];
    _0x50cb6e[0x1] += _0x50cb6e[0x2] >>> 0x10;
    _0x50cb6e[0x2] &= 0xffff;
    _0x50cb6e[0x1] += _0x254488[0x1] * _0x1b3d5f[0x3];
    _0x50cb6e[0x0] += _0x50cb6e[0x1] >>> 0x10;
    _0x50cb6e[0x1] &= 0xffff;
    _0x50cb6e[0x1] += _0x254488[0x2] * _0x1b3d5f[0x2];
    _0x50cb6e[0x0] += _0x50cb6e[0x1] >>> 0x10;
    _0x50cb6e[0x1] &= 0xffff;
    _0x50cb6e[0x1] += _0x254488[0x3] * _0x1b3d5f[0x1];
    _0x50cb6e[0x0] += _0x50cb6e[0x1] >>> 0x10;
    _0x50cb6e[0x1] &= 0xffff;
    _0x50cb6e[0x0] += _0x254488[0x0] * _0x1b3d5f[0x3] + _0x254488[0x1] * _0x1b3d5f[0x2] + _0x254488[0x2] * _0x1b3d5f[0x1] + _0x254488[0x3] * _0x1b3d5f[0x0];
    _0x50cb6e[0x0] &= 0xffff;
    return [_0x50cb6e[0x0] << 0x10 | _0x50cb6e[0x1], _0x50cb6e[0x2] << 0x10 | _0x50cb6e[0x3]];
};

function _0x5e5dd7(_0x3277b6, _0x821466) {
    _0x3277b6 = [_0x3277b6[0x0] >>> 0x10, _0x3277b6[0x0] & 0xffff, _0x3277b6[0x1] >>> 0x10, _0x3277b6[0x1] & 0xffff];
    _0x821466 = [_0x821466[0x0] >>> 0x10, _0x821466[0x0] & 0xffff, _0x821466[0x1] >>> 0x10, _0x821466[0x1] & 0xffff];
    var _0x4a00ef = [0x0, 0x0, 0x0, 0x0];
    _0x4a00ef[0x3] += _0x3277b6[0x3] + _0x821466[0x3];
    _0x4a00ef[0x2] += _0x4a00ef[0x3] >>> 0x10;
    _0x4a00ef[0x3] &= 0xffff;
    _0x4a00ef[0x2] += _0x3277b6[0x2] + _0x821466[0x2];
    _0x4a00ef[0x1] += _0x4a00ef[0x2] >>> 0x10;
    _0x4a00ef[0x2] &= 0xffff;
    _0x4a00ef[0x1] += _0x3277b6[0x1] + _0x821466[0x1];
    _0x4a00ef[0x0] += _0x4a00ef[0x1] >>> 0x10;
    _0x4a00ef[0x1] &= 0xffff;
    _0x4a00ef[0x0] += _0x3277b6[0x0] + _0x821466[0x0];
    _0x4a00ef[0x0] &= 0xffff;
    return [_0x4a00ef[0x0] << 0x10 | _0x4a00ef[0x1], _0x4a00ef[0x2] << 0x10 | _0x4a00ef[0x3]];
};

function _0xaf3f19(_0x4ae6c4, _0x4bdd15) {
    _0x4bdd15 %= 0x40;
    if (_0x4bdd15 === 0x0) {
        return _0x4ae6c4;
    } else if (_0x4bdd15 < 0x20) {
        return [_0x4ae6c4[0x0] << _0x4bdd15 | _0x4ae6c4[0x1] >>> 0x20 - _0x4bdd15, _0x4ae6c4[0x1] << _0x4bdd15];
    } else {
        return [_0x4ae6c4[0x1] << _0x4bdd15 - 0x20, 0x0];
    }
};

function _0x573ab2(_0x479a89) {
    _0x479a89 = _0x20950c(_0x479a89, [0x0, _0x479a89[0x0] >>> 0x1]);
    _0x479a89 = _0xcea9ec(_0x479a89, [0xff51afd7, 0xed558ccd]);
    _0x479a89 = _0x20950c(_0x479a89, [0x0, _0x479a89[0x0] >>> 0x1]);
    _0x479a89 = _0xcea9ec(_0x479a89, [0xc4ceb9fe, 0x1a85ec53]);
    _0x479a89 = _0x20950c(_0x479a89, [0x0, _0x479a89[0x0] >>> 0x1]);
    return _0x479a89;
};

function _0x20950c(_0x64cb5f, _0xbc71c6) {
    return [_0x64cb5f[0x0] ^ _0xbc71c6[0x0], _0x64cb5f[0x1] ^ _0xbc71c6[0x1]];
};

function _0x1b4f3e(_0x2c6451) {
    return _0x5c3ccd(_0x2c6451, '8', 'a');
};

function _0x135413(_0x2ead27, _0x696ed3) {
    _0x696ed3 %= 0x40;
    if (_0x696ed3 === 0x20) {
        return [_0x2ead27[0x1], _0x2ead27[0x0]];
    } else if (_0x696ed3 < 0x20) {
        return [_0x2ead27[0x0] << _0x696ed3 | _0x2ead27[0x1] >>> 0x20 - _0x696ed3, _0x2ead27[0x1] << _0x696ed3 | _0x2ead27[0x0] >>> 0x20 - _0x696ed3];
    } else {
        _0x696ed3 -= 0x20;
        return [_0x2ead27[0x1] << _0x696ed3 | _0x2ead27[0x0] >>> 0x20 - _0x696ed3, _0x2ead27[0x0] << _0x696ed3 | _0x2ead27[0x1] >>> 0x20 - _0x696ed3];
    }
};

function _0x56adff(_0x367ce7) {
    var _0x388197 = '';
    for (var _0x4eef0b = 0x0, _0x2716d4 = Object['keys'](_0x367ce7)['sort'](); _0x4eef0b < _0x2716d4['length']; _0x4eef0b++) {
        var _0x2f46c3 = _0x2716d4[_0x4eef0b];
        var _0x462021 = _0x367ce7[_0x2f46c3];
        var _0x404b5f = _0x462021['error'] ? 'error' : JSON['stringify'](_0x462021['value']);
        _0x388197 += ''['concat'](_0x388197 ? '|' : '')['concat'](_0x2f46c3['replace'](/([:|\\])/g, '\x5c$1'), ':')['concat'](_0x404b5f);
    }
    return _0x388197;
};

function _0x5c3ccd(_0x22f4de, _0x1117ba, _0x3918a8) {
    _0x22f4de = _0x22f4de['replace'](new RegExp(_0x1117ba, 'g'), '+');
    _0x22f4de = _0x22f4de['replace'](new RegExp(_0x3918a8, 'g'), _0x1117ba);
    _0x22f4de = _0x22f4de['replace'](/\+/g, _0x3918a8);
    return _0x22f4de;
}

function _0x1b7f09(_0x527311, _0x4393a1, _0xf563b9) {
    var _0x327542 = [];
    for (var _0x1dfab8 = 0x0; _0x1dfab8 < _0x527311; _0x1dfab8++) {
        _0x327542[_0x1dfab8] = selectFrom(_0x4393a1, _0xf563b9);
        for (var _0x8cf356 = 0x0; _0x8cf356 < _0x1dfab8; _0x8cf356++) {
            if (_0x327542[_0x1dfab8] == _0x327542[_0x8cf356]) {
                _0x1dfab8--;
                break;
            }
        }
    }
    return _0x327542;
}

function hashComponents(_0x20a5df) {
    return _0xb28cc7(_0x56adff(_0x20a5df));
};

function splicingObj1(_0xfab512) {
    var _0x3669a2 = "";
    var _0x5b7fef = Object['keys'](_0xfab512)['sort']();
    for (var _0x115e41 = 0x0; _0x115e41 < Object['keys'](_0xfab512)['length']; _0x115e41++) {
        _0x3669a2 += _0xfab512[_0x5b7fef[_0x115e41]];
    }
    return _0x3669a2;
};

function encryFunc(_0x4873f5, _0x14bdd0) {
    var _0x1f75bc;
    var _0x34ad50 = '';
    var _0xc04719 = '0123456789abcdefghijklmnopqrstuvwxyz';
    var _0x40bd43 = '8';
    var _0x4750fe = _0x1b7f09(_0x4873f5 * 0x2, 0x0, 0x23);
    for (var _0x4a1494 = 0x0; _0x4a1494 < _0x4750fe['length']; _0x4a1494++) {
        _0x34ad50 += _0xc04719['charAt'](_0x4750fe[_0x4a1494]);
    }
    for (var _0x4a1494 = 0x0; _0x4a1494 < _0x4873f5; _0x4a1494++) {
        _0x14bdd0 = _0x5c3ccd(_0x14bdd0, _0x34ad50['charAt'](_0x4a1494 * 0x2), _0x34ad50['charAt'](_0x4a1494 * 0x2 + 0x1));
    }
    _0x1f75bc = _0x4873f5['toString'](0x10) + parseInt(_0x40bd43) + _0x34ad50 + _0x1b4f3e(_0x14bdd0);
    return _0x1f75bc;
}

function selectFrom(_0x2bde70, _0x420fec) {
    var _0x14cef0 = _0x420fec - _0x2bde70 + 0x1;
    return Math['floor'](Math['random']() * _0x14cef0 + _0x2bde70);
}

var components ={
    "fonts": {
        "value": [
            "Agency FB",
            "Calibri",
            "Century",
            "Century Gothic",
            "Franklin Gothic",
            "Haettenschweiler",
            "Leelawadee",
            "Lucida Bright",
            "Lucida Sans",
            "MS Outlook",
            "MS Reference Specialty",
            "MS UI Gothic",
            "MT Extra",
            "Marlett",
            "Microsoft Uighur",
            "Monotype Corsiva",
            "Pristina",
            "Segoe UI Light",
            "SimHei"
        ],
        "duration": 47
    },
    "domBlockers": {
        "duration": 42
    },
    "fontPreferences": {
        "value": {
            "default": 161.296875,
            "apple": 161.296875,
            "serif": 136,
            "sans": 161.296875,
            "mono": 119,
            "min": 10.09375,
            "system": 161.296875
        },
        "duration": 44
    },
    "audio": {
        "value": 124.04347527516074,
        "duration": 2
    },
    "screenFrame": {
        "value": [
            0,
            0,
            50,
            0
        ],
        "duration": 0
    },
    "osCpu": {
        "duration": 0
    },
    "languages": {
        "value": [
            [
                "zh-CN"
            ]
        ],
        "duration": 0
    },
    "colorDepth": {
        "value": 24,
        "duration": 0
    },
    "deviceMemory": {
        "value": 8,
        "duration": 0
    },
    "screenResolution": {
        "value": [
            1707,
            1067
        ],
        "duration": 0
    },
    "hardwareConcurrency": {
        "value": 24,
        "duration": 0
    },
    "timezone": {
        "value": "Asia/Shanghai",
        "duration": 0
    },
    "sessionStorage": {
        "value": true,
        "duration": 0
    },
    "localStorage": {
        "value": true,
        "duration": 0
    },
    "indexedDB": {
        "value": true,
        "duration": 0
    },
    "openDatabase": {
        "value": false,
        "duration": 0
    },
    "cpuClass": {
        "duration": 0
    },
    "platform": {
        "value": "Win32",
        "duration": 0
    },
    "plugins": {
        "value": [
            {
                "name": "Alipay Security Control 3",
                "description": "Alipay Security Control",
                "mimeTypes": [
                    {
                        "type": "application/x-alisecctrl-plugin",
                        "suffixes": "*"
                    }
                ]
            },
            {
                "name": "Alipay security control",
                "description": "npaliedit",
                "mimeTypes": [
                    {
                        "type": "application/aliedit",
                        "suffixes": ""
                    }
                ]
            },
            {
                "name": "BaiduYunGuanjia Application",
                "description": "YunWebDetect",
                "mimeTypes": [
                    {
                        "type": "application/bd-npyunwebdetect-plugin",
                        "suffixes": ""
                    }
                ]
            },
            {
                "name": "Chromium PDF Plugin",
                "description": "Portable Document Format",
                "mimeTypes": [
                    {
                        "type": "application/x-google-chrome-pdf",
                        "suffixes": "pdf"
                    }
                ]
            },
            {
                "name": "Chromium PDF Viewer",
                "description": "",
                "mimeTypes": [
                    {
                        "type": "application/pdf",
                        "suffixes": "pdf"
                    }
                ]
            },
            {
                "name": "Microsoft Office",
                "description": "The plugin allows you to have a better experience with Microsoft SharePoint",
                "mimeTypes": [
                    {
                        "type": "application/x-sharepoint",
                        "suffixes": ""
                    },
                    {
                        "type": "application/x-sharepoint-uc",
                        "suffixes": ""
                    }
                ]
            },
            {
                "name": "Microsoft® Windows Media Player Firefox Plugin",
                "description": "np-mswmp",
                "mimeTypes": [
                    {
                        "type": "application/x-ms-wmp",
                        "suffixes": "*"
                    },
                    {
                        "type": "application/asx",
                        "suffixes": "*"
                    },
                    {
                        "type": "video/x-ms-asf-plugin",
                        "suffixes": "*"
                    },
                    {
                        "type": "application/x-mplayer2",
                        "suffixes": "*"
                    },
                    {
                        "type": "video/x-ms-asf",
                        "suffixes": "asf,asx,*"
                    },
                    {
                        "type": "video/x-ms-wm",
                        "suffixes": "wm,*"
                    },
                    {
                        "type": "audio/x-ms-wma",
                        "suffixes": "wma,*"
                    },
                    {
                        "type": "audio/x-ms-wax",
                        "suffixes": "wax,*"
                    },
                    {
                        "type": "video/x-ms-wmv",
                        "suffixes": "wmv,*"
                    },
                    {
                        "type": "video/x-ms-wvx",
                        "suffixes": "wvx,*"
                    }
                ]
            },
            {
                "name": "iTrusChina iTrusPTA,XEnroll,iEnroll,hwPTA,UKeyInstalls Firefox Plugin",
                "description": "iTrusPTA&XEnroll hwPTA,IEnroll,UKeyInstalls for FireFox,version=1.0.0.2",
                "mimeTypes": [
                    {
                        "type": "application/pta.itruspta.version.1",
                        "suffixes": "*"
                    },
                    {
                        "type": "application/cenroll.cenroll.version.1",
                        "suffixes": ""
                    },
                    {
                        "type": "application/itrusenroll.certenroll.version.1",
                        "suffixes": ""
                    },
                    {
                        "type": "application/hwpta.itrushwpta",
                        "suffixes": ""
                    },
                    {
                        "type": "application/hwwdkey.installwdkey",
                        "suffixes": ""
                    },
                    {
                        "type": "application/hwepass2001.installepass2001",
                        "suffixes": ""
                    }
                ]
            },
            {
                "name": "腾讯视频",
                "description": "腾讯视频 version:11.103.2233.0",
                "mimeTypes": [
                    {
                        "type": "application/tecent-qqlive-plugin",
                        "suffixes": ""
                    }
                ]
            }
        ],
        "duration": 1
    },
    "canvas": {
        "value": {
            "winding": true,
            "geometry": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHoAAABuCAYAAADoHgdpAAAAAXNSR0IArs4c6QAAGBBJREFUeF7tnQmYVMW1x3/VPTMwgxKUTVBAGOKggkmYmSRqNIqKxiDiEhWXGJfQaIx5RqN5WZ5kM8tL8vKMikOiRmM0iyZqTMyLUUlc48yAChoQGAQFRBF9yjJM93Rlzr3dMz3dt++te/v2InK+jw+0azl1/reqTp1z6pSijKQb9Gi6aEQxGU0DEcahGQ3sl4et5Wg2oHgJeBHNUmpoV8vVev3z9ol068nAFDSTUXofUHXAIPtvPcj+t0VbQW0Fvc3+t96GVq+gWAosIaqWqgsbVzZoPboLGhVM1tAQgXEad/40bFDY/GlYWgPty5VaX0YxW12rUjKgJ+oBJJmBZjqKI1wAdWcruR26t0L3NvvPHts047Xi/cAkIBpsVF3Aw8CjwFNRpV/as04xrA5G1MHwQbBnbbCGbdAXKvjrQPjjC0pJVyWlkgCtJ+gZwOyer/zMQKMTMBNv2aAm5U/cvZkPAAelQDfoUMD9I3CfV9naahguoNfBuCFYH0EwugO4s0Op+4NV91+raEDrA3QNnVwCzOkZVINv1pJdNriJ/4fE276rWxWGA83AR3NnuXwqt/V8C78GOoK1DnsPhn3fZ4O+W02QVpYDCwbCdcWe5aEDrdGKCXwZzeUohvoevYAbf9MGWSd9V3esIBPvYz3r8uEId9wI/Bx4K5zWoUp27yEwcQ/7b5+k4Q0FP+qA76GU9lndqHioQOt6/Rk084BxRr1nFopvhvgbwWevQYd37wHXToNXphoUDlpEZvmkoVC/Z5AW1vQAMm+VUr8IUtmtTihA6/G6AcUPAdmL/VF8UwrgLf7q+SgtS/N3U4qWVU0Utk8Aw3w04rfoXrtBw1BoCNTJ/RquWK2ULO2hUMFA63o9B811QLUvjmRp7toIieIBLPzc2XO0+AaQo76JZn5Cag/3xbjPwgL4B0YGWdLjCj6/SqkWnz06Fi8IaD1et6AsZcuckp02wF2bzOsELPnVlLLlWl2UtVkBO/BTTWa2AD5koJ9aPTshC1YrFfNVyaFwIKD1OD2KCHekzsLmPHS9Cjs2gk6Y1wlQ8rUeRes/elbnf5rWHQ+cBgw2rRCw3MAqG+wP7OWrATmDJ+CslwswvPgGWtdrsWLd5evIJOffHeuKqmilJfci8LkgRyY5islJf6QvDIIVFoXtI3v7PYcvV3DqKqXEeuebfAGtJ+qpJJFD/ijjnkTZ6lxX9Fks/DwPXNAD9OvGzGUVlBl9Ts/JVoywxSaZ3QK2P2VtQwRmrFRqkV/2jIFOzeS/GoMsZ2CZxV2ykBafZCZ/uhCQ0ywK2J8p0cyWPg8cYQMuZ3EzElv6dL8z2whoPUaPptoyA5tZuMQW3bm26Bp1Wi7yKZ0VZLnOJ1hZxmVp2N1M8gWXEs38Y2P92NKXd8ORa5TaYNq3GdDj9SPGipc4G7avhuQOUx4KLicGdGPFy7Q3UdAuNC0cQrnBA2DaeBiRdrC5tykK2mqljjTt2RNoX0eo7ndgqyyipSOjI1RQdkp19Mrkb8Z+MNpsKfFz9HIFWtfrGNoyDXuTGEC2rfIuF2IJMYZ8LcT2HJuSM7YAXkqaXg/7mtnMFcRWKbXAi728QKfMmkuMLF471sMO4+3Ciyej38WsKVbM4p7IU16vS4tsLnUaceMoaDRS/+MapniZS/MDPUGLi9bbdi1Wrs5XjMAJs9BnM23XYTbs1JbYxuXYVWo6eB+YYnSwv79DKTHo5iVHoFNeqFs8xyVn5O1rPIuFXeBu4MqwG/Vq75SeyIRier3y9f/xcUZnbQXnuXm9coBO+ZNXe7oaE2/CtsAuey+x5v1dnLUfB9YFbiFgxT2Ay0sdfJXi9ZgJMF4YcKU1HTA+nz87F+gJ+j+Ba1ybtI5QKyFZ9B0yh435YPlDy0LTU19ZqTuvrYLjJtpxa+70lQ6lxCObQ/2AtsJ/trPeNTJELF7bV5TMGJLJsUTUHQK86TXcYv0ukSpfDh58WBBbYlQ5/v2uFjSJVKmF0U5hSf2BnqC/2GMP+pErQ50vl8ysmc3HTZ5LTUGiNKt8PHCoWdHQS4m59NAxXs1e3qHUj7MLZQO9zNXMWSblK8300YAoD2UlMY+KD7Rc5K2cLe9QSs4J/agX6FRIrhypnElcjdtWlMQL5cSAGNrlSFURJEetHFGWiDPxeskS7h5qfEJ2KHEm0L9yjbsWkIOG3YYgg8tM4q5D6MeoCYkbl0CFcpH4sz8ptxXy0h0dSomfp5csoFMx2Pm9EBIZIj7lMpEoYfuXqe+83UogWlUZmRLXpkukSgQGrlSqF1Mb6AlazAESNZJLEuO1dXnZlmxh6C+pqJEyijW3a3GZHVhGjmQJn9ngFoN2aodSYluyyAbaLcivc01JAvncRFZUD1VQrMrh2crmVaJTRDlzoGzPVnpGS/xw7g3GMniknJiuCG07mzEJ1xbFodx0bH2+UOIXO5TqDRRR1tXVeB6L4rblZTGMZMpuY8pIUm55OvYvxhMz13Hx2BdDiizhDlQNe6ev7Co9Xp+AcrhIWOYzc5rvh1K39IonqQJaLucxK5PtPGdrDTNXK2UdmZXOZ9uugNksDJbVtu31DZTL9p3NV/5Z3Wv7FqDFHSlxj30kF94k7qsCSNyRvapjBfDTjwVxW8p5pRLoqPE5F/s03LpaKQtbWbpzA//KbBzJlFtRAv/CAmZCKlo0rPYKacfBiKJg4apUAKHM6P727QrRtNNjPibMMN5CBOlUt1I07zRvuRp4r+YtQPe/eC1LtizdFUL1FcJHXja+U0EMyp1sWcIzqEMp6wjdH2hJJ7H1+fAyDYQgg11A+xCi3PY47cB+aTacgZbrM+JvriDaBbRPMMRfLX7rFDkDXUFKWJpRX0CrN6FqA0TXQ/RViG6EtyXWPJ9DZm8YXA/dI6F7L+geDYlRoD3js/qkX0lLt3CVpZTlAi3+5q3/8vn5FL+4O9BxiD4L0aVQtQTUWkgmoSsJ3T4T3UQjUBOBSAT0WOg+CBIHQrf4JF2SOVQa0ALJyfv3+qtzgS5DEL7JZ+IIdNXzUPU4RB+EqIKkhng3dHUjKQIKIlFdaqJQHYWIgm4N3cdA4lAb+GyqRKAzgv8zgbYdGttXQTy0hEwFyTqzcp9DIwHVC6HmLxBd21dEAN7RbYMdJgnIA1KAp9vtHgtdx0FcAo4luVyZw4ryjVeu88i1HugNK1K6Xj+C5gi2POedkS9MQRq2dSaaf1b/Gar/AFVZieUE4B1FDjkeUGUDnkmJwRA/CfY5Hi70vKdoONIQi9VVw9kHyeLWe+NSLGO/QHeeyxbJF1BhVPUEV9bcyd1V4sPKoq1d9rJaCpLtYZBDZsCjR8IJs2G9BCFXGMkxa8jAX3QodZ5wZjs14puvqRTbtiWu6CaouR2qn3B2amzpCn+p9sJJlvLsNJBXABfJAnkILDkbNgfKKebVc7Df5a71xD0znBriptyx9j66Amf+CMZIvlpVf4eBLRCxl+QcN+X2hK14lYNEQZNbE2mSy6pHpf7jnSj8Yy6sk/27AujA4ehDx2a4KSXw4K1l66y0yOWm6puhViLE+qhf4IFo1Z1F3pO9ZCCxWqKVCz0J9Nkm7P/30HGw6nyvVor/+/BBVJ80qS/wQHrUk9qTbJJ0qOWizVBzPQyU69i5ZGneolVvi5d+yc5mR5ZwUXbqFfwtj7yemAJLJQlWoHygoYCwb1Tphy9s7M2Ao6zM9XfrFbSG0n6ARtZC7f9CdX7TqxUcKNq1aNmVQKKFn1sFbmfolWPg4S8AY8vC8Rk9B8DvRNX75SUBYUDplrZZPM8fkFThJacO2O2HEHFPF/mXpOZzomWXSMn2FIOsfdfXwKc8FsEtw+AO0djEcV1aur7nFYHj4CQVa7onDfTXSfBNri4tI7AWdv8eKO+coF2dCfaX/bmS6PdROMwggr9zGNwmUYSlndkSZFAN/6ViTd+ygb6x7TcoTuO3wLOlkuRmGPRdiBpmS9ga57LupPdTCKViX8zfl0RglmFC443j4F65dl6aPXsm8D8iC81v1dym01MzuvVxUIcgn8AvSySp2mug+hmzzkQJ29JlZbOruEt2Z9XAIEMd9sUPwsKvmI25wFI/A6ZZ6PK4mtMkbw9Ye/Ri4INW2z8JI8eiB5cDboUBfzIfSlwu3tvZtisikD/Tvj2tGiYap3aE1k/C4nPNxx6gpGgDD/bVe0bFmj6UBloywNlX8x4H/hygddMq1Y9B7bWmpe1ycm5O7c8VdxF+ShQONtinM0f84KWw2ppkRSFZMyS7ZYpWqliTha3SLe2vgN7b+kH0ne/1pPyRZ7/CpugbUHcJKJ9KlcxmmdWpLPoHV1Jqi30jMN1wn07Lc2tPVt8Hfgqb/b8r4wWJpKB7qr/3/FUVa7IyMcvSLSlB+tLU/b3nDozk8A2ban9i2a59U5bzoqwB/dkB+8MicLJPoEUA/zoEHg0/bULa9J4h4y0q1mRdGhKg5fpxH7dyVpUsJmFmhKl6AupEAQhA78j5ue8AXVHppwYoODfQe1dw7xdgY3jJUGRJljmarRqqWFMqCjQbaMFC0n6Hdj1CQ92l4ORqNME9C2ipUjEJ5WoUTOqZ1c/53I5kEHuNgplPh5a4zCmhnG5pvVrFmuXKvsPSnRa+HLXkyFUoVf8Jam8N3koev3NFpIgcquAUeWa0G9oDOFuOvgwmSJa6giknRaSe3zqPCF9TsWZLW+yvjGX2JwYrUZADfKx9zcSh7qLcyBA/48pQxjKrSc5CyQTl8Uqln56cy4qjKl/S10xlrK0bFvkEe9gQOFlOtwH2+QwhZyd9tUFWV4N6U8UaLSuN7NF9x6vsoYqjw7KUBqTqv0GtZ4Zh98YzjlfZBcuexjn7eNWagMU+Z8ZhX4L9xfkRjBTMzXwbqw9kq721KtZkpUTobzBx6kuADurZGnRF/0C+IGPJMJg4VS9q2guv9BVOBpOnE/CMD7CHjYGTxbHtn7LTV2SBLA0uVbGmKSmgUyZQt37kxU6/t2glJLfO0gMKo5QJ1K2Roty4NHlqIZ8J9J8JeNYH2DNuhNHeGbMzZZD91IIDyGLsflLFmq2Atj6nhpsk3wHELOUn2mhACwyQQKAQaGvcNSC/KI+nSJCI24NnIzycGk8lzLXxqcdDk68tbnkcpqUfPHMGOcep0fZ14JuecEhMj7yBavSUcxwGzQa5/RAGuezT6eZL/hySifnzyQQsMZjZIyNwosQHGJ3J+z2HlBdkWzAZbkoJPIA/GOGxPuXh8gI70ga7/cCoSaNCsnwbBB6U7IEz0cRn1YAcr7zoiQQsNQD7jPkw2DWJvvTU74EzD5ClfEbggYQSdesVXvz2/i4zW9Rdt2W85hYY+IBxk0YFDUOJSvJk4UFR+KgPZ8bjCXjeA+zDPwWTLC9yPur3ZKEByHJdqS+USFrVLa3bQZk/gyozWgIV8ilodZdDVcjXb30EBwZ6hFTc8yappGoVnFQNuxnM5kzIHkvACy5gjx0Hx4n7MJdE8UrCmekHzYxARneqWHNtujU7oVxL+9Og/T/643T0kquruxf8Cq7zV+0z3Nfo6OV1hMrm5JAqmJx1RcdoSepxqHuBfUEbRPu/RGtwhMrTu2pVscYPZwHdeh0oiU/1T3LGlkxW6Y81rGNVPk58BvDLLjPP6dmkIA+F10fhKB9LttMY3PbsT86HvXv3aXko/JLMN63MZnK6U329ijVfkgV0mxxFJY1zMBJzqWzJVkTaA1Dr/cBOsI5StXxeyRFzqTw0IeFIFkmubXk0y88NGlmqzzTSir2Hlu/oddRlUG/Zvu/vCaC6IvMtK38gWyycpWJNvbG99tL9s/b9SeoXvDn0KCFer8dautj+UEgScekvwCW7u/aAa6fBOr/PGqWdFwULKKMBBwvaiENm7Hh98o1i0pSDbC8FAFnudh+gPtvYm9mgLzF7S5vkfzB6Os11vFMvXknrpomINa3Y161Nr83KoycSvXM4yH0UeYPRmL2mKpgacE/2+jBSXi+J+pD3TudOHvNS5NCn+qUVCgQyrFexJjtqKEV9QN/Yeg9KnejFm+fvR3x6Pft1SiJZuE2uWBQ5UZjbRXgJ5BNl66O5L9t4sifa9Yej0FAkkFNh/Wcs7ubTrQnbf7XfsLfUkc/2JlAJCLIEatyr5jaLfcQB6F7XlieU7gVOOBVGZVnEZHMUhe2+AtvOVz07tYXEXR9k/u5FP/YE1wOjtmbt9whlODyJuxaVywrJFRK7uNjH942gjn3Z3k4LwSOpv6EuahYd1BHoDxHx/6R8zthO/xS8L88ZU6aRmL8fTT347NdRkk+Qsth9RIKWNYzshteT8IbP+ztDFfHRER7aL8qjQ5X1HnXY7B2WAtdRgRHr2aokatbLqiCQRUZJPVVd1CyO7lygra9oQdtf0UhWxuB03mnmfnSxbMgFSjFniVTlLVOxuOV7CVEAlTc5RZOQAGZJJS9OuOyrq8L9Oxo2pACXf1t/UsMSw8juyv4jipasQPLvLCome44CFoPKP+76hh00EJAUD6o5TRLG2I/6v3vV0irxuD8N2IVdzQ/QBXW0E1aWp05uFZNjIaQ/r2LN17kDffOSMcR3yGlY9NRg5LZ0B2vxvVPrLQ2//V0h491G9YBJ6vwpOfbn3EdIW1rvBCXXa4ORkzIWrKX3Xi3Zav7o/FiRmTD0r1WsebZT2VygFyyaiU7ea9awQ6mPn7OBhh3W7YBd5FMCLw5cz8LbgtsyVORENWeq49nGUT0uSCkTg0nTpok+h7iruEhg0dAVtM13faIur6DyKGHp8nmAXnQGOin+AP808atLmbZisv+Ku2rwyH7PseLbYgHwTyoyW82ZKuYpR8rrVNUL2h5DB3hAd0TLImY95Nea7H9gO2ONe45axGsx/7LLuAcdAOjW89FKQgL9Ud0jizl7vnUndxf5lMDtFy1m25H+Zaf0BWpO881uvbmGSQSb1W90Meei4nuvfMrwXVF8wfwuGOpPdgazWcbuAXRADfzos9cxoauf9+RdIehyMtlRs46/3e5fZi6aduZwPAOfdEv7TaD9pcLb51vLOH5JuZ7SLidcwfv+85RlvPJ1nzJTN6tYY0aCg/zdewN9U2sDCfWYr3iM6oWvct4N/YOfgovgvVHzlotfJX6EH5ltokp/TF3QLPnWPckTaGlBt7ReCer7nq31FojDibNBAtN3kbcENibhXjkZ+YlH01epWLNx8LwR0BbYfj1b+1/1HIetDnYm9BbNzlXi0fHP8a/vm8vKwzjiJBxzoOe3ir9aspuYhdTVLlzCOTdYN/l2kYcEfnnxErYfYSqrTST19Gx/s5eMjYG2Z7XPs/XMs9awV9z5yXIvzt4rv79avYb7fmUuI4Mzc0EzOl1Zt7T/FHRvvLArHiNuaWPWA03vFcwCjfOeT7Tx2nmGMlLXqVjj54P042tG24pZWx0KiUQxSKmTgE+c9TZjtNsF1CB87xx1XlZv88CvBhspYYrH0UxXsaZAWeB8A22BfeOiJlTy/lRgj7vQ97zpBU79vwN2DmRCHsVdx77A5gtMZLMRHZmh5k5tC8pBIKBtsNtPRmmDJFUapp39OhPjEny7i9ISWFn9Og/fPtzDOGmX1uoUNbfx94UILzDQtnK26Hx00tvxsdt9yzjzdp9Wn0KG9S6oe8fZy9gy01smKnKBmjPV1WFhMtqCgLb37NbLQP3Ys7MPf+5ZPvi6RFzvomeGP8vT1xvIQn9RxZpdL02bCrNgoC2wTYLNq15azulX1jPIl/nHdBzvnnJbSfCbH6wisW+DO9Nqnoo1hpDtx+4lFKDtZbz9JLR230eG/GYRp93t37H+7oHRm9PfnbKIN093l4FSJ6s5jWbpRrx7DBdoexlvOzLzdqojDxPnLWbaC/6d64YDquhiDx+wmJXzvMY+TcWaHgl7HKHN6DRjuqVNLsfIXev8Tz8fPGcZU97yVkTCHm0521syZBlPLnAbs7xoLnea5TZQ6BQ60NbMvqH9IKr0DfmNKpthxqVrGd1V2qdjQhefYYPra9Zy/7Vj8z6eIsaQhLpYXdz4nGGLvosVBejUMl5nuzbzmUvXwjlf2kitlttUOy9tVxv55X+PzP8ckroOxOUYzOJlKriiAd27lNuOEPFlO3i9OmD2V15j96TTNTnTMVRuuXcir3HnNSPyPHC2CaWv8grqC2twRQfamt3i4oyq7zvf1FwLh39tA5M6d67bHcsGbuAf3x7lOJMVD9Ktr/LraiwE9H8DS/2Y2JDkvzUAAAAASUVORK5CYII=",
            "text": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAAA8CAYAAABYfzddAAAAAXNSR0IArs4c6QAAGbNJREFUeF7tnQuQVNWZx3/39mtmeAyP4TEMjCBvDaCI4rqkgq7BFMaNsRaSyhNRRmTLR0qrzGbLFBWzJqnSTXArSkBRk5jawGrMGk00ibgJMT4QBCSOvBkeAziCw2Ne3fee9bu3T8+dO7d7unsGGMw9VVTR0+ece853vv/5/t93vnPbICyhBEIJnLMSMM7ZkX9MB65qUB/TqeWclrGCUBeLWPhQaEUI7XQ2OeMALo3BgD5QFoOWJDQ2w8nW0znFwL5DABcn8hDAxcnttLU6YwAeUAaTK2Fgn85zOd4MtfXQcPK0zdPfcQjg4kTd+wG8aMU1GOp37vTMJ8Eej6GW8JPFm4qbsqeV9A2301Iy3/lrSctqDPUiK255qNt9Swdf/WmfQvvMBuDD9Gc2d/EjVnMNW7s3vAnD4JNfhOrr4dR++NtDYIvVNWHSYhgwGQ7+EdY9BlsPcCZIfQjg4pY0GMCLVjyCoRanu2zAUFejjGuxzcd4dNHh4h5VRKtblk/DNu+hpWQRJS2zMNTPnbH0FHhlY1DGC7SU3EhJy+MYai5wR48AuB28BfUZBOBTJJhPDS/wCX7HQ90D8OgKuOwf4aqn+ev/vUosHmNG5V7YfD+MX0itdTX79uzl09fNhb8sgjefh3fri1i8wpqEAC5MXrp2RwDfvHIYpv0KytjlWKWffe2Ux4pc1mPgyXesNT+5HWVMZmXNrfk2Kaje35sFNg24+gKYuAB14V18etpMB8C//fPT8NI1MOtxFi78Prt37GTNy7+l4tTvYfMPYG2t6x+fxhICuDjhtgNYWwzpR4PX2+eiFQsw7Y09Yv3yHaswASkhgOkRCl05AC6uhmGz4PIfs+y7PyCRSLD4a9Phtdtg6rf45Sut1G75G/c+cD/mlvthzxrXH971fr6rVlS9EMBFic0Tuhe6qow/APdlpZDaQsMkh3pGU7dhRZ5Hfxbgu1RXqOlyDPUuyhA/8z8w1K+dIQoFts3hab/Wped+Sux9jp6XMj6DaR/6yCL/8qN+v5BpI1YalqWr1WKbsx2a397Hz4E7UcYbzsZU2nxTun4tyvgBMM/nA7+KMq5I0+n2/jr44s7TXKrdzlruBK53XA+Xlnf2q9tdk/Z+vet2y/JpFerU2w30zfy1gpP8gR8ynOMZH/g9hnEHX3DqLOZPPMJTvMiFfIbbmcs7rGYFfQiIJE8eAWMq3L5LhkJbI1RcAi1H4PgOKK2E8onQ8AaYCUieAJWC+kbYuLc4DcuzVQjgPAXlq9ZugbWCClBW1ryYtbt2S/1Qpp7XUrrfz8NQ/TPA0gpd0vJAWsGXO1a1Kwvr/b4dkBUZ0HspsNB9FyCzsSLziFhrOmws7vcSEPuRA3IpXnfBUWoniOW6Ck1lO5zPUEdLyd3p/7tzdjeNWzs8R9qL7JTxdrrfO2kpWZcJYtnmLzHtZ7IG4NJy/Z2xbK4EqQSQX2GhA95p7O9kgeX7O5nPKzzIMI4jfvIaLmEBr2bXhGmjoGogdluEurq7GXz1pVnrHl9fyyB1P6VDmuDoSXhtV3EalmerEMB5CiorgLUl6wrA0kFnwIrin+8AI2INxzYvZmXNE46iiwXWlLyrz/45+AHusgTXArcDrH0j8VpDL5AEdMEbT+4otBfw3uBd8EZwpwNu7xg0gKERQ52Hbd6QNQjotnvmbe67QgP2BhbzML8IBLAObAnYb+dlB/BSckaop4yEUYOcqPKf/n0ubSdKsmqNYdrM/sFzREoseP8EvLm7OA3Ls1UI4DwF1W0L7AK43ZIZaizQz7FsyhAaWZnxlbsCrP/7QgBsRQ5lLJ1mDN5jG9fiSUCuM7B0/a6CWO6G8XAGeB0jyy4Nbrfk2QHsRrddC52L3Sxa8cgy478XCyA3MZIlfIlnWO5Y2CAfWED7EFc5lHkZV3ETf3HqZi1jh8LE4c7X762Zyr4/jctadcjUg0xb9Jr7fd0H8M6B4jQsz1YhgPMUVFYAdx3EEmslAaWOVkYA21KyBqHHbnnd+SyU9XQC2EtxdZDLa2X9FthrGfMFsBfgLv3/F48P76fiuQD8Isp4L0Pfsx3F+Xxg75FREID13+7hRQ5Szrf4bW4tGNwXZp7v1EmejPPmf86m6f12f1s3jvdr4dJvvOLSZymb98H+Y8VpWJ6tQgDnKaisAJYvdCBLB3wEhFJcRb6+QzTYpbfVH/1bxcqap9NWWRIu2s9RTyeAJfDlp/1ewCVa+3ay0NpHFsvZmjiZ9k/ndjgLFp9XNgTvZuAPnmkGooybiFgpbPPJQEvv9YEl4KVlFhTld5/3wCHj7sVBVjRbFFos8H1cm/GVc6qBRDw+NRHKEi6IT8WoXX0RRzZVoSxTAowMnnyYC764gcTAFrerlAUvvwspuzgNy7NVCOA8BZUTwPJlcATYDTp5i98/9Fs4b3RYgliGkujKd50ugj57lbrzGNxotdu26yi01BP6LNFxt41LXTtS4AZAaP8VAWfenSlvx+SW94DBgGSDjQImpJ9zI4a6p/25vImBjhTd4Zxp6wQZP53uOLaMpCXKvJTnnAh0LS799VvmpVzHA/xPcOTZrxeD+rhW2MgzCe/tOjj4YXHaVUCrEMAFCMtTNc9VLK7zHm/lDWL1RDZWjw+wGx2mo/fKqHnc28urjHWAKYGtoCK+8kaqc0ef/Q1HlMPUapDEjlzlDJz/6seHAC5Od849AOvUSk3vi5t372uVzjpTRo1OYXWOhn7EP3Enf8xqXe/hBr7EG1kBnnWicvto1GAYMQBK4+3V2lKuxZXA1Rm8lRQCuDiV7P0ADor8nsl87OLkWnirAAqtkzj81les7tV8A0n46HZudOEjPS0tQgAXJ9beD+Di5nXOtjpj1wl7mYRCABe3ICGAi5PbaWsVAvi0ifZj2XEI4F62rCGAe9mC9PLhhADu5QsUDi+UQC4JhAAO9SOUwDksgRDA5/DihUMPJRACONSBUAJnQQJq7ewo7InyflmUIU0pGJ0yrnwlVehQQgAXKrGwfiiBIiWgfn9JOc3JQVhmOViRTt0oO4URayRx8qgxd0eOa2XtLUMAF7kYYbNQAvlKQP1mykDajCoM5d4iyadYZgvl0f3Gp99qDINY+QgsrBNK4DRIQP3vBdVYJUOovhYqZ0FTA9S/BA0bOj+tYiZUzoGycqhfB3XPg6nqjc9tPJhtaHlZ4K9uok9pkuGGSV9LEZXOTIWyYrTFFMdqj3H4lSspmL+fBnl1r0uFceObjIzCYBXBoTimQq5UJm2DAXaUk6umITeRzlpZuImJZoq+UZMPll/MHhnI4o2MTtkM7g3jCxLMgjcYHo1QdbbGd7bko579xKiPXggxlJnLoPLKjqJ5/W4XyLrIO7qnf6djnbpnYcO3wYxmBXFOANesJ2ZEGG3ZyPutnGJYWGYUlTIxDUveBA62QSoRpe6RqZzeW9+nGTZfe5WqeMK9s6ds7GgEW9mcNCNYvQUgIYALV4KzAWD1q4sGgDXWsbzTv+cM+qXnn2fDute59a7bKS8vg5eugmQTlFXAnBdpaGjkke8/yKw5V3LlnDnuRF+/A+rXwqnm7cZXOvvFWQG8dCvx+lbGWYpSUeZYjCPDp1G/1CBzs3vBRgbELUbZBnKdJRk/zq6Hr+TM/R5H4WuZs4Ve6IjJ8Z9czPYe7r5HugsBXLgYzzSAlcLgVxdOxTCjzHzAocVbNmzgji8vcgY/ZeZ0lj2xsh2caeu7ZP4Cardsceqs/NVTjJ00CbQVjhmtxmc3v+OffVYA16xnrNBGhz72YfeqSZwIEl3NespsA3m5Ukzo5ohL2OYFeeHiPnst9EJ76enZG03wk0MAF74iZxzAz02oIJU4zxnprJVQMZPnn32WB//tPudPFZUVrH75RZceC0DHfgmmfJPPXn4VTY1uzOreZd9zrbDQbKHbTonsND7/doe3KwQCeMlW+iZPMU78wGiEQ8svIucbzYR6JkoZQhtNJR+w1xrF0LY2hgZZspteZRBlnCf0Ox7nyMNT2Oddkls2Ml4ou/5OK2zK4kDcpNlSjDJMdDQvaRnUPz6d94Xuyyt+LEV/w8QU1qCgcddJ6rryz/UC+1UjYpBSNtvNCEOzUeh5W4kPbmOEUpTr+IC0S8GHOxs54H+2no+pkMBEGVAuz7UNmvu1sueHV9CMwli4kUpTIS9xlo1RfnJUXlBVl4oxKpcPXBLlQPMJqmNRSmzDee+3+O8Nqy6mHqPzrxzdtp3+LUcZTpwyZWf8fpU0abGSHP7pTD7wysW/HkmTqpjtPkvcKzvKMf+8s/nAwvL2tyAvRSwzFW3NMXb9bJoTc8hdfPKRyipKayTJoTabqN/f9gN4wW5Kokedt6jE4iUcePhCDvkfKIbJMBmfsjCtKLufuJi8X0uinpk2AcPu55rbu2Ds1x1gLvnyAup21nHXd+7l2nnXw7ovQ8MWN7g182HWPPkLh0KL5V321ErKysqg9hH3n1PUh8bn39npHWswgLcwygFgWoFXzHCUJ++iQRpJkUqUs+2/xre/ZXxJum9HaW1Orrq0PSikBSuKpIXmUXhZWFF4xz8VkIrSiHKnTA5FTAYqixLDxJLTNPle6hopTlRdxo5crKBmPdWGyUDt16sIdtTGTllY/ZPsbC5lWBCAb93MQDvlbBpOYE8UWLYRDYQgt8IznzZxPfR4bYvW3c1smz0b+8AmxikLRwFkrjLHdFAtqaLYRopEYBDLIBUxMOT5neQQ4UTVtI5yqFlPpbxFVMtRt/EE8GTjqF8xg8yPI/nXIwNcAXBa5rLZ7DjOdr15BQF49lqi5/dlrGnStxDwLlWYB95gnIp2lo/e6GyDPt6AWZAF1gzTr4NayZdsZXhbC1WWQfPuRrZ1ZQR0O4c+PzP1YkzlYqusGq5c7USdk421NDSVUzlljhuNXvv5dLMYzPkNxGLUbXiJyvImYhWToHwKrJ0PTWnxKztl3LC1w4/6BQJ44ZtMFMHKQoycznuFUmLZWfelmIAiRhN7H7uCo3qCNeuZJAKWz7JwXoDXrHcsTrXspkaKbStmkNQKk65/6lgpu9ZcSJsowLj+jHd2bwmqye5vsFfvlIvfpso2GCYAsE6xc9WsYBfAuytlo9BBCrBgLSX0Y3xUQBihpcVgj7YewmBSzYxxAGrRYpjuXORZGQBEUabisGY381YTWTMfSzYT22CIs0lZHHz0cpwfk/P2KZ+DAJyeSzJlUqflcPNrDFMRRgi4TMX7K2ZQp/sTlmUkMJOtvP/4pezXFvq27SROfsDYSIxSmZteC+/4/evhfLeBEVGb4bKJmbB/+TSOyN/9AHZA2L5JFRQ7kXVNWQz3y0dOSuJtjNHsrCsA/+vrDG6KcF7cxBKW5TVSMr6DbzFB9LStlUM/vSI3A/XqkFo7uoQP+7kv6c5aYhArh6S8li1dJJDVJPS5i9+gGhXfbMx4K1OpE4AFGGPKmRBRlHYnmKN3OC9N9lAXoYyGWAvDYveKGTjEPwMUm2OrLsX5KQAPgJP9WtnuUMx0uXkLw2hjpADYbuaAVnZHadI0yYyKrrcrUy6xFgJgHbG2U6SSJezwU7+FtfSLHGesAMQ7Nj0fPzBkXHrjcyxsgOsiQcNIylFSMwjAwhz8G6YjV630UVpHRdm29ELaxMIk2xgum+h7ARZGb6Zilb0Knms9RPH3b2CibKrKoOGx6Ti/x+IFcPVUtnssaEHg7Uo+WubCILoCsLhcKsoEYW1+kGoXUsYe68OOhy/MPzCrfj2xH3bcfcmhlGSMxvpqqBRPocBSX0t5tbPftpdo/F3jurcyjLgTgL0T604wZ/Emhtow0k7RrK34TVsZRJLzooqTyiIiO5z2QfTGIf6U+HorZuBsT1phgs4QNVUXuuvfRb3zEP/5ics6+zl+cRYCYM0kTMWHK2bQwS/R/Wp/3rsRZubjcx+kjVDytlZGCxVsSbDdvyl4AZLFAgcyJrFOJa2Ml00znmBPPsd92WSba/zOeqXZm3d8GsAS5BRXgSiDijm10PJJH+91sJp+mXcFYKmv2Y4/+JrZnAPWqCsIqqemDKQM9+XbMslkjNcf/Dqz/nyrQ5HzLk1J1n3yIWbd+2THJonm7d40y04A9ipJdyzwN16l9ESC8WmfzBG29n8lgGOZxA1FhQZAzXrKVYQxQo1Sg9j2xBicFxMHRV31jM4WgPPdHPR8vX5UrvloRhFknfWcb97EGFIMCgRwlKOPTqPTb6DkM97bXiBxdBCJRJy+ROgXsZ3jw4g/DpJr/DLGoE1QA9iriWLZvewrH8XW/eSSz00bOE/0Kh8Aa0YjG6a2tFr/zSilflaXzxjVC+P601oqrl2mrPv2tTQ1OuGbgkp5ZSMzv+lJ9pDWZUatcc3mTKAv0AfWlqNYH1iPUnbjaJw+QmGHT6VB6JX4KLJwZoyEWGilXH/XjDJUfBv/pnEuAzhI4XLNJx8FDQJIV8df2QDsWGZFlZGibzpinVEwUeq0m+NE4rWP2F0AS9KPLUkybu5AQTGWfOQTFDDLdozkdRc1jc5mSPJFnnrukjJSbZO99bc8OZP6DfIbCIWV6lm1TJrnngtnSqL5HWPujsxPT2Y7RnIicPlGoSXkDs5xQDLVwgEdMNJURKxs22AOSOjeiGAJYJtjxIXWycCELsbElzXp6w/rn8sA9kTcM4qajwVWNq3Hy9gmwTr/kucCMHlYYOLsf3QKh5espW9bf4fqxcR3lmBb1KQZk6bSU5w4DqVy3Od3T7oJYCenIHoSM8228jqm1DLIB8Ba5vlYYOnXo6NODsORd6iSE5hcrlEuGKrVRIhNuchbp6m+nHXfl1TK/Cl0jCQz732JsgrPAZBp2vzzprcNz3Fgj5wD6yCJnxYtXEe/SB/GYpBUERrMVqqMCCckyynj80YokWhsymKwl25nrHhA7q/+7mxRaHm+9vWK9YGD4gt695f+s0XOte8dRKHFl1sxg1q/gul1kOM17QNrliV0tCrGdglsedtl4hW++EJ3AOwF1YK/MjoaZ7BY5JIEO/MJFOVabz12Pa98AZwJWMWcY8Ddcq6NTUmZxd4f+87A87Wf6plPTMYwOnDm2jVTqFvn/lBIPmXsnC2Mvda3lMo8YdywaZu3fdZMLE9yQ85MLO9Onkpy/InL21MQNUiFLlkmzZKA4LWwOlKdPmpJSDKD/9iqN1pg787dVRRaIqLeOeeaj8hrYjkTJH3Ve+ST2czSkW0nwSbgMoOcQ1v92enPmtPBGu07Sn86ApstUKnXpid9YC+onIhyExMclyrgjDpIybuKQotLEGthnJw85Atg72acMvkgBgPE4HiPzvIBnLeOenpyJWZ0hL/dzmensHNt1yAOBK+zaMY+44bNztGcLjlzoQ8kGS9h9sBcaIWxeDNDlEVlOpEh8EhAK4880G+hddBGDybo6KS3Ari758DZgCPHO6lmRlhRVCJGvc4S8p9zZjsHFvrdFme350x6eGuSykgKI1rKQd2fZhDpDKZd2scVf9m2GGlGGNjTPrD/JEGOqpJQLcTSO7ZcgMl1DlyiGC36Ku0LAbCclZulVFltKP95eaHgdXC2el6EyHvTMskcnk4aaivY+ex0GuudBLwOpby6gUnXb6F8rOd8OFPDstj0t83G0va7CA6mcg1QDvSbjzt+UoYOONlGLhidTKj0bt7aRrvSePv0pk52SgpIU2ydORQUleytAJY5dicTK9cRnTe1U/xTsy2TieVsgiKvIABLtNu0SMjaOGmN3uyoFEcfvYw9OlnDochNnJfJWEuvq87CihjOeXtMUgm9R089RaG1jix4jfHRmHPbrdM5f6AV7iITSyi5jLuQ65be1Eon8afA1MmgcarVFwwnFqnKhi/xi5NN7T5xrDxJWUWOu/vR+F7jurc6Ibvr+8AKo+Yt55f4KoTa6QWXKKVh0tKa4ugTl3I4KM9WBi+bQGujk9US90eYvdFRUZighILeDGCZn+RC92tiZCxCP51SKcoovvG2ExzMlgvd1Rn7jRsYYkYYJkkdaSVw8r4jSfrKOWqQgsrfbItj3nxxsbC2xWHJF/crk/jc3lxmWVOdA33+ZRzTSRleOt/TABZmkUg5AdCY3wXLalyCcqFtWiOGk1dfIZdwCgGwPEe7DIWmTuYygB1yoosx5bqNaTcan9u6I6iLrgHcnQd/TNqe6dssHxOxnZVp6A3GmwmWz0A0gAtNncwJYKHSpbXjSbmpw0UVZZ4gtWmnMd9lvv4SAjgPqYYAzkNIZ6CKTg6SR3nzvfWjdVwiHiOWb/qstA1KOuqp6ailmEy/YCRWZEhBfUYMhW2/z+fe2e89NgoBXJAU3cqZxJYs56xFdBk2KUIC3sQLuUUUNZDgm5PYn3bHxsgtLnEbdM53tscsFWABr3wK8/y+VJsmA4s9+81nKmr1BXH6RofSpgainCSW4GLQRsQ8ysHoEeOW9ksL2avn8/S/wzpONNZgnBxzONcbFao7Z4N/hyI8LVP2Bt+ca5a2G5XVwTfnSmQzdd4bcEED8QZX098XdLGiO5NTq/+hlMRR5wpqh9I6KGXM/2vmsk4+zwgpdBYpeehaTJTCUhxZNd25hB+WsywBCXyV2YywoY++e50+ojxxrJR9QRls/iF73ySTUmL12FfIpf2zLILM40MA95aVCMcRSqAICYQALkJoYZNQAr1FAiGAe8tKhOMIJVCEBEIAFyG0sEkogd4igRDAvWUlwnGEEihCAiGAixBa2CSUQG+RQAjg3rIS4ThCCRQhgRDARQgtbBJKoLdIIARwb1mJcByhBIqQQAjgIoQWNgkl0Fsk8P+GYBg8Z5/fZgAAAABJRU5ErkJggg=="
        },
        "duration": 34
    },
    "touchSupport": {
        "value": {
            "maxTouchPoints": 0,
            "touchEvent": false,
            "touchStart": false
        },
        "duration": 0
    },
    "vendor": {
        "value": "Google Inc.",
        "duration": 0
    },
    "vendorFlavors": {
        "value": [
            "chrome"
        ],
        "duration": 0
    },
    "cookiesEnabled": {
        "value": true,
        "duration": 0
    },
    "colorGamut": {
        "value": "srgb",
        "duration": 0
    },
    "invertedColors": {
        "duration": 0
    },
    "forcedColors": {
        "value": false,
        "duration": 0
    },
    "monochrome": {
        "value": 0,
        "duration": 0
    },
    "contrast": {
        "value": 0,
        "duration": 0
    },
    "reducedMotion": {
        "value": false,
        "duration": 0
    },
    "hdr": {
        "value": false,
        "duration": 0
    },
    "math": {
        "value": {
            "acos": 1.4473588658278522,
            "acosh": 709.889355822726,
            "acoshPf": 355.291251501643,
            "asin": 0.12343746096704435,
            "asinh": 0.881373587019543,
            "asinhPf": 0.8813735870195429,
            "atanh": 0.5493061443340548,
            "atanhPf": 0.5493061443340548,
            "atan": 0.4636476090008061,
            "sin": 0.8178819121159085,
            "sinh": 1.1752011936438014,
            "sinhPf": 2.534342107873324,
            "cos": -0.8390715290095377,
            "cosh": 1.5430806348152437,
            "coshPf": 1.5430806348152437,
            "tan": -1.4214488238747245,
            "tanh": 0.7615941559557649,
            "tanhPf": 0.7615941559557649,
            "exp": 2.718281828459045,
            "expm1": 1.718281828459045,
            "expm1Pf": 1.718281828459045,
            "log1p": 2.3978952727983707,
            "log1pPf": 2.3978952727983707,
            "powPI": 1.9275814160560204e-50
        },
        "duration": 0
    },
    "videoCard": {
        "value": {
            "vendor": "Google Inc. (Intel)",
            "renderer": "ANGLE (Intel, Intel(R) UHD Graphics (0x00004688) Direct3D11 vs_5_0 ps_5_0, D3D11)"
        },
        "duration": 8
    },
    "pdfViewerEnabled": {
        "value": true,
        "duration": 0
    },
    "architecture": {
        "value": 255,
        "duration": 0
    }
}

function GenerateFP(_0x5c1adc, _0x39e545) {
    if (_0x39e545 === void 0x0) {
        _0x39e545 = ![];  //false
    }
    if (_0x5c1adc) {
        _0x26e045 = Object.assign(Object.assign({}, components), {
            'param': {
                'value': _0x5c1adc,
                'duration': 0x0
            }
        });
    } else {
        _0x26e045 = Object.assign({}, components);
    }
    _0x22dd67 = hashComponents(_0x26e045);
    if (_0x39e545) {
        return _0x22dd67;
    } else {
        return _0x22dd67['slice'](0x0, 0x8);
    }
};

_0x40ed1f = new _0xa995c3()

function get_en(knock2, config2) {
    // var _0x42d77b = _0x40ed1f['GenerateFP']();
    var _0x42d77b = "EA9AB65D";
    var _0x34957f = GenerateFP(![], !![])
    var _0x30ee8c = _0x40ed1f['GenerateFP'](knock2['substr'](-0x5, 0x5));
    // var _0x30ee8c = dong_can;
    var _0x184fa6 = GenerateFP(knock2['substr'](-0x5, 0x5));
    const _0x59bba5 = 'adszzSECRETB';
    var _0x1cbeb7 = crypto.createHash("md5").update(_0x30ee8c + _0x184fa6 + _0x59bba5).digest('hex')['slice'](0x0, 0x5);
    var _0x38e801 = '0123456789qwe'
    var _0xe67885 = _0x38e801
    var _0x30b74a = "3748e5135E6c21a5a5372e55"  //  _0x1f1e69['dfu']
    var _0x183d7b = "3748e5135E6c21a5a5372e55" // localStorage['getItem']('vaptchaut')
    const _0x280f74 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.95 Safari/537.36i-cn.vaptcha.com8549731620"
    var _0x3c7b59 = crypto.createHash('md5').update(_0x280f74).digest('hex')['slice'](0x0, 0x5);
    var globalMd5 = crypto.createHash("md5").update(splicingObj1(config2)).digest("hex");

    _0x5d0500 = _0x42d77b + _0x34957f + _0x30ee8c + _0x184fa6 + _0x1cbeb7 + _0x38e801 + _0xe67885 + _0x30b74a + _0x183d7b + _0x3c7b59 + globalMd5['slice'](0x0, 0x5);
    en = encryFunc(selectFrom(0x3, 0xf), _0x5d0500);
    return en
}

// g_en = get_en("1730971241TCFZaK0bcb1",{
//         "knock": "1730804230jnGhW73bcd2",
//         "cdn_servers": [
//             "static-cn.vaptcha.net"
//         ],
//         "css_version": "2.9.12",
//         "js_path": "verify.2.2.4.js",
//         "help": true,
//         "is_vip": 1,
//         "guideVersion": "3.1.0",
//         "sdk_ver": "vaptcha-sdk.1.2.35.669f69e6.js",
//         "net_way": -1,
//         "node": "CN",
//         "server": "https://0.vaptcha.com/verify"
//     });
// console.log(g_en)

var _0x319301 = {
    '_sample': 'abcdefgh234lmntuwxyz',
    '_convertScale': function (_0x1acba4) {
        _0x1acba4 = Math['floor'](_0x1acba4);
        var _0x395d5e = this['_sample'][_0x1acba4 % 0x14];
        _0x1acba4 = Math['floor'](_0x1acba4 / 0x14);
        var _0x2de1a1 = this['_sample'][_0x1acba4 % 0x14];
        var _0x5461c6 = Math['floor'](_0x1acba4 / 0x14);
        _0x5461c6 = _0x5461c6 ? this['_sample'][_0x5461c6] : '_';
        return ''['concat'](_0x5461c6 || '_')['concat'](_0x2de1a1 || '_')['concat'](_0x395d5e || '_');
    },
    'assemblyCoordData': function (_0x4ae77e) {
        var _0x2e15c5 = [];
        var _0x31480a = [];
        var _0x457f77 = [];
        for (var _0x72bd9d = 0x0, _0x5abd1e = _0x4ae77e; _0x72bd9d < _0x5abd1e['length']; _0x72bd9d++) {
            var _0x171511 = _0x5abd1e[_0x72bd9d];
            _0x2e15c5['push'](this['_convertScale'](_0x171511['x']));
            _0x31480a['push'](this['_convertScale'](_0x171511['y']));
            _0x457f77['push'](this['_convertScale'](_0x171511['time']));
        }
        return _0x2e15c5['join']('') + _0x31480a['join']('') + _0x457f77['join']('');
    }
};

function splicingObj2(_0x3e8955, _0x3eb13c) {
    var _0x4ef315 = '';
    var _0x8fd444 = Object['keys'](_0x3e8955)['sort']();
    for (var _0x1b3890 = 0x0; _0x1b3890 < Object['keys'](_0x3e8955)['length']; _0x1b3890++) {
        _0x4ef315 += _0x3e8955[_0x8fd444[_0x1b3890]];
    }
    if (_0x3eb13c)
        _0x4ef315 += _0x3eb13c;
    return _0x4ef315;
}

function validate_en(get_res, knock2,track) {
    // track =[{x: 188, y: 87, time: 14.899999976158142}]
    var _0x4a6fbb = {
        v: _0x319301['assemblyCoordData'](track),
        dt: "1640",
        ch: 227,
        cw: 350,
        p: "27267"
    }
    var _0x3eec43 = '47E8C527';
    var _0x3103e9 = GenerateFP(![], !![]);
    var _0x2240d0 =get_res['ha'] + _0x40ed1f['GenerateFP'](get_res['ha']);
    var _0x239e2a = get_res['hb'] + GenerateFP(get_res['hb']);  //指纹
    var _0x4ae6d5 = "b6ac168C1C6d9953eec3391d" // _0x1cb1c6['compareDfu'](_0x4e08cb, _0x40e91b);
    var _0x134bff = "d34dc7FD8B5f2c708367346a32e4ba2d" //  localStorage['getItem']('vaptchaut')
    const _0x1e9617 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0i-cn.vaptcha.com8549731620";
    var _0xcb99fc = crypto.createHash('md5').update(_0x1e9617).digest('hex')['slice'](0x0, 0x5);
    const _0x55b95b = '6f22fff634c'; //
    var _0xca6c03 = crypto.createHash('md5').update(knock2 + parseInt(_0x55b95b)['toString']()).digest('hex')['slice'](0x0, 0x5);
    var globalMd5 = crypto.createHash('md5').update(splicingObj2(get_res, "8549731620SECRET"['substr'](0x0, 0xa))).digest('hex');

    _0x15e37d = '' + _0x4a6fbb['dt'] + _0x4a6fbb['ch'] + _0x4a6fbb['cw'] + _0x4a6fbb['p']['toString']()['substr'](0x0, 0x5) + _0x3eec43 + _0x3103e9 + _0x2240d0 + _0x239e2a + _0x4ae6d5 + _0x134bff + _0xcb99fc + _0xca6c03 + globalMd5['slice'](0x0, 0x5) + _0x4a6fbb['v'];
    en = encryFunc(selectFrom(0x3, 0xf), _0x15e37d);
    return en
}

var track =[
    {
        "x": 202,
        "y": 142,
        "time": 102.5
    },
    {
        "x": 195,
        "y": 142,
        "time": 128.69999998807907
    },
    {
        "x": 189,
        "y": 142,
        "time": 136.60000002384186
    },
    {
        "x": 184,
        "y": 142,
        "time": 142.60000002384186
    },
    {
        "x": 177,
        "y": 142,
        "time": 150.80000001192093
    },
    {
        "x": 168,
        "y": 142,
        "time": 158.60000002384186
    },
    {
        "x": 156,
        "y": 142,
        "time": 169.19999998807907
    },
    {
        "x": 145,
        "y": 142,
        "time": 176.80000001192093
    },
    {
        "x": 134,
        "y": 142,
        "time": 184.60000002384186
    },
    {
        "x": 126,
        "y": 141,
        "time": 193.60000002384186
    },
    {
        "x": 118,
        "y": 141,
        "time": 199.30000001192093
    },
    {
        "x": 111,
        "y": 141,
        "time": 208.60000002384186
    },
    {
        "x": 105,
        "y": 141,
        "time": 224.9000000357628
    },
    {
        "x": 99,
        "y": 136,
        "time": 312.80000001192093
    },
    {
        "x": 94,
        "y": 134,
        "time": 330.69999998807907
    },
    {
        "x": 88,
        "y": 129,
        "time": 354.60000002384186
    },
    {
        "x": 85,
        "y": 124,
        "time": 534.9000000357628
    },
    {
        "x": 82,
        "y": 119,
        "time": 548.6999999880791
    },
    {
        "x": 76,
        "y": 114,
        "time": 575.9000000357628
    },
    {
        "x": 71,
        "y": 110,
        "time": 614.8000000119209
    },
    {
        "x": 68,
        "y": 105,
        "time": 784.8000000119209
    },
    {
        "x": 69,
        "y": 100,
        "time": 825
    },
    {
        "x": 74,
        "y": 98,
        "time": 888.6000000238419
    },
    {
        "x": 80,
        "y": 95,
        "time": 962.9000000357628
    },
    {
        "x": 85,
        "y": 92,
        "time": 1068.800000011921
    },
    {
        "x": 88,
        "y": 87,
        "time": 1199.300000011921
    },
    {
        "x": 94,
        "y": 82,
        "time": 1231.1000000238419
    },
    {
        "x": 100,
        "y": 78,
        "time": 1360.699999988079
    },
    {
        "x": 105,
        "y": 73,
        "time": 1440.699999988079
    },
    {
        "x": 110,
        "y": 73,
        "time": 1515.800000011921
    },
    {
        "x": 116,
        "y": 72,
        "time": 1578.699999988079
    },
    {
        "x": 121,
        "y": 72,
        "time": 1660.800000011921
    },
    {
        "x": 126,
        "y": 72,
        "time": 1751.4000000357628
    },
    {
        "x": 132,
        "y": 72,
        "time": 1846.699999988079
    },
    {
        "x": 137,
        "y": 72,
        "time": 1954.6000000238419
    },
    {
        "x": 142,
        "y": 72,
        "time": 2017.5
    },
    {
        "x": 147,
        "y": 72,
        "time": 2082.800000011921
    },
    {
        "x": 152,
        "y": 72,
        "time": 2122.800000011921
    },
    {
        "x": 158,
        "y": 74,
        "time": 2253.5
    },
    {
        "x": 164,
        "y": 78,
        "time": 2398.699999988079
    },
    {
        "x": 168,
        "y": 83,
        "time": 2447
    },
    {
        "x": 171,
        "y": 88,
        "time": 2489.600000023842
    },
    {
        "x": 178,
        "y": 94,
        "time": 2520.600000023842
    },
    {
        "x": 183,
        "y": 98,
        "time": 2690.900000035763
    },
    {
        "x": 188,
        "y": 102,
        "time": 2725
    },
    {
        "x": 194,
        "y": 106,
        "time": 2754.699999988079
    },
    {
        "x": 198,
        "y": 111,
        "time": 2868.600000023842
    },
    {
        "x": 202,
        "y": 116,
        "time": 2894.699999988079
    },
    {
        "x": 206,
        "y": 121,
        "time": 2916.600000023842
    },
    {
        "x": 210,
        "y": 126,
        "time": 2942.600000023842
    },
    {
        "x": 214,
        "y": 132,
        "time": 2983
    },
    {
        "x": 218,
        "y": 138,
        "time": 3014.600000023842
    },
    {
        "x": 223,
        "y": 143,
        "time": 3048.5
    },
    {
        "x": 227,
        "y": 149,
        "time": 3096.800000011921
    },
    {
        "x": 231,
        "y": 154,
        "time": 3130.600000023842
    },
    {
        "x": 235,
        "y": 159,
        "time": 3160.600000023842
    },
    {
        "x": 240,
        "y": 162,
        "time": 3253.300000011921
    },
    {
        "x": 245,
        "y": 165,
        "time": 3274.5
    },
    {
        "x": 250,
        "y": 168,
        "time": 3362.699999988079
    },
    {
        "x": 255,
        "y": 172,
        "time": 3380.699999988079
    },
    {
        "x": 260,
        "y": 176,
        "time": 3406
    }
];
// var en2 = validate_en({
//         "hb": "4f0b9",
//         "img_order": "18769986120",
//         "img": "https://img-cn.vaptcha.net/vaptcha/26b0f23ee28946158504d0ae6d0be438.jpg",
//         "frequency": 3.62,
//         "aso": "",
//         "is_vip": 1,
//         "adt": 0,
//         "r": "f395cb36f64bd5a",
//         "u": "",
//         "ut": "",
//         "token": "",
//         "ha": "29d91",
//         "a_t": 0,
//         "a_p": "",
//         "a_i": ""
//     }, "17308734842wnw0zdf537",track)
// console.log(en2)

function hex2int(_0x2a721b) {
        var _0x35c614 = _0x2a721b['length'], _0x84b795 = new Array(_0x35c614), _0x596f99;
        for (var _0x459fd1 = 0x0; _0x459fd1 < _0x35c614; _0x459fd1++) {
            _0x596f99 = _0x2a721b['charCodeAt'](_0x459fd1);
            if (0x30 <= _0x596f99 && _0x596f99 < 0x3a) {
                _0x596f99 -= 0x30;
            } else {
                _0x596f99 = (_0x596f99 & 0xdf) - 0x41 + 0xa;
            }
            _0x84b795[_0x459fd1] = _0x596f99;
        }
        var _0x5239ef = _0x84b795['reduce'](function(_0x3af38a, _0x270d62) {
            _0x3af38a = 0x10 * _0x3af38a + _0x270d62;
            return _0x3af38a;
        }, 0x0);
        return _0x5239ef;
    };
function Decrypt(_0x33bc25, _0xcc5af2) {
        var _0x1b7e7e = '';
        _0x1b7e7e = (parseInt(_0x33bc25) - _0xcc5af2)['toString']();
        if (_0x1b7e7e['length'] < 0xa) {
            _0x1b7e7e = '0' + _0x1b7e7e;
        }
        return _0x1b7e7e;
    }

function pow (str1) {
	var compatible = "0123456789abcdef" // ç¨äºéä½é¾åº¦ 16è¿å¶,åå«è¶å¤æ¶é¾åº¦è¶ä½
	var level = 5;
	var i = 0;
	// console.time('powæ¶é´');
	while (true) {
		var str = str1 + i.toString()
		var hash = SHA256(str);
		if (isOk(hash, compatible, level)) {
			// console.timeEnd('powæ¶é´');
			return i
		}
		i++
	}
}

function isOk (hash, compatible, level) {
	if (hash.length < level + 1) { // check str len
		return false
	}
	// let prefix = hash.substr(hash, level + 1)
	var prefix = hash.substr(hash, level)
	for (var compatibleKey in compatible) { // compatible
		// if (prefix === "0".repeat(level) + compatibleKey) {
		//     return true
		// }
		var zero = "";
		for (var i=0; i<level; i++) {
			zero += "0";
		}
		if (prefix === zero) {
			return true
		}
	}
	return false
}

/**
 *
 * Secure Hash Algorithm (SHA256)
 * http://www.webtoolkit.info/
 *
 * Original code by Angel Marin, Paul Johnston.
 *
 **/
function SHA256 (s) {
	var chrsz = 8;
	var hexcase = 0;

	function safe_add (x, y) {
		var lsw = (x & 0xFFFF) + (y & 0xFFFF);
		var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
		return (msw << 16) | (lsw & 0xFFFF);
	}

	function S (X, n) {
		return (X >>> n) | (X << (32 - n));
	}

	function R (X, n) {
		return (X >>> n);
	}

	function Ch (x, y, z) {
		return ((x & y) ^ ((~x) & z));
	}

	function Maj (x, y, z) {
		return ((x & y) ^ (x & z) ^ (y & z));
	}

	function Sigma0256 (x) {
		return (S(x, 2) ^ S(x, 13) ^ S(x, 22));
	}

	function Sigma1256 (x) {
		return (S(x, 6) ^ S(x, 11) ^ S(x, 25));
	}

	function Gamma0256 (x) {
		return (S(x, 7) ^ S(x, 18) ^ R(x, 3));
	}

	function Gamma1256 (x) {
		return (S(x, 17) ^ S(x, 19) ^ R(x, 10));
	}

	function core_sha256 (m, l) {
		var K = new Array(0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5, 0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5, 0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3, 0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174, 0xE49B69C1, 0xEFBE4786, 0xFC19DC6, 0x240CA1CC, 0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA, 0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7, 0xC6E00BF3, 0xD5A79147, 0x6CA6351, 0x14292967, 0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13, 0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85, 0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3, 0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070, 0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5, 0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3, 0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208, 0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2);
		var HASH = new Array(0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19);
		var W = new Array(64);
		var a, b, c, d, e, f, g, h, i, j;
		var T1, T2;
		m[l >> 5] |= 0x80 << (24 - l % 32);
		m[((l + 64 >> 9) << 4) + 15] = l;
		for (var i = 0; i < m.length; i += 16) {
			a = HASH[0];
			b = HASH[1];
			c = HASH[2];
			d = HASH[3];
			e = HASH[4];
			f = HASH[5];
			g = HASH[6];
			h = HASH[7];
			for (var j = 0; j < 64; j++) {
				if (j < 16) W[j] = m[j + i];
				else W[j] = safe_add(safe_add(safe_add(Gamma1256(W[j - 2]), W[j - 7]), Gamma0256(W[j - 15])), W[j - 16]);
				T1 = safe_add(safe_add(safe_add(safe_add(h, Sigma1256(e)), Ch(e, f, g)), K[j]), W[j]);
				T2 = safe_add(Sigma0256(a), Maj(a, b, c));
				h = g;
				g = f;
				f = e;
				e = safe_add(d, T1);
				d = c;
				c = b;
				b = a;
				a = safe_add(T1, T2);
			}
			HASH[0] = safe_add(a, HASH[0]);
			HASH[1] = safe_add(b, HASH[1]);
			HASH[2] = safe_add(c, HASH[2]);
			HASH[3] = safe_add(d, HASH[3]);
			HASH[4] = safe_add(e, HASH[4]);
			HASH[5] = safe_add(f, HASH[5]);
			HASH[6] = safe_add(g, HASH[6]);
			HASH[7] = safe_add(h, HASH[7]);
		}
		return HASH;
	}

	function str2binb (str) {
		var bin = Array();
		var mask = (1 << chrsz) - 1;
		for (var i = 0; i < str.length * chrsz; i += chrsz) {
			bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << (24 - i % 32);
		}
		return bin;
	}

	function Utf8Encode (string) {
		string = string.replace(/\r\n/g, "\n");
		var utftext = "";
		for (var n = 0; n < string.length; n++) {
			var c = string.charCodeAt(n);
			if (c < 128) {
				utftext += String.fromCharCode(c);
			} else if ((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			} else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}
		}
		return utftext;
	}

	function binb2hex (binarray) {
		var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
		var str = "";
		for (var i = 0; i < binarray.length * 4; i++) {
			str += hex_tab.charAt((binarray[i >> 2] >> ((3 - i % 4) * 8 + 4)) & 0xF) +
				hex_tab.charAt((binarray[i >> 2] >> ((3 - i % 4) * 8)) & 0xF);
		}
		return str;
	}

	s = Utf8Encode(s);
	return binb2hex(core_sha256(str2binb(s), s.length * chrsz));
}


// console.log(pow("ef4ce5b6d03e113"));
// console.log(hex2int(GenerateFP("da940")));

function get_order(img_order,ha_canvas,hb,r){
    // _0x40ed1f['GenerateFP'](ha)
    var _0x3b0a39 = hex2int(ha_canvas);
    var _0x53e0aa = hex2int(GenerateFP(hb));
    var _0x33539f = pow(r)
    var _0x3ac810 = _0x3b0a39 + _0x53e0aa + parseInt("8549731620SECRET") + _0x33539f;
    var _0x2b65e1 = Decrypt(img_order, _0x3ac810);
    return _0x2b65e1
}


console.log(get_order("22022596151", "D7E0A6F5", "da940", "aada2cb9476364f"));