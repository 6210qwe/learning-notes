var rs = require("jsrsasign");

// 秘钥
var privateKeyString = `-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCsLXAB3UQmNw4l
IbF/cq+JV/PvfVeoZrAGd3+HCxnACG0K7tN1/APm1QaVF70ZUM0Nrq+JTBn9JHfR
MDz710nZy6SxMLsN7YM3iD0899EflraBjKHNR52SfmeMGtEoCwC/fU2HwLlu7ZTb
z5QlmFcxcmMSHCVr6X3nnN+liAbznBkwKui8cLtkenacDhWA3EwH4aCYBdB/v5HQ
mx9zuTSDuoOiYM1LnGDRrZFymteWRiXStyxpUWqvwKEzjmS+sMVpnbiWqFuc8Nhm
0rTGLdt82gp0zYkX++pRUAlC4k9kIZg6t9h6/q9aBYLXBDL3Z75T6FDQzuCkhtrp
2eE+0GrLAgMBAAECggEAANPbFPc2S6S6Ga2Wx9EKTPOyRXVpxXJw6CcM4t5Hymd/
9qx9MbT7Y9GkTXUmwIdl5OnxCAzolxHkzYmY0XEQds6GxR9B1uhMWCj8el2KkMdN
q0O8x1rPxBN9devvE20yHLmCdOOVQJY9v+y4fpHD4YX2OfEOsP0XUNStMoN73RHh
+xaKr/SyvzWtyJgjO4uywBSIvORFSHVS9TjBi9vxc6+ussz58ZtGgb0X4qA7cCp3
s5CsI9Do9+DfN+qfuZxbTlPPjVdCxR+2DImcFNKfYYXBfwgsg64C4G1Sn2JKabt6
6Lf8MfeNYtUuu7Pv9hMKpKDG6XA8BxnBw+YFt7Q8GQKBgQDhuo2OFHkBopS3iUET
HvCRi/KVvjeFeu94OCMGsZqgkV9aoUAEiWma7bGyKTlE0eEWoMaGCzuiKGHRpEFi
n9N9zgthj00/yr7o5Pq0Gf5tRTnQtaDEOvdZNrl4hZ/U2vnwYChjcN0D9iuZdia6
+tMD02oW6I56Rk/M0SuyK+S+1wKBgQDDRG2WZDNLTiX0fVQO1JFHQtBOxXtBfJlP
mlO2vAhh3E3YJ5bVSb2m/yC/0dGsczOXs6r/XgtkvSNntNAk4DhenrpClor3v+y3
OpqMGvPwIZJk/gVQxDWwcWKDKWtHUSpinOGcFob4SJHvKQ6A6rMHKgFxzvBgaCR4
1wZEbSs5LQKBgBiqIreIoyQ7mJZpZ/Pn6I9uxEX6b+Sk5y+yqpkbpPKwj8O+ZNla
DnEAUe9Os9RCPp8TWD3jUlPIp8+ZbA+TuS9A6VtyphU3WR7njkFJqdRUwRl+DyAB
9W8JHMD/kNRYTQEn8KHU/kFlj6QIFflOWOpNGoWASbkwn52YqXahdzAnAoGBALRg
9crDbQ7XdgBP9eJtQnbNpZfenWl1LDp4mXRoZmXgGJjgmVkV8XfeneYUcNgY40Pz
2LZlrai1f4tBYDVwWyItBmqUnnMWfBkWrcVW8JiWqqFYdpiRZ/dCBnqbPFp5A+ps
eYyy0qNwhj6jcp5sME0h5Iu5Whv0mBx4pXV4U0FRAoGBAKF7tGCKId600S8uvBpy
7xIYRJ+rK3WU0UliO5iWWB6LfRp6qIrBMzuVeSVbQQYkwccAGUgBVTpHlz0GVKX+
cyI1+bnvZzjx+zGz7+tIUP0bYgd18vMsDHA/bBQHJdybAXDuQEUNZQipnweVO43H
D81lAQXDlWOU+9wTRuVvEtR0
-----END PRIVATE KEY-----
`;

// 获取签名
function getSHA256withRSA(content) {
  const key = rs.KEYUTIL.getKey(privateKeyString);
  // 创建 Signature 对象，设置签名编码算法
  const signature = new rs.KJUR.crypto.Signature({ alg: "SHA256withRSA" });
  // 初始化
  signature.init(key);

  signature.updateString(content);
  // 生成密文
  const originSign = signature.sign();
  // console.log(originSign)

  return rs.hextob64(originSign).replace(/\//g, "_").replace(/\+/g, "-");
}

// console.log(getSHA256withRSA("appId=fae0d199f50c8c88a742809706dbbbe6&marketingId=1816637851165659138&redeemCode=000&t=1721990138058"));

// cWn8W8irbs2WHZ5OXNbdMUcRjHN721KvJ2kL7GfIEcjpA0DdFj8N7nzw4RQRnMc90OxwE6c8YRaCVAfl3ZBBWrXpd+Ahc6uVIEa2YBn381QsFeU/cBfIx2LrEbrJw/w+J/4r7w+JXo8o9fMulVG2+DZVLKEFwyiUmG7OKUMIS6piUt+yIfpWrLX7bZ8bEFIo6BAQk89YqyrpxX32EQ7l9rPV/jDRXXxO5F4NclAy8YOwMla/ek5nPZ1U3u494nX6iNSJlNjfz6emKJiMJBTahFtFkShG6uugoqkPDXnOU8DokkJyFo6Nik81VHgx1oD6TTASne+OPBvFnXuTT47hOw==

//"SvnnE0eCp3OxWTO6vFhyF1fIjZBTlSzV6DWbf0SAQDNkKNp0xfCBSuNDAKM5K+VlvSZ+fXOBeDO1psmzgtZWxh3UCCpxerzUvE9cwqaiRZ8AocOLPBGho+Iq452HwIoi24lBrI8EJ0H0NpOllZLFatc2WotR1qyACf5vKaFw2ic7UyBY7j3fqI8Uu6f/MD+iB432utgwz9B4w4a6bbx/OVGebbRDYJmiaBUKPvhMS5s1MdD9T8MDMmF5vrphQltjSl4u0byaSAZGlo0GbkH00Pr/1M3DZlVvAiuEYH8eTniqB4cNBuyF3uyc2tsC/nW20mcQyH8a8cUhVCh0INUqDA=="
//SvnnE0eCp3OxWTO6vFhyF1fIjZBTlSzV6DWbf0SAQDNkKNp0xfCBSuNDAKM5K-VlvSZ-fXOBeDO1psmzgtZWxh3UCCpxerzUvE9cwqaiRZ8AocOLPBGho-Iq452HwIoi24lBrI8EJ0H0NpOllZLFatc2WotR1qyACf5vKaFw2ic7UyBY7j3fqI8Uu6f_MD-iB432utgwz9B4w4a6bbx_OVGebbRDYJmiaBUKPvhMS5s1MdD9T8MDMmF5vrphQltjSl4u0byaSAZGlo0GbkH00Pr_1M3DZlVvAiuEYH8eTniqB4cNBuyF3uyc2tsC_nW20mcQyH8a8cUhVCh0INUqDA==