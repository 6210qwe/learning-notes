# -*- coding: utf-8 -*-
# @Time      : 2024/7/26 下午5:08
# @File      : main.py
# @Software  : Pycharm
import time

import execjs
import requests
import json
with open('encode.js', 'rb') as f:
    js = f.read().decode()
ctx = execjs.compile(js)
redeemCode="为运动健儿加柚打气" #口令

marketingId="1816637851165659138"
token='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ3eG1pbmlfMTgxNjc1NTgzMDYyNDc4MDI4OSIsImlhdCI6MTcyMTk4MzMxOH0.ufaA0VXXGSSg559uIzDOYNC7PuOBfoZ65vLLVBaJqx6lnBsWBFTnMIM17Y_52kh2YmL2BgieMLzA_NG-G_tQFg'
headers = {
    "Accept": "*/*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Access-Token": token,
    "Connection": "keep-alive",
    "Content-Type": "application/json",
    "Referer": "https://servicewechat.com/wx060ecb4f74eac0da/61/page-frame.html",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090a13) XWEB/8555",
    "x-devops-env": "prod",
    "x-devops-router;": "",
    "x-devops-tenant": "mxbc",
    "xweb_xhr": "1"
}
url = "https://xyk.mxbc.net/api/v1/marketing/redeem-act/community/verify"
tt=int(time.time()*1000)
word=f'appId=fae0d199f50c8c88a742809706dbbbe6&marketingId={marketingId}&redeemCode={redeemCode}&t={tt}'
sign=ctx.call("getSHA256withRSA",word)
data = {
    "redeemCode": redeemCode,
    "marketingId": marketingId,
    "t": tt,
    "appId": "fae0d199f50c8c88a742809706dbbbe6",
    "sign":sign
}
data = json.dumps(data, separators=(',', ':'))
response = requests.post(url, headers=headers, data=data)
print(response.text)