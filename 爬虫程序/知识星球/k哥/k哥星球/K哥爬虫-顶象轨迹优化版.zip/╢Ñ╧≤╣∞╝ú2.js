function getslidetrack(targetX) {
    // 自定义随机数生成器，用于生成指定范围的随机整数
    const randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

    let x = 0, y = 0, t = 0;
    let track = [[-randomInt(10, 45), -randomInt(10, 45), 0], [0, 0, 0]];

    const movements = [
        { xArr: [1, 3, 2, 1, 2, 1, 3, 1, 4, 1], tArr: [1, 0, 1, 3, 1], x2Arr: [1, 2, 1, 0, 1, 2, 1], tMin: 10, tMax: 22 },
        { xArr: [2, 3, 1, 3, 2, 1, 1], tArr: [1, 0, 3, 2, 1, 4], x2Arr: [1, 2, 1, 0, 1, 2, 1], tMin: 17, tMax: 25 },
        { xArr: [1], tArr: [10, 22], x2Arr: [2, 1, 2, 1, 2, 1, 1, 3], tMin: 17, tMax: 28 },
        { xArr: [1], tArr: [60, 85], x2Arr: [1, 1, 0, 1, 0, 1, 1, 2], tMin: 60, tMax: 85 }
    ];

    const yChanges = [0, 0, 0, 1, 1, 1, -1, -1, -1];

    while (x < targetX) {
        let mode = targetX - x < 5 ? 3 : targetX - x < 13 ? 2 : targetX > 100 ? 0 : 1;
        const { xArr, tArr, x2Arr, tMin, tMax } = movements[mode];

        let x1 = xArr[randomInt(0, xArr.length - 1)];
        let t1 = tArr[randomInt(0, tArr.length - 1)];
        let x2 = x2Arr[randomInt(0, x2Arr.length - 1)];
        let t2 = randomInt(tMin, tMax);

        // Adjust y coordinate slightly on certain steps
        if (track.length % 5 === 0) {
            y += yChanges[randomInt(0, yChanges.length - 1)];
        }

        // Append first step
        t += t1;
        x += x1;
        track.push([x, y, t]);

        // Append second step
        t += t2;
        x += x2;
        track.push([x, y, t]);
    }

    // Final adjustment to reach the target
    x += randomInt(-1, 1);
    t += randomInt(100, 300);
    track.push([x, y, t]);

    return track;
}
function ol(arg){
    let e = arg.length;
    var t = [[Math.random(-1,1),0,Math.random(110,150)]]
    var x,y,t;
    for (let index = 1; index < (e-1); index++) {
        if(index == 1){
            t.push([Math.random(-1,1),Math.random(-1,1),Math.random(1,6)]);
        }else{
            var oo =(arg[index][2] - arg[index-1][2]) ;
            var cc = (arg[index][1] - arg[index-1][1])
            t.push( [(arg[index][0] - arg[index-1][0]),cc,oo]);
        }
    }
    t.push([0,0,Math.random(250,300)])
    return t;
}