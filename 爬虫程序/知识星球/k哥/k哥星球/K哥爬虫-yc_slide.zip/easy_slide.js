var _0xodG = 'v2';
(function (_0x43efe3, _0x2b517b, _0x94067a, _0x25aab1, _0x2c806e, _0x350439, _0x5dcb2f) {
  return _0x43efe3 = _0x43efe3 >> 3, _0x350439 = 'hs', _0x5dcb2f = 'hs', function (_0x1b3d3a, _0x3f7fbc, _0x351ac6, _0x199e0e, _0xc0e1fa) {
    _0x199e0e = 'tfi', _0x350439 = _0x199e0e + _0x350439, _0xc0e1fa = 'up', _0x5dcb2f += _0xc0e1fa, _0x350439 = _0x351ac6(_0x350439), _0x5dcb2f = _0x351ac6(_0x5dcb2f), _0x351ac6 = 0;
    const _0x46ba53 = _0x1b3d3a();
    while (--_0x25aab1 + _0x3f7fbc) {
      try {
        _0x199e0e = 841729;
      } catch (_0x56397d) {
        _0x199e0e = _0x351ac6;
      } finally {
        _0xc0e1fa = _0x46ba53[_0x350439]();
        if (_0x43efe3 <= _0x25aab1) _0x351ac6 ? _0x2c806e ? _0x199e0e = _0xc0e1fa : _0x2c806e = _0xc0e1fa : _0x351ac6 = _0xc0e1fa;else {
          if (_0x351ac6 == _0x2c806e['replace'](/[sAMGUxEmKPFRtSbako=]/g, '')) {
            if (_0x199e0e === _0x3f7fbc) {
              _0x46ba53['un' + _0x350439](_0xc0e1fa);
              break;
            }
            _0x46ba53[_0x5dcb2f](_0xc0e1fa);
          }
        }
      }
    }
  }(_0x94067a, _0x2b517b, function (_0x3a2e1d, _0x47a545, _0xb067c5, _0x334f87, _0x358a32, _0x32aa21, _0x4216a2) {
    return _0x47a545 = "split", _0x3a2e1d = arguments[0], _0x3a2e1d = _0x3a2e1d[_0x47a545](''), _0xb067c5 = "reverse", _0x3a2e1d = _0x3a2e1d[_0xb067c5]("v"), _0x334f87 = "join", 1688728, _0x3a2e1d[_0x334f87]('');
  });
}(1504, 841729, _0x191f, 190), _0x191f) && (_0xodG = 138);
function _0x191f() {
  const _0x243ff2 = function () {
    return [_0xodG, 'KPbtvtSs2SkMxsmkUkkEGAoPaFRK==', 'W6pdRCkjfmkK', 'W4SRWObYsXKfW5ZcJs/dRCkDpCoQW5HDrCoXWQqgnea', 'WPBcP8o/WPFdJG', 'zSkSp3BdRG', 'WQ/cPSouxee', 'q8kBW4noeXZdGNDOamo4oCoWDq', 'uZ9aW6q4', 'aCkVWOJdTHO', 'zcxdN8kBW4m', 'W7GHAttdRaWKW6lcVXFdM8o3', 'WQJdOvXqFa', 'pqS+cCoE', 'WOrXWRldI0RcNq', 'W54sWRSOWQ3cPSknuq', 'h8kHW4y8WPLWoZWo', 'W5vFWOqgW6eX', 'WQldHCkaWRJcLSkFWO9TwCojqCoagmkinCkEW7i5W7CKW5dcImkYFY3cPCootSksW5pdPCksDh/dPfldVSoyF1y', 'xbVdH35n', 'W7DUWPFdJSke', 'rCoyv3VdGmkSWRtcMYi', 'W5bIWQJdQM/cPr8', 'DmkidhhdKSoxBmorWOa', 'c8o8zmktWPC', 'W4CCWPa', 'W7TWWPnQW6m', 'W55oWORdOmky', 'pXldU2n4', 'uCkeBmkuWR1gpSkd', 'WPbAWQ9OW45rCa', 'qCowW4pcOSkWgb7cVCkEs8oPWQ7dOCksnqZcS8kwW7BcP8kHW6JdG8kLWOhcSmoTWQxdG0DX', 'WRhdMMzevG', 'WOZdUNzmDravaq', 'nZRdM2Hl', 'W6uMWPXaxG', 'WRhdP1iQcCkOWRldKmotW7ddTtlcVG', 'W4HuWOqgW6eX', 'WOf9WQVdM1O', 'WO7cQSoR']["concat"](function () {
      return ['WPeBWRBdTMG', 'WPfrWOb8W70', 'i1mvWPSW', 'tr1zW6GY', 'WPmTWRhcGf4', 'oxrQWOzN', 'a8k4WRVdNai', 'BbVdHNTwhGWZhrNdThPkbuKeW5BcM1hcK8k8', 'dCkMWQ7dGGNcJ2e', 'hvG9', 'sCkVW5BdLaFdMauuBXZcHSoneuG5WOm', 'WOZdSf1mrbyveSk5WRyw', 'hfvyWPrwdG', 'vSkrW4vDbGBdN1XJ', 'mrTCW4rO', 'tdhdSCkkW5tdPwq', 'FI0kld4', 'WO/cS8oyqvxdVXddU8kQW4OQ', 'kCkGWR3cSmk5', 'W4bMWRpdMCkoFCokjSkR', 'ECkXW4H7oq', 'WROSWPRdTYqeetJdH07dL8kaoa', 'W6XLWOTX', 'bComF8keWO9qoCkBW4m', 'DZiWpa', 'W54sWPG', 'm0GdWPW8WQG', 'CCksfvddNSoeBCokW4O', 'DIvqW6y2ta', 'bLa3DYe', 'W61WWOOMW6W', 'ef9tWPHB', 'FX4woWO', 'bK0kWPqD', 'W5tdTmk5W6FcImoHBmoaW6pdUmkFEW', 'm8o7A8kpWPu', 'WQ4MW5CKWPpdSCoPWP/dSmk/kCkw', 'jeGC', 'BGZdGfzl', 'W4rXWQ/dMq']["concat"](function () {
        return ['ArFdNf0', 'W5hcHmkIWOtdVG', 'WONcOmoEWOVdJa', 'rfLQymkFcSkXW43dOCksWOnLW57dOa', 'W7qFWPhcONvyrMtcGKRdHCkkaSoAWO8PomkjW54EW5hcKq', 'iKbpW5m', 'WOlcHmo2Aeu', 'WOfhWQNdM30', 'WRBdTK1OqG', 'W5jVWPH7W4S', 'd0iJhSo3W6BcS8oH', 'lGbgW4L5gCkBWQe', 'Ds5uW6y0sSk2WQ/dHaKwWP4Vd8knWOXFWOxcI8kvW73cOcpdKbKVWR3cKmoWdmkbW7OpWRHlWRzTi8oqWQe', 'WPmFWQBdTw4', 'i8oftSkaWRW', 'x8kfWPVcU8kSxv3cPCkguSkNWRJdQSkv', 'zbZdMfXAhW', 'sIy5W7/dGwBdGa', 'WRyxWR3cG04', 'WQpcJ8o/E3W', 'eIG6oCob', 'WQ5ZncNdL0r0WQdcJadcN8oGo27dUsVdT8ktWQnouSoThmk2W5/cGMxdPcOiWQq', 'zmoPW4vnW74', 'WPTnWPGPWP3cRCknqq', 'mumiWRiJWQJdLfNdRSoIWOJdNX1bWQJdSa', 'gwjZDMXGWRORWQxdHWi', 'WQNdICkAWONcNSkaW4C', 'utBcGYvdw8oZlSkMn8k7WOhcIq', 'lfH4W5Wb', 'aZldSW', 'BcLEW6yZuCo1WQ3dKG', 'WONcU8oxrG', 'zSogW6Sdxa', 'fqyRc8ogxCoJWPldVa', 'WPZdSxXoAq', 'iXTpW41C', 'amkbyCkpdZZcQ8oytuu0WQJcSSk4iSoY', 'FdFdH2bX', 'qq4eW4bcmCoaDmkMW5O', 'nG5hW4rO']["concat"](function () {
          return ['n0LpW5O5', 'W6JcOmoKA8ow', 'fgvhWPxcIa', 'cwLJWPtcIa', 'W6O8vs3dNq0RW7C', 'nd8HW7ldQa', 'od/cPCkQerJdSc7dLa', 'dmorESkv', 'gNv4WOre', 'WOvfW5u', 'W6HLWO1OW4NcSmo8WQtdHG', 'WPTiW5LKW6NcHCkVwqbfW6m', 'uSoFxxO', 'hZ84W4RdTvVdQ2BdHW', 'FLqaWP4XWQJdIa', 'WP5AWRrOW4rizq', 'ySkiauhdKSofFmoFWOxdLW', 'WQ9HWPRdR3q', 'aWyMo8ogwCo0', 'WQRcJCoqCx8', 'gKiVdSo3W70', 'WQ3dHmkpWQ/cTmkcW4zVASoC', 'itxcQmkTnXRdSsZdLfWV', 'tSo8W6y8WPjmlgPlwSoMiua', 'oCk1rmkIfa', 'WRCLWPdcOW', 'W4NcP8oSF8oz', 'W6xdNmkIh8k/', 'u8oSW60PWP93', 'r8owW6uNuXtdGmoYyc7cRa', 'vcZcKZrsBCo4jG', 'rdddMmkbW5e', 'ogeoBGddP0yJWQJdLq', 'rmorA1FdTG', 'umoqnmo4qw7dSCkuuK4TWQVcLSk+', 'tbJdT3z4', 'u8kejCozW44szSoeW4FcH0K7C2K', 'ySkij1BdImoFzSoz', 'qCkgW5nweG', 'W4ZcN0JcUmkoxelcGq']["concat"](function () {
            return ['W4mGWPHyrHG', 'kComFSkmWQ4', 'nCkLWRNdKs0', 'aSktWOpcM8kMteRdUSkyuSkL', 'W5n7WRldNSkozCow', 'jfzkW5GK', 'WQG0WO/cU3e', 'mXBdUvnI', 'Dmkgf0NdNCoez8olWPNdH8oSWRFdIfJdVq', 'WOHhWRyZ', 'WQL7WPXqW70', 'zmomvxhdOG', 'Ew/dGCktW7ZcPWD3', 'WRarWONdRhK', 'wCoLrMNdPq', 'f3H6WPJcGq', 'eLnwWRrdh8oarmk6W7FdQComW6HHWQldJW', 'islcSCk3bXZdQZhdNLW', 'r3hdLSooWPJcIbaAW6H0', 'aZ12W5PO', 'dSkdy8k5hc3cKSofzvGV', 'gtuFW63dOq', 'WPZdOuzFvG', 'C8oIW4PfW60', 'r8kLW57dVHddMq', 'W4bEWRldTCks', 'imoxtrBcJ8kdomoiWQldImolWO3dJG', 'hK5cWOhcTa', 'W5S1WQ0mWQG', 'W4ldUmk+i8krW5BcNCoXW6m', 'fSoTt8kyWRK', 'W6JcOmo0v8ov', 'nJSakSol', 'yc7dHSkzW6u', 'W5tdTCk1W6VcImoHmmo9W6xdOCkEFwe', 'eahcISknhq', 'W7GczbJdRq', 'D8kxbe7dGW', 'W4lcMN/cPCks', 'uCkaW4HC']["concat"](function () {
              return ['amkHWQxdLa', 'WOi+WOfnxranWPtcIJBdV8k4iq', 'WRRdTMrsFG', 'W5rHWR3dQSkq', 'zJ8jkaO', 'W4i/WR4pWOC', 'W60Hzq', 'bHJdSMfK', 'gbuOW6pdNq', 'aSknzmk4oJBcOCojqfG', 'FmoaW4fCW44tvfhdH8oSumoUiKJcRq', 'dNyJBZG', 'nNj3WPW', 'Fd3dLK5u', 'gNKjyZS', 'WOVdPuLrCW', 'dNqQmCoO', 'uSoxuhxdGCk3WRxcIYGQn8kZWRtcIcG', 'BdNcPbnQ', 'eSkrFmkMha', 'umo+W7pcG03dKxrho8ocWR3dUW', 'WOddV8kOWQVcHq', 'WQhdJu5zAW', 'W7LJWProW7a', 'DcZcQtfX', 's8o7W6iGWPH2pw9bvW', 'W592WRBdImkcFq', 'fmorEmkcWR0', 'WR3dUSkGlCoX', 'hbSaW7VdPa', 'qYZcIcroESoJiCk3o8k9', 'hJuJW57dPf4', 'saxdT8kXW7a', 'rmkUW5ZdTGxdLq', 'WQ8LWPdcK2a', 'bdFdP1L/', 'WRDlWQZdNLhcGttcKvy', 'W7K0WOWFWQG', 'W71LWPbZW5q', 'jYNcMSojWRNdVdL+WRzzoSop']["concat"](function () {
                return ['x2ddKSo7WOW', 'qSkCW4nkdYhdK19ObCoTi8oU', 'jhzqWR5z', 'jCkYWOddKX4', 'F8kLfvddNa', 'qs7cGYfq', 'e8kxWPtcUCkVsKddVCkav8kaWRhdP8kxmq', 'W7v9WPTZW74', 'eCk4WQFdMq8', 'aqFcSCk9eq', 'W4VcMSoiwSoDwX8xtSoAESkdWOvzW7NcPG', 'WORdIs3dVCklFKlcOJuQ', 'z8o1W6v+W6y', 'fJvgW4nQ', 'bYiHWPe', 'gYxdGL9F', 'jbPlW4T5gCkBWQe', 'ySkLW4radG', 'fG03hCoywCoPWONdH8kOWPH7W7JdLmo7nq', 'WQdcNCoeWRJdIG', 'W7VdHmkGpCkm', 'W7OjWP0RWOG', 'W68MyYVdLJCGW7ZcMrVdI8o9lG', 'WQpdV0DMxa', 'WOJdUCkGk8oz', 'kSkhWQZdKq8', 'efTBWPrBdSo2', 'yZpcQJbU', 'W7VcMSkEWPBdNG', 'jIlcSW', 'rthcLdHi', 'W77cUw3cTSkA', 'v8oduMZdGSkYWRxcJci', 'WPFdU0bkDryj', 'bCkzWQtcPSk6uuhdRW', 'WR/cISooqf/dVYJdJCkr', 'WQxdISkpWRBcMG', 'WRzNWPDMW5ZcQmoGW7NdK8kKi8kKW6O'];
              }());
            }());
          }());
        }());
      }());
    }());
  }();
  _0x191f = function () {
    return _0x243ff2;
  };
  return _0x191f();
}
function _0xb0e1(_0x4ad0fe, _0x45424b) {
  const _0x435f32 = _0x191f();
  return _0xb0e1 = function (_0x2908f9, _0x5e1641) {
    _0x2908f9 = _0x2908f9 - 430;
    let _0x50d0ad = _0x435f32[_0x2908f9];
    if (_0xb0e1['ylbpUW'] === undefined) {
      var _0x24aaa7 = function (_0x355ed5) {
        let _0x2c275 = '';
        let _0x11d9df = '';
        for (let _0x3cca0d = 0, _0x4d9f80, _0x39aa06, _0x15af05 = 0; _0x39aa06 = _0x355ed5['charAt'](_0x15af05++); ~_0x39aa06 && (_0x4d9f80 = _0x3cca0d % 4 ? _0x4d9f80 * 64 + _0x39aa06 : _0x39aa06, _0x3cca0d++ % 4) ? _0x2c275 += String['fromCharCode'](255 & _0x4d9f80 >> (-2 * _0x3cca0d & 6)) : 0) {
          _0x39aa06 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='['indexOf'](_0x39aa06);
        }
        for (let _0x4b6527 = 0, _0x116fcc = _0x2c275['length']; _0x4b6527 < _0x116fcc; _0x4b6527++) {
          _0x11d9df += '%' + ('00' + _0x2c275['charCodeAt'](_0x4b6527)['toString'](16))['slice'](-2);
        }
        return decodeURIComponent(_0x11d9df);
      };
      const _0xb0e11e = function (_0x25972c, _0x29c5da) {
        let _0x27fa82 = [];
        let _0x3a3089 = 0;
        let _0x3cf22a;
        let _0x61060f = '';
        _0x25972c = _0x24aaa7(_0x25972c);
        let _0x239a15;
        for (_0x239a15 = 0; _0x239a15 < 256; _0x239a15++) {
          _0x27fa82[_0x239a15] = _0x239a15;
        }
        for (_0x239a15 = 0; _0x239a15 < 256; _0x239a15++) {
          _0x3a3089 = (_0x3a3089 + _0x27fa82[_0x239a15] + _0x29c5da['charCodeAt'](_0x239a15 % _0x29c5da['length'])) % 256, _0x3cf22a = _0x27fa82[_0x239a15], _0x27fa82[_0x239a15] = _0x27fa82[_0x3a3089], _0x27fa82[_0x3a3089] = _0x3cf22a;
        }
        _0x239a15 = 0, _0x3a3089 = 0;
        for (let _0x1a91be = 0; _0x1a91be < _0x25972c['length']; _0x1a91be++) {
          _0x239a15 = (_0x239a15 + 1) % 256, _0x3a3089 = (_0x3a3089 + _0x27fa82[_0x239a15]) % 256, _0x3cf22a = _0x27fa82[_0x239a15], _0x27fa82[_0x239a15] = _0x27fa82[_0x3a3089], _0x27fa82[_0x3a3089] = _0x3cf22a, _0x61060f += String['fromCharCode'](_0x25972c['charCodeAt'](_0x1a91be) ^ _0x27fa82[(_0x27fa82[_0x239a15] + _0x27fa82[_0x3a3089]) % 256]);
        }
        return _0x61060f;
      };
      _0xb0e1['jsmlBS'] = _0xb0e11e, _0x4ad0fe = arguments, _0xb0e1['ylbpUW'] = true;
    }
    const _0x54b449 = _0x435f32[0];
    const _0x142385 = _0x2908f9 + _0x54b449;
    const _0x191f17 = _0x4ad0fe[_0x142385];
    return !_0x191f17 ? (_0xb0e1['UVUpdd'] === undefined && (_0xb0e1['UVUpdd'] = true), _0x50d0ad = _0xb0e1['jsmlBS'](_0x50d0ad, _0x5e1641), _0x4ad0fe[_0x142385] = _0x50d0ad) : _0x50d0ad = _0x191f17, _0x50d0ad;
  }, _0xb0e1(_0x4ad0fe, _0x45424b);
}
const _0x223b37 = function () {
  let _0x2d2b5d = true;
  return function (_0x24cdde, _0x1d70cc) {
    const _0x3acde5 = _0x2d2b5d ? function () {
      if (_0x1d70cc) {
        const _0x116900 = _0x1d70cc["apply"](_0x24cdde, arguments);
        return _0x1d70cc = null, _0x116900;
      }
    } : function () {};
    return _0x2d2b5d = false, _0x3acde5;
  };
}();
(function () {
  const _0x320818 = typeof window !== "undefined" ? window : typeof process === "object" && typeof require === "function" && typeof global === "object" ? global : this;
  _0x320818["setInterval"](_0x54b487, 2000);
})(), function () {
  _0x223b37(this, function () {
    const _0xf9af6a = new RegExp("function *\\( *\\)");
    const _0x115346 = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
    const _0x53f59f = _0x54b487("init");
    if (!_0xf9af6a["test"](_0x53f59f + "chain") || !_0x115346['test'](_0x53f59f + "input")) {
      _0x53f59f('0');
    } else {
      _0x54b487();
    }
  })();
}();
const _0x4a14bb = function () {
  let _0x486a12 = true;
  return function (_0x7cf2e3, _0x13e138) {
    const _0x554de9 = _0x486a12 ? function () {
      if (_0x13e138) {
        const _0x34a281 = _0x13e138['apply'](_0x7cf2e3, arguments);
        return _0x13e138 = null, _0x34a281;
      }
    } : function () {};
    return _0x486a12 = false, _0x554de9;
  };
}();
const _0x378ea8 = _0x4a14bb(this, function () {
  const _0x32be23 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === "function" && typeof global === "object" ? global : this;
  const _0x4b49d8 = _0x32be23["console"] = _0x32be23['console'] || {};
  const _0x5303b3 = ['log', 'warn', 'info', "error", "exception", "table", 'trace'];
  for (let _0x576c5c = 0; _0x576c5c < _0x5303b3['length']; _0x576c5c++) {
    const _0x345fc1 = _0x4a14bb['constructor']["prototype"]["bind"](_0x4a14bb);
    const _0x36adaf = _0x5303b3[_0x576c5c];
    const _0x1daca2 = _0x4b49d8[_0x36adaf] || _0x345fc1;
    _0x345fc1["__proto__"] = _0x4a14bb["bind"](_0x4a14bb), _0x345fc1["toString"] = _0x1daca2["toString"]['bind'](_0x1daca2), _0x4b49d8[_0x36adaf] = _0x345fc1;
  }
});
_0x378ea8(), document["addEventListener"]("DOMContentLoaded", function () {
  const _0x5c22c6 = document["querySelector"](".slider-handle");
  const _0x39eb8c = document['querySelector'](".puzzle-piece");
  const _0x255abf = document["querySelector"](".puzzle-image");
  const _0x4a1bb3 = document['querySelector'](".slider");
  let _0x1ff435 = false;
  let _0x4615f0;
  let _0x1ae804;
  function _0x4153b4(_0x5a7497) {
    return new Promise((_0xb90761, _0x66288f) => {
      const _0x2b45e3 = new Image();
      _0x2b45e3["onload"] = () => _0xb90761(_0x2b45e3), _0x2b45e3["onerror"] = _0x66288f, _0x2b45e3["src"] = _0x5a7497;
    });
  }
  function _0x5ce987(_0x17f493) {
    const _0x5b6ec3 = document['cookie']["split"](';');
    let _0x119d4b = null;
    for (let _0x4de2de of _0x5b6ec3) {
      const [_0x1cc261, _0xeec935] = _0x4de2de["trim"]()['split']('=');
      if (_0x1cc261 === _0x17f493) {
        _0x119d4b = _0xeec935;
      }
    }
    return _0x119d4b;
  }
  var _0x28ac48 = _0x5ce987("_err");
  if (_0x28ac48) {
    const _0x5c2705 = document["getElementsByClassName"]('modal-title')[0];
    _0x5c2705["textContent"] = _0x5c2705['textContent'] + " (Error: " + _0x28ac48 + ')';
  }
  function _0x5cc496(_0x49fb4d, _0x45898e) {
    let _0x2f7fee = '';
    var _0x45898e = _0x45898e + 'zVbhsiCROg';
    for (let _0x351fbd = 0; _0x351fbd < _0x49fb4d["length"]; _0x351fbd++) {
      const _0x37b77c = _0x49fb4d["charCodeAt"](_0x351fbd) ^ _0x45898e["charCodeAt"](_0x351fbd % _0x45898e["length"]);
      _0x2f7fee += String["fromCharCode"](_0x37b77c);
    }
    return _0x2f7fee;
  }
  async function _0x176127() {
    const _0x4e930a = new Date()["getTime"]();
    const _0xaa150a = "/_guard/easy_slide.png";
    const _0x110ae5 = document["querySelector"](".puzzle-image");
    const _0x51c2eb = document["querySelector"](".puzzle-piece");
    const _0x4af70a = _0xaa150a + "?t=" + _0x4e930a;
    try {
      const _0x45bd8d = '3|6|5|4|8|2|1|7|0'["split"]('|');
      let _0x338777 = 0;
      while (true) {
        switch (_0x45bd8d[_0x338777++]) {
          case '0':
            _0x51c2eb['style']["backgroundImage"] = "url(" + _0x4af70a + ')';
            continue;
          case '1':
            _0x51c2eb["style"]["top"] = _0x1b202a + 'px';
            continue;
          case '2':
            var _0x1b202a = parseInt(_0x5cc496(_0x341fcc, _0x195965));
            continue;
          case '3':
            await _0x4153b4(_0x4af70a);
            continue;
          case '4':
            var _0x341fcc = decodeURIComponent(_0x341fcc);
            continue;
          case '5':
            var _0x3fdd50 = _0x5ce987('guard');
            continue;
          case '6':
            var _0x341fcc = _0x5ce987("guardword");
            continue;
          case '7':
            _0x110ae5["style"]["backgroundImage"] = "url(" + _0x4af70a + ')';
            continue;
          case '8':
            var _0x195965 = _0x3fdd50['substr'](0, 8);
            continue;
        }
        break;
      }
    } catch (_0x170f4a) {
      console["error"]("Image loading failed:", _0x170f4a), _0x110ae5['style']["backgroundImage"] = "linear-gradient(45deg, #ffd700, #ffa500)", _0x51c2eb["style"]["backgroundImage"] = "linear-gradient(45deg, #ffd700, #ffa500)";
    }
  }
  function _0x348498(_0x203143) {
    const _0x198dea = '3|4|0|2|5|1'['split']('|');
    let _0x2db61c = 0;
    while (true) {
      switch (_0x198dea[_0x2db61c++]) {
        case '0':
          _0x1ae804 = _0x5c22c6["offsetLeft"];
          continue;
        case '1':
          _0x5c22c6["style"]["boxShadow"] = "0 4px 15px rgba(66,133,244,0.5)";
          continue;
        case '2':
          _0x5c22c6['style']["transition"] = 'none';
          continue;
        case '3':
          _0x1ff435 = true;
          continue;
        case '4':
          _0x4615f0 = _0x203143["type"] === "mousedown" ? _0x203143["clientX"] : _0x203143['touches'][0]["clientX"];
          continue;
        case '5':
          _0x39eb8c['style']["transition"] = 'none';
          continue;
      }
      break;
    }
  }
  function _0x2a9123(_0x136127) {
    if (!_0x1ff435) return;
    _0x136127["preventDefault"]();
    const _0x3ba6d6 = _0x136127['type'] === "mousemove" ? _0x136127['clientX'] : _0x136127["touches"][0]['clientX'];
    const _0x30cad4 = _0x3ba6d6 - _0x4615f0;
    let _0x26e60f = _0x1ae804 + _0x30cad4;
    const _0x5bd4b6 = _0x4a1bb3["offsetWidth"] - _0x5c22c6["offsetWidth"];
    _0x26e60f = Math["max"](0, Math['min'](_0x26e60f, _0x5bd4b6)), _0x5c22c6['style']['left'] = _0x26e60f + 'px', _0x39eb8c["style"]["left"] = _0x26e60f + 'px';
  }
  function _0x59de52() {
    function _0x40fb99(_0x20cad9) {
      return btoa(_0x20cad9);
    }
    if (!_0x1ff435) return;
    _0x1ff435 = false, _0x5c22c6['style']['transition'] = "all 0.3s ease", _0x39eb8c['style']["transition"] = "all 0.3s ease", _0x5c22c6['style']["boxShadow"] = "0 2px 10px rgba(66,133,244,0.3)";
    const _0x167271 = _0x39eb8c["getBoundingClientRect"]();
    const _0x4b9064 = _0x255abf['getBoundingClientRect']();
    const _0x3f4be5 = _0x167271["left"] - _0x4b9064['left'];
    const _0x32d3e9 = _0x167271["top"] - _0x4b9064["top"];
    x = Math["round"](_0x3f4be5), y = Math["round"](_0x32d3e9);
    var _0x2c1619 = _0x5ce987("guard");
    var _0x564781 = _0x2c1619["substr"](0, 8);
    var _0x1499fd = _0x5cc496(x["toString"]() + 'x' + y["toString"](), _0x564781);
    var _0x2b7a59 = _0x40fb99(_0x1499fd);
    document["cookie"] = "guardret=" + _0x2b7a59, window["location"]["reload"]();
  }
  _0x176127(), _0x5c22c6["addEventListener"]("mousedown", _0x348498), document["addEventListener"]("mousemove", _0x2a9123), document['addEventListener']("mouseup", _0x59de52), _0x5c22c6["addEventListener"]("touchstart", _0x348498, {
    'passive': false
  }), document["addEventListener"]('touchmove', _0x2a9123, {
    'passive': false
  }), document['addEventListener']("touchend", _0x59de52, {
    'passive': false
  });
});
function _0x54b487(_0x448a69) {
  function _0x160963(_0x4a5161) {
    if (typeof _0x4a5161 === 'string') {
      const _0x4c804f = function () {
        while (true) {}
      };
      return _0x4c804f();
    } else {
      if (('' + _0x4a5161 / _0x4a5161)["length"] !== 1 || _0x4a5161 % 20 === 0) {}
    }
    _0x160963(++_0x4a5161);
  }
  try {
    if (_0x448a69) return _0x160963;else _0x160963(0);
  } catch (_0x2b84c5) {}
}