双旋转验证码解决方案
================================================

通过比对边缘像素点色差，均匀取旋转角度查看所有像素点最小色差和即为最合适的旋转角度，注意本项目存在一定误差，如有其他更优方式可以提供，可以私聊作者或提交pr
（由于作者对OpenCV以及图形学知识较为匮乏，更优解可参考：https://github.com/Juannie-PP/tenon）


<hr>
<center>
<h2> Captcha Solvers
</center>
<h3>
    <center>
        <b>CapSolver.com</b>
        <br>
        <a href="https://capsolver.com">
            <img src="https://cdn.discordapp.com/attachments/1173683153538392214/1174968261666938920/goodgif.gif?ex=65698577&is=65571077&hm=f994ad332705597ff5476c0546436a778e1c9ceb7feea39e019c7be0e05050ea&" alt="Capsolver's Banner">
        </a>
    </center>
</h3>
[Capsolver](https://www.capsolver.com/) offers a wide variety of solutions to meet various requirements. Covering everything from the widely-used reCAPTCHA to more specialized types such as DataDome, FunCaptcha, hCaptcha, aws captcha and more, they have mastered the skill of captcha solving. If you're looking to get around recaptcha, hcaptcha, or even funcaptcha, Capsolver is your dependable option for bypassing captchas.
<hr>
