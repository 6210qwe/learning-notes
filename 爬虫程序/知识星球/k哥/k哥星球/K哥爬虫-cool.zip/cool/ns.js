KgUser={
    
    IsEmpty: function(e) {
        return void 0 === e || null == e || "" == e
    },
    Guid: function() {
        function e() {
            return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
        }
        return e() + e() + "-" + e() + "-" + e() + "-" + e() + "-" + e() + e() + e()
    },
    Md5: function(e) {
        var o = 0
          , s = 8;
        function a(e, t, r, i, n, o) {
            return m((t = m(m(t, e), m(i, o))) << n | t >>> 32 - n, r)
        }
        function u(e, t, r, i, n, o, s) {
            return a(t & r | ~t & i, e, t, n, o, s)
        }
        function l(e, t, r, i, n, o, s) {
            return a(t & i | r & ~i, e, t, n, o, s)
        }
        function p(e, t, r, i, n, o, s) {
            return a(t ^ r ^ i, e, t, n, o, s)
        }
        function f(e, t, r, i, n, o, s) {
            return a(r ^ (t | ~i), e, t, n, o, s)
        }
        function m(e, t) {
            var r = (65535 & e) + (65535 & t);
            return (e >> 16) + (t >> 16) + (r >> 16) << 16 | 65535 & r
        }
        return e = e ? function(e) {
            for (var t = function(e, t) {
                e[t >> 5] |= 128 << t % 32,
                e[14 + (t + 64 >>> 9 << 4)] = t;
                for (var r = 1732584193, i = -271733879, n = -1732584194, o = 271733878, s = 0; s < e.length; s += 16) {
                    var a = r
                      , g = i
                      , c = n
                      , d = o;
                    r = u(r, i, n, o, e[s + 0], 7, -680876936),
                    o = u(o, r, i, n, e[s + 1], 12, -389564586),
                    n = u(n, o, r, i, e[s + 2], 17, 606105819),
                    i = u(i, n, o, r, e[s + 3], 22, -1044525330),
                    r = u(r, i, n, o, e[s + 4], 7, -176418897),
                    o = u(o, r, i, n, e[s + 5], 12, 1200080426),
                    n = u(n, o, r, i, e[s + 6], 17, -1473231341),
                    i = u(i, n, o, r, e[s + 7], 22, -45705983),
                    r = u(r, i, n, o, e[s + 8], 7, 1770035416),
                    o = u(o, r, i, n, e[s + 9], 12, -1958414417),
                    n = u(n, o, r, i, e[s + 10], 17, -42063),
                    i = u(i, n, o, r, e[s + 11], 22, -1990404162),
                    r = u(r, i, n, o, e[s + 12], 7, 1804603682),
                    o = u(o, r, i, n, e[s + 13], 12, -40341101),
                    n = u(n, o, r, i, e[s + 14], 17, -1502002290),
                    i = u(i, n, o, r, e[s + 15], 22, 1236535329),
                    r = l(r, i, n, o, e[s + 1], 5, -165796510),
                    o = l(o, r, i, n, e[s + 6], 9, -1069501632),
                    n = l(n, o, r, i, e[s + 11], 14, 643717713),
                    i = l(i, n, o, r, e[s + 0], 20, -373897302),
                    r = l(r, i, n, o, e[s + 5], 5, -701558691),
                    o = l(o, r, i, n, e[s + 10], 9, 38016083),
                    n = l(n, o, r, i, e[s + 15], 14, -660478335),
                    i = l(i, n, o, r, e[s + 4], 20, -405537848),
                    r = l(r, i, n, o, e[s + 9], 5, 568446438),
                    o = l(o, r, i, n, e[s + 14], 9, -1019803690),
                    n = l(n, o, r, i, e[s + 3], 14, -187363961),
                    i = l(i, n, o, r, e[s + 8], 20, 1163531501),
                    r = l(r, i, n, o, e[s + 13], 5, -1444681467),
                    o = l(o, r, i, n, e[s + 2], 9, -51403784),
                    n = l(n, o, r, i, e[s + 7], 14, 1735328473),
                    i = l(i, n, o, r, e[s + 12], 20, -1926607734),
                    r = p(r, i, n, o, e[s + 5], 4, -378558),
                    o = p(o, r, i, n, e[s + 8], 11, -2022574463),
                    n = p(n, o, r, i, e[s + 11], 16, 1839030562),
                    i = p(i, n, o, r, e[s + 14], 23, -35309556),
                    r = p(r, i, n, o, e[s + 1], 4, -1530992060),
                    o = p(o, r, i, n, e[s + 4], 11, 1272893353),
                    n = p(n, o, r, i, e[s + 7], 16, -155497632),
                    i = p(i, n, o, r, e[s + 10], 23, -1094730640),
                    r = p(r, i, n, o, e[s + 13], 4, 681279174),
                    o = p(o, r, i, n, e[s + 0], 11, -358537222),
                    n = p(n, o, r, i, e[s + 3], 16, -722521979),
                    i = p(i, n, o, r, e[s + 6], 23, 76029189),
                    r = p(r, i, n, o, e[s + 9], 4, -640364487),
                    o = p(o, r, i, n, e[s + 12], 11, -421815835),
                    n = p(n, o, r, i, e[s + 15], 16, 530742520),
                    i = p(i, n, o, r, e[s + 2], 23, -995338651),
                    r = f(r, i, n, o, e[s + 0], 6, -198630844),
                    o = f(o, r, i, n, e[s + 7], 10, 1126891415),
                    n = f(n, o, r, i, e[s + 14], 15, -1416354905),
                    i = f(i, n, o, r, e[s + 5], 21, -57434055),
                    r = f(r, i, n, o, e[s + 12], 6, 1700485571),
                    o = f(o, r, i, n, e[s + 3], 10, -1894986606),
                    n = f(n, o, r, i, e[s + 10], 15, -1051523),
                    i = f(i, n, o, r, e[s + 1], 21, -2054922799),
                    r = f(r, i, n, o, e[s + 8], 6, 1873313359),
                    o = f(o, r, i, n, e[s + 15], 10, -30611744),
                    n = f(n, o, r, i, e[s + 6], 15, -1560198380),
                    i = f(i, n, o, r, e[s + 13], 21, 1309151649),
                    r = f(r, i, n, o, e[s + 4], 6, -145523070),
                    o = f(o, r, i, n, e[s + 11], 10, -1120210379),
                    n = f(n, o, r, i, e[s + 2], 15, 718787259),
                    i = f(i, n, o, r, e[s + 9], 21, -343485551),
                    r = m(r, a),
                    i = m(i, g),
                    n = m(n, c),
                    o = m(o, d)
                }
                return Array(r, i, n, o)
            }(function(e) {
                for (var t = Array(), r = (1 << s) - 1, i = 0; i < e.length * s; i += s)
                    t[i >> 5] |= (e.charCodeAt(i / s) & r) << i % 32;
                return t
            }(e), e.length * s), r = o ? "0123456789ABCDEF" : "0123456789abcdef", i = "", n = 0; n < 4 * t.length; n++)
                i += r.charAt(t[n >> 2] >> n % 4 * 8 + 4 & 15) + r.charAt(t[n >> 2] >> n % 4 * 8 & 15);
            return i
        }(e) : ""
    },
    


}
function getKgMid() {
    var e = ""
      , t = ""
      , r = "";
    if (e && e != t &&undefined,
    !e && t && KgUser.Cookie.write(KgUser.KgMid.name, t, 86400 * KgUser.KgMid.days, "/", KgUser.GetDomain(), !0, "None"),
    true) {
        if (KgUser.IsEmpty(r)) {
            e = KgUser.Guid(),
            r = KgUser.Md5(e);
            try {
                KgUser.Cookie.write(KgUser.KgMid.name, KgUser.Md5(e), 86400 * KgUser.KgMid.days, "/", KgUser.GetDomain(), !0, "None"),
                window.localStorage.setItem(KgUser.KgMid.name, KgUser.Md5(e))
            } catch (e) {}
        }
    } else {
        var t = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"
          , e = function() {
            var e = {
                "0": {
                    "0": {},
                    "1": {}
                },
                "1": {
                    "0": {},
                    "1": {}
                },
                "2": {
                    "0": {},
                    "1": {}
                },
                "3": {
                    "0": {},
                    "1": {}
                },
                "4": {
                    "0": {},
                    "1": {}
                }
            }
              , t = "";
            if (0 < e.length) {
                for (var r = [], i = 0, n = e.length; i < n; i++) {
                    var o = e[i].name;
                    r.push(o)
                }
                t = r.toString()
            }
            return t
        }()
          , i = screen.width + "x" + screen.height
          , n = screen.colorDepth || ""
          , o = screen.pixelDepth || ""
          , s = function() {
            var e = ["canvas"];
            try {
                var t, r = document.createElement("canvas");
                r.getContext && r.getContext("2d") && (r.width = 200,
                r.height = 200,
                r.style.display = "inline",
                (t = r.getContext("2d")).rect(0, 0, 10, 10),
                t.rect(2, 2, 6, 6),
                e.push("canvas winding:" + (!1 === t.isPointInPath(5, 5, "evenodd") ? "yes" : "no")),
                t.textBaseline = "alphabetic",
                t.fillStyle = "#f60",
                t.fillRect(125, 1, 62, 20),
                t.fillStyle = "#069",
                t.font = "14px 'Arial'",
                t.fillText("hello kugou", 2, 15),
                t.fillStyle = "rgba(102, 204, 0, 0.2)",
                t.font = "18pt Arial",
                t.fillText("hello kugou", 4, 45),
                t.globalCompositeOperation = "multiply",
                t.fillStyle = "rgb(255,0,255)",
                t.beginPath(),
                t.arc(50, 50, 50, 0, 2 * Math.PI, !0),
                t.closePath(),
                t.fill(),
                t.fillStyle = "rgb(0,255,255)",
                t.beginPath(),
                t.arc(100, 50, 50, 0, 2 * Math.PI, !0),
                t.closePath(),
                t.fill(),
                t.fillStyle = "rgb(255,255,0)",
                t.beginPath(),
                t.arc(75, 100, 50, 0, 2 * Math.PI, !0),
                t.closePath(),
                t.fill(),
                t.fillStyle = "rgb(255,0,255)",
                t.arc(75, 75, 75, 0, 2 * Math.PI, !0),
                t.arc(75, 75, 25, 0, 2 * Math.PI, !0),
                t.fill("evenodd"),
                r.toDataURL && e.push("canvas fp:" + r.toDataURL()))
            } catch (e) {}
            return KgUser.Md5(e.toString())
        }();
        r = KgUser.Md5(t + e + i + n + o + s)
    }
    return r
}

console.log(getKgMid())