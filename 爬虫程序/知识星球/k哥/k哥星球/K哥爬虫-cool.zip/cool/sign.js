KgUser={
    
    IsEmpty: function(e) {
        return void 0 === e || null == e || "" == e
    },
    Guid: function() {
        function e() {
            return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
        }
        return e() + e() + "-" + e() + "-" + e() + "-" + e() + "-" + e() + e() + e()
    },
    Md5: function(e) {
        var o = 0
          , s = 8;
        function a(e, t, r, i, n, o) {
            return m((t = m(m(t, e), m(i, o))) << n | t >>> 32 - n, r)
        }
        function u(e, t, r, i, n, o, s) {
            return a(t & r | ~t & i, e, t, n, o, s)
        }
        function l(e, t, r, i, n, o, s) {
            return a(t & i | r & ~i, e, t, n, o, s)
        }
        function p(e, t, r, i, n, o, s) {
            return a(t ^ r ^ i, e, t, n, o, s)
        }
        function f(e, t, r, i, n, o, s) {
            return a(r ^ (t | ~i), e, t, n, o, s)
        }
        function m(e, t) {
            var r = (65535 & e) + (65535 & t);
            return (e >> 16) + (t >> 16) + (r >> 16) << 16 | 65535 & r
        }
        return e = e ? function(e) {
            for (var t = function(e, t) {
                e[t >> 5] |= 128 << t % 32,
                e[14 + (t + 64 >>> 9 << 4)] = t;
                for (var r = 1732584193, i = -271733879, n = -1732584194, o = 271733878, s = 0; s < e.length; s += 16) {
                    var a = r
                      , g = i
                      , c = n
                      , d = o;
                    r = u(r, i, n, o, e[s + 0], 7, -680876936),
                    o = u(o, r, i, n, e[s + 1], 12, -389564586),
                    n = u(n, o, r, i, e[s + 2], 17, 606105819),
                    i = u(i, n, o, r, e[s + 3], 22, -1044525330),
                    r = u(r, i, n, o, e[s + 4], 7, -176418897),
                    o = u(o, r, i, n, e[s + 5], 12, 1200080426),
                    n = u(n, o, r, i, e[s + 6], 17, -1473231341),
                    i = u(i, n, o, r, e[s + 7], 22, -45705983),
                    r = u(r, i, n, o, e[s + 8], 7, 1770035416),
                    o = u(o, r, i, n, e[s + 9], 12, -1958414417),
                    n = u(n, o, r, i, e[s + 10], 17, -42063),
                    i = u(i, n, o, r, e[s + 11], 22, -1990404162),
                    r = u(r, i, n, o, e[s + 12], 7, 1804603682),
                    o = u(o, r, i, n, e[s + 13], 12, -40341101),
                    n = u(n, o, r, i, e[s + 14], 17, -1502002290),
                    i = u(i, n, o, r, e[s + 15], 22, 1236535329),
                    r = l(r, i, n, o, e[s + 1], 5, -165796510),
                    o = l(o, r, i, n, e[s + 6], 9, -1069501632),
                    n = l(n, o, r, i, e[s + 11], 14, 643717713),
                    i = l(i, n, o, r, e[s + 0], 20, -373897302),
                    r = l(r, i, n, o, e[s + 5], 5, -701558691),
                    o = l(o, r, i, n, e[s + 10], 9, 38016083),
                    n = l(n, o, r, i, e[s + 15], 14, -660478335),
                    i = l(i, n, o, r, e[s + 4], 20, -405537848),
                    r = l(r, i, n, o, e[s + 9], 5, 568446438),
                    o = l(o, r, i, n, e[s + 14], 9, -1019803690),
                    n = l(n, o, r, i, e[s + 3], 14, -187363961),
                    i = l(i, n, o, r, e[s + 8], 20, 1163531501),
                    r = l(r, i, n, o, e[s + 13], 5, -1444681467),
                    o = l(o, r, i, n, e[s + 2], 9, -51403784),
                    n = l(n, o, r, i, e[s + 7], 14, 1735328473),
                    i = l(i, n, o, r, e[s + 12], 20, -1926607734),
                    r = p(r, i, n, o, e[s + 5], 4, -378558),
                    o = p(o, r, i, n, e[s + 8], 11, -2022574463),
                    n = p(n, o, r, i, e[s + 11], 16, 1839030562),
                    i = p(i, n, o, r, e[s + 14], 23, -35309556),
                    r = p(r, i, n, o, e[s + 1], 4, -1530992060),
                    o = p(o, r, i, n, e[s + 4], 11, 1272893353),
                    n = p(n, o, r, i, e[s + 7], 16, -155497632),
                    i = p(i, n, o, r, e[s + 10], 23, -1094730640),
                    r = p(r, i, n, o, e[s + 13], 4, 681279174),
                    o = p(o, r, i, n, e[s + 0], 11, -358537222),
                    n = p(n, o, r, i, e[s + 3], 16, -722521979),
                    i = p(i, n, o, r, e[s + 6], 23, 76029189),
                    r = p(r, i, n, o, e[s + 9], 4, -640364487),
                    o = p(o, r, i, n, e[s + 12], 11, -421815835),
                    n = p(n, o, r, i, e[s + 15], 16, 530742520),
                    i = p(i, n, o, r, e[s + 2], 23, -995338651),
                    r = f(r, i, n, o, e[s + 0], 6, -198630844),
                    o = f(o, r, i, n, e[s + 7], 10, 1126891415),
                    n = f(n, o, r, i, e[s + 14], 15, -1416354905),
                    i = f(i, n, o, r, e[s + 5], 21, -57434055),
                    r = f(r, i, n, o, e[s + 12], 6, 1700485571),
                    o = f(o, r, i, n, e[s + 3], 10, -1894986606),
                    n = f(n, o, r, i, e[s + 10], 15, -1051523),
                    i = f(i, n, o, r, e[s + 1], 21, -2054922799),
                    r = f(r, i, n, o, e[s + 8], 6, 1873313359),
                    o = f(o, r, i, n, e[s + 15], 10, -30611744),
                    n = f(n, o, r, i, e[s + 6], 15, -1560198380),
                    i = f(i, n, o, r, e[s + 13], 21, 1309151649),
                    r = f(r, i, n, o, e[s + 4], 6, -145523070),
                    o = f(o, r, i, n, e[s + 11], 10, -1120210379),
                    n = f(n, o, r, i, e[s + 2], 15, 718787259),
                    i = f(i, n, o, r, e[s + 9], 21, -343485551),
                    r = m(r, a),
                    i = m(i, g),
                    n = m(n, c),
                    o = m(o, d)
                }
                return Array(r, i, n, o)
            }(function(e) {
                for (var t = Array(), r = (1 << s) - 1, i = 0; i < e.length * s; i += s)
                    t[i >> 5] |= (e.charCodeAt(i / s) & r) << i % 32;
                return t
            }(e), e.length * s), r = o ? "0123456789ABCDEF" : "0123456789abcdef", i = "", n = 0; n < 4 * t.length; n++)
                i += r.charAt(t[n >> 2] >> n % 4 * 8 + 4 & 15) + r.charAt(t[n >> 2] >> n % 4 * 8 & 15);
            return i
        }(e) : ""
    },
    
};;;;

function get_sign(clienttime,dfid,mid,uuid,data){
    json_data=JSON.stringify(data)
    res= `NVPh5oo715z5DIWAeQlhMDsWXXQV4hwtappid=1014clienttime=${clienttime}clientver=1000dfid=${dfid}mid=${mid}srcappid=2919uuid=${uuid}${json_data}NVPh5oo715z5DIWAeQlhMDsWXXQV4hwt`
    signature = KgUser.Md5(res)

    return signature

}
console.log(get_sign('1724051219493','1bmA3D0aPYI6477l6V1VLpty','41803bc96e65e66750457a0752c20d87','41803bc96e65e66750457a0752c20d87',{
    "eventid": "gz_tx_event_be43282bec5f5027037c3c13d5643614",
    "userid": 0,
    "platid": 4,
    "v_type": 23,
    "verifycode": "KGCodeYD|{\"ticket\":\"CN31_b_0gxP_MRwzKhQNZt55G2qdhuLGB.AS6qgWb6..t6BbdPbuqYN00W2AA0fZHec2b9W._SNRwdRwDJ9dIqGhIfM5sHNCFf1UJYwsx1DMUg0r2R4*TAOx__Ko2XN8CXunmL2GYGyt6gneq5lsUDeqBrRz0abSw2on3DX.fOOoqdex1s.EWyYeFO.ZTxC*P_lm1zPovA_A2mjqFeZAOUrvVwpCt*4uvpCiMxKj1_sAv0PmLA_IGQYQQRFZuZJprHadi1s_2Un1vhvJh2nj3UPG5F1iFAbI*Q*NArMtTGsKcKbSX_GX*XHIJUjSFfiHRZ4AdhqGRWdR4AvYHnWHMTVZWMzfcXEVZsjUX4vtU23rZqap1O0dzKK0CNUylaZWHV2Rr90pqO8jAgKjf2mC5E84XPRYIibY4xpfTopaKX3WvUWgAWUeR6hTcFbYXE6s*X02FGS3JT6j2fdsnB0vRlZZOLbI5iQnS0ZyFUyFZrn.i3f*rbj9BIvtQm1BOMLCYehEFR2LBOY77_v_i_1\"}",
    "wasm": 1,
    "i": "",
    "sid": "ht9rJkQeo+R5OuKTuztwYgkocXikpRPHbFCFJoEhYcTWNhFhpGwPE9ailIdgpjE9wmdP3WIQhaQeBItZxU/jXqwUs2UpTwzWAIuVjstk3NAlKOvORe+H5X7+sBjwZintaj0Q0WWAYCxGqXIhKSBlFZEjuqljjwDRWLbdaddjpQjftCzjEi2DUvnHPJfnNSjKRI6FodHm3ioLJNvDdgW3Iebm8bTd0QF94g8FEXaUkm5jkIFUGiYgnnA2tnqvtt6Tkk/rrQ1jfjB+m25ZirQOjP6jOCBk6PAFkz/ZH9DWHvZqc0t74Wz1pAvWIN+Gz+4F+hUHa7Jo+rRyf7YDZNrfLQ==",
    "edt": "oIzPtgBDFgaFWgJOZWw/ZtHdxGBs1CyiCv3Ra6i/DMqep8vaQKJTVa4gT23AM83gqaihEAjYcbGx/R3lD6Dt/mRFyjqGGXjj4WaZb8ZwfdHTBLSjVpwq1ZpqfnCtQcnksxCBKBO7F4CFaP//SlsHZNtc9diJg9woVUZYeW8HlSI1dMcZudY1UkFJ0h7pX5/wQgy2Dt8+/P2lZ/m3Pur08sVhYjEtB0wcHYShx0Qw8BrcJZ1NtUa/EXMnd9LiEB13OjdPvqFsmnn/ARs1oczs7sFONR8HzTfdzuqYUrSkrqlqIICvYJQofolGF689/gcdljK/2BZWMHNjLiFNnbTOc2ALcF7YDaO4jiaNI3L7WYfbS1D5JyXfNsDZxlVsrbt+1o4hxwgGw5SzMOAXQaOvvOeUNGOxigZhBmG0XV6BbAyOQ4gIic3LCtFo2jD2MgteULn2/TP6R2p/rbtewd3OYvqqCtJ+nwlcFrBStX2bmK3l8+88YiHtXWTXuhro8IQuaejwTkjfl/5hw5PldibTuouSMRIKfiVaAwdq6oj2VR2b3G4rCgfaJKCesZ22mIyhkIeYButkaJWPCCv7JeyIYzaQWhDYsK/jK5GifCBsa4VlCv/L96sI3ef1NN1syNgJWQ99YKGzkKHX+o+DZR9qveEmv0k8/V2r3bMWyZKtK4tAa3d1hiZLWrY+QjYfSu+vAmiPk+KF7dTWyC48on2x8QPAUF6gfIRx1kAIJQIfiyOvHHbSIIBlvsVUH2V/yXztl2QmXAHGY8z8SYcndEKqZPtkUdpJxVI4LmUbBclT+3Tp8oksR6QjF6AjVvGNUJkUrOCyCGKNux7q0DqNVxlrb7H/c9pStPexBKY1b23DFCu60TRb1nJgyvdeCwrCJKWxioSjOTrglToZ+TK/KsOojWmxIgsp0J0mnbLVly55zrmL/aacqjFX5WW48ilYd9zfgyVqpbL5hvBs0SpVQIlHNS1fCggMKolegUUrOcLEWOCSoFHeXhXX9y71QLiXCgeR5MJkx3GlbJbGAs6hFo6bxBoxVymj5gN4CEfiE11P/UMhk0uLbOmMj4RG7Rtf3q+/P4gj6oqeMc6U2ZxPz0lbFlPhy1/0XQkxaTdQvvnGVydtf+q1G9DJrgk3axPviAXpsP2ZhWNMOZ8CALxgvxeYi9zNyaSytvPMxHzg1eylxGjasuRRgsXdgzFLJ7jYo4cXyD6qCrdK79k3usNOHqauZGREwxmQoX42/2nOwNYIyGAFlMYy6Qgi32jdGwIDcoscamb0lWC02yj9j00UvoDC5LNMBK0/ll1BDAczU3K/LgDVxUONqKGeNVOIY+dO5h/zoDpglanGjlR+sr0XBvfs40Umqj8C0F4gR0LddLQwoi3IqBQHaQsEzPvzkYLiVuMCNnG4eG7IigDIKzjNvTS+GF3V76nzdVsvcpoDSe6JLo9EyGB3NnbuT2u4EhOXCvp3ee4GavKjTU71Ssh6QOdny0HCuPTw51ln37XB6wWXpRJlg19u9JhewVfxLjj8avk5gJ+zrdWjWLzQiLDSZajqjWRKdLWED8LcWFgmg43OQk7vqVfoRzV9pdBa3A3Jjwv+UfP/7Yvshxyd2dq+Kq7wZx69bSpElkmabL25qDOr733QcK10fOdILAA+dHpjnkGerur1gmTUMkuTtp8Hakpz11V4p9WSLLyiJ351J0oFwhdq36EZMbm52acxswUy8gU7Yc+Szb8ja8hzY33iPe2RbdAYbAV1UxwqU5JrEgKLjVgX+v2jP9+b7EkhqowSzMmaFOLdVxTwtgaOArvEEhDtcwY3qcmHYtbouLgnJZKZEE83dizhnakwr1cEhhpskFbpHn751mUqpK6pdaNC9O/znvDkbk6mBLK8nAbujkSRmTiQyrdW0CCeXtOhxEP19O556sIvKrUJkDxb3LdP4UEj/AQzQbocFEMKimiBRHgMLrhUm5/o4MxmiIds/CMIXV3nfxQQicoSXOxbX6mB9YXkQBnvU3jaAbwfvIOljHz7W2x1u5sgPNoDXmVBsPR/noOGQgysAPhUxoNM9WBJWOppx07NhzX0T63Y/yRgq3I+NOqvJQWFrAXPEmVGjEDTmGu0EusmtjSUbsPAKH7BPzt5Qgs1smbRBzCKjLlIWl2nIw86gmqMUi8SqSR06vYRSHYZDh5jDrgf5sSJezRLi/4YxbwkuhN7i7ZCzK1/NbtpVDIHCZ/cTb/NDpNxHHUcF+3CDoo5GzaCdth+uhVeDMUrd7rb/jWrODPRpoguNz3MgdPGjLKyD8v3HNl10Z1NOm7M7v4t8xojb5JDSbhHflUsftbnLx5yLJkmMNbuswmgV6LNaT7VggGHvnUSrYmPqpV/V8EZ5HQrPFZPIe1nDPEimkgRzioK+YcD5G9p8winrOw4hN37Qptyn1Dw1VaBteFTpAVNG1NDV5SgBmYwi+g7U754dFrycYG6WrGcKiK9PSsdZG8/mrVK3Rphb1VMVqrADqfaaDlNccWJPLSEIkTj5WrLGer7gFSJKP1eMn5Z2huBxyu252yc0nkxb6bDZoYbN0oD19lMOJolaQPlmlGcx5RsE3UGQwb2L32vduaehPr0dMVcsylE4IHwitBelPLNZVI4lbHuujJQJzPULir6hy7ByKifxrijZBx+/VA4fSq80umX/4cKxJ4ThaPxLD97O3ZcYHsHx8sDwxlWP/Nta2UxWsDn/s9ThRIrLq5mV9ESD1gp0eLKD71SoY1jWY95lyTI5jXzkGJLGKv6e80cywqbIx3AlpvHReGrJlqwrbTSxz2IBP8oH84J5fnl+V3OZW08TqIzwkHW2ZguNdkxyrCcrwQ80rnt1rM4oi63zqKoxWqr8Iyb6jsMwwTMFYVp50khOLnuQa1U9nR76mrVp8H/YzeYxUk8KIA/7tRYXoXQMH9A8AWrkj+lxsA6X2UMQNpRQCKe6T6SP1Awr0GET2vl/5+ogQjIXJZ1hab7sm8nqDIkW0FfLOhXnCVsh9rW1HA9rOXxyN/RORrWrJZhvznOFZwfAQ/nVvXZHC+liKZZ7VwTlWogGZPTFV5LTojiUkx3Qy5TR02ig3H1BRkmCC6PBSY2KUjCCLXLJN9TgU42fvMcHtnfxYuDDaUlaR/APccHGnVPG+0LqdlGCTXDP0GGNM0tj/PK1H0ALR5ATn1QEcNaNP7468WT4tH/mTPIDfY7OtvKIScBgrce9zuCGtBzqkf8Zfklik6mPgtzFiRUBpZbhJrXfOcGcfOBhNGaTRjtog43eDabMVHhJIE9FljIgswxKoGLc5YbGszaFh48zmlTpbyUGGmtn7g/PeEhLjJkmq3LDYRrybGzs/7+M3mT13sNZl+auOtDH2p7wX4R0EOEnfyraRXhD1E2lwk0j3wGhGWsHf7SBPA4L6xvaN7YOUS3PPuw4xaBCyRbYKA3FbtfJMCiBNbPaWIq0Ctjr6yWHfjsVJQsdptFgnfdNreTeFbv6QUA2wxydUonfqvvW2I9CEY9hZLzEDZR8qpmX2VeGkBuhJCpBYKoRDxSfJQw9kjkpoN0T3sb7ndF6MsYKFgLboZdNH3JO1LjYFo5u8i/QSsfIBayYpdsv7NVsuNGxPnu6KwvYtJ2+ZoiRhGUvUJj5s6tk1oSdEL3gxqy15Kj8FNo9FFl164lDU+ng9y0psDju3hcQjBSnPMFd96qjh03T6ifNN29lS+ZKAM5/pO5C4BOw2zY3+aZEkJ8d4L96WpSOJnZWn2JWneyPsgqluqSGJArmWYsK8jRCgkWSjZUXZyxVZyr2uGDi7NHQVis4g+A8Eoy8aBquUbVWUvk1S+4StnEHxfLXNDwKzupQOI41t1m/4DjN3F1p1zXVruwSXH5g097Slmxh6IQ+hQFQsZnv/wfjLmqnoSsSuPompiXBBrz+xAm9UrSPxTlmG+UAIIAAzB2ju9mhsvD9kQ=",
    "sessionid": "sid_0227459581-gz_tx_event_be43282bec5f5027037c3c13d5643614",
    "pk": "005b405f32c487540c0579316cde44e6cd4a0960430abaa4e48d871d04c8dd3279612a0fff189d776694b1094f11ea96d94e96a1cb31edb30cff36112b24a6bb872f7325fc9842dba83af0d81e559e756c4285179cc649552587e1ba8f08da92bdbc2896a06912c409936ba507c2720c8a6781e75784e686d7c03b7cd59d1580",
    "params": "c4c60d2773f1f33692fcdb2975fb437b"
}))

