window = global;
window.window = window
Window = function(){}
window.__proto__ = Window.prototype
crypto = require("crypto")
window.addEventListener = function(res){
	console.log("addEventListener", res)
}
window.requestAnimationFrame = function(res){
	console.log("addEventListener", res)
}
navigator = {
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    platform: 'Win32',
    getBattery: function () {
        return battery
    },
    plugins: [],
	webdriver: false,
	vendor: 'Google Inc.',
	appCodeName: 'Mozilla',
	languages: ['zh-CN', 'zh'],
	language: 'zh-CN',
	deviceMemory: 8,
	hardwareConcurrency: 8,
	cookieEnabled: true,
}
Navigator = function Navigator(res){debugger;};
navigator.__proto__ = Navigator.prototype;
// location
location = {
    "ancestorOrigins": {},
    "href": "https://we.51job.com/api/job/search-pc",
    "origin": "https://we.51job.com",
    "protocol": "https:",
    "host": "we.51job.com",
    "hostname": "we.51job.com",
    "port": "",
    "pathname": "/api/job/search-pc",
    "search": "",
    "hash": "",
	toString: function(){
		return this.href
	}
}

Location = function (res){
    debugger;
};
location.__proto__ = Location.prototype;

cssstyle = {
	'display': 'inline'
}
HTMLCanvasElement =function HTMLCanvasElement (){
}
canvas = {
	width: 60,
	height: 400,
    getContext: function (res) {
        console.log("canvas触发getContext", res)
		if (res == '2d'){
			return CanvasRenderingContext2D
		}else if (res == "webgl"){
			return WebGLRenderingContext22
		}
        //return WebGLRenderingContext
    },
    style: cssstyle,
    toDataURL: function (res) {
        console.log("canvas触发toDataURL", res)

        return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAA8CAYAAABIFuztAAAAAXNSR0IArs4c6QAAIABJREFUeF7tXQl8VMX9/87bHAQSuQ9REfEoeBSFBNTSVqutaK1tvQ9ERUmCrYpXq4KiiHjghRZIgiIiYBG1rVX+UsWjVUQSUBS5RAS55YYAIdl9889v9s3b2bfv7b7dbCCBeZ+PbUhm5s38Zub3/d2PQT+aApoCmgKaApoCKVCApdBHd2nkFOCF4I18CSlNn5XhYD7vbQH0AdAZwFwAFQD2pUQo3UlTwCcFDuYL5ZMEh14zDSAHzZ5nArgZQFFmBuvW+fAmaN08A6s27MP6zdU1AD4EMAzAnINmxXohDYoCjQ9ABpaNA+PFAJaAs4fA+KvgrC/GF86sF8rS++gZXzgIRSXdwdn74Kxfvb2P3nXtpGZoUvUagB/Ee9P1WPN/F8+1OQ/fpGXUBTgS5+J2TMYEpGvMtEzMZZADooEUlt4K4H4wfi5KixekcW2dALzbtXNOt2cHH4tzC1ogEIhc5207azD2jfUYMXE1qvaZzwEYXAsmh6TmmUaa66EcFHAHkJvGt4dhfgSgq92+Ppm0320JX8ZBMI2z8MLAjRhYdh4Yf1cDiE8CagDZ/wJT/QBIOzJTDb6y49FP/PkYZGYYngfg29V7cfE9i7Dwuz1/A3CLz5Oim2kK+KJA7IUKH/jRMUw5LIn/s14l70RTDs+hE6qaXI5X+u9O1Dwtf9caSFwyNjoNJCx0TK4HjSAtx83nIFOuPb/d1ZOG/cRX8/Wbq9H92vnYtK3mbAAkGOpHUyAtFIgGkIZ+uTSA1G3TtQbCLK21MQNI1w6tMxd/O70AuU0D5OvA9Q8vxdThXdG6OblEws+09zehfNEuPHlrF/vfVw5d8qnlaK/bOdK9NQUsCkQARNrdGZ+JsiKymcY+brZ5ae7i7CPbXh/53WAY5gbLb3A3GP+rbRYjkxhnXzpMZbe5vtvdpFYCwyyJ8UlE1nGBsoDIuOoaqEHYnxL+u/RxAG1EX85K7DGifSDUZwAYD7+DsxlRWlHsfJfYZjf1/YwvFtpe+HFvI30gEd+PO41oBJ/zJx9IB+xw9V2QRnEFCjENZdiA5uiHAcK/MRiXYwk6iIkW478YhyniZ6mBlGAKJuBnmIGTY9rQLwbhGpTgF+JvF2AhXkMZmjmChHYjG5ejEJ2w1R6f2m/EYTgLd2IQPsat+MD+t5yPHK8S2aJdF2y2x5d96XczcPILAG5SzsXmuJpIhObh/eFsMBgfDcavEP4M0tY5Oy9q751+MlUoCwU2xJiGw5OJP4/om/jY0BuO+uvDRRRsBcyYvRW/veMbfDj2FJzVo4Xdsv9DS/HunG348f9ODx9RztG27xxs2REktWVZ9JD6X5oCqVEgAiB+HcTOSxNhWpttJhn+3ViYxsUIhDoIJk+XRPoupJlMvTh+bMVODcQ55/hgFgY4FWBUv05kHQ/bIBYx55VEOdGJ1tIpGnnnCpuRFJbeB9N4UfhpIoAB8Xd6yEEeBp8wGDjn7QRqL7OiuudJzJ8ApA+WuzJrYvQ/oJVgwJ/gOPTFreiKDfgIT6E9dtqAcSnmCyYvAYSm8j6eQXeswUycJPq9i+eEY/05/Arj8MuoMQgszsR3MafW2ZYa0HgEYDSHDTgsCvgk6FA7mvNytI36uzpeh7Kd/jWQMHicZZ/ZiFDQxt77ZAHE6USPjDnOU2iLvddz33/+lIJzCsJg4RdAqO01w5Zg6sxNFJQREYxS4xu6l6aAoIATQKbZ0pUXgcKMKtJOXiLGW4Dxm2Mks6Z7jovREtyYnaq1eEVUJQIQp5NdrkGVAvc0XW5FOIUZuvSluJnHnIzcbd70jkSmv/DfnxXMaF92pWuElTp3tQ35nfwECiQxfxmF5WTWUlp/Fq8Jxu8EAklOtZ+ToVMbpyahgpJT63AeMzefCvWnhwBL/Vn2pXmSpiQBjNp8hBNA67gNVwhtioBNRGEl2isa1EuYcvatC4A4BQv/Pr11K94sOPyYjk3E8r9avht3PbcCE4aegCPbZdvkfOntDXhv7nZh2pLP0JKVeGTi6hEiKkw/mgJpoEDyAKKauvbmvGgxwwmWSSds/gpLb4ujzEJq6KsbWPiRxhIBiOrwVomjMoSqJp/EMPB45rtYJ3osyDoZjrsZLWymiABYdIiuG4AwfiyA1gnDhpOb//sSQNwAQ0r6pG2okj/9241h0++cYbxOAJFARG2lVhLv7Kogoc5Rak3STKaO0QaVNoDIPmTiGo1pwuwlpCW/AKICPmmR8vESnlRBJJ4JS9VA/Gjc7kT67ptXe3Q58ZhmSV//O0evwNOvrh0CYGTSnXUHTQEXCkQAxA8DlwNIpsrZg2B8AjgbAMO8QtiDM4K3IBR4xdZG3KS5gxlAIj6fubaG464BJQMgr8fNB0kRQGg740n36QIQeWxUP0g8IFHfOw35AsjIPEUP+UhIO5Kg4HarJYAR0DRIAPFrLnZnWTPfeLTbby4+O+yme/GtDVj9o3fC+e/6tELPrnmi7W/vWIgZs7eRGXW65oaaAumggDMKK9ru6/UGKaFx9jiA3op/YCw4Gw7gOlQ1GSjMQ/sTQOKbsLxNSF6Je07fhNfFV99LQKrmqhANVWkzGQ2EEgkjgQLeIJLk/NVEQsmsp2E8BuFqjMVUYe6hx2kaUoFA+kmcPgdq4+UMT/Q3Ob7UIEbgX8IxrwKGH3MYmdho7gPwKYpxja2ZJKmBxEZqObUGt/OWSAOpe5LoXYV/6DCq9J7jBbluH7sLz7z8hetNnTVrFgLLbhfO9X3VJtr0nROq3BPqWJu9/mM6mIceQ1MgGkAikmyvmOgUNQ8kzFjftMwrt4ncENnXMFvBNL60Jeb9CSDxnOhkQifzmtcFlkmJ0rFNZ0NG4VA0lhqFpQYERNYXZvBOO3nEbxJ2vCcLIJExKWEyPA+3J4n5qwCiMnsJCtJPIU1PatSU0y/i5rNwAshInI8b8alwwscDF3VZEgTodxPwsugrQY0c9KpmQXOYil54HG/G+G1UwMkt28d8VRNw808495HMUU6fmFuAhpvfxClgyIW7+VRi97pNk2zjh0Wv9swhP8ichTtx5sAF4C455t2Pb4b5L58Gw2B4eMIPeKBs1bTaaLIrNdvTFEgXBdwzcyPMKPIeZya6M0olImlHJyHuTwChObj5H9S5x5MAneumfsAfBBGiAeRZqzRE2I6ggo4KPPQzhfgSD2S8JGUACY8ps+6jQ4bVk+Bz/s5SJsSsydmsMmXJrMk5PQpv4G5cgs3IFW9TzU9+AES2kf3VMGCvgyz7yGgvtZ1zPAlwUhtS+6jjlJRNCZ/3SHiud/hs7DmKDeNVz3x4gpvBGYWrj7L9ViqAmEYHERDh9sizJn2H8W94ccGJueNml52KjAyG1z/YhIEPL8X4zs3RMzcTj6yuxBfNA3j7qZNweJssfPb1Tvyi+KstwRDvXrv6teliHnocTYH9X9ohnTR3OjXTOfbBMJYHWDqLKfrxdUizVmMmS51rYdXneZNavYxkTEzoN08/Oe+PFGVFmsj366pE8mBVtYmjO2SjX992osTJxHc24ranv8PO3aELAbyTeFjdQlPAPwUaN4B4Rcv4X//B3dIjMMIJIG6hsaoGIsNjGzuxGjSAqLlTauSXN9Ep7bw0O4vdcMtlHXHJ2W3Q68Q8Ya7auTuIWeXbMeaN9fT/W0TuJ/B6Y98/Pf+GR4HGCyB1d0Y2vN2oy4wITMncJn0kERNMFzsZzhpfBRA189ypZXg50esyzQPZt0EDSOqEOZXCNGpLt/+yNpfyRGsYCsuiEu5UoXoMoMRgp/4e3VNTIIYCjQ9A1DIhzhIih/oGRzL8w5TwoA8BiJor4RVSqwHEcaDq04R1qJ9dvf5GSYHGByCNkswNa9L6g1INaz/0bDQFGisFNIA01p2rw7w1gNSBeLqrpoCmgE0BDSD6MGgKaApoCmgKpEQBDSApkU130hTQFNAU0BTQAKLPgKaApoCmQOOjwFEAegKgD8Mcbv1HFTbXW/9RPaJFtZGZXwKoqa/laQCpL8rqcTUFNAU0BdJPgVa1FQ/+XJsUWiCHZgw49ogctMwzsGhVFXbvCalv3U75QrVFsz9J/1TU74HUx+h6TE0BTQFNAU2BdFHgLCsptNlJXZpiwIXtcU5+c3Tt3BTZmQH7HWs27cP8Zbvw2nubMe39zQiGRKG02QDoS7O70zUZGkdrIOmkph5LU0BTQFMg/RTIAnArJYu2bZmFUX/ujOsuaO/rLSvWVuH251fgrY+pIAHof6ha+gpfnX000gDig0i6iaaApoCmwAGiQIbF9E+56OetMfnBE5DXlH6V3DN91iZcO3wp9lXzYK1PhD4qRv6ROj++AKSwAl3BcDEzcTKAXDAwDgQZxxbO8L9gLt6c0BW76jybAzzAgx8iY10zDADD2YwhFxwcDEtFlVWgD+dYXFaAvxzIaRaW4wnG0K1WGvmwNB9P01yKKnAHgLMbwvzcaFNUjkvBcN2Bmt+BpI/bfh3I89NQ3j2oHD/hBq6CgYklp2FlQ5kXzWNQObqYAH36FwYwdFxB+iT2FNZJ/o7zCDz++UQ3Yr0pDBHu8sG8HTj3lq+o9D+Zsf5kaSQpj0cd487mxtloFcjCYHCcygg0iKECexiDyTmyGQOpVvTs4EBJWX79OGrqtMIkOhfPx7U8hMvELnFUgYnoBULqPQ2FQWsASWJDraYaQJKnWX32KP4CnXkII8BhNAAGHbPUBgQgp9Dnh7sd0xTlE05FsyYRP0eq+/PUq2tw13PfU/fPYYFkqmPFBZDiBWjHq/EAGI4GUMWBt6tbY9rEY1BFHTkHK56L0xEQhdzagGN7wMDIsT2xuC4TOpB9JaOBiS9LCvAAIxhpYI8GkOQ3RANI8jSrzx4NiEHX5zLTMfbzTXNY50VT83F0hyb2eNXBEGZ/XYlTjm2K1odRUWb3Z86inWjXPAtdjoj0pZZX3b8Ef39/E/14H4Cv6zJRVw1EgMM83APgTAIGBPBkaQ8scHuROAwMw2o9/K04sDS7OYY8fzy8P9Jcl9nWc18bQBTzUD2/MunhNYAkTbIDauLTJqzY/dIA4usM08e/Rtw/oBOGDyQZPvL8Zez3GPXKGlxwZku88xR5FWKfmZ9vQ9/BC5HXNICNM3ojJzuivWzYWoPOf/yc/CHlln/F14TcGrkCSHE5TjaBIQxoxgy8WdITE+O9QZh+OH7LTSw3m+D5jCr8gTNcyIEvyvLxgNq3aD5+wUO4jcxfjOPtkgIRoyweAVzlGA4Dp8q/2ReQ42UzA6uMEAZyjg7WxLdxhtdKe2LGTZ+hZUYWbgZAhCfIJU2poiYXYxP5ZxTgiF4mxy5SsU0mvkro6mO4YT7aZobQj4XjssOf7AMquYFPg80wyfluZT1TwXAsgHyxdmCVUYNnSs7ASvLFbDgMV3AT9EXE5gibDFcEgL+FgOJ4PhDO8bJhoKj2K4idyERA5kVm4N0OOzHtwbNBDrSo56Y56GkEcDEzcCw4KBGJ5hIExxrDwD/G9cCHqibm3A9moj/joKSmAOeohIFPnOv28oGQlmsGcQ/jOJ4z/MiDeHx8byxLdJqd9BFqIsNGFsBrCAp6RflbnBrIzXNxVMgQJpSWJsfk8b3wmvOdRXNwPAJ4CAyZHHgywLFJ2sUDBh4OmvgV+cXIVyboBSwJcEwcVyB8ZvajAogZwP9UeoFhNwfmBJvhRec5IR9BiOF6cJxAd4XMxwzYZgIfh/IwPdGZprtUVIHHGMOJHPi0LB+POdc4YAnyMivxGDiOYgFML+mBV2SbgV+ggAXRHwxHMiBDngmegUnjTwMxHvEUVuBsBtwMjmwwzCrNx+io+z4X/TjDZYyhmgNjGXAa3SW1DeeoZgGMLu2B/ybae7pvWaY43+o9X2BwTA0Z+AtMtFXHSgTgbn93AzhPHuGYcBr9fML3sWx6AY4/MlqDuGzIYrz+wWYcf2QOlk0X7CPmGffmetw8arn4/cp/FERpMPS73925CG/P3mIC6Aek7r/2ApAiAgBw7EIIw0pPx7eJNjbq0FggAQPbwTG0LF9kR4qnuBzhscOMamFZPu6Vf7MvNtCULm1ZPj5XNpgYCzFcApq9YGhCBxtAyDQx3TDQBxxHgGGvYJxMgAi1/Sq7BYbH04qKKsQHd34h/TriQDOhRVWyGozkmbjYDUAKK9BHXB4gT/EPkeErx/KjbA0YeEw16ykMeBMH2rDIfNfX5GKImY2a7C0CdMn+SUQi8yFlBjVlwA4A+8BAMXwxTnTLF0XA3MRJB1JV97XGcGmCpKGLynEVGK4QzJ+CIoC9PAw6TcnnRbQFx7TSArxqMwzLiU/aptgPDhJt9jDUsluL5rUfFv6uJhf3SybnBiDEvDIqcR8DTk4GPK7/Hk2yNuN+RvSxfFU2fRjoQnwH4AT1IruZsArLMYQxnM45FpXm4x6nuXLgXFxuMPTjBlYF9+K+7Gy0FQBiwADHj+DozJmgTxVjyCEaWqbesWX5+NCFXhRC2dwPvWymDDSR+yLGj5yrxTV5eDgRiBRW4A/guIEBm1gW7ivpjh/Ve1pYgd4MuAscNfKeW8BzM2P4teNcSJ9niHO8V5qPsZJmRRW4DRzncIYqg+PJkgLMpfcMnIuTDAP3guMwCS501zgH5TM0teayBwxVAYaScT3FN0w8n5vnoVvIxH1gaCHvG4BM4YvlIJsMnePcegIQwSNcJ8eRKc5+OOgmBkST4Z1K2xeP7pjdbuUbvWK6pwNAxry+Hn9+SgDMo1aOSErTdAWQwgo8ShcbHMuzWuCeZE1Slv9kJAdaqpspDuc8jGLATwRvZOIi2gBTPA/nmRzFJE2GmuC+F0/CVgVACHCW1hh4/KUe2CSkp10YDobjOIfJmAC7MaW98ZnQZCpwLQcuYYZgio+U5Se29XmZsNwYUPFsHGFmYjhjaAdgjcHxrJQ+6eKwAO5gHO04sDqUg6G0FlqzXI+YM/BGSX5Y6iuah5yyfOwRYMZxAQjAOCaX5OMtuqjqmNZOuwEI0XQbC2KcQoeLwNDPkhBnlOajxAJyoWWKi2zgnY47MUFqKAPmo2OmKUyYx9Da9gVw78TTQBmt9vwtAcDeD0t7vAYGLqWfmYEXSnvi3xZQRUVhEQjYIMkRA7LxTnLxPFzPTVzspA9J7CbDnVZJBxIc7Ig5t/0rmo9zYOJPIljCISTd8i2y9+3AI4ykf0syt6VShjxiFJxhdjAXY4iJCy3UxF/FuebYyoIYRpqkk14EbqwGz9LfvOilvpszfNxxF0bLfRlYjnMNhiLOkVXrm3ypLB//jEurL9DZNDGcceTCwJjSHpgVBSDl+BNj6Kv6/AaW4yKDYQC1YwzvdNiJl+j9IkIxD9eA4yIhXJgoK+0F8X33G79Bq8BejGDAUZzh2+pWwraOrK0YaWmX4ndSeEnFhGVpS49YZ3K9wfEU3Tea19pcXMUoSpQ0JYc2ky4NxIvOgtfV4CEAR7oJaSlxZeAwAFOuPb8tJj3QtV4AZP7SXeh5PVU5wd/pXSnOMzYKa8AnyMvIERvf2c0E5fdFUsJTzVSK6cDgTEi6mdzEqPG9wiqxfdEVldtmuAzbDAMPqCF/xfPwR27iBk5yuuNCyXdxjhYqM4s3/6QAJBKxtZMDI8rysUQdu2g+uvOQ0K5IG7Evu7KetRIkZT8JvADauZkObYkxbKJzC+N1NQXYTBf4UUqiQsI2cAlJbjV5uNcpzUowZxx71UiZePtBzK96Ox4ToA68V5YvMl9J07EBpLoNHrA1CGBHMoEXiegjac4YmiUCEMH0qjCSmejoNN9IEy7N3QAeKSnAQhVAJJNUtTlVoODA62X5eDlKYHA5v270sucFtGUmni8pwEcOpk+m5VPB8InTXOR2tm1Ny2HGku+BicPl+XTc/Y9Ke+Jpp2am3NEof6eljd9G4MY4psMQYfAkCO00TTw6vhe+kfNLBUAk4JNGpmo5ckxFSIi6A/UJIKqvmAQ3HsQIPyZYHzy0C4DRD97UCcNujPZ/CMB+dBkmvLURvbrl4fMJ9EHK2Ofv723EVQ8sIyEAW/9zBlrkRueO7NwTRPNzPqOO79O7fMzJtUmMBmIfYDIH1cGZXDQPv+MmbmLACqnFFJfjLG7gFs7FYWpKEp60QcvDC44jDYaSkp7ic5yqxB6Tg2H7U4B9znDAqHVwvFxakPib0H4BRNWkOMecsgKQZBTzFFZgONl8VSC2GbDDfEedi8vxMxO4nYqfcRPDnIdRZTiuJiwPjXHg5ziBGUJKyjSAZ0oK8GmiA+NF23jzF/sltVcV4CSAhM1e6xkXn19NCjxU+jCg2s20qvrQEgGIdbaEBO4M/pDh3BxYLM1bkunxsF/Q1q6ihAaZjwMsLe2Ju4n5JqSXZUqT+xnFxBlWBoAp7Xeiws1/lWgPBXhbmhYxOFXbV3yRlQETQ8f2wurCCpzCGIaQGVMV7NT3yDPKGKpYAENVgc42ZVHxPgaDkWfKYQKlsVIBkMIK3MqAX3tZRey5m8isDxOWG60VE3AN+XdU06WfvYnThj5N/PiTtx6DO68ixSb6+XZNFabM3Ihz81ugT/fmrsPs3RfCk1PWCN9Hf4+sdXbG/6gvlTghM1ZKTwyAOKSiGCe437dQrLdQn01kyMsu/R/MwBTTRDs6EJIBD5yLAmbgbrLDywOtAogbmB0oAPELTnK9nGEl2dEn9MGueBKRrVEZWOfUTiTdiypwl/X9azcT1sel+XjSuUd+5nvT12jPgjgcQZxC/gVmCCd8M/KDuWkgXsKFGwgrGgg5gomtUCLqXjdJMt75ssdhiNHeZD/JaHwBiOUD4BxBqWnI88+BLqrmaDM9A4aXSdRtfokkYC961Wo511g+PhHUwIB1ponZgWy85/RlxKOZbU5maB0lmFXgHgb8TBWAbBOy9GuFfUpRj/SRkZDjdHyrpiyrU4zfrQ4AIszqXgKbolHVixPdSQfFT5XpBpJ++aRHu7gaSB3HFt0VDeSDWt/cM6mO6eUDEZJzqj4QmoyMAqm1sXUliS3rMPyHzBuc4QiSbowAOggNhWEd2dizQvg9Ay51ms3iXcCGDiDJMhQ/DNKV4ViSrxdT9wIQO9KH9igckKA+FIlFjuHKdAGINfgOzrGPfEdupqC6Aoibw94rD8SW9k0cLc1YXoKMH6k52f2mtXppvSIKSolwk3QRzmOGZUEDT0/ogXV+Ln6h5euQzNc2BTK0Un0jcv5+xvSKnLLXE8eh7IeWMQzbpQKD2mZ/AojtzAea87Cm/Wyac8ZIrZh83YXtMXHICX62I+k2X323G937zad+0wFMSnoAq4MrgMgIFGIefqKwRMhjhnCcbeXAROmwVkwBn2dwTKLQSc6wl6RroxJtLLMKSaQPWdEi3ZxhlY0ZQOyIM8W05EcDAcMGDtxXli9KqEQ9CQAkvgZC9n4DL5X0xD8cES3VYFgDjpVkcmRBLAgFcDRjwmwQZR5MVaKm0FqZU8RCyDYZ7qJoMT9h4pIAfgDW1voSONHlmPYZZVhGOUw123G9CEF3mCYVExZzMy8KMJCmOkVDSoVe6oZTwEHmJvQ2DPycc5wkSuyEIxh951xJ3xln2ElmLGbgRAogoCAWVdO1zc4Mu5zmKT8MRvpBrDB66kIRhKOdFSpSAhBpDvYwGe8vAKknp7kbeaf+9LhmeQte6RH1tycm/4C/jlnlZzvsNu1bZ2HD272j+kyasRHXPSwi5sli8XFSAyqN05MHYkXGUBifaju17ZLAdgOYaXL0p0gFyg2xfR4mOlE0EhjOAYXDOSJiGiKARMXYexzoKHu8kg8Tbz229BvO+4iJHHNEscU60RXbu3ogFPtwhvSBSP8MRVmxTAxzmkWkvwpm+gDEYVYSoZ9uTlavw6xqnF6Cje138gsgMufJADMNPGVJ/Uc4o5ZsAGHIUU1B6lwVB7Mdnl5XAFHHj4ouBHb7LQPi9C+aHKdZ5qt3ywowRr5Dnj/SPP3mZci+DvOVEG0B9HBGIdIvUwEQN3OwShslaMZ3GK/qb1K1d6/5RUUPetybVBmxSz8SyM9Y/87p6NAqkm3+1v82o2LXpRg+nIrqJn62bNmCy887DrP+Fs4KkM/lQxdj+iwhn94IRId3Jx410sKzFpaiisbNRFclWcYwb1wPPCTVOeXgtrek266qhqFEiKym8EvGsdIZNtwQAYTIp9TNihuFxYCmjjXHFEOU22EndgGdOEfU5aY2apSRRxTWbhbAo86qATI0mFu+FRpLRCB5BEo4KhGk0wdiB0JYkhwVrKOvqbnayp0HOVEUFhX9ZMBQyrfw4wOh8W1hAOjGgQ9qky5P58B2pw8qKowXmF3SUyTp2aVu7Cgsip5SkvKSBZBB83C6aWIQBcqyAB5yFhqMZ7aNd/EVa8DXDGgPJswvItfK7fyRc9W5RuvcX1kbBHMZD4crPyFzxGwHuoHtFI1EbVkGhjITLZy5EakAiK1FUf0sA2NKeoJs9/ZTZCUsgvxFSlKi9Bm65ft43Se3+VnnZDCjJEiGfW6aVTKM10dbypW505mJvmtPEH1u247Rz4/1MQTwySefgK19AUOu62S3X7e5Bl0uEZnolAhCQTspP54A4lDVYmphWfHXFxgMV1IinVctLGl/FZeVEtWUsF3pNJYlJtXwR7miBgsgdcwD8fJXWOG1V3MOStiaVlaA6cSonHkOHomERDY7Rp4OfWG5yAK+gjEETBNTKeta1aDAsdEARsqKo1YBTUo++7mVvFYvACIAcS76whC11Aw5t0QnOUEeyGArHj9hHoj6HiXhrro2IiWbAzNVyZzaOgAkpOZIqHkg3OHgTxZAFP9Ee0q0DVVj1ItnhnOI1ORLAN9T4mmiZEK5Tru6BEOOcIRbCZIU2KHSQp4/63f/rcnFeHqHpVH/CoaQWPNUYVExXWWq+yiZupWFbpuylICEbLdQZbczQO8fNB/DOBefcd3hyPkK5zpR4qUjD8Q2x1NeFcMkmZsU7z7v84TFAAAGd0lEQVS5ZqJbSbeUMmAYmFbSQ+RP1OdDhWpfaJbDWi6dVoAj2mbb7xr46Ld44a0Nvt6dk82w+q3eUTWzrn9kGV5+eyP1fxaIzg3yNajSKG41XiuhjMqXywxwUY1X5ABGsm8JGDbwEEa5xUCrpUtiLpcVNkjRPk5waegAQvOrUya6R4i0Q9KhCsjE1KgqsMjcFZnr4Z/d8kBWMoYOlFEflR0eTnyLSkqLyna2qixbNKeMd3p+sOqbZamhv8kyRAEUHuXco5iCIwHP6yDHy0QHZYZT6RagdTLl7pUKCPS5UBKWoiRzFUA4Qw4DdgrahPeGqhbITPQdponRMq9JnJEEzl+PKKzfc6C/LGHicud2WWGjvj9T6hAauDP3RdLb0j5v5RzniArcVoUCYV6WlQY4VrEsDCezpypokpRf3QbDZH6M2CsrmVA1lapBHdZnISo5w4REYbBRBV7DTnq16gQFZ9A+QNVAokxrsg81Cmf1V3LK0qeIO+U+OQGEZ8AU1YPDTnNRsSEOoxXVKyhZ1A5KcEQyJsGkz6PP155/RkvMeDpS84oiqC66czE+/lLk9uLC1tm4oGU22mQamL+rBqUb9mBbkKNZDsObj52E3/Rqab/y/z7bigvuECk5ZPWhku51KhibsLg8aRrrc4Xa1hccnewSITK0kOODIyrxL6849cIKkag0wsrKjgoLduSc/FCTi3s8a0e5MNwDFYWlHgBL+ryRcfxUqYW1w8pUnpzMeqIu8Xycx7lI9Guv1v2ysviplpBbGO+HVG9J1gsT41GNKIY3SnpgZky5Dkekj1oDq6oVZmdvxqNWpr9tTkuRIXp+D0TkqJCpg6Ol0wTqddHcamExhg1mAONZEL+hEiXJAIjF6MOlTZSQa/X9ihM9m2WghJs4iXH8TKm7tqDaQClVSVD7pUIv6m/VKLtcMDfJuBl2g2Oh23v8MCWpaREgybBlt36y0jY3cLVdC8uqxcUM/EfWVVOFHU7lbNzMp1ZCLZly1YglIXxxDKxNYmtphXXbyZfx1iK0sN3oDzNSh8xgWBCswb8DAdzJgeyY8GL6LEUmbmQGelrCql27zGT4rVWby75PTgCh+YgyNlSFINGjgEUaAITeNooiWUcOOhr39o+YoUImx7CylXh+8lq8ckJzdMoJoE2WgSV7gnhpfRWWtDQwbeSJOE6pxPvDj1Xoce0X2LIzSKBB6QAJ684lWm5CAEk0wKHw9wNZDvxQoG8616gk7tmZ8H7GF/44oLeXZB4FID4L//l5r26THgo01P2h3BrOcbXB8VCKH6aisiaUBHycW2LhwhW78fSra7FiXbgAenYWcOW5bdH//PYIUCqn9SxfW4XzBy/E8jV7CTyfAtLz7SYNID7OrwYQH0TaD01EcmoID9Kr3IrvSUc2fZ/Gb/kaGsst6dW5nIbKoPYD2RvFKxri/lj+xLvJ5ByswlCnvykJwpI/hM79KWTOeu7O46I0i3jjkKby3OvrMKx0FXbtCZHJlcK3XD/NkcR87KYaQBJQTQ3HpXhpt0zvVAiv+yRPAUetpigHM13WjCxRWZaMxXbNL6+3XPZa+GuaeT9FdkYl/sQ4zgTDZ26RR9SuITKo5Cl48PZoiPtDQSLcwEXcxBi1FliKu0DnlSoC/zojwFD0x8Mx4MJ26PETd6va9sogps3ahCcnryWtg15JplUqWZJUZfVEc9UA4kGh679Ai+ywtHu45XALulU0TURg/ff0UkB1/lO5eVHaP/xpZlGC3grGoAsbNzlKDe4QM0zwRc2GyKDSS9nGPdohtD9UPfE6MmnRjrXIy0C3Y3KQnRH5YNSaH/fhu7V7KRKRHvr+OVXFfsP6RlJaN1oDiAc5iz9DZ54hPihEkTl7YOLfJQWYkuaSBWndzENlMCsEsx8YjpcfwaKPMyXjYBYMh76kydFSROKYeIFK4HvR8BBiUI3yGB2C+0MfcaOQ5s5WLhXlU9EH4Si+l/6jKCsKt/qCcmPqa1M1gNQXZfW4mgKaApoCBzkFNIAc5Busl6cpoCmgKVBfFNAAUl+U1eNqCmgKaAoc5BTQAHKQb7BenqaApoCmQH1RQANIfVFWj6spoCmgKXCQU0ADyEG+wXp5mgKaApoC9UUBDSD1RVk9rqaApoCmwEFOAQ0gB/kG6+VpCmgKaArUFwU0gNQXZfW4mgKaApoCBzkFNIAc5Busl6cpoCmgKVBfFPh/LwNIw9lvQ6gAAAAASUVORK5CYII='
	},
	getAttributeNames: function (res) {
        console.log("canvas触发getAttributeNames", res)
        return this[res]
    },
	setAttribute: function (resk, resv) {
        console.log("canvas触发setAttribute", resk, resv)
        this[resk] = resv
    },
	display: function (res) {
        console.log("canvas触发display", res)
    },
	
}
canvas.__proto__=HTMLCanvasElement.prototype

function WebGLRenderingContext() {}

// 为 WebGLRenderingContext 添加 Symbol.hasInstance
 Object.defineProperty(WebGLRenderingContext, Symbol.hasInstance, {
  value: function (obj) {
    return obj && typeof obj === 'object' && obj.drawingBufferWidth !== undefined && obj.drawingBufferHeight !== undefined;
  }
}); 
WebGLDebugRendererInfo = {
	UNMASKED_VENDOR_WEBGL: 37445,
	UNMASKED_RENDERER_WEBGL: 37446,
}
WebGLLoseContext = {
    loseContext: function (res) {
        console.log("WebGLLoseContext触发loseContext", res)
        return {}
    },	
}
WebGLRenderingContext22= {
	canvas: canvas,
	drawingBufferColorSpace: "srgb",
	drawingBufferHeight: 150,
	drawingBufferWidth: 300,
	unpackColorSpace: "srgb",
	DEPTH_TEST: 2929,
	LEQUAL: 515,
	COLOR_BUFFER_BIT: 16384,
	DEPTH_BUFFER_BIT: 256,
	getShaderParameter: function(res){
		console.log("WebGLRenderingContext触发getShaderParameter", res)
    return true

	},
  getProgramParameter: function(res){
		console.log("WebGLRenderingContext触发getShaderParameter", res)
    return true

	},
  
	getShaderInfoLog: function(res){
		console.log("WebGLRenderingContext触发getShaderInfoLog", res)
	},
	getExtension: function (res) {
        console.log("WebGLRenderingContext触发getExtension", res)
		if (res == "WEBGL_lose_context"){
			return WebGLLoseContext
		}else if (res ==  "WEBGL_debug_renderer_info"){
			return WebGLDebugRendererInfo
		}
    },
	getParameter: function (res) {
        console.log("WebGLRenderingContext触发getParameter", res)
		if (res == 37445){
			return 'Google Inc. (Intel)'
		}else if (res == 37446){
			return 'ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E9B) Direct3D11 vs_5_0 ps_5_0, D3D11)'
		}else if (res == 33901){
			return {
				"0": 1,
				"1": 1024
			}
		}else if (res == 33902){
			return {
				"0": 1,
				"1": 1
			}
		}else if(res == 3410){
			return 8
		}else if(res == 3411){
			return 8
		}else if(res == 3412){
			return 8
		}else if(res == 3413){
			return 8
		}else if(res == 3414){
			return 24
		}else if(res == 3415){
			return 0
		}else if(res == 7936){
			return 'WebKit'
		}else if(res == 7937){
			return 'WebKit WebGL'
		}else if(res == 7938){
			return 'WebGL 1.0 (OpenGL ES 2.0 Chromium)'
		}else if(res == 35661){
			return 32
		}else if(res == 35724){
			return 'WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)'
		}else if(res == 34076){
			return 16384
		}else if(res == 36349){
			return 1024
		}else if(res == 34024){
			return 16384
		}else if(res == 34930){
			return 16
		}else if(res == 3379){
			return 16384
		}else if(res == 36348){
			return 30
		}else if(res == 34921){
			return 16
		}else if(res == 36347){
			return 4096
		}else if(res == 3386){
			return {
				"0": 32767,
				"1": 32767
			}
		}
		
		
    },
	reateBuffer: function (res) {
        console.log("WebGLRenderingContext触发createBuffer", res)
        return {}
    },
	createBuffer: function (res) {
        console.log("WebGLRenderingContext触发createBuffer", res)
        return {}
    },
	bindBuffer: function (res) {
        console.log("WebGLRenderingContext触发bindBuffer", res)
        return {}
    },	
	bufferData: function (res) {
        console.log("WebGLRenderingContext触发bufferData", res)
        return {}
    },	
	createProgram: function (res) {
        console.log("WebGLRenderingContext触发createProgram", res)
        return {}
    },	
	createShader: function (res) {
        console.log("WebGLRenderingContext触发createShader", res)
        return {}
    },	
	shaderSource: function (res) {
        console.log("WebGLRenderingContext触发shaderSource", res)
        return {}
    },	
	compileShader: function (res) {
        console.log("WebGLRenderingContext触发compileShader", res)
        return {}
    },	
	attachShader: function (res) {
        console.log("WebGLRenderingContext触发attachShader", res)
        return {}
    },	
	linkProgram: function (res) {
        console.log("WebGLRenderingContext触发linkProgram", res)
        return {}
    },	
	useProgram: function (res) {
        console.log("WebGLRenderingContext触发useProgram", res)
        return {}
    },	
	getAttribLocation: function (res) {
        console.log("WebGLRenderingContext触发getAttribLocation", res)
        return {}
    },	
	getUniformLocation: function (res) {
        console.log("WebGLRenderingContext触发getUniformLocation", res)
        return {}
    },	
	enableVertexAttribArray: function (res) {
        console.log("WebGLRenderingContext触发enableVertexAttribArray", res)
        return {}
    },	
	vertexAttribPointer: function (res) {
        console.log("WebGLRenderingContext触发vertexAttribPointer", res)
        return {}
    },	
	uniform2f: function (res) {
        console.log("WebGLRenderingContext触发uniform2f", res)
        return {}
    },	
	drawArrays: function (res) {
        console.log("WebGLRenderingContext触发drawArrays", res)
        return {}
    },
	getSupportedExtensions: function (res) {
        console.log("WebGLRenderingContext触发getSupportedExtensions", res)
        return [
    "ANGLE_instanced_arrays",
    "EXT_blend_minmax",
    "EXT_color_buffer_half_float",
    "EXT_disjoint_timer_query",
    "EXT_float_blend",
    "EXT_frag_depth",
    "EXT_shader_texture_lod",
    "EXT_texture_compression_bptc",
    "EXT_texture_compression_rgtc",
    "EXT_texture_filter_anisotropic",
    "EXT_sRGB",
    "KHR_parallel_shader_compile",
    "OES_element_index_uint",
    "OES_fbo_render_mipmap",
    "OES_standard_derivatives",
    "OES_texture_float",
    "OES_texture_float_linear",
    "OES_texture_half_float",
    "OES_texture_half_float_linear",
    "OES_vertex_array_object",
    "WEBGL_color_buffer_float",
    "WEBGL_compressed_texture_s3tc",
    "WEBGL_compressed_texture_s3tc_srgb",
    "WEBGL_debug_renderer_info",
    "WEBGL_debug_shaders",
    "WEBGL_depth_texture",
    "WEBGL_draw_buffers",
    "WEBGL_lose_context",
    "WEBGL_multi_draw"
]
    },
	clearColor: function (res) {
        console.log("WebGLRenderingContext触发clearColor", res)
        return {}
    },
	enable: function (res) {
        console.log("WebGLRenderingContext触发enable", res)
        return {}
    },
	depthFunc: function (res) {
        console.log("WebGLRenderingContext触发depthFunc", res)
        return {}
    },
	clear: function (res) {
        console.log("WebGLRenderingContext触发clear", res)
        return {}
    },
	getShaderPrecisionFormat: function (res) {
        console.log("WebGLRenderingContext触发getShaderPrecisionFormat", res)
        return {}
    },
	getContextAttributes: function (res) {
        console.log("WebGLRenderingContext触发getContextAttributes", res)
        return {
			"alpha": true,
			"antialias": true,
			"depth": true,
			"desynchronized": false,
			"failIfMajorPerformanceCaveat": false,
			"powerPreference": "default",
			"premultipliedAlpha": true,
			"preserveDrawingBuffer": false,
			"stencil": false,
			"xrCompatible": false
		}
    },

}
CanvasRenderingContext2D = {
	
	direction: "ltr",
	fillStyle: 'rgba(102, 204, 0, 0.7)',
	filter: '#f60',
	font: '11pt no-real-font-123',
	fontKerning: "auto",
	fontStretch: "normal",
	fontVariantCaps: "normal",
	globalAlpha: 1,
	globalCompositeOperation: "source-over",
	imageSmoothingEnabled: true,
	imageSmoothingQuality: "low",
	letterSpacing: "0px",
	lineCap: "butt",
	lineDashOffset: 0,
	lineJoin: "miter",
	lineWidth: 1,
	miterLimit: 10,
	shadowBlur: 0,
	shadowColor: "rgba(0, 0, 0, 0)",
	shadowOffsetX: 0,
	shadowOffsetY: 0,
	strokeStyle	: "#000000",
	textAlign: "start",
	textBaseline: "alphabetic",
	textRendering: "auto",
	wordSpacing: "0px",
	fillText: function (res) {
        //console.log("CanvasRenderingContext2D触发fillText", res)
        return {}
    },
	fillRect: function (res) {
        //console.log("CanvasRenderingContext2D触发fillRect", res)
        return {}
    },
}
documentevent = {}
document = {
	cookie: '__snaker__id=4bvH4q3uo2v12YnX; kg_mid=2136ccf146cf10f47874be3631902050; kg_dfid=11RbSD1SLKqY4cuqj14L7vnR; kg_dfid_collect=d41d8cd98f00b204e9800998ecf8427e; Hm_lvt_aedee6983d4cfc62f509129360d6bb3d=1723899994; HMACCOUNT=EB7970FDFD2AFA95; ACK_SERVER_10015=%7B%22list%22%3A%5B%5B%22gzlogin-user.kugou.com%22%5D%5D%7D; gdxidpyhxdE=aqSE%5CxmT7a9H0eiuzzRMNQA5vriLZvxEU8emgP4WSoewAYH45r%5CitJB%2Bm4yljaK5hyCXSOuNlj6H8YBtVK3rL4xvijfgKg7GCLq1TiNxp7HnSLj%5C7h2j2B19tfvgxohrVB2uHN4YpYS1NoYo2gM0wpu85WnLLl9zSr%2BwQo8y1C%2BGeiBp%3A1723907462651; Hm_lpvt_aedee6983d4cfc62f509129360d6bb3d=1723906577',
	createElement: function(res){
		console.log('createElement', res)
		return canvas
	}
}

memory = {
  'Proxy': true,
  'random':0.5,

  'author': 'QiQi',
  'QQ': '2151889887'
}

// Math.random = function(){return memory['random']};
memory.proxy = (function() {
  memory.Object_sx = ['Date'];
  memory.Function_sx = []//['Array', 'Object', 'Function', 'String', 'Number', 'RegExp', 'Symbol', 'Error', 'EvalError', 'RangeError', 'ReferenceError', 'SyntaxError', 'TypeError', 'URIError', 'Uint8Array'];
  memory.setFun = [];
  memory.getObjFun = [];
  memory.color = {
      'set': [3, 101, 100],
      'get': [255, 140, 0],
      'has': [220, 87, 18],
      'apply': [107, 194, 53],
      'ownKeys': [147, 224, 255],
      'deleteProperty': [199, 21, 133],
      'defineProperty': [179, 214, 110],
      'construct': [200, 8, 82],
      'getPrototypeOf': [255, 255, 255],

      'object': [147, 224, 255],
      'function': [147, 224, 255],
      'number': [255, 224, 0],
      'array': [147, 224, 0],
      'string': [255, 224, 255],
      'undefined': [255, 52, 4],
      'boolean': [76, 180, 231],
  };
  memory.log = console.log;
  memory.log_order = 0;
  memory.proxy_Lock = 0;
  // 文本样式
  function styledText(text, styles) {
      let styledText = text;
      // RGB颜色
      if (styles.color) {
          styledText = `\x1b[38;2;${styles.color[0]};${styles.color[1]};${styles.color[2]}m${styledText}\x1b[0m`;
      }
      // 背景颜色
      if (styles.bgColor) {
          styledText = `\x1b[48;2;${styles.bgColor[0]};${styles.bgColor[1]};${styles.bgColor[2]}m${styledText}\x1b[0m`;
      }
      // 粗体
      if (styles.bold) {
          styledText = `\x1b[1m${styledText}\x1b[0m`;
      }
      // 斜体
      if (styles.italic) {
          styledText = `\x1b[3m${styledText}\x1b[0m`;
      }
      // 下划线
      if (styles.underline) {
          styledText = `\x1b[4m${styledText}\x1b[0m`;
      }
      // 返回带样式的文本
      return styledText
  }
  // 文本填充
  function limitStringTo(str, num) {
      str = str.toString()
      if (str.length >= num) {
          return str + ' '
      } else {
          const spacesToAdd = num - str.length;
          const padding = ' '.repeat(spacesToAdd);
          // 创建填充空格的字符串
          return str + padding;
      }
  }
  // 进行代理
  function new_obj_handel(target, target_name) {
      if(memory.Proxy == false){return target};

      let name = target_name.indexOf('.') != -1 ? target_name.split('.').slice(-1)[0]: target_name;
      if (target['isProxy'] || memory.Object_sx.includes(name)) {
          return target;
      }else{
          return new Proxy(target,my_obj_handler(target_name))
      }
  }
  function new_fun_handel(target, target_name) {
      if(memory.Proxy == false){return target}
      let name = target_name.indexOf('.') != -1 ? target_name.split('.').slice(-1)[0]: target_name;
      if (memory.Function_sx.includes(name)) {
          return target;
      }else{
          return new Proxy(target,my_fun_handler(target_name))
      }
  }
  // 获取数据类型
  function get_value_type(value) {
      if (Array.isArray(value)) {
          return 'array'
      }
      if (value == undefined) {
          return 'undefined'
      }
      return typeof value;
  }
  // 函数与对象的代理属性
  function my_obj_handler(target_name) {
      return {
          set: function (obj, prop, value) {
              if(memory['proxy_Lock']){
                  return Reflect.set(obj, prop, value);
              };

              const value_type = get_value_type(value);
              const tg_name = `${target_name}.${prop.toString()}`;
              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('setter',20) + limitStringTo(`hook->${tg_name};`,50)

              // 如果设置到的属性是对象 --> 输出值对象
              // 如果设置到的属性是方法 --> 输出值function
              // 其他的就全部输出值
              if (value && value_type === "object") {
                  memory.log(styledText(text, {
                      color: memory.color['set'],
                  }), styledText('value->',{
                      color: memory.color['set'],
                  }),value)
              }
              else if (value_type === "function") {
                  memory.setFun.push(tg_name)
                  memory.log(styledText(text , {
                      color: memory.color['set'],
                  }),styledText(`value->`, {
                      color: memory.color['set'],
                  }),styledText(`function`, {
                      color: memory.color[value_type],
                  }))
              }
              else {
                  memory.log(styledText(text, {
                      color: memory.color['set'],
                  }),styledText(`value->`, {
                      color: memory.color['set'],
                  }),styledText(`${value}`, {
                      color: memory.color[value_type],
                  }))
              }

              return Reflect.set(obj, prop, value);
          },
          get: function (obj, prop) {
              if(memory['proxy_Lock']){
                  return Reflect.get(obj, prop)
              };
              if (prop === "isProxy") {
                  return true;
              }

              const value = Reflect.get(obj, prop);
              const tg_name = `${target_name}.${prop.toString()}`;
              const value_type = get_value_type(value);

              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('getter',20) + limitStringTo(`hook->${tg_name};`,50)
              // 如果获取到的属性是对象 --> 对其getter和setter进行代理
              // 如果获取到的属性是方法 --> 对其caller进行代理
              // 其他的就全部输出值
              if (value_type === 'object') {
                  if (memory.getObjFun.indexOf(tg_name) == -1){
                      memory.log(styledText(text, {
                          color: memory.color['get'],
                      }), styledText('value->',{
                          color: memory.color['get'],
                      }),value)
                      memory.getObjFun.push(tg_name)
                  }
                  return new_obj_handel(value,tg_name)
              }
              else if(value_type === "function"){
                  if (memory.getObjFun.indexOf(tg_name) == -1){
                      memory.log(styledText(text , {
                          color: memory.color['get'],
                      }),styledText(`value->`, {
                          color: memory.color['get'],
                      }),styledText(`function`, {
                          color: memory.color[value_type],
                      }))
                      memory.getObjFun.push(tg_name)
                  }
                  return new_fun_handel(value,tg_name);
              }
              else{
                  memory.log(styledText(text , {
                          color: memory.color['get'],
                      }),styledText( `value->` , {
                          color: memory.color['get'],
                      }),styledText( `${value}` , {
                          color: memory.color[value_type],
                      }))
                  return value
              }
          },
          has: function(obj, prop) {
              if(memory['proxy_Lock']){
                  return Reflect.has(obj, prop)
              }

              const value = Reflect.has(obj, prop);
              const value_type = get_value_type(value);
              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('in',20) + limitStringTo(`hook->"${prop.toString()}" in ${target_name};`,50)
              memory.log(styledText(text, {
                      color: memory.color['has'],
                  }), styledText(`value->`, {
                      color: memory.color['has'],
                  }), styledText(`${value}`, {
                      color: memory.color[value_type],
                  }))

              return value;
          },
          ownKeys:function(obj){
              if(memory['proxy_Lock']){
                  return Reflect.ownKeys(obj);
              }

              const value = Reflect.ownKeys(obj);
              const value_type = get_value_type(value);
              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('ownKeys',20) + limitStringTo(`hook->${target_name};`,50)
              memory.log(styledText(text, {
                      color: memory.color['ownKeys'],
                  }), styledText(`value->`, {
                      color: memory.color['ownKeys'],
                  }), styledText(`${value}`, {
                      color: memory.color[value_type],
                  }));

              return value
          },
          deleteProperty:function(obj, prop) {
              if(memory['proxy_Lock']){
                  return Reflect.deleteProperty(obj, prop);
              }

              const value = Reflect.deleteProperty(obj, prop);
              const tg_name = `${target_name}.${prop.toString()}`;
              const value_type = get_value_type(value);
              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('delete',20) + limitStringTo(`hook->${tg_name};`,50)
              memory.log(styledText(text, {
                      color: memory.color['deleteProperty'],
                  }), styledText(`value->`, {
                      color: memory.color['deleteProperty'],
                  }), styledText(`${value}`, {
                      color: memory.color[value_type],
                  }));

              return value;
          },
          defineProperty: function (target, property, descriptor) {
              if(memory['proxy_Lock']){
                  return Reflect.defineProperty(target, property, descriptor);
              };

              const value = Reflect.defineProperty(target, property, descriptor);
              const tg_name = `${target_name}.${property.toString()}`;
              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('defineProperty',20) + limitStringTo(`hook->${tg_name};`,50)
              memory.log(styledText(text, {
                      color: memory.color['defineProperty'],
                  }), styledText('value->',{
                      color: memory.color['defineProperty'],
                  }),descriptor)

              return value;
          },
          getPrototypeOf(target) {
              if(memory['proxy_Lock']){
                  return Reflect.getPrototypeOf(target);
              }

              var value = Reflect.getPrototypeOf(target);
              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('getPrototypeOf',20) + limitStringTo(`hook->${target_name};`,50)
              memory.log(styledText(text, {
                      color: memory.color['getPrototypeOf'],
                  }), styledText('value->',{
                      color: memory.color['getPrototypeOf'],
                  }),value)

              return value;
          }
      };
  }
  function my_fun_handler(target_name) {
      return  {
          apply:function(target, thisArg, argumentsList){
              if(memory['proxy_Lock']){
                  return Reflect.apply(target, thisArg, argumentsList);
              };

             if(memory.setFun.indexOf(target_name) != -1 || memory.setFun.includes(target_name.split('.')[0])){
                  // 扣的代码触发
                  var value = Reflect.apply(target, thisArg, argumentsList);
                  memory.setFun.push(`log_${memory['log_order'] + 1}`)
              }
              else{
                  // 补的环境触发的分支
                  memory['proxy_Lock'] = 1
                  var value = Reflect.apply(target, thisArg, argumentsList);
                  memory['proxy_Lock'] = 0

              }

              const value_type = get_value_type(value);
              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('caller',20) + limitStringTo(`hook->log_${memory['log_order']} = ${target_name}();`,50);
              memory.log(styledText(text, {
                      color: memory.color['apply'],
                  }),styledText('arguments->',{
                      color: memory.color['apply'],
                  }),argumentsList, styledText('returnValue->',{
                      color: memory.color[value_type],
                  }),value)

              if(value_type == 'object'){
                  return new_obj_handel(value,`log_${memory['log_order']}`);
              }
              else if(value_type == 'function'){
                  return new_fun_handel(value,`log_${memory['log_order']}`);
              }
              return  value;
          },
          construct: function (target, args, newTarget) {
              if(memory['proxy_Lock']){
                  return Reflect.construct(target, args, newTarget)
              }

              if(memory.setFun.indexOf(target_name) != -1 || memory.setFun.includes(target_name.split('.')[0])){
                  var value = Reflect.construct(target, args, newTarget);
                  memory.setFun.push(`log_${memory['log_order'] + 1}`)
              }
              else{
                  memory['proxy_Lock'] = 1
                  var value = Reflect.construct(target, args, newTarget);
                  memory['proxy_Lock'] = 0
              }


              const text = limitStringTo(++memory['log_order'],5) + limitStringTo('new',20) + limitStringTo(`hook->log_${memory['log_order']} = new ${target_name}();`,50)
              memory.log(styledText(text, {
                      color: memory.color['construct'],
                  }), styledText('arguments->',{
                      color: memory.color['construct'],
                  }),args, styledText('returnValue->',{
                      color: memory.color['construct'],
                  }),value);
              return new_obj_handel(value,  `log_${memory['log_order']}`);
          },
      }
  }
  // 返回进行对象代理
  return new_obj_handel
}());


// location = memory.proxy(location,'location');
//window = memory.proxy(window,'window');
//document = memory.proxy(document,'document');
// canvas = memory.proxy(canvas,'canvas');
// navigator = memory.proxy(navigator,'navigator');
// screen = memory.proxy(screen,'screen');
// CanvasRenderingContext2D = memory.proxy(CanvasRenderingContext2D,'CanvasRenderingContext2D');
"use strict";

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var wasm_bindgen;

(function () {
  var __exports = {};
  var wasm;
  var heap = new Array(32).fill(undefined);
  heap.push(undefined, null, true, false);

  function getObject(idx) {
    return heap[idx];
  }

  var heap_next = heap.length;

  function dropObject(idx) {
    if (idx < 36) return;
    heap[idx] = heap_next;
    heap_next = idx;
  }

  function takeObject(idx) {
    var ret = getObject(idx);
    dropObject(idx);
    return ret;
  }

  var cachedTextDecoder = new TextDecoder('utf-8', {
    ignoreBOM: true,
    fatal: true
  });
  cachedTextDecoder.decode();
  var cachegetUint8Memory0 = null;

  function getUint8Memory0() {
    if (cachegetUint8Memory0 === null || cachegetUint8Memory0.buffer !== wasm.memory.buffer) {
      cachegetUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }

    return cachegetUint8Memory0;
  }

  function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
  }

  function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    var idx = heap_next;
    heap_next = heap[idx];
    heap[idx] = obj;
    return idx;
  }

  var WASM_VECTOR_LEN = 0;
  var cachedTextEncoder = new TextEncoder('utf-8');
  var encodeString = typeof cachedTextEncoder.encodeInto === 'function' ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
  } : function (arg, view) {
    var buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
      read: arg.length,
      written: buf.length
    };
  };

  function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
      var buf = cachedTextEncoder.encode(arg);

      var _ptr = malloc(buf.length);

      getUint8Memory0().subarray(_ptr, _ptr + buf.length).set(buf);
      WASM_VECTOR_LEN = buf.length;
      return _ptr;
    }

    var len = arg.length;
    var ptr = malloc(len);
    var mem = getUint8Memory0();
    var offset = 0;

    for (; offset < len; offset++) {
      var code = arg.charCodeAt(offset);
      if (code > 0x7F) break;
      mem[ptr + offset] = code;
    }

    if (offset !== len) {
      if (offset !== 0) {
        arg = arg.slice(offset);
      }

      ptr = realloc(ptr, len, len = offset + arg.length * 3);
      var view = getUint8Memory0().subarray(ptr + offset, ptr + len);
      var ret = encodeString(arg, view);
      offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
  }

  function isLikeNone(x) {
    return x === undefined || x === null;
  }

  var cachegetInt32Memory0 = null;

  function getInt32Memory0() {
    if (cachegetInt32Memory0 === null || cachegetInt32Memory0.buffer !== wasm.memory.buffer) {
      cachegetInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }

    return cachegetInt32Memory0;
  }

  function debugString(val) {
    // primitive types
    var type = _typeof(val);

    if (type == 'number' || type == 'boolean' || val == null) {
      return "".concat(val);
    }

    if (type == 'string') {
      return "\"".concat(val, "\"");
    }

    if (type == 'symbol') {
      var description = val.description;

      if (description == null) {
        return 'Symbol';
      } else {
        return "Symbol(".concat(description, ")");
      }
    }

    if (type == 'function') {
      var name = val.name;

      if (typeof name == 'string' && name.length > 0) {
        return "Function(".concat(name, ")");
      } else {
        return 'Function';
      }
    } // objects


    if (Array.isArray(val)) {
      var length = val.length;
      var debug = '[';

      if (length > 0) {
        debug += debugString(val[0]);
      }

      for (var i = 1; i < length; i++) {
        debug += ', ' + debugString(val[i]);
      }

      debug += ']';
      return debug;
    } // Test for built-in


    var builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    var className;

    if (builtInMatches.length > 1) {
      className = builtInMatches[1];
    } else {
      // Failed to match the standard '[object ClassName]'
      return toString.call(val);
    }

    if (className == 'Object') {
      // we're a user defined class or Object
      // JSON.stringify avoids problems with cycles, and is generally much
      // easier than looping through ownProperties of `val`.
      try {
        return 'Object(' + JSON.stringify(val) + ')';
      } catch (_) {
        return 'Object';
      }
    } // errors


    if (_instanceof(val, Error)) {
      return "".concat(val.name, ": ").concat(val.message, "\n").concat(val.stack);
    } // TODO we could test for more things here, like `Set`s and `Map`s.


    return className;
  }

  function makeMutClosure(arg0, arg1, dtor, f) {
    var state = {
      a: arg0,
      b: arg1,
      cnt: 1
    };

    var real = function real() {
      // First up with a closure we increment the internal reference
      // count. This ensures that the Rust closure environment won't
      // be deallocated while we're invoking it.
      state.cnt++;
      var a = state.a;
      state.a = 0;

      try {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        return f.apply(void 0, [a, state.b].concat(args));
      } finally {
        if (--state.cnt === 0) wasm.__wbindgen_export_2.get(dtor)(a, state.b);else state.a = a;
      }
    };

    real.original = state;
    return real;
  }

  function __wbg_adapter_26(arg0, arg1) {
    wasm._dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__he25972c9b3fefae8(arg0, arg1);
  }

  function __wbg_adapter_29(arg0, arg1, arg2) {
    wasm._dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h7b132ceac93324a9(arg0, arg1, addHeapObject(arg2));
  }

  function __wbg_adapter_32(arg0, arg1, arg2) {
    wasm._dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h6d18d2f5d81b3bb0(arg0, arg1, addHeapObject(arg2));
  }
  /**
  */


  __exports.run = function () {
    wasm.run();
  };

  function handleError(f) {
    return function () {
      try {
        return f.apply(this, arguments);
      } catch (e) {
        wasm.__wbindgen_exn_store(addHeapObject(e));
      }
    };
  }

  function getArrayU8FromWasm0(ptr, len) {
    return getUint8Memory0().subarray(ptr / 1, ptr / 1 + len);
  }

  var cachegetFloat64Memory0 = null;

  function getFloat64Memory0() {
    if (cachegetFloat64Memory0 === null || cachegetFloat64Memory0.buffer !== wasm.memory.buffer) {
      cachegetFloat64Memory0 = new Float64Array(wasm.memory.buffer);
    }

    return cachegetFloat64Memory0;
  }

  function __wbg_adapter_165(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen__convert__closures__invoke2_mut__h695c06ab86e08564(arg0, arg1, addHeapObject(arg2), addHeapObject(arg3));
  }
  /**
  */


  var EData = /*#__PURE__*/function () {
    _createClass(EData, [{
      key: "free",
      value: function free() {
        var ptr = this.ptr;
        this.ptr = 0;

        wasm.__wbg_edata_free(ptr);
      }
      /**
      */

    }], [{
      key: "__wrap",
      value: function __wrap(ptr) {
        var obj = Object.create(EData.prototype);
        obj.ptr = ptr;
        return obj;
      }
    }]);

    function EData() {
      _classCallCheck(this, EData);
      var ret = window.wasm.edata_new();
      return EData.__wrap(ret);
    }
    /**
    * @returns {string}
    */


    _createClass(EData, [{
      key: "get_edt",
      value: function get_edt() {
        try {
          wasm.edata_get_edt(8, this.ptr);
          var r0 = getInt32Memory0()[8 / 4 + 0];
          var r1 = getInt32Memory0()[8 / 4 + 1];
		  //console.log(this.ptr, r0, r1)
          return getStringFromWasm0(r0, r1);
        } finally {
          wasm.__wbindgen_free(r0, r1);
        }
      }
      /**
      * @returns {string}
      */

    }, {
      key: "get_sid",
      value: function get_sid() {
        try {
          wasm.edata_get_sid(8, this.ptr);
          var r0 = getInt32Memory0()[8 / 4 + 0];
          var r1 = getInt32Memory0()[8 / 4 + 1];
          return getStringFromWasm0(r0, r1);
        } finally {
          wasm.__wbindgen_free(r0, r1);
        }
      }
    }]);

    return EData;
  }();

  __exports.EData = EData;

  async function load(module, imports) {
    if (typeof Response === 'function' && _instanceof(module, Response)) {
      if (typeof WebAssembly.instantiateStreaming === 'function') {
        try {
          return await WebAssembly.instantiateStreaming(module, imports);
        } catch (e) {
          if (module.headers.get('Content-Type') != 'application/wasm') {
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
          } else {
            throw e;
          }
        }
      }

      var bytes = await module.arrayBuffer();
      return await WebAssembly.instantiate(bytes, imports);
    } else {
      var instance = await WebAssembly.instantiate(module, imports);

      if (_instanceof(instance, WebAssembly.Instance)) {
        return {
          instance: instance,
          module: module
        };
      } else {
        return instance;
      }
    }
  }

  async function init(input) {
    if (typeof input === 'undefined') {
      var src;

      if (typeof document === 'undefined') {
        src = location.href;
      } else {
        src = document.currentScript.src;
      }

      input = src.replace(/\.js$/, '_bg.wasm');
    }

    var imports = {};
    imports.wbg = {};

    imports.wbg.__wbg_setTimeout_b3d3e28b860025e3 = function (arg0, arg1) {
      setTimeout(takeObject(arg0), arg1 >>> 0);
    };

    imports.wbg.__wbindgen_object_drop_ref = function (arg0) {
      takeObject(arg0);
    };

    imports.wbg.__wbindgen_cb_drop = function (arg0) {
      var obj = takeObject(arg0).original;

      if (obj.cnt-- == 1) {
        obj.a = 0;
        return true;
      }

      var ret = false;
      return ret;
    };

    imports.wbg.__wbindgen_string_new = function (arg0, arg1) {
      var ret = getStringFromWasm0(arg0, arg1);
      return addHeapObject(ret);
    };

    imports.wbg.__wbindgen_jsval_eq = function (arg0, arg1) {
      var ret = getObject(arg0) === getObject(arg1);
      return ret;
    };

    imports.wbg.__wbindgen_object_clone_ref = function (arg0) {
      var ret = getObject(arg0);
      return addHeapObject(ret);
    };

    imports.wbg.__wbindgen_cb_forget = function (arg0) {
      takeObject(arg0);
    };

    imports.wbg.__wbg_instanceof_Window_d64060d13377409b = function (arg0) {
      var ret = _instanceof(getObject(arg0), Window);

      return true;
    };

    imports.wbg.__wbg_document_bcf9d67bc56e8c6d = function (arg0) {
      var ret = getObject(arg0).document;
      return isLikeNone(ret) ? 0 : addHeapObject(ret);
    };

    imports.wbg.__wbg_navigator_a1711d7939511fb0 = function (arg0) {
      var ret = getObject(arg0).navigator;
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_crypto_e775ee2e074e46de = handleError(function (arg0) {
      var ret = getObject(arg0).crypto;
      return addHeapObject(ret);
    });
    imports.wbg.__wbg_requestAnimationFrame_96f88ce2d311332e = handleError(function (arg0, arg1) {
      var ret = getObject(arg0).requestAnimationFrame(getObject(arg1));
      return ret;
    });
    imports.wbg.__wbg_createElement_467bb064d2ae5833 = handleError(function (arg0, arg1, arg2) {
      var ret = getObject(arg0).createElement(getStringFromWasm0(arg1, arg2));
      return addHeapObject(ret);
    });

    imports.wbg.__wbg_clientX_48aae9fc88d6ea69 = function (arg0) {
      var ret = getObject(arg0).clientX;
      return ret;
    };

    imports.wbg.__wbg_clientY_b23802d9e0dd2c51 = function (arg0) {
      var ret = getObject(arg0).clientY;
      return ret;
    };

    imports.wbg.__wbg_buttons_d9a487d62a2bcfad = function (arg0) {
      var ret = getObject(arg0).buttons;
      return ret;
    };

    imports.wbg.__wbg_encrypt_3eac7f61933c3be9 = handleError(function (arg0, arg1, arg2, arg3) {
      var ret = getObject(arg0).encrypt(getObject(arg1), getObject(arg2), getObject(arg3));
      return addHeapObject(ret);
    });
    imports.wbg.__wbg_importKey_370896d933eba99c = handleError(function (arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
      var ret = getObject(arg0).importKey(getStringFromWasm0(arg1, arg2), getObject(arg3), getObject(arg4), arg5 !== 0, getObject(arg6));
      return addHeapObject(ret);
    });

    imports.wbg.__wbg_deltaX_91eab99c5941b593 = function (arg0) {
      var ret = getObject(arg0).deltaX;
      return ret;
    };

    imports.wbg.__wbg_deltaY_ba4bc93322183cab = function (arg0) {
      var ret = getObject(arg0).deltaY;
      return ret;
    };

    imports.wbg.__wbg_subtle_a33b474f137433b4 = function (arg0) {
      var ret = getObject(arg0).subtle;
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_getRandomValues_bd83b9bca41f01e4 = handleError(function (arg0, arg1, arg2) {
      var ret = getObject(arg0).getRandomValues(getArrayU8FromWasm0(arg1, arg2));
      return addHeapObject(ret);
    });

    imports.wbg.__wbg_clientX_bc61648c02723dc7 = function (arg0) {
      var ret = getObject(arg0).clientX;
      return ret;
    };

    imports.wbg.__wbg_clientY_67b12bba9c15ace2 = function (arg0) {
      var ret = getObject(arg0).clientY;
      return ret;
    };

    imports.wbg.__wbg_length_4c6909494a0e02f9 = function (arg0) {
      var ret = getObject(arg0).length;
      return ret;
    };

    imports.wbg.__wbg_item_bb8a8818d4856ef0 = function (arg0, arg1) {
      var ret = getObject(arg0).item(arg1 >>> 0);
      return isLikeNone(ret) ? 0 : addHeapObject(ret);
    };

    imports.wbg.__wbg_setAttribute_02daabbc925a51e3 = handleError(function (arg0, arg1, arg2, arg3, arg4) {
      getObject(arg0).setAttribute(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
    });

    imports.wbg.__wbg_instanceof_WebGlRenderingContext_dca65729c7187d57 = function (arg0) {
      var ret = _instanceof(getObject(arg0), WebGLRenderingContext);
	  //var ret = true
      return ret;
    };

    imports.wbg.__wbg_bufferData_e135b678b6ef2433 = function (arg0, arg1, arg2, arg3) {
      getObject(arg0).bufferData(arg1 >>> 0, getObject(arg2), arg3 >>> 0);
    };

    imports.wbg.__wbg_attachShader_9958cc9636fc8494 = function (arg0, arg1, arg2) {
      getObject(arg0).attachShader(getObject(arg1), getObject(arg2));
    };

    imports.wbg.__wbg_bindBuffer_c96c99b259d952f4 = function (arg0, arg1, arg2) {
      getObject(arg0).bindBuffer(arg1 >>> 0, getObject(arg2));
    };

    imports.wbg.__wbg_clear_ec5c1c21ed3b2fe2 = function (arg0, arg1) {
      getObject(arg0).clear(arg1 >>> 0);
    };

    imports.wbg.__wbg_clearColor_b9e0f7e215dc534e = function (arg0, arg1, arg2, arg3, arg4) {
      getObject(arg0).clearColor(arg1, arg2, arg3, arg4);
    };

    imports.wbg.__wbg_compileShader_82966bc7f1d070fe = function (arg0, arg1) {
      getObject(arg0).compileShader(getObject(arg1));
    };

    imports.wbg.__wbg_createBuffer_501da6aef1c4b91c = function (arg0) {
      var ret = getObject(arg0).createBuffer();
      return isLikeNone(ret) ? 0 : addHeapObject(ret);
    };

    imports.wbg.__wbg_createProgram_531dab3c15c28e4f = function (arg0) {
      var ret = getObject(arg0).createProgram();
      return isLikeNone(ret) ? 0 : addHeapObject(ret);
    };

    imports.wbg.__wbg_createShader_376b269548a48c7a = function (arg0, arg1) {
      var ret = getObject(arg0).createShader(arg1 >>> 0);
      return isLikeNone(ret) ? 0 : addHeapObject(ret);
    };

    imports.wbg.__wbg_drawArrays_1c6a2bff627558ed = function (arg0, arg1, arg2, arg3) {
      getObject(arg0).drawArrays(arg1 >>> 0, arg2, arg3);
    };

    imports.wbg.__wbg_enableVertexAttribArray_0f8b0b1592940e3f = function (arg0, arg1) {
      getObject(arg0).enableVertexAttribArray(arg1 >>> 0);
    };

    imports.wbg.__wbg_getProgramInfoLog_5def5bb3d8d30e1f = function (arg0, arg1, arg2) {
      var ret = getObject(arg1).getProgramInfoLog(getObject(arg2));
      var ptr0 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len0;
      getInt32Memory0()[arg0 / 4 + 0] = ptr0;
    };

    imports.wbg.__wbg_getProgramParameter_c021157c5817259f = function (arg0, arg1, arg2) {
      var ret = getObject(arg0).getProgramParameter(getObject(arg1), arg2 >>> 0);
	  //var ret = true
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_getShaderInfoLog_b619769ff40aac70 = function (arg0, arg1, arg2) {
      var ret = getObject(arg1).getShaderInfoLog(getObject(arg2));
      var ptr0 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len0;
      getInt32Memory0()[arg0 / 4 + 0] = ptr0;
    };

    imports.wbg.__wbg_getShaderParameter_d03718a8c98a4d23 = function (arg0, arg1, arg2) {
  

      var ret = getObject(arg0).getShaderParameter(getObject(arg1), arg2 >>> 0);
      //ret =true
	  return addHeapObject(ret);
    };

    imports.wbg.__wbg_linkProgram_9e60adcb42d34c3c = function (arg0, arg1) {
      getObject(arg0).linkProgram(getObject(arg1));
    };

    imports.wbg.__wbg_shaderSource_c208cc7a688e8923 = function (arg0, arg1, arg2, arg3) {
      getObject(arg0).shaderSource(getObject(arg1), getStringFromWasm0(arg2, arg3));
    };

    imports.wbg.__wbg_useProgram_c4a6df84383cd1a6 = function (arg0, arg1) {
      getObject(arg0).useProgram(getObject(arg1));
    };

    imports.wbg.__wbg_vertexAttribPointer_5660aa1f2b819de1 = function (arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
      getObject(arg0).vertexAttribPointer(arg1 >>> 0, arg2, arg3 >>> 0, arg4 !== 0, arg5, arg6);
    };

    imports.wbg.__wbg_addEventListener_fe52a115589ccc2c = handleError(function (arg0, arg1, arg2, arg3) {
      getObject(arg0).addEventListener(getStringFromWasm0(arg1, arg2), getObject(arg3));
    });

    imports.wbg.__wbg_instanceof_HtmlCanvasElement_308a7fa689ff20ef = function (arg0) {
      var ret = _instanceof(getObject(arg0), HTMLCanvasElement);
		//var ret = true
      return ret;
    };

    imports.wbg.__wbg_getContext_554fc171434d411b = handleError(function (arg0, arg1, arg2) {
      var ret = getObject(arg0).getContext(getStringFromWasm0(arg1, arg2));
      return isLikeNone(ret) ? 0 : addHeapObject(ret);
    });
    imports.wbg.__wbg_toDataURL_ca175b3d0bb6f5d9 = handleError(function (arg0, arg1) {
      var ret = getObject(arg1).toDataURL();
      var ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len0;
      getInt32Memory0()[arg0 / 4 + 0] = ptr0;
    });
    imports.wbg.__wbg_cookie_eb31c284e2ed620b = handleError(function (arg0, arg1) {
      var ret = getObject(arg1).cookie;
      var ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len0;
      getInt32Memory0()[arg0 / 4 + 0] = ptr0;
    });

    imports.wbg.__wbg_keyCode_e19b105e5d2d09d5 = function (arg0) {
      var ret = getObject(arg0).keyCode;
      return ret;
    };

    imports.wbg.__wbg_shiftKey_0924a6b92b68d3f6 = function (arg0) {
      var ret = getObject(arg0).shiftKey;
      return ret;
    };

    imports.wbg.__wbg_alpha_71e14e01b1c605a6 = function (arg0, arg1) {
      var ret = getObject(arg1).alpha;
      getFloat64Memory0()[arg0 / 8 + 1] = isLikeNone(ret) ? 0 : ret;
      getInt32Memory0()[arg0 / 4 + 0] = !isLikeNone(ret);
    };

    imports.wbg.__wbg_beta_f48a7d1a10feff4e = function (arg0, arg1) {
      var ret = getObject(arg1).beta;
      getFloat64Memory0()[arg0 / 8 + 1] = isLikeNone(ret) ? 0 : ret;
      getInt32Memory0()[arg0 / 4 + 0] = !isLikeNone(ret);
    };

    imports.wbg.__wbg_gamma_eb5fbdd72123221e = function (arg0, arg1) {
      var ret = getObject(arg1).gamma;
      getFloat64Memory0()[arg0 / 8 + 1] = isLikeNone(ret) ? 0 : ret;
      getInt32Memory0()[arg0 / 4 + 0] = !isLikeNone(ret);
    };

    imports.wbg.__wbg_touches_ea1e29cf107bf92b = function (arg0) {
      var ret = getObject(arg0).touches;
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_next_7a1e3e5ba77a5417 = handleError(function (arg0) {
      var ret = getObject(arg0).next();
      return addHeapObject(ret);
    });

    imports.wbg.__wbg_done_179f9d81f2c93943 = function (arg0) {
      var ret = getObject(arg0).done;
      return ret;
    };

    imports.wbg.__wbg_value_dd36c45a14714446 = function (arg0) {
      var ret = getObject(arg0).value;
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_get_fa38f22e54fe1ab1 = handleError(function (arg0, arg1) {
      var ret = Reflect.get(getObject(arg0), getObject(arg1));
      return addHeapObject(ret);
    });
    imports.wbg.__wbg_call_20c04382b27a4486 = handleError(function (arg0, arg1) {
      var ret = getObject(arg0).call(getObject(arg1));
      return addHeapObject(ret);
    });

    imports.wbg.__wbg_new_a938277eeb06668d = function () {
      var ret = new Array();
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_push_2bfc5fcfa4d4389d = function (arg0, arg1) {
      var ret = getObject(arg0).push(getObject(arg1));
      return ret;
    };

    imports.wbg.__wbg_values_04df67902f0aa20f = function (arg0) {
      var ret = getObject(arg0).values();
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_newnoargs_bfddd41728ab0b9c = function (arg0, arg1) {
      var ret = new Function(getStringFromWasm0(arg0, arg1));
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_now_40a39f1fea2317e3 = function () {
      var ret = Date.now();
      return ret;
    };

    imports.wbg.__wbg_new_f46e6afe0b8a862e = function () {
      var ret = new Object();
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_exec_0847b50db1960a9b = function (arg0, arg1, arg2) {
      var ret = getObject(arg0).exec(getStringFromWasm0(arg1, arg2));
      return isLikeNone(ret) ? 0 : addHeapObject(ret);
    };

    imports.wbg.__wbg_new_ad3a28429d2566a0 = function (arg0, arg1, arg2, arg3) {
      var ret = new RegExp(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3));
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_new_261626435fed913c = function (arg0, arg1) {
      try {
        var state0 = {
          a: arg0,
          b: arg1
        };

        var cb0 = function cb0(arg0, arg1) {
          var a = state0.a;
          state0.a = 0;

          try {
            return __wbg_adapter_165(a, state0.b, arg0, arg1);
          } finally {
            state0.a = a;
          }
        };

        var ret = new Promise(cb0);
        return addHeapObject(ret);
      } finally {
        state0.a = state0.b = 0;
      }
    };

    imports.wbg.__wbg_resolve_430b2f40a51592cc = function (arg0) {
      var ret = Promise.resolve(getObject(arg0));
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_then_a9485ea9ef567f90 = function (arg0, arg1) {
      var ret = getObject(arg0).then(getObject(arg1));
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_then_b114127b40814c36 = function (arg0, arg1, arg2) {
      var ret = getObject(arg0).then(getObject(arg1), getObject(arg2));
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_self_944d201f31e01c91 = handleError(function () {
      var ret = self.self;
      return addHeapObject(ret);
    });
    imports.wbg.__wbg_window_993fd51731b86960 = handleError(function () {
      var ret = window.window;
      return addHeapObject(ret);
    });
    imports.wbg.__wbg_globalThis_8379563d70fab135 = handleError(function () {
      var ret = globalThis.globalThis;
      return addHeapObject(ret);
    });
    imports.wbg.__wbg_global_073eb4249a3a8c12 = handleError(function () {
      var ret = global.global;
      return addHeapObject(ret);
    });

    imports.wbg.__wbindgen_is_undefined = function (arg0) {
      var ret = getObject(arg0) === undefined;
      return ret;
    };

    imports.wbg.__wbg_buffer_985803c87989344b = function (arg0) {
      var ret = getObject(arg0).buffer;
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_newwithbyteoffsetandlength_36d42f1c91e7259d = function (arg0, arg1, arg2) {
      var ret = new Uint8Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_length_32e166b42b85060a = function (arg0) {
      var ret = getObject(arg0).length;
      return ret;
    };

    imports.wbg.__wbg_new_b7e3d6adc8b9377a = function (arg0) {
      var ret = new Uint8Array(getObject(arg0));
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_set_66e888cef8f00a73 = function (arg0, arg1, arg2) {
      getObject(arg0).set(getObject(arg1), arg2 >>> 0);
    };

    imports.wbg.__wbg_newwithbyteoffsetandlength_3c83a6445776097f = function (arg0, arg1, arg2) {
      var ret = new Float32Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_buffer_4f0ba77e90f96e9d = function (arg0) {
      var ret = getObject(arg0).buffer;
      return addHeapObject(ret);
    };

    imports.wbg.__wbg_ownKeys_8a63b9d67c805cfd = handleError(function (arg0) {
      var ret = Reflect.ownKeys(getObject(arg0));
      return addHeapObject(ret);
    });
    imports.wbg.__wbg_set_6db0a4cb6e322f85 = handleError(function (arg0, arg1, arg2) {
      var ret = Reflect.set(getObject(arg0), getObject(arg1), getObject(arg2));
      return ret;
    });

    imports.wbg.__wbindgen_string_get = function (arg0, arg1) {
      var obj = getObject(arg1);
      var ret = typeof obj === 'string' ? obj : undefined;
      var ptr0 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len0;
      getInt32Memory0()[arg0 / 4 + 0] = ptr0;
    };

    imports.wbg.__wbindgen_boolean_get = function (arg0) {
      var v = getObject(arg0);
      var ret = typeof v === 'boolean' ? v ? 1 : 0 : 2;
      return ret;
    };

    imports.wbg.__wbindgen_debug_string = function (arg0, arg1) {
      var ret = debugString(getObject(arg1));
      var ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN;
      getInt32Memory0()[arg0 / 4 + 1] = len0;
      getInt32Memory0()[arg0 / 4 + 0] = ptr0;
    };

    imports.wbg.__wbindgen_throw = function (arg0, arg1) {
      throw new Error(getStringFromWasm0(arg0, arg1));
    };

    imports.wbg.__wbindgen_memory = function () {
      var ret = wasm.memory;
      return addHeapObject(ret);
    };

    imports.wbg.__wbindgen_closure_wrapper191 = function (arg0, arg1, arg2) {
      var ret = makeMutClosure(arg0, arg1, 64, __wbg_adapter_26);
      return addHeapObject(ret);
    };

    imports.wbg.__wbindgen_closure_wrapper193 = function (arg0, arg1, arg2) {
      var ret = makeMutClosure(arg0, arg1, 64, __wbg_adapter_32);
      return addHeapObject(ret);
    };

    imports.wbg.__wbindgen_closure_wrapper220 = function (arg0, arg1, arg2) {
      var ret = makeMutClosure(arg0, arg1, 73, __wbg_adapter_29);
      return addHeapObject(ret);
    };

    if (typeof input === 'string' || typeof Request === 'function' && _instanceof(input, Request) || typeof URL === 'function' && _instanceof(input, URL)) {
      input = fetch(input);
    }

    var _await$load = await load(await input, imports),
        instance = _await$load.instance,
        module = _await$load.module;

    wasm = instance.exports;
    init.__wbindgen_wasm_module = module;

    wasm.__wbindgen_start();
	window.wasm = wasm;
	console.log(window.wasm )
	

    return wasm;
  }

  wasm_bindgen = Object.assign(init, __exports);
  

})();

wasm_bindgen("https://h5.kugou.com/apps/verify-pkg/verifycode_bg.wasm?20200701")

setTimeout(() => {
			  var t = new wasm_bindgen.EData;
        console.log(t.get_sid())
		    console.log(t.get_edt())
		    setTimeout = function(){}
}, 1000);