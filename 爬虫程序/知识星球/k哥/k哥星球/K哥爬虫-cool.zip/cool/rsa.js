!function(e, t) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = e || self).RSA = t()
}(this, function() {
    "use strict";
    var r, h, U, v = 16, k = 65536, C = k >>> 1, _ = k * k, w = k - 1;
    function i(e) {
        r = new Array(e);
        for (var t = 0; t < r.length; t++)
            r[t] = 0;
        h = new b,
        (U = new b).digits[0] = 1
    }
    i(130);
    !function(e) {
        var t = new b
          , r = (t.isNeg = e < 0,
        e = Math.abs(e),
        0);
        for (; 0 < e; )
            t.digits[r++] = e & w,
            e >>= 16
    }(1e15);
    function b(e) {
        this.digits = "boolean" == typeof e && 1 == e ? null : r.slice(0),
        this.isNeg = !1
    }
    function I(e) {
        var t = new b(!0);
        return t.digits = e.digits.slice(0),
        t.isNeg = e.isNeg,
        t
    }
    function K(e) {
        for (var t = "", r = e.length - 1; -1 < r; --r)
            t += e.charAt(r);
        return t
    }
    var y = new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");
    var n = new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f");
    function S(e) {
        for (var t = "", r = (M(e),
        M(e)); -1 < r; --r)
            t += function(e) {
                for (var t = "", r = 0; r < 4; ++r)
                    t += n[15 & e],
                    e >>>= 4;
                return K(t)
            }(e.digits[r]);
        return t
    }
    function o(e) {
        for (var t = new b, r = e.length, i = 0; 0 < r; r -= 4,
        ++i)
            t.digits[i] = function(e) {
                for (var t, r = 0, i = Math.min(e.length, 4), n = 0; n < i; ++n)
                    r = (r <<= 4) | (t = 48 <= (t = e.charCodeAt(n)) && t <= 57 ? t - 48 : 65 <= t && t <= 90 ? 10 + t - 65 : 97 <= t && t <= 122 ? 10 + t - 97 : 0);
                return r
            }(e.substr(Math.max(r - 4, 0), Math.min(r, 4)));
        return t
    }
    function T(e) {
        for (var t, r, i = "", n = M(e); -1 < n; --n)
            i += (t = e.digits[n],
            r = void 0,
            r = String.fromCharCode(255 & t),
            t >>>= 8,
            String.fromCharCode(255 & t) + r);
        return i
    }
    function A(e, t) {
        if (e.isNeg != t.isNeg)
            t.isNeg = !t.isNeg,
            i = E(e, t),
            t.isNeg = !t.isNeg;
        else {
            for (var r, i = new b, n = 0, o = 0; o < e.digits.length; ++o)
                r = e.digits[o] + t.digits[o] + n,
                i.digits[o] = 65535 & r,
                n = Number(k <= r);
            i.isNeg = e.isNeg
        }
        return i
    }
    function E(e, t) {
        if (e.isNeg != t.isNeg)
            t.isNeg = !t.isNeg,
            i = A(e, t),
            t.isNeg = !t.isNeg;
        else {
            for (var r, i = new b, n = o = 0; n < e.digits.length; ++n)
                r = e.digits[n] - t.digits[n] + o,
                i.digits[n] = 65535 & r,
                i.digits[n] < 0 && (i.digits[n] += k),
                o = 0 - Number(r < 0);
            if (-1 == o) {
                for (var o = 0, n = 0; n < e.digits.length; ++n)
                    r = 0 - i.digits[n] + o,
                    i.digits[n] = 65535 & r,
                    i.digits[n] < 0 && (i.digits[n] += k),
                    o = 0 - Number(r < 0);
                i.isNeg = !e.isNeg
            } else
                i.isNeg = e.isNeg
        }
        return i
    }
    function M(e) {
        for (var t = e.digits.length - 1; 0 < t && 0 == e.digits[t]; )
            --t;
        return t
    }
    function x(e) {
        for (var t = M(e), r = e.digits[t], i = (t + 1) * v, n = i; i - v < n && 0 == (32768 & r); --n)
            r <<= 1;
        return n
    }
    function s(e, t) {
        for (var r, i = new b, n = M(e), o = M(t), s = 0; s <= o; ++s) {
            for (var a = 0, g = s, c = 0; c <= n; ++c,
            ++g)
                r = i.digits[g] + e.digits[c] * t.digits[s] + a,
                i.digits[g] = r & w,
                a = r >>> 16;
            i.digits[s + n + 1] = a
        }
        return i.isNeg = e.isNeg != t.isNeg,
        i
    }
    function g(e, t, r, i, n) {
        for (var o = Math.min(t + n, e.length), s = t, a = i; s < o; ++s,
        ++a)
            r[a] = e[s]
    }
    var c = new Array(0,32768,49152,57344,61440,63488,64512,65024,65280,65408,65472,65504,65520,65528,65532,65534,65535);
    function B(e, t) {
        for (var r = Math.floor(t / v), i = new b, n = (g(e.digits, 0, i.digits, r, i.digits.length - r),
        t % v), o = v - n, s = i.digits.length - 1, a = s - 1; 0 < s; --s,
        --a)
            i.digits[s] = i.digits[s] << n & w | (i.digits[a] & c[n]) >>> o;
        return i.digits[0] = i.digits[s] << n & w,
        i.isNeg = e.isNeg,
        i
    }
    var d = new Array(0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535);
    function N(e, t) {
        for (var r = Math.floor(t / v), i = new b, n = (g(e.digits, r, i.digits, 0, e.digits.length - r),
        t % v), o = v - n, s = 0, a = s + 1; s < i.digits.length - 1; ++s,
        ++a)
            i.digits[s] = i.digits[s] >>> n | (i.digits[a] & d[n]) << o;
        return i.digits[i.digits.length - 1] >>>= n,
        i.isNeg = e.isNeg,
        i
    }
    function R(e, t) {
        var r = new b;
        return g(e.digits, 0, r.digits, t, r.digits.length - t),
        r
    }
    function a(e, t) {
        var r = new b;
        return g(e.digits, t, r.digits, 0, r.digits.length - t),
        r
    }
    function u(e, t) {
        var r = new b;
        return g(e.digits, 0, r.digits, 0, t),
        r
    }
    function D(e, t) {
        if (e.isNeg != t.isNeg)
            return 1 - 2 * Number(e.isNeg);
        for (var r = e.digits.length - 1; 0 <= r; --r)
            if (e.digits[r] != t.digits[r])
                return e.isNeg ? 1 - 2 * Number(e.digits[r] > t.digits[r]) : 1 - 2 * Number(e.digits[r] < t.digits[r]);
        return 0
    }
    function j(e, t) {
        var r = x(e)
          , i = x(t)
          , n = t.isNeg;
        if (r < i)
            return e.isNeg ? ((o = I(U)).isNeg = !t.isNeg,
            e.isNeg = !1,
            t.isNeg = !1,
            s = E(t, e),
            e.isNeg = !0,
            t.isNeg = n) : (o = new b,
            s = I(e)),
            new Array(o,s);
        for (var o = new b, s = e, a = Math.ceil(i / v) - 1, g = 0; t.digits[a] < C; )
            t = B(t, 1),
            ++g,
            ++i,
            a = Math.ceil(i / v) - 1;
        s = B(s, g),
        r += g;
        for (var c = Math.ceil(r / v) - 1, d = R(t, c - a); -1 != D(s, d); )
            ++o.digits[c - a],
            s = E(s, d);
        for (var u = c; a < u; --u) {
            for (var l = u >= s.digits.length ? 0 : s.digits[u], p = u - 1 >= s.digits.length ? 0 : s.digits[u - 1], f = u - 2 >= s.digits.length ? 0 : s.digits[u - 2], m = a >= t.digits.length ? 0 : t.digits[a], h = a - 1 >= t.digits.length ? 0 : t.digits[a - 1], K = (o.digits[u - a - 1] = l == m ? w : Math.floor((l * k + p) / m),
            o.digits[u - a - 1] * (m * k + h)), y = l * _ + (p * k + f); y < K; )
                --o.digits[u - a - 1],
                K = o.digits[u - a - 1] * (m * k | h),
                y = l * k * k + (p * k + f);
            (s = E(s, function(e, t) {
                for (var r, i = new b, n = M(e), o = 0, s = 0; s <= n; ++s)
                    r = i.digits[s] + e.digits[s] * t + o,
                    i.digits[s] = r & w,
                    o = r >>> 16;
                return i.digits[1 + n] = o,
                i
            }(d = R(t, u - a - 1), o.digits[u - a - 1]))).isNeg && (s = A(s, d),
            --o.digits[u - a - 1])
        }
        return s = N(s, g),
        o.isNeg = e.isNeg != n,
        e.isNeg && (o = (n ? A : E)(o, U),
        s = E(t = N(t, g), s)),
        0 == s.digits[0] && 0 == M(s) && (s.isNeg = !1),
        new Array(o,s)
    }
    function l(e) {
        this.modulus = I(e),
        this.k = M(this.modulus) + 1;
        var t, e = new b;
        e.digits[2 * this.k] = 1,
        this.mu = (t = this.modulus,
        j(e, t)[0]),
        this.bkplus1 = new b,
        this.bkplus1.digits[this.k + 1] = 1,
        this.modulo = p,
        this.multiplyMod = f,
        this.powMod = m
    }
    function p(e) {
        for (var t = a(e, this.k - 1), t = a(s(t, this.mu), this.k + 1), r = E(u(e, this.k + 1), u(s(t, this.modulus), this.k + 1)), i = 0 <= D(r = r.isNeg ? A(r, this.bkplus1) : r, this.modulus); i; )
            i = 0 <= D(r = E(r, this.modulus), this.modulus);
        return r
    }
    function f(e, t) {
        e = s(e, t);
        return this.modulo(e)
    }
    function m(e, t) {
        for (var r = new b, i = (r.digits[0] = 1,
        e), n = t; 0 != (1 & n.digits[0]) && (r = this.multiplyMod(r, i)),
        0 != (n = N(n, 1)).digits[0] || 0 != M(n); )
            i = this.multiplyMod(i, i);
        return r
    }
    var P = {};
    function G(e, t, r, i) {
        this.e = o(e),
        this.d = o(t),
        this.m = o(r),
        this.chunkSize = "number" != typeof i ? 2 * M(this.m) : i / 8,
        this.radix = 16,
        this.barrett = new l(this.m)
    }
    function O(e, t, r, i) {
        var n, o, s, a, g, c, d, u = new Array, l = t.length, p = "", f = "string" == typeof r ? r == P.NoPadding ? 1 : r == P.PKCS1Padding ? 2 : 0 : 0, m = "string" == typeof i && i == P.RawEncoding ? 1 : 0;
        for (1 == f ? l > e.chunkSize && (l = e.chunkSize) : 2 == f && l > e.chunkSize - 11 && (l = e.chunkSize - 11),
        n = 0,
        o = 2 == f ? l - 1 : e.chunkSize - 1; n < l; )
            f ? u[o] = t.charCodeAt(n) : u[n] = t.charCodeAt(n),
            n++,
            o--;
        for (1 == f && (n = 0),
        o = e.chunkSize - l % e.chunkSize; 0 < o; ) {
            if (2 == f) {
                for (a = Math.floor(256 * Math.random()); !a; )
                    a = Math.floor(256 * Math.random());
                u[n] = a
            } else
                u[n] = 0;
            n++,
            o--
        }
        for (2 == f && (u[l] = 0,
        u[e.chunkSize - 2] = 2,
        u[e.chunkSize - 1] = 0),
        g = u.length,
        n = 0; n < g; n += e.chunkSize) {
            for (c = new b,
            o = 0,
            s = n; s < n + e.chunkSize; ++o)
                c.digits[o] = u[s++],
                c.digits[o] += u[s++] << 8;
            d = e.barrett.powMod(c, e.e),
            p += 1 == m ? T(d) : 16 == e.radix ? S(d) : function(e, t) {
                for (var r = new b, i = (r.digits[0] = t,
                j(e, r)), n = y[i[1].digits[0]]; 1 == D(i[0], h); )
                    i = j(i[0], r),
                    digit = i[1].digits[0],
                    n += y[i[1].digits[0]];
                return (e.isNeg ? "-" : "") + K(n)
            }(d, e.radix)
        }
        return p
    }
    return P.NoPadding = "NoPadding",
    P.PKCS1Padding = "PKCS1Padding",
    P.RawEncoding = "RawEncoding",
    P.NumericEncoding = "NumericEncoding",
    {
        encrypt: function(e, t, r) {
            return i(130),
            r = r || "NoPadding",
            O(new G("10001","",t = t || "B1B1EC76A1BBDBF0D18E8CD9A87E53FA3881E2F004C67C9DDA2CA677DBEFA3D61DF8463FE12D84FF4B4699E02C9D41CAB917F5A8FB9E35580C4BDF97763A0420A476295D763EE10174E6F9EBF7DF8A77BA5B20CDA4EE705DEF5BBA3C88567B9656E52C9CD5CD95CA735FF2D25F762B133273EEEB7B4F3EA8B6DA29040F3B67CD",1024), e, r)
        }
    }
});

