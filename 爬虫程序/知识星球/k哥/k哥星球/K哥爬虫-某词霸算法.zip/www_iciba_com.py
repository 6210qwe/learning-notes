# ======================
# -*-coding: Utf-8 -*-
# author: K哥爬虫
# ======================
import json
import base64
import hashlib
import requests
import urllib.parse
from loguru import logger
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

"""
金山词霸翻译
https://www.iciba.com/translate
"""


class Iciba:
    def __init__(self):
        self.headers = {
            "authority": "ifanyi.iciba.com",
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "cache-control": "no-cache",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://www.iciba.com",
            "pragma": "no-cache",
            "referer": "https://www.iciba.com/",
            "sec-ch-ua": "\"Not A(Brand\";v=\"99\", \"Microsoft Edge\";v=\"121\", \"Chromium\";v=\"121\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
        }

    @staticmethod
    def aes_encrypt(aes_key: str, text: str) -> str:
        key = aes_key.encode('utf-8')
        srcs = text.encode('utf-8')
        cipher = AES.new(key, AES.MODE_ECB)
        # 在加密之前进行填充
        padded_data = pad(srcs, AES.block_size)
        encrypted = cipher.encrypt(padded_data)
        # 返回 base64 编码后的密文
        return base64.b64encode(encrypted).decode('utf-8')

    def get_sign(self, search_word: str) -> str:
        aes_key = 'L4fBtD5fLC9FQw22'
        concat_search_params = '6key_web_new_fanyi' + '6dVjYLFyzfkFkk' + search_word
        md5_encrypt_result = hashlib.md5(concat_search_params.encode()).hexdigest()[:16]
        sign = self.aes_encrypt(aes_key, md5_encrypt_result)
        return urllib.parse.quote(sign)

    @staticmethod
    def aes_decrypt(ciphertext):
        key = 'aahc3TfyfCEmER33'.encode('utf-8')
        # 将密文进行 base64 解码
        ciphertext = base64.b64decode(ciphertext)
        # 创建 AES 解密器对象
        cipher = AES.new(key, AES.MODE_ECB)
        # 对密文进行解密
        decrypted_data = cipher.decrypt(ciphertext)
        # 对解密后的数据进行去填充操作
        decrypted_data = unpad(decrypted_data, AES.block_size)
        # 返回解密后的明文
        return decrypted_data.decode('utf-8')

    def get_translate_data(self):
        trans_word = 'ratel'
        logger.debug('translate word: %s' % trans_word)
        sign = self.get_sign(trans_word)
        logger.info('sign: %s' % sign)
        url = "https://ifanyi.iciba.com/index.php"
        params = {
            "c": "trans",
            "m": "fy",
            "client": "6",
            "auth_user": "key_web_new_fanyi",
            "sign": sign
        }
        data = {
            "from": "en",
            "to": "zh",
            "q": trans_word
        }
        response = requests.post(url, headers=self.headers, params=params, data=data)
        content = response.json()['content']
        logger.info('content: %s' % content)
        trans_result = json.loads(self.aes_decrypt(content))['out']
        logger.success('translate result: %s' % trans_result)

    def main(self):
        self.get_translate_data()


if __name__ == '__main__':
    Iciba().main()
