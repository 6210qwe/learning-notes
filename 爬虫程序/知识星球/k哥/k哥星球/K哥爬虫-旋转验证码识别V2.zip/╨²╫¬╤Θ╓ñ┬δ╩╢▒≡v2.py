from PIL import Image, ImageDraw
import math


def extract_circle_pixels(img_path, center, radius, num_samples=360):
    image = Image.open(img_path)
    draw = ImageDraw.Draw(image)

    pixels = []
    sample_step = 2 * math.pi / num_samples

    for i in range(num_samples):
        angle = i * sample_step
        x = int(center[0] + radius * math.cos(angle))
        y = int(center[1] + radius * math.sin(angle))

        pixel = image.getpixel((x, y))
        pixels.append(pixel)

        if i > 0:  # Skip the first point to avoid errors
            draw.line((last_x, last_y, x, y), fill="red", width=2)

        last_x, last_y = x, y

    return pixels


def calculate_diff(list1, list2):
    total_diff = sum(math.sqrt(sum((a - b) ** 2 for a, b in zip(p1[:3], p2))) for p1, p2 in zip(list1, list2))
    return total_diff


if __name__ == '__main__':
    # 图片的圆心和半径, 例：背景图片为back.jpg, 内容图片为title.png
    back_center = (200, 100)
    back_radius = 81
    title_center = (80, 80)
    title_radius = 74

    back_path = 'back.jpg'
    title_path = 'title.png'

    back_pixels = extract_circle_pixels(back_path, back_center, back_radius)
    title_pixels = extract_circle_pixels(title_path, title_center, title_radius)

    Difference_value = float('inf')
    Angle = 0

    for i in range(360):
        rotated_pixels = [title_pixels[(j + i) % 360] for j in range(360)]
        total_diff = calculate_diff(back_pixels, rotated_pixels)

        if Difference_value > total_diff:
            Difference_value = total_diff
            Angle = i

    print(f'旋转角度为: {360 - Angle}')
