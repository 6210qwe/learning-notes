const files     = require('fs');  //导入文件库，防止与fs变量名冲突
const types     = require("@babel/types");
const parser    = require("@babel/parser");
const template  = require("@babel/template").default;
const traverse  = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath  = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");



const t = require('@babel/types');
traverse(ast,{
    'CallExpression':{
        enter : function(path){

            let callee = path.get('callee')
            let arguments = path.get('arguments')
            if(!t.isFunctionExpression(callee) || arguments.length ===0)
                return

            let scope = callee.scope;
            let params = callee.get('params')
            for(let i = 0;i <arguments.length; i++){
                let arg = params[i]
                let {name} = arg.node;
                let binding = scope.getBinding(name);
                if(!binding || binding.constantViolations.length>0)
                    continue;
                for(let refer_path of binding.referencePaths){
                    refer_path.replaceInline(arguments[i])
                }
                arg.remove();
                arguments[i].remove()
            }

            let {body} = callee.node.body;
            if (body.length == 1 && t.isReturnStatement(body[0]))
            {
            	path.replaceWith(body[0].argument);
            }

        }
    }
})


// 检查路径或其任一子路径是否包含逗号表达式
function containsSequenceExpression(path) {
    let containsSequence = false;
    // 深度优先遍历当前路径及其所有子路径
    path.traverse({
        SequenceExpression(_path) {
            containsSequence = true;
            _path.stop(); // 找到逗号表达式后立即停止遍历
        }
    });
    return containsSequence;
}

//请使用学员专版babel库
const constantFold = {
    "BinaryExpression|UnaryExpression|MemberExpression|CallExpression"(path) {
        if (containsSequenceExpression(path)) {
            return;
        }
        if (path.isUnaryExpression({ operator: "-" }) ||
            path.isUnaryExpression({ operator: "void" })) {
            return;
        }
        const { confident, value } = path.evaluate();

        if (!confident || typeof value == "function")
            return;

        if (typeof value == 'number' && (!Number.isFinite(value))) {
            return;
        }

        console.log(path.toString(),"--->",value);

        path.replaceWith(types.valueToNode(value));
    },
}

traverse(ast, constantFold);




console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });