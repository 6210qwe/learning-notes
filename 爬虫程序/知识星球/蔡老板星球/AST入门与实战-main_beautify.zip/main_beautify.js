const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = "./beautify.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode,{"sourceType":"module"});


const keyToLiteral = {

	ObjectProperty:
	{
		exit({ node }) {
			const key = node.key;
			if (!node.computed && types.isIdentifier(key)) {
				node.key = types.StringLiteral(key.name);
				return;
			}
			if (node.computed && types.isStringLiteral(key)) {
				//处理 var a = {["b"]:c};  这种情况
				node.computed = false;
			}
		}
	},
}


const standardLoop =
{
    "ForStatement|WhileStatement|ForInStatement|ForOfStatement|DoWhileStatement"({ node }) {
        if (!types.isBlockStatement(node.body)) {
            node.body = types.BlockStatement([node.body]);
        }
    },
    IfStatement(path)
    {
    	const consequent = path.get("consequent");
    	const alternate  = path.get("alternate");
    	if (!consequent.isBlockStatement()) 
    	{
    		consequent.replaceWith(types.BlockStatement([consequent.node]));
    	}
    	if (alternate.node !== null && !alternate.isBlockStatement()) {
    		alternate.replaceWith(types.BlockStatement([alternate.node]));
    	}
    },
}




const DeclaratorToDeclaration =
{
	VariableDeclaration(path) {
		let { parentPath, node } = path;
		if (parentPath.isFor()) {
			return;
		}
		let { declarations, kind } = node;

		if (declarations.length == 1) {
			return;
		}

		let newNodes = [];

		for (const varNode of declarations) {
			let newDeclartionNode = types.VariableDeclaration(kind, [varNode]);
			newNodes.push(newDeclartionNode);
		}

		path.replaceWithMultiple(newNodes);

	},
}


const varDeclarToFuncDeclar =
{
	VariableDeclaration(path) {
		let { parentPath, node, scope } = path;
		if (!parentPath.isBlock()) {//过滤掉部分特殊情况，例如for循环里的变量定义
			return;
		}
		let { declarations, kind } = node;
		if (declarations.length != 1) {
			return;
		}

		let { id, init } = declarations[0];
		if (!types.isFunctionExpression(init, { id: null })) {
			return;
		}

		let { params, body } = init;
		let newNode = types.FunctionDeclaration(id, params, body);
		path.replaceWith(newNode);
	}
}


// 检查路径或其任一子路径是否包含逗号表达式
function containsSequenceExpression(path) {
	let containsSequence = false;
	// 深度优先遍历当前路径及其所有子路径
	path.traverse({
		SequenceExpression(_path) {
			containsSequence = true;
			_path.stop(); // 找到逗号表达式后立即停止遍历
		}
	});
	return containsSequence;
}

//请使用学员专版babel库
const constantFold = {
	"BinaryExpression|UnaryExpression"(path) {
		if (containsSequenceExpression(path)) {
			return;
		}
		if (path.isUnaryExpression({ operator: "-" }) ||
			path.isUnaryExpression({ operator: "void" })) {
			return;
		}

		const { confident, value } = path.evaluate();

		if (!confident || typeof value == "function")
			return;


		if (typeof value == 'number' && (!Number.isFinite(value))) {
			return;
		}

		console.log(path.toString(), "--->", value);

		path.replaceWith(types.valueToNode(value));
	},
}


const resolveSequence = 
{
	SequenceExpression(path)
	{
		let {scope,parentPath,node} = path;
		let expressions = node.expressions;
		if (parentPath.isReturnStatement({"argument":node}))
		{
			let lastExpression = expressions.pop();
			for (let expression of expressions)
			{
				parentPath.insertBefore(types.ExpressionStatement(expression=expression));
			}

			path.replaceInline(lastExpression);
		}
		else if (parentPath.isExpressionStatement({"expression":node}))
		{
			let body = [];
			expressions.forEach(express=>{body.push(types.ExpressionStatement(express));});
            path.replaceWithMultiple(body);
		}
		else
		{
			return;
		}

		scope.crawl();
	}
}



function isBaseLiteral(node) {

	if (types.isLiteral(node)) {
		return true;
	}

	if (types.isUnaryExpression(node)) {
		return isBaseLiteral(node.argument);
	}

	return false;
}


const decodeObjectofValue =
{
	VariableDeclarator(path) {
		let { node, scope } = path;
		const { id, init } = node;

		if (!types.isObjectExpression(init)) return;

		let properties = init.properties;

		if (properties.length == 0 || !properties.every(property => isBaseLiteral(property.value)))
			return;

		let binding = scope.getBinding(id.name);

		if (!binding) return;

		let { constant, referencePaths, constantViolations } = binding;

		if (!constant) {//新版本的babel库，在循环里面的变量定义，默认非常量
			if (constantViolations.length != 1 || constantViolations[0] != path) //旧版本屏蔽该行即可
			{
				return;
			}
		}

		let newMap = new Map();

		for (const property of properties) {
			let { key, value } = property;

			let KeyName = types.isIdentifier(key) ? key.name : key.value;

			if (!KeyName || KeyName.length != 5) {
				//  continue; //仅针对ob混淆
			}
			newMap.set(KeyName, value);
		}

		if (newMap.size != properties.length) {
			return;
		}

		let canBeRemoved = true;

		for (const referPath of referencePaths) {

			let { parentPath } = referPath;

			if (!parentPath.isMemberExpression()) {
				canBeRemoved = false;
				break;
			}

			let AncestorPath = parentPath.parentPath;

			if (AncestorPath.isAssignmentExpression({ "left": parentPath.node })) {
				canBeRemoved = false;
				break;
			}
			if (AncestorPath.isUpdateExpression() && ['++', '--'].includes(AncestorPath.node.operator)) {
				canBeRemoved = false;
				break;
			}

			let { property } = parentPath.node;

			let curKey = types.isIdentifier(property) ? property.name : property.value;

			if (!newMap.has(curKey)) {
				canBeRemoved = false;
				break;
			}

			parentPath.replaceWith(newMap.get(curKey));
		}

		canBeRemoved && path.remove();

		newMap.clear();
	},
}




const restoreVarDeclarator =
{
	VariableDeclarator(path) {
		let scope = path.scope;
		let { id, init } = path.node;

		if (!types.isIdentifier(id) || init == null || !isBaseLiteral(init)) {
			return;
		}

		const binding = scope.getBinding(id.name);

		if (!binding) return;

		let { constant, referencePaths, constantViolations } = binding;

		if (constantViolations.length > 1) {
			return;
		}

		if (constant || constantViolations[0] == path) {
			for (let referPath of referencePaths) {
				referPath.replaceWith(init);
			}
		}
	},
}




const restoreAssignConstant =
{//常量还原插件
    AssignmentExpression(path) {

        let { scope, node, parentPath } = path;

        let { left, operator, right } = node;

        if (!types.isIdentifier(left) || operator != "=" || !isBaseLiteral(right)) {
            return;
        }

        let binding = scope.getBinding(left.name);

        if (!binding) {//如果没有binding,或者赋值语句本身改变了它，因此这里判断只有一处改变。
            return;
        }

        let { referencePaths, constantViolations } = binding;

        let canVisit = false;

        if (constantViolations.length == 1 && constantViolations[0] == path) {
            canVisit = true;
        }
        if (constantViolations.length == 2 && constantViolations[0] == binding.path && binding.path.isVariableDeclarator({ init: null }) &&
            constantViolations[1] == path) {//针对循环体里面定义的变量
            canVisit = true;
        }

        if (!canVisit) return;

        let { start } = node;

        for (let referPath of binding.referencePaths) {

            if (referPath.node.end <= start) {
                continue;
            }

            referPath.replaceWith(right);
        }

        if (parentPath.isExpressionStatement() || parentPath.isSequenceExpression()) {
            path.remove();
        }
    },

}



const simplySpAssignmentExpression = 
{
    AssignmentExpression(path)
    {

        let {parentPath,node,scope} = path;

        if (!parentPath.isCallExpression({"callee":node}))
        {
            return;
        }

        let {arguments} = parentPath.node;

        if (arguments.length != 1 || !types.isLiteral(arguments[0]))
        {//这里根据情况进行改写
        //  return;
        }

        let {left,operator,right} = node;

        if (!types.isIdentifier(left) || operator != "=" || !types.isIdentifier(right))
        {
            return;
        }

        let otherNode = types.CallExpression(left,arguments);

        let NewNode  = types.SequenceExpression([node,otherNode]);

        parentPath.replaceWith(NewNode);

    }
}





const removeDeadCode = {
	"IfStatement|ConditionalExpression"(path) {
		let { consequent, alternate } = path.node;
		let testPath = path.get('test');
		const evaluateTest = testPath.evaluateTruthy();
		if (evaluateTest === true) {
			if (types.isBlockStatement(consequent)) {
				consequent = consequent.body;
			}
			path.replaceWithMultiple(consequent);
			return;
		}
		if (evaluateTest === false) {
			if (alternate != null) {
				if (types.isBlockStatement(alternate)) {
					alternate = alternate.body;
				}
				path.replaceWithMultiple(alternate);
			}
			else {
				path.remove();
			}
		}
	},
	"LogicalExpression"(path) {
		let { left, operator, right } = path.node;

		let leftPath = path.get('left');

		const evaluateLeft = leftPath.evaluateTruthy();

		if ((operator == "||" && evaluateLeft == true) ||
			(operator == "&&" && evaluateLeft == false)) {
			path.replaceWith(left);
			return;
		}
		if ((operator == "||" && evaluateLeft == false) ||
			(operator == "&&" && evaluateLeft == true)) {
			path.replaceWith(right);
		}
	},
	"EmptyStatement|DebuggerStatement"(path) {
		path.remove();
	},
	"VariableDeclarator"(path) {
		let { node, scope, parentPath, parent } = path;

		let ancestryPath = parentPath.parentPath;

		if (ancestryPath.isForOfStatement({ left: parent }) ||
			ancestryPath.isForInStatement({ left: parent })) {//目前发现这两个需要过滤
			return;
		}

		let { id, init } = node;

		if (!types.isIdentifier(id) || (!isBaseLiteral(init) && init != null)) {
			return;
		}

		let binding = scope.getBinding(id.name);//重新解析ast后，一定会有binding;
		if (!binding) return;

		let { referenced, constant, constantViolations } = binding;

		if (referenced || constantViolations.length > 1) {
			return;
		}

		if (constant || constantViolations[0] == path) {
			console.log(path.toString());
			path.remove();
		}
	},
}


const simplifyLiteral = {
	NumericLiteral({ node }) {
		if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
	StringLiteral({ node }) {
		if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
}




console.time("处理完毕，耗时");


if (1) {

	traverse(ast, keyToLiteral);

	traverse(ast, standardLoop);

	traverse(ast, DeclaratorToDeclaration);

	traverse(ast, varDeclarToFuncDeclar);

	ast = parser.parse(generator(ast).code,{"sourceType":"module"});

	traverse(ast, resolveSequence);

	ast = parser.parse(generator(ast).code,{"sourceType":"module"});

	traverse(ast, constantFold);

	traverse(ast, decodeObjectofValue);

	ast = parser.parse(generator(ast).code,{"sourceType":"module"});

	traverse(ast, restoreVarDeclarator);

	traverse(ast, restoreAssignConstant);

	traverse(ast, simplySpAssignmentExpression);

	ast = parser.parse(generator(ast).code,{"sourceType":"module"});

	traverse(ast, constantFold);

	traverse(ast, removeDeadCode);

}



console.timeEnd("处理完毕，耗时");


traverse(ast, simplifyLiteral);

let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});


files.writeFile(decodeFile, code, (err) => { });











