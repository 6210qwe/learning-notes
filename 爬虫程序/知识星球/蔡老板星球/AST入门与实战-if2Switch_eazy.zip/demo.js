
var TX = function (a, v, T, V, I, N, f, u, M) {
  for (u = 0; u != 60;) {
    if (u == 59) {
      N = VG(27, 0, V, I);
      if (f = N >= 0) {
        Array.prototype.splice.call(I, N, v);
      }
      M = f;
      u = 66;
    } else {
      if (u == 5) {
        u = (T >> 2 & 3) == 1 ? 59 : 66;
      } else {
        if (u == 7) {
          u = ((T ^ 30) & 7) >= 5 && (T | 6) >> a < 1 ? 23 : 5;
        } else {
          if (u == 23) {
            this.src = v;
            this.N = {};
            this.gh = 0;
            u = 5;
          } else {
            if (u == 66) {
              return M;
            }
            if (u == 0) {
              u = 7;
            }
          }
        }
      }
    }
  }
};
