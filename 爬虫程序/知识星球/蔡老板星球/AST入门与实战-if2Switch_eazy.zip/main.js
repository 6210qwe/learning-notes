const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.replace(".js", "") + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode, { "sourceType": "module" });     //支持es6语法
console.time("处理完毕，耗时");



const if2Switch =
{
    ForStatement(path) {
        let { init, test, body, update } = path.node;

        if (!types.isAssignmentExpression(init) || !types.isBinaryExpression(test) || update != null) {
            return;
        }

        if (body.body.length != 1 || !types.isIfStatement(body.body[0])) {
            return;
        }

        let { left, operator, right } = init;

        if (!types.isIdentifier(left) || operator != "=") {
            return;
        }

        if (test.left.name != left.name || test.operator != "!=") {
            return;
        }

        

        let switchBolck = [];
        path.traverse({
            IfStatement(_path) {
                let { test, consequent } = _path.node;

                if (types.isBinaryExpression(test) && test.left.name == left.name && test.operator == "==") 
                {
                    consequent.body.push(types.BreakStatement());
                    let switchCaseNode = types.SwitchCase(test.right,consequent.body);
				    switchBolck.push(switchCaseNode);	
                }
            }
        })
        
        if (switchBolck.length > 0)
        {
            let switchNode = types.SwitchStatement(left,switchBolck);
            path.node.body = types.BlockStatement([switchNode]);
        }



    }
}

traverse(ast, if2Switch);


console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
    "compact": false,  // 是否压缩代码
    "comments": false,  // 是否保留注释
    "jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });