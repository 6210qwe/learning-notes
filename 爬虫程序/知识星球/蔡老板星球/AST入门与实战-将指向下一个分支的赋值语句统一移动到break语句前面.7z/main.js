const files     = require('fs');  //导入文件库，防止与fs变量名冲突
const types     = require("@babel/types");
const parser    = require("@babel/parser");
const template  = require("@babel/template").default;
const traverse  = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath  = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.replace(".js","") + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode,{"sourceType":"module"});     //支持es6语法
console.time("处理完毕，耗时");




const addBreakStatement =
{
	SwitchCase(path) {
		let { consequent } = path.node;
		if (consequent.length == 0)
		{
			return;
		}
		if (!types.isBreakStatement(consequent.at(-1))) {
			consequent.push(types.BreakStatement());
		}
	}
}

traverse(ast, addBreakStatement);


function isStopNode(node) {
	if (types.isReturnStatement(node) || types.isThrowStatement(node)) {
		return true;
	}
	
	return false;

}

const changeAssignNode = 
{
	SwitchStatement(path)
	{
		let {discriminant,cases} = path.node;

		if (!types.isIdentifier(discriminant))
		{
			return;
		}

		for (let i=0; i<cases.length; i++)
		{
			let {consequent} = cases[i];

			let lastNode = consequent.at(-2);

			if (isStopNode(lastNode))
			{
				continue;
			}

			if (!types.isExpressionStatement(lastNode) || !types.isAssignmentExpression(lastNode.expression) || 
		        !types.isIdentifier(lastNode.expression.left,{"name":discriminant.name}))
			{
				for (var j=0; j<consequent.length;j++)
				{
					
					if (types.isExpressionStatement(consequent[j]) && types.isAssignmentExpression(consequent[j].expression))
					{
						let {left} = consequent[j].expression;
						if (types.isIdentifier(left,{"name":discriminant.name}))
						{
							break;
						}
					}

				}

				if (j<consequent.length)
				{
					let insertNode = cases[i].consequent[j];
					cases[i].consequent.splice(-1,0,insertNode);
					cases[i].consequent.splice(j,1);
				}
			}
			
			
		}
	}
}

traverse(ast, changeAssignNode);

console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });