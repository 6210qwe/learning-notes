var TX = function (a, v, T, V, I, N, f, u, M) {
  for (u = 0; u != 60;) {
    switch (u) {
      case 59:
        u = 66;
        N = VG(27, 0, V, I);
        if (f = N >= 0) {
          Array.prototype.splice.call(I, N, v);
        }
        M = f;
        break;
      case 5:
        u = (T >> 2 & 3) == 1 ? 59 : 66;
        break;
      case 7:
        u = ((T ^ 30) & 7) >= 5 && (T | 6) >> a < 1 ? 23 : 5;
        break;
      case 23:
        u = 5;
        this.src = v;
        this.N = {};
        this.gh = 0;
        break;
      case 66:
        return M;
        break;
      case 0:
        u = 7;
        break;
    }
  }
};