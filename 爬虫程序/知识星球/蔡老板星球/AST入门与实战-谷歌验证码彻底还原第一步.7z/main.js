﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const { returnStatement } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";  //默认的js文件
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./step1.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");



const DeclaratorToDeclaration =
{
	VariableDeclaration(path) {
		let { parentPath, node } = path;
		if (!parentPath.isBlock()) {
			return;
		}
		let { declarations, kind } = node;

		if (declarations.length == 1) {
			return;
		}

		let newNodes = [];

		for (const varNode of declarations) {
			let newDeclartionNode = types.VariableDeclaration(kind, [varNode]);
			newNodes.push(newDeclartionNode);
		}

		path.replaceWithMultiple(newNodes);
	},
}

traverse(ast, DeclaratorToDeclaration);


const standardLoop =
{
	"ForStatement|WhileStatement|ForInStatement|ForOfStatement"({ node }) {
		if (!types.isBlockStatement(node.body)) {
			node.body = types.BlockStatement([node.body]);
		}
	},
	IfStatement(path) {
		const consequent = path.get("consequent");
		const alternate = path.get("alternate");
		if (!consequent.isBlockStatement()) {
			consequent.replaceWith(types.BlockStatement([consequent.node]));
		}
		if (alternate.node !== null && !alternate.isBlockStatement()) {
			alternate.replaceWith(types.BlockStatement([alternate.node]));
		}
	},
}

traverse(ast, standardLoop);




const resolveSequence =
{
    SequenceExpression:
    {
        /**  @param  {NodePath} path */
        exit(path) {

            let statementPath = path.getStatementParent();
            if (!statementPath) return;

            let canVisitFlag = true;

            statementPath.traverse({
                "LogicalExpression|ConditionalExpression"(_path) {
                    if (!_path.isAncestor(path)) {

                        return;
                    }

                    let key = _path.isLogicalExpression() ? "left" : "test";

                    let execPath = _path.get(key);

                    if (execPath != path && !execPath.isAncestor(path)) {
                        canVisitFlag = false;
                        _path.stop();
                    }
                },
            })

            if (!canVisitFlag) return;

            if (statementPath.isLoop()) {//循环表达式内的test节点，不能随意插在该表达式前面

                let initPath = statementPath.get('init');

                if (initPath.node == undefined || (initPath != path && !initPath.isAncestor(path))) {
                    return
                }
            }

            let expressions = path.node.expressions;
            let lastNode = expressions.pop();

            for (let expression of expressions) {
                statementPath.insertBefore(types.ExpressionStatement(expression = expression));
            }

            path.replaceWith(lastNode);

        }
    }
}

traverse(ast, resolveSequence);



let ifNODETEP = template(`if(A){B;}`);
const LogicalToIfStatement =
{
	LogicalExpression(path) {
		let { node, parentPath } = path;
		if (!parentPath.isExpressionStatement({ "expression": node })) {
			return;
		}
		let { left, operator, right } = node;
		let ifNode = "";
		if (operator == "||") {
			let UnaryNode = types.UnaryExpression(operator = "!", argument = left);
			ifNode = ifNODETEP({ "A": UnaryNode, "B": right });
		}
		else if (operator == "&&") {
			ifNode = ifNODETEP({ "A": left, "B": right });
		}
		else {
			return;
		}

		parentPath.replaceWith(ifNode);
	},

}



let ifNODE2 = template(`if(A){B;}else{C;}`);
const ConditionToIf = {
	ConditionalExpression: {
		exit(path) {
			let { test, consequent, alternate } = path.node;
			let ifStateNode = ifNODE2({ "A": test, "B": consequent, "C": alternate });
			path.replaceWithMultiple(ifStateNode);
			path.skip();
		}
	},
}

for (let i=0;i<5;i++)
{
	traverse(ast, resolveSequence);
	ast = parser.parse(generator(ast).code);  //防止scope污染，重新解析一下ast
	traverse(ast, LogicalToIfStatement);
	ast = parser.parse(generator(ast).code);  //防止scope污染，重新解析一下ast
	traverse(ast, ConditionToIf);
}






function getRandomName(length) {

	let initArr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
	let puzzleArr = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
	let ranInx = Math.floor(Math.random() * initArr.length);
	let randomName = initArr[ranInx];

	for (var i = 1; i < length; i++) {
		ranInx = Math.floor(Math.random() * puzzleArr.length);
		randomName += puzzleArr[ranInx];
	}

	return randomName;
}


let allNewNames = new Map();  //定义一个全局变量，保存需要处理的函数

function getUnusedIdentifier() {//获取未被使用的名称,返回 Identifier 类型。
	do {
		var newName = "clb_" + getRandomName(3);

	} while (allNewNames.has(newName))

	allNewNames.set(newName, 1);

	let UnusedIdentifier = types.Identifier(newName);

	return UnusedIdentifier;
}


let DEFINENODE = template(`var A;`);
let ASSIGN_NODE = template(`A = B;`);

function isNeedSimple(path) {
	let NeedSimple = false;

	if (path.isConditionalExpression()) {
		NeedSimple = true;
	}


	path.traverse({
		
		"SequenceExpression|ConditionalExpression"(_path) {
			NeedSimple = true;
			_path.stop();
		},
	})

	return NeedSimple;
}

const simplifyExpression =
{
	IfStatement(path) {

		let pendingPath = path.get("test");

		if (!isNeedSimple(pendingPath)) {
			return;
		}

		let UnusedIdentifier = getUnusedIdentifier();

		let newDefineNode = DEFINENODE({ "A": UnusedIdentifier, });
		path.insertBefore(newDefineNode);

		let newAssinNOde = ASSIGN_NODE({ "A": UnusedIdentifier, "B": pendingPath.node });
		path.insertBefore(newAssinNOde);

		pendingPath.replaceWith(UnusedIdentifier);
	},
	ReturnStatement(path) {

		let pendingPath = path.get("argument");

		if (pendingPath.isArrayExpression() || !isNeedSimple(pendingPath)) {
			return;
		}

		let UnusedIdentifier = getUnusedIdentifier();

		let newDefineNode = DEFINENODE({ "A": UnusedIdentifier, });
		path.insertBefore(newDefineNode);

		let newAssinNOde = ASSIGN_NODE({ "A": UnusedIdentifier, "B": pendingPath.node });
		path.insertBefore(newAssinNOde);

		pendingPath.replaceWith(UnusedIdentifier);
	},
	ForStatement(path) {
		let initPath = path.get('init');
		if (!isNeedSimple(initPath)) {
			return;
		}
		path.insertBefore(initPath.node);

		path.node.init = null;
	},

}

traverse(ast, simplifyExpression);













console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

fs.writeFile(decodeFile, code, (err) => { });