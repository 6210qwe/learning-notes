#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SM4算法完整实现
国密SM4对称加密算法的纯Python实现
"""

class SM4:
    def __init__(self):
        # S盒
        self.S_BOX = [
            1,
            88,
            132,
            233,
            162,
            39,
            185,
            237,
            238,
            159,
            164,
            76,
            59,
            144,
            97,
            94,
            214,
            196,
            213,
            221,
            65,
            116,
            49,
            222,
            224,
            63,
            51,
            118,
            157,
            106,
            53,
            45,
            191,
            58,
            253,
            71,
            148,
            254,
            131,
            40,
            43,
            57,
            13,
            128,
            178,
            30,
            46,
            226,
            183,
            67,
            243,
            44,
            6,
            192,
            172,
            29,
            32,
            210,
            82,
            170,
            142,
            19,
            231,
            127,
            161,
            146,
            168,
            195,
            105,
            69,
            249,
            246,
            26,
            151,
            215,
            190,
            92,
            245,
            86,
            4,
            112,
            109,
            11,
            50,
            99,
            96,
            176,
            117,
            95,
            244,
            198,
            177,
            87,
            169,
            68,
            153,
            229,
            5,
            110,
            89,
            218,
            137,
            12,
            7,
            104,
            54,
            119,
            21,
            101,
            155,
            28,
            211,
            123,
            34,
            93,
            2,
            166,
            230,
            108,
            42,
            209,
            75,
            187,
            14,
            78,
            41,
            251,
            240,
            189,
            115,
            135,
            252,
            236,
            60,
            202,
            70,
            134,
            100,
            174,
            9,
            38,
            33,
            22,
            17,
            121,
            201,
            8,
            239,
            182,
            47,
            167,
            179,
            147,
            173,
            98,
            152,
            216,
            203,
            73,
            150,
            165,
            223,
            206,
            138,
            188,
            199,
            31,
            74,
            205,
            242,
            27,
            125,
            248,
            81,
            20,
            255,
            114,
            139,
            36,
            61,
            56,
            145,
            48,
            16,
            225,
            83,
            219,
            62,
            85,
            126,
            208,
            0,
            160,
            171,
            181,
            102,
            184,
            23,
            3,
            140,
            15,
            250,
            133,
            113,
            241,
            141,
            52,
            163,
            156,
            80,
            111,
            90,
            220,
            143,
            120,
            84,
            175,
            217,
            18,
            186,
            25,
            79,
            37,
            154,
            207,
            180,
            136,
            64,
            204,
            158,
            24,
            193,
            234,
            72,
            35,
            129,
            55,
            232,
            228,
            149,
            91,
            122,
            77,
            212,
            200,
            235,
            103,
            124,
            130,
            247,
            66,
            10,
            107,
            227,
            194,
            197
        ]

        # FK固定参数
        self.FK = [3073561711, 1332717957, 1666521335, 3214722373]

        # CK固定参数
        self.CK = [
            1779911708,
            3560110299,
            2795305861,
            346703132,
            6546479,
            2553688457,
            825963191,
            3000389807,
            1436244341,
            687537412,
            1028283729,
            958197830,
            2737609583,
            1924726585,
            1626281073,
            3050929911,
            3759914832,
            2893842435,
            2440191754,
            3756110599,
            1779861933,
            135486808,
            1727723913,
            3743872279,
            3014335276,
            2437275141,
            1796269370,
            3316512385,
            2844109665,
            3045157748,
            200917231,
            711568583
        ]

        self.round_keys = []

    def _rotl(self, x, n):
        """循环左移"""
        return ((x << n) | (x >> (32 - n))) & 0xffffffff

    def _s_box_transform(self, x):
        """S盒变换"""
        return (self.S_BOX[(x >> 24) & 0xff] << 24) | \
            (self.S_BOX[(x >> 16) & 0xff] << 16) | \
            (self.S_BOX[(x >> 8) & 0xff] << 8) | \
            self.S_BOX[x & 0xff]

    def _tau(self, x):
        """τ变换"""
        return self._s_box_transform(x)

    def _l_transform(self, x):
        """线性变换L"""
        return x ^ self._rotl(x, 2) ^ self._rotl(x, 10) ^ self._rotl(x, 18) ^ self._rotl(x, 24)

    def _l_prime_transform(self, x):
        """密钥扩展中的线性变换L'"""
        return x ^ self._rotl(x, 13) ^ self._rotl(x, 23)

    def _t_transform(self, x):
        """T变换"""
        return self._l_transform(self._tau(x))

    def _t_prime_transform(self, x):
        """密钥扩展中的T'变换"""
        return self._l_prime_transform(self._tau(x))

    def _f_function(self, x0, x1, x2, x3, rk):
        """轮函数F"""
        return x0 ^ self._t_transform(x1 ^ x2 ^ x3 ^ rk)

    def _bytes_to_words(self, data):
        """将字节数据转换为32位字"""
        words = []
        for i in range(0, len(data), 4):
            word = (data[i] << 24) | (data[i+1] << 16) | (data[i+2] << 8) | data[i+3]
            words.append(word)
        return words

    def _words_to_bytes(self, words):
        """将32位字转换为字节数据"""
        data = []
        for word in words:
            data.extend([
                (word >> 24) & 0xff,
                (word >> 16) & 0xff,
                (word >> 8) & 0xff,
                word & 0xff
            ])
        return bytes(data)

    def _key_expansion(self, key):
        """密钥扩展"""
        if len(key) != 16:
            raise ValueError("密钥长度必须为16字节")

        key_words = self._bytes_to_words(key)

        # 初始化K0-K3
        k = [0] * 36
        for i in range(4):
            k[i] = key_words[i] ^ self.FK[i]

        # 生成轮密钥
        for i in range(32):
            k[i+4] = k[i] ^ self._t_prime_transform(k[i+1] ^ k[i+2] ^ k[i+3] ^ self.CK[i])

        # self.round_keys = k[4:36]
        self.round_keys = [71273853,2008715155,2023534942,4068148403,4271297986,3985097575,4249877446,3650934003,86888268,2377299641,676152382,1328846744,2377008672,2003526700,1276278588,3251650253,2050718423,855985561,3406453630,891402436,1088422844,2555710248,2204722429,285861725,1858091327,1152810995,4045056524,144737900,1864177124,3172438407,2988070373,1574635448]


    def _encrypt_block(self, plaintext):
        """加密单个块"""
        if len(plaintext) != 16:
            raise ValueError("明文块长度必须为16字节")

        x = self._bytes_to_words(plaintext)

        # 32轮迭代
        for i in range(32):
            x[0], x[1], x[2], x[3] = x[1], x[2], x[3], self._f_function(x[0], x[1], x[2], x[3], self.round_keys[i])

        # 反序变换
        return self._words_to_bytes([x[3], x[2], x[1], x[0]])

    def _decrypt_block(self, ciphertext):
        """解密单个块"""
        if len(ciphertext) != 16:
            raise ValueError("密文块长度必须为16字节")

        x = self._bytes_to_words(ciphertext)

        # 32轮迭代（逆序使用轮密钥）
        for i in range(32):
            x[0], x[1], x[2], x[3] = x[1], x[2], x[3], self._f_function(x[0], x[1], x[2], x[3], self.round_keys[31-i])

        # 反序变换
        return self._words_to_bytes([x[3], x[2], x[1], x[0]])

    def _pkcs7_pad(self, data):
        """PKCS7填充"""
        pad_len = 16 - (len(data) % 16)
        return data + bytes(b'\x00' * pad_len)

    def _pkcs7_unpad(self, data):
        """PKCS7去填充"""
        if not data:
            return data
        pad_len = data[-1]
        if pad_len > 16 or pad_len == 0:
            raise ValueError("无效的填充")
        for i in range(pad_len):
            if data[-(i+1)] != pad_len:
                raise ValueError("无效的填充")
        return data[:-pad_len]

    def encrypt(self, plaintext, key):
        """加密（ECB模式）"""
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        if isinstance(key, str):
            key = key.encode('utf-8')

        self._key_expansion(key)
        plaintext = self._pkcs7_pad(plaintext)

        ciphertext = b''
        for i in range(0, len(plaintext), 16):
            block = plaintext[i:i+16]
            ciphertext += self._encrypt_block(block)

        return ciphertext

    def decrypt(self, ciphertext, key):
        """解密（ECB模式）"""
        if isinstance(key, str):
            key = key.encode('utf-8')

        if len(ciphertext) % 16 != 0:
            raise ValueError("密文长度必须是16的倍数")

        self._key_expansion(key)

        plaintext = b''
        for i in range(0, len(ciphertext), 16):
            block = ciphertext[i:i+16]
            plaintext += self._decrypt_block(block)

        return self._pkcs7_unpad(plaintext)

    def encrypt_hex(self, plaintext, key):
        """加密并返回十六进制字符串"""
        return self.encrypt(plaintext, key).hex()

    def decrypt_hex(self, ciphertext_hex, key):
        """从十六进制字符串解密"""
        ciphertext = bytes.fromhex(ciphertext_hex)
        return self.decrypt(ciphertext, key)





if __name__ == "__main__":
    """测试函数"""
    sm4 = SM4()

    # 测试数据
    key = "4zwN0HHdXkxooXKy"  # 16字节密钥
    plaintext = b"0|215174930471"

    print("=== SM4算法测试 ===")
    print(f"密钥: {key}")
    print(f"明文: {plaintext}")

    # 加密
    ciphertext = sm4.encrypt(plaintext, key)
    ciphertext_hex = ciphertext.hex().upper()
    print(f"密文(十六进制): {ciphertext_hex}")
