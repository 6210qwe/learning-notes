const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");






const resolveSequence =
{
    SequenceExpression:
    {
        /**  @param  {NodePath} path */
        exit(path) {
            let statementPath = path.getStatementParent();
            if (!statementPath) return;

            let paths = [];
            statementPath.traverse({
                "LogicalExpression|ConditionalExpression"(_path) {
                    paths.push(_path);//收集所有不确定会不会执行的表达式
                },
            })

            let canVisitFlag = true;

            for (let _path of paths) {
                if (_path.isAncestor(path)) {
                    canVisitFlag = false;//过滤不能还原的情况
                    break;
                }
            }

            if(paths.length == 1 && canVisitFlag == false)
            {
                let AncestorPath = paths[0];

                let key = AncestorPath.isLogicalExpression() ? "left":"test";

                let ablePath = AncestorPath.get(key);

                if (ablePath == path || ablePath.isAncestor(path))
                {
                    canVisitFlag = true;
                }

            }

            if (canVisitFlag) {

               if (statementPath.isLoop()) {//循环表达式内的test节点，不能随意插在该表达式前面

                    let initPath = statementPath.get('init');

                    if (initPath.node == undefined || (initPath != path && !initPath.isAncestor(path))) {
                        return
                    }
                }

                let expressions = path.node.expressions;
                let lastNode = expressions.pop();

                for (let expression of expressions) {
                    statementPath.insertBefore(types.ExpressionStatement(expression = expression));
                }

                path.replaceWith(lastNode);

            }
        }
    }
}

traverse(ast, resolveSequence);




function getRandomName(length) {

	let initArr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
	let puzzleArr = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
	let ranInx = Math.floor(Math.random() * initArr.length);
	let randomName = initArr[ranInx];

	for (var i = 1; i < length; i++) {
		ranInx = Math.floor(Math.random() * puzzleArr.length);
		randomName += puzzleArr[ranInx];
	}

	return randomName;
}


let allNewNames = new Map();  //定义一个全局变量，保存需要处理的函数

function getUnusedIdentifier() {//获取未被使用的名称,返回 Identifier 类型。
	do {
		var newName = "clb_" + getRandomName(3);

	} while (allNewNames.has(newName))

	allNewNames.set(newName, 1);

	let UnusedIdentifier = types.Identifier(newName);

	return UnusedIdentifier;
}


let DEFINENODE = template(`var A;`);
let ASSIGN_NODE = template(`A = B;`);

function isNeedSimple(path) {
	let NeedSimple = false;

	if (path.isConditionalExpression()) {
		NeedSimple = true;
	}


	path.traverse({
		"SequenceExpression|ConditionalExpression"(_path) {
			NeedSimple = true;
			_path.stop();
		},
	})

	return NeedSimple;
}

const simplifyExpression =
{
	'IfStatement|ReturnStatement'(path) {
		let key = path.isIfStatement()?"test":"argument";

		let pendingPath = path.get(key);

		if (!isNeedSimple(pendingPath)) {
			return;
		}

		let UnusedIdentifier = getUnusedIdentifier();

		let newDefineNode = DEFINENODE({ "A": UnusedIdentifier, });
		path.insertBefore(newDefineNode);

		let newAssinNOde = ASSIGN_NODE({ "A": UnusedIdentifier, "B": pendingPath.node });
		path.insertBefore(newAssinNOde);

		pendingPath.replaceWith(UnusedIdentifier);
	},
	ForStatement(path) {
		let initPath = path.get('init');
		if (!isNeedSimple(initPath)) {
			return;
		}
		path.insertBefore(initPath.node);

		path.node.init = null;
	},

}

traverse(ast, simplifyExpression);





console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
});

files.writeFile(decodeFile, code, (err) => { });