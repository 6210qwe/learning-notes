﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";  //默认的js文件
const decodeFile = "./step1.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");


const window = globalThis;


const callToConditionalExpression =
{
	CallExpression: {
		exit(path) {
			let { callee, arguments } = path.node;
			if (arguments.length != 1 || !types.isConditionalExpression(arguments[0])) {
				return;
			}

			let { test, consequent, alternate } = arguments[0];

			let consequentCallNode = types.CallExpression(callee, [consequent]);
			let alternateCallNode = types.CallExpression(callee, [alternate]);

			let ConditionalNode = types.ConditionalExpression(test, consequentCallNode, alternateCallNode);

			path.replaceWith(ConditionalNode);
		}

	},
}

traverse(ast, callToConditionalExpression);



function calcCallExpression(name, path) {

	let { scope, node } = path;

	let binding = undefined;
	if (path.isVariableDeclarator()) {
		binding = scope.getBinding(node.id.name);
		if (!binding || binding.constantViolations.length > 1) {

			return;
		}

		if (binding.constantViolations.length == 1 && binding.constantViolations[0] != path) {

			return;
		}
	}
	else if (path.isAssignmentExpression() && path.get('left').isIdentifier()) {
		binding = scope.getBinding(node.left.name);
		if (!binding || binding.constantViolations.length != 1) {

			return;
		}
	}

	if (!binding) return;

	for (let referPath of binding.referencePaths) {

		let { parentPath, node } = referPath;

		if (parentPath.isVariableDeclarator({ "init": node }) || parentPath.isAssignmentExpression({ "right": node })) {
			calcCallExpression(name, parentPath);
		}

		if (!parentPath.isCallExpression({ "callee": node })) {

			continue;
		}

		let { arguments } = parentPath.node;

		if (arguments.length != 1 || !types.isStringLiteral(arguments[0])) {

			continue;
		}
		let value = globalThis[name](arguments[0].value);
		console.log(parentPath.toString(), "--->", value);
		parentPath.replaceWith(types.valueToNode(value));
	}

}


const getAtobSourceCode =
{
	FunctionDeclaration(path) {
		let name = path.node.id.name;
		let sourceCode = path.toString();
		if (!sourceCode.includes("fromCharCode") || !sourceCode.includes("charCodeAt")) {
			return;
		}

		let allPrevSiblings = path.getAllPrevSiblings();
		if (allPrevSiblings.length < 1) {
		//	return;
		}

		if (!allPrevSiblings[0].isVariableDeclaration()) {
		//	return;
		}




		for (let prevSibling of allPrevSiblings.reverse())  //这里的reverse确保代码的执行流程一致。
		{
			sourceCode = prevSibling.toString() + sourceCode;
		}

		eval(sourceCode);

		globalThis[name] = eval(name);



		if (true) {//使用块级作用域分离代码


			let scope = path.parentPath.scope;
			let binding = scope.getBinding(name);

			for (let referPath of binding.referencePaths) {

				let { parentPath, node } = referPath;

				if (parentPath.isVariableDeclarator({ "init": node }) || parentPath.isAssignmentExpression({ "right": node })) {
					calcCallExpression(name, parentPath);
				}

				if (!parentPath.isCallExpression({ "callee": node })) {

					continue;
				}

				let { arguments } = parentPath.node;

				if (arguments.length != 1 || !types.isStringLiteral(arguments[0])) {

					continue;
				}
				let value = globalThis[name](arguments[0].value);
				console.log(parentPath.toString(), "--->", value);
				parentPath.replaceWith(types.valueToNode(value));
			}

		}

		path.stop(); //遍历一次就停止，防止遍历到错误的函数

	},

}


traverse(ast, getAtobSourceCode);



function isExpressionConstant(PathOrNode)
{

    let node = PathOrNode.node || PathOrNode;

    let BrowList = ['window', 'document', 'navigator', 'location', 'history', 'screen',];

    if (types.isLiteral(node) && node.value != null)
    {
        return true;
    }

    if (types.isIdentifier(node) && BrowList.includes(node.name))
    {
        return true;
    }

    if (types.isIdentifier(node) && typeof globalThis[node.name] != "undefined") {
        return true;
    }

    if (types.isMemberExpression(node))
    {
        let {object,property} = node;

        if (types.isIdentifier(object) && typeof globalThis[object.name] != "undefined")
        {
            let properName = types.isIdentifier(property) ? property.name : property.value;
            if (typeof globalThis[object.name][properName] != "undefined") {
                return true;
            }
        }

        if (types.isMemberExpression(object))
        {
            return isExpressionConstant(object);
        }

    }

    if (types.isUnaryExpression(node) && ["+", "-", "!","typeof","~"].includes(node.operator)) {
        return isExpressionConstant(node.argument);
    }

    return false;
}

const restoreVarDeclarator =
{
    VariableDeclarator(path) {
        let scope = path.scope;
        let { id, init } = path.node;

        if (!types.isIdentifier(id) || init == null || !isExpressionConstant(init)) {
            return;
        }

        const binding = scope.getBinding(id.name);

        if (!binding) return;

        let { constant, referencePaths, constantViolations } = binding;  

        if (constantViolations.length > 1) {
            return;
        }

        if (constant || constantViolations[0] == path) {
            for (let referPath of referencePaths) {
                referPath.replaceWith(init);
            }
        }
    },
}

traverse(ast, restoreVarDeclarator);


const restoreAssignConstant = 
{//常量还原插件
    AssignmentExpression(path)
    {
        let {scope,node,parentPath} = path;

        let {left,operator,right} = node;

        if (!types.isIdentifier(left) || operator != "=" || !isExpressionConstant(right))
        {
            return;
        }

        let binding = scope.getBinding(left.name);

        if (!binding || binding.constantViolations.length > 1)
        {//如果没有binding,或者赋值语句本身改变了它，因此这里判断只有一处改变。
            return;
        }

        let {start} = binding.constantViolations[0].node;

        let referStart = start;

        for (let referPath of binding.referencePaths)
        {
            if (referPath.node.start < referStart)
            {
                referStart = referPath.node.start;
            }
        }

        if (start > referStart)
        {//防止在更改前被引用
            return;
        }

        for (let referPath of binding.referencePaths)
        {
            referPath.replaceWith(right);
        }

        if(parentPath.isExpressionStatement() || parentPath.isSequenceExpression())
        {
            path.remove();
        }
    },

}

traverse(ast, restoreAssignConstant);

ast = parser.parse(generator(ast).code);  //去除多余的 ()，可以将其屏蔽，看看效果。



function containsSequenceExpression(path) {
    let containsSequence = false;
    // 深度优先遍历当前路径及其所有子路径
    path.traverse({
        SequenceExpression(_path) {
            containsSequence = true;
            _path.stop(); // 找到逗号表达式后立即停止遍历
        }
    });
    return containsSequence;
}

//请使用学员专版babel库
const constantFold = {
    "BinaryExpression|UnaryExpression|MemberExpression|CallExpression"(path) {
        if (containsSequenceExpression(path)) {
            return;
        }
        if (path.isUnaryExpression({ operator: "-" }) ||
            path.isUnaryExpression({ operator: "void" })) {
            return;
        }
        const { confident, value } = path.evaluate();

        if (!confident || typeof value == "function")
            return;

        if (typeof value == 'number' && (!Number.isFinite(value))) {
            return;
        }

        console.log(path.toString(),"--->",value);

        path.replaceWith(types.valueToNode(value));
    },
}

traverse(ast, constantFold);


traverse(ast, getAtobSourceCode);


console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

fs.writeFile(decodeFile, code, (err) => { });