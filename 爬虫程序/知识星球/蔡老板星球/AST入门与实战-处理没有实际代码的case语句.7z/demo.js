var jp = function (a, v, T, V, I, N, f, u, M, e, w, Q) {
  for (w = 36; w != 8;) {
    switch (w) {
      case 2:
        w = 85;
        break;
      case 47:
        return Q;
        break;
      case 36:
        w = 81;
        break;
      case 72:
        jp(" ", 3, true, null, I[e], N, f, u, M);
        w = 68;
        break;
      case 17:
        if (T.classList) {
          Array.prototype.forEach.call(V, function (W) {
            sU(34, 8, "string", "class", a, 0, W, T);
          });
        } else {
          P(82, "class", Array.prototype.filter.call(N5(64, "string", T), function (W) {
            return !(VG(25, 0, W, V) >= 0);
          }).join(a), T);
        }
        w = 38;
        break;
      case 81:
        w = (v & 42) == v ? 2 : 6;
        break;
      case 66:
        w = Array.isArray(I) ? 36 : 40;
        break;
      case 24:
        e = 0;
        w = 2;
        break;
      case 6:
        w = (v + 5 ^ 30) < v && (v - 9 | 55) >= v ? 17 : 38;
        break;
      case 38:
        w = (v - 8 ^ 27) < v && (v - 1 | 8) >= v ? 66 : 47;
        break;
      case 89:
        Q = T && T.parentNode ? T.parentNode.removeChild(T) : null;
        w = 6;
        break;
      case 68:
        e++;
        w = 85;
        break;
      case 40:
        u = ug(52, u);
        if (f && f[Yt]) {
          f.V.add(String(I), u, T, H(32, V, N) ? !!N.capture : !!N, M);
        } else {
          ug(10, null, false, f, M, T, N, I, u);
        }
        w = 47;
        break;
      case 85:
        w = e < I.length ? 72 : 47;
        break;
    }
  }
};