﻿const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const { switchStatement, assignmentExpression, ifStatement } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");



const simplifyAssign =
{
	SwitchStatement(path) {
		let { discriminant, cases } = path.node;
		if (!types.isIdentifier(discriminant)) {
			return;
		}

		let name = discriminant.name;

		let casesPath = path.get('cases');

		for (let eachCase of casesPath) {
			let { test } = eachCase.node;
			if (!types.isNumericLiteral(test)) {
				continue;
			}
			let value = test.value;
			eachCase.traverse({
				AssignmentExpression(_path) {
					let { left, operator, right } = _path.node;

					if (!types.isIdentifier(left, { "name": name }) || !types.isNumericLiteral(right)) {
						return;
					}

					if (operator == "-=") {
						_path.node.right.value = value - right.value;
					}
					else if (operator == "+=") {
						_path.node.right.value = value + right.value;
					}
					else {
						return;
					}

					_path.node.operator = "=";
				}
			})
		}


	}
}

traverse(ast, simplifyAssign);


const changeIfToConditional =
{
	IfStatement(path) {
		let { test, consequent, alternate } = path.node;

		if (!types.isBlockStatement(consequent) || !types.isBlockStatement(alternate)) {
			return;
		}

		if (consequent.body.length != 1 || alternate.body.length != 1) {
			return;
		}

		let conseNode = consequent.body[0];
		let alterNode = alternate.body[0];

		if (!types.isExpressionStatement(conseNode) || !types.isAssignmentExpression(conseNode.expression)) {
			return;
		}
		if (!types.isExpressionStatement(alterNode) || !types.isAssignmentExpression(alterNode.expression)) {
			return;
		}

		let conseLeft = conseNode.expression.left;
		let conseOp   = conseNode.expression.operator;
		let conseRight   = conseNode.expression.right;

		if (!types.isIdentifier(conseLeft) || conseOp != "=" || !types.isNumericLiteral(conseRight) ||
		    conseLeft.name != alterNode.expression.left.name)
		{
			return;
		}

		let ConditionalNode = types.ConditionalExpression(test,conseRight,alterNode.expression.right);

		let assignNode = types.AssignmentExpression("=",conseLeft,ConditionalNode);

		path.replaceWith(types.ExpressionStatement(assignNode));
	}
}


traverse(ast, changeIfToConditional);


console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });

files.writeFile(decodeFile, code, (err) => { });