r = 0 >  !Number ? 6 : 13;
"undefined" != typeof window;
"undefined" != typeof global;
"undefined" != typeof globalThis;
"undefined" != typeof Math;
var B4 = window["JSON"]["stringify"];
var Fq = window["screen"]["width"];