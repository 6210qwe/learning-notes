﻿const files     = require('fs');  //导入文件库，防止与fs变量名冲突
const types     = require("@babel/types");
const parser    = require("@babel/parser");
const template  = require("@babel/template").default;
const traverse  = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath  = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.replace(".js","") + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode,{"sourceType":"module"});     //支持es6语法
console.time("处理完毕，耗时");



const keyToIdentifier = {
	MemberExpression:
	{
		exit({ node }) {
			const prop = node.property;
			if (node.computed && types.isStringLiteral(prop)) {
				node.property = types.Identifier(prop.value);
				node.computed = false;
				return;
			}
			if (node.computed && types.isArrayExpression(prop) && prop.elements.length == 1) {//0327直播新增
				if (types.isStringLiteral(prop.elements[0])) {
					node.property = types.Identifier(prop.elements[0].value);
					node.computed = false;
				}
			}
		}
	},
	ObjectProperty:
	{
		exit({ node }) {
			const key = node.key;
			if (!node.computed && types.isIdentifier(key)) {
				node.key = types.StringLiteral(key.name);
				return;
			}
			if (node.computed && types.isStringLiteral(key)) {
				//处理 var a = {["b"]:c};  这种情况
				node.computed = false;
			}
		}
	},
}

traverse(ast, keyToIdentifier);






function getRandomName(length) {

	let initArr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
	let puzzleArr = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
	let ranInx = Math.floor(Math.random() * initArr.length);
	let randomName = initArr[ranInx];

	for (var i = 1; i < length; i++) {
		ranInx = Math.floor(Math.random() * puzzleArr.length);
		randomName += puzzleArr[ranInx];
	}

	return randomName;
}


let allNewNames = new Map();  //定义一个全局变量，保存需要处理的函数

function getUnusedIdentifier() {//获取未被使用的名称,返回 Identifier 类型。
	do {
		var newName = getRandomName(2);
		if (allNewNames.size > 300) {
			newName = getRandomName(3);
		}
	} while (allNewNames.has(newName))

	allNewNames.set(newName, 1);

	let UnusedIdentifier = types.Identifier(newName);

	return UnusedIdentifier;
}

let spIdentifiers = new Map();


const getAllspIdentifiers =
{//h获取所有需要处理的变量名。
	"Identifier"({ node }) {
		let name = node.name;
		for (var index = 0; index < name.length; index++) {
			if (name.charCodeAt(index) > 127) {
				break;
			}
		}
		if (index < name.length && !spIdentifiers.has(node.name)) {
			spIdentifiers.set(node.name, false);
		}
	},
}



traverse(ast, getAllspIdentifiers);




if (spIdentifiers.size > 0) {
	let vCount = 0;
	let fCount = 0;
	let pCount = 0;
	let kCount = 0;
	const renameSpIdentifier =
	{
		VariableDeclarator(path) {
			let { scope, node } = path;
			let { id } = node;

			if (types.isIdentifier(id) && spIdentifiers.has(id.name)) {
				let newIdname = "v" + vCount;
				scope.rename(id.name, newIdname);
				vCount++;
			}
		},
		FunctionDeclaration(path) {
			let { scope } = path.parentPath;
			let { id, params } = path.node;
			if (types.isIdentifier(id) && spIdentifiers.has(id.name)) {
				let newIdname = "f" + fCount;
				scope.rename(id.name, newIdname);
				fCount++;
			}
			for (let i=0;i<params.length ;i++)
			{
				let tmpNode = params[i];
				if (types.isIdentifier(tmpNode)&& spIdentifiers.has(tmpNode.name))
				{
					let newIdname = "p" + pCount;

					const binding = path.scope.getBinding(tmpNode.name);
					binding.referencePaths.forEach(refPath => {
						refPath.node.name = newIdname;
					});
					binding.constantViolations.forEach(refPath => {
						refPath.traverse({
							Identifier(_path)
							{
								if (_path.node.name == tmpNode.name)
								{
									_path.node.name = newIdname;
								}
							}
						})
					});

					path.node.params[i].name = newIdname;
					pCount++;
				}
				
			}
		},
		FunctionExpression(path)
		{
			let {scope,node} = path;
			let {params } = path.node;
			for (let i=0;i<params.length ;i++)
			{
				let tmpNode = params[i];
				if (types.isIdentifier(tmpNode) && spIdentifiers.has(tmpNode.name))
				{
					let newIdname = "p" + pCount;

					const binding = path.scope.getBinding(tmpNode.name);
					binding.referencePaths.forEach(refPath => {
						refPath.node.name = newIdname;
					});
					binding.constantViolations.forEach(refPath => {
						refPath.traverse({
							Identifier(_path)
							{
								if (_path.node.name == tmpNode.name)
								{
									_path.node.name = newIdname;
								}
							}
						})
					});

					path.node.params[i].name = newIdname;
					pCount++;
				}
				
			}

		},
		ObjectProperty(path)
		{
			let {scope,node} = path;
			let {key} = node;
			if (types.isStringLiteral(key) && spIdentifiers.has(key.value))
			{
				let newIdname = "k" + kCount;
				scope.traverse(scope.block,{
					MemberExpression(_path)
					{
						let {object,property} = _path.node;
						if(types.isIdentifier(property,{"name":key.value}))
						{
							_path.node.property.name = newIdname;
						}
					}
				})

				path.node.key.value = newIdname;
				kCount++;
			}

		}


	}

	traverse(ast, renameSpIdentifier);
}



allNewNames.clear();
spIdentifiers.clear();



console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });