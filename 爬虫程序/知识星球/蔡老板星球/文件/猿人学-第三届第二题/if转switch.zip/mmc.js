
function oM(jC, pD) {
    var bG = 27;
    for (; ; ) {
        if (bG < 16) {
            if (bG < 8) {
                if (bG < 4) {
                    if (bG < 2) {
                        if (bG < 1) {
                            oM[vD] = 255 - vD;
                            bG += 14;
                        } else {
                            gL = 0;
                            bG += 21;
                        }
                    } else {
                        if (bG < 3) {
                            if (nQ < pD["length"]) {
                                bG += 9;
                            } else {
                                bG += 21;
                            }
                        } else {
                            bG += 23;
                        }
                    }
                } else {
                    if (bG < 6) {
                        if (bG < 5) {
                            bG += 9;
                        } else {
                            [oM[gL],oM[eJ]] = [oM[eJ], oM[gL]];
                            bG -= 1;
                        }
                    } else {
                        if (bG < 7) {
                            tJ = 0;
                            bG += 24;
                        } else {
                            eJ = eJ + oM[tJ] & 255;
                            bG += 1;
                        }
                    }
                }
            } else {
                if (bG < 12) {
                    if (bG < 10) {
                        if (bG < 9) {
                            [oM[tJ],oM[eJ]] = [oM[eJ], oM[tJ]];
                            bG += 23;
                        } else {
                            eJ = eJ + oM[gL] + mB[gL] & 255;
                            bG -= 4;
                        }
                    } else {
                        if (bG < 11) {
                            vD = 0;
                            bG += 11;
                        } else {
                            tJ = tJ + 1 & 255;
                            bG -= 4;
                        }
                    }
                } else {
                    if (bG < 14) {
                        if (bG < 13) {
                            mB = new Uint8Array(256);
                            bG -= 2;
                        } else {
                            gL++;
                            bG += 9;
                        }
                    } else {
                        if (bG < 15) {
                            mB[vD] = jC[vD % jC["length"]];
                            bG += 6;
                        } else {
                            return gB;
                        }
                    }
                }
            }
        } else {
            if (bG < 24) {
                if (bG < 20) {
                    if (bG < 18) {
                        if (bG < 17) {
                            gB = new Uint8Array(pD["length"]);
                            bG -= 10;
                        } else {
                            nQ++;
                            bG -= 15;
                        }
                    } else {
                        if (bG < 19) {
                            vD++;
                            bG += 3;
                        } else {
                            nQ = 0;
                            bG -= 17;
                        }
                    }
                } else {
                    if (bG < 22) {
                        if (bG < 21) {
                            bG -= 2;
                        } else {
                            if (vD < 256) {
                                bG -= 21;
                            } else {
                                bG -= 18;
                            }
                        }
                    } else {
                        if (bG < 23) {
                            if (gL < 256) {
                                bG -= 13;
                            } else {
                                bG += 3;
                            }
                        } else {
                            bG -= 8;
                        }
                    }
                }
            } else {
                if (bG < 28) {
                    if (bG < 26) {
                        if (bG < 25) {
                            oM = new Uint8Array(256);
                            bG -= 12;
                        } else {
                            bG -= 9;
                        }
                    } else {
                        if (bG < 27) {
                            eJ = 0;
                            bG -= 25;
                        } else {
                            var oM;
                            var mB;
                            var vD;
                            var eJ;
                            var gL;
                            var gB;
                            var tJ;
                            var nQ;
                            var uC;
                            bG -= 3;
                        }
                    }
                } else {
                    if (bG < 30) {
                        if (bG < 29) {
                            gB[nQ] = pD[nQ] ^ uC;
                            bG += 1;
                        } else {
                            bG -= 12;
                        }
                    } else {
                        if (bG < 31) {
                            eJ = 0;
                            bG -= 11;
                        } else {
                            uC = oM[oM[tJ] + oM[eJ] & 255];
                            bG -= 3;
                        }
                    }
                }
            }
        }
    }
}
var pD = Array["apply"](null, Array(16))["map"](function() {
    return "0123456789abcdef0123456789abcdef0123456789abcdef6789abcdef789abcdef6789abcdef"["charAt"](Math["floor"](Math["random"]() * 62));
})["join"]("");

var lK  = new TextEncoder()["encode"](pD);
var uO = oM(lK, new TextEncoder()["encode"](navigator["userAgent"] + Date["now"]()))
var mmc = Array["from"](uO)["map"](function(mU) {

        return mU["toString"](16)["padStart"](2, "0");

})["join"]("") + pD;

console.log(mmc);