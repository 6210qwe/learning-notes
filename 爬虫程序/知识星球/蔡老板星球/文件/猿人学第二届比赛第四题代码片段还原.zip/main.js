﻿const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const { switchStatement, assignmentExpression, ifStatement } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");


const combinNextCase = 
{
	SwitchCase(path)
	{
		let {consequent} = path.node;
		
		let lastNode = consequent.at(-1);

		if (!types.isBreakStatement(lastNode) && !types.isReturnStatement(lastNode))
		{
			let nextSibling = path.getNextSibling();
			if (nextSibling.isSwitchCase())
			{
				path.node.consequent.push(...nextSibling.node.consequent);
			}
		}

	}
}

traverse(ast,combinNextCase);


const removeDeadCodeOfEndNode = {

	"ContinueStatement|BreakStatement|ReturnStatement|ThrowStatement"(path) {
		let AllNextSiblings = path.getAllNextSiblings();  //获取所有的后续兄弟节点

		for (let nextSibling of AllNextSiblings) {

			if (nextSibling.isFunctionDeclaration() || nextSibling.isVariableDeclaration({ kind: "var" })) {//变量提升.....
				continue;
			}

			if (nextSibling.isBreakStatement()) {
				continue;
			}
			nextSibling.remove();
		}

	},
}

traverse(ast, removeDeadCodeOfEndNode);





const simplifyAssign =
{
	SwitchStatement(path) {
		let { discriminant, cases } = path.node;
		if (!types.isIdentifier(discriminant)) {
			return;
		}

		let name = discriminant.name;

		let casesPath = path.get('cases');

		for (let eachCase of casesPath) {
			let { test } = eachCase.node;
			if (!types.isNumericLiteral(test)) {
				continue;
			}
			let value = test.value;
			eachCase.traverse({
				AssignmentExpression(_path) {
					let { left, operator, right } = _path.node;

					if (!types.isIdentifier(left, { "name": name }) || !types.isNumericLiteral(right)) {
						return;
					}

					if (operator == "-=") {
						_path.node.right.value = value - right.value;
					}
					else if (operator == "+=") {
						_path.node.right.value = value + right.value;
					}
					else {
						return;
					}

					_path.node.operator = "=";
				}
			})
		}


	}
}

traverse(ast, simplifyAssign);

const dealWithSwitch =
{
	WhileStatement(path) {
		let { scope, node } = path;
		let body = node.body.body;
		if (body.length != 1 ||
			!types.isSwitchStatement(body[0])) {
			return;
		}
		let { discriminant, cases } = body[0];

		let name = discriminant.name;

		let prevSibling = path.getPrevSibling();

		if (!prevSibling || !prevSibling.isExpressionStatement()) {
			return;
		}

		let { expression } = prevSibling.node;

		if (!types.isAssignmentExpression(expression)) {
			return;
		}

		let { left, operator, right } = expression;

		if (!types.isIdentifier(left, { "name": name }) || operator != "=" || !types.isNumericLiteral(right)) {
			return;
		}

		let initValue = right.value;

		let codeBody = [];
		let breakFlag =false;
		while (true) {

			for (let eachCase of cases) {
				let { test, consequent } = eachCase;

				if (test.value != initValue) {
					continue;
				}

				let length = consequent.length;

				let lastNode = consequent.at(-2);

				if (types.isReturnStatement(lastNode)) {
					codeBody = codeBody.concat(consequent.slice(0, length - 1));
					breakFlag = true;
					break;
				}
				else {
					codeBody = codeBody.concat(consequent.slice(0, length - 2));
					initValue = lastNode.expression.right.value;
					continue;

				}
			}

			if (breakFlag)
			{
				break;
			}
		}

		if (codeBody.length == 0) {
			return;
		}

		path.replaceWithMultiple(codeBody);
		prevSibling.remove();


	}
}


traverse(ast, dealWithSwitch);





console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });

files.writeFile(decodeFile, code, (err) => { });