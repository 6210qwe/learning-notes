(function (p, p2, p3, p4, p5, p6, p7) {
  f(40, p);
  function f(p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20) {
    function f2(p21) {
      var vP11 = p11;
      for (var vLN1 = 1; vLN1 < p21; ++vLN1) {
        vP11 = vP11.__proto__;
      }
      return vP11;
    }
    function f3() {
      if (p12) {
        return p12;
      }
      var vO = {};
      Object.defineProperties(vO, {
        Gj: {
          get: function () {
            return p14;
          },
          set: function (p22) {
            p14 = p22;
          }
        },
        is: {
          get: function () {
            return p15;
          },
          set: function (p23) {
            p15 = p23;
          }
        }
      });
      vO.__proto__ = p11;
      p12 = vO;
      return vO;
    }
    while (1) {
      switch (p8) {
        case 0:
          p8 = 32;
          break;
        case 1:
          p18 = p14 + p15;
          p8 = 23;
          break;
        case 2:
          p16 = p["add"]((p8 = 8) - 5, 4);
          break;
        case 3:
          p16 = p["console"][p8 = 39, "log"];
          break;
        case 4:
          p16 = p["add"]((p8 = 17) + 94, p["c"]);
          break;
        case 5:
          p18[(p8 = 26) - 25] = p["d"];
          break;
        case 6:
          p8 = 18;
          p["d"] = p7;
          break;
        case 7:
          p8 = 41;
          p["j"] = p7;
          break;
        case 8:
          p8 = 14;
          p["d"] = p16;
          break;
        case 9:
          p8 = 6;
          p["c"] = p7;
          break;
        case 10:
          p16 = p["add"]((p8 = 28) + 194, p["d"]);
          break;
        case 11:
          p8 = 43;
          p18 = p["add"](p["h"], p["g"]);
          break;
        case 12:
          p8 = 19;
          p20 = p["add"](p["i"], p["j"]);
          break;
        case 13:
          p8 = 2;
          p["c"] = p16;
          break;
        case 14:
          p16 = p["console"][p8 = 20, "log"];
          break;
        case 15:
          p8 = 35;
          p["h"] = p7;
          break;
        case 16:
          p18[(p8 = 33) - 33] = p["e"];
          break;
        case 17:
          p8 = 10;
          p["e"] = p16;
          break;
        case 18:
          p16 = p["add"]((p8 = 13) - 12, 2);
          break;
        case 19:
          p19 = p18 + p20;
          p8 = 29;
          break;
        case 20:
          p8 = 22;
          p18 = [];
          break;
        case 21:
          p8 = 7;
          p["i"] = p7;
          break;
        case 22:
          p18[(p8 = 5) - 5] = p["c"];
          break;
        case 23:
          return p18;
          break;
        case 24:
          p["j"] = (p8 = 42) + 846;
          break;
        case 25:
          p["g"] = (p8 = 31) + 635;
          break;
        case 26:
          p8 = 27;
          p17 = p5(p16, (p18.unshift(p["console"]), p18))();
          break;
        case 27:
          p8 += 7;
          p["e"] = p7;
          break;
        case 28:
          p8 = 3;
          p["f"] = p16;
          break;
        case 29:
          p8 = 38;
          p17 = p4(p16, p["console"])(p19);
          break;
        case 30:
          p["h"] = (p8 = 25) + 530;
          break;
        case 31:
          p16 = p["console"][p8 -= 20, "log"];
          break;
        case 32:
          p8 = 9;
          p["add"] = p16;
          break;
        case 33:
          p18[(p8 = 36) - 35] = p["f"];
          break;
        case 34:
          p8 = 4;
          p["f"] = p7;
          break;
        case 35:
          p8 = 30;
          p["g"] = p7;
          break;
        case 36:
          p8 = 15;
          p17 = p5(p16, (p18.unshift(p["console"]), p18))();
          break;
        case 37:
          p8 = 12;
          p18 = p["add"](p["h"], p["g"]);
          break;
        case 38:
          return;
          break;
        case 39:
          p8 = 16;
          p18 = [];
          break;
        case 40:
          p8 = 0;
          p16 = function () {
            return p5(f, [p6, 1, this, arguments, f3(), p7, p7].concat(p4([].slice, arguments)()))();
          };
          break;
        case 41:
          p["i"] = (p8 = 24) + 642;
          break;
        case 42:
          p16 = p["console"][p8 = 37, "log"];
          break;
        case 43:
          p8 = 21;
          p17 = p4(p16, p["console"])(p18);
          break;
      }
    }
  }
})(globalThis, true, false, Object.call.bind(Array.bind), Array.apply.bind(Number.bind), null);