from com.pnfsoftware.jeb.client.api import IScript
from com.pnfsoftware.jeb.core.units.code import ICodeUnit
from com.pnfsoftware.jeb.core.units.code.java import IJavaSourceUnit, IJavaConstant, IJavaCall, IJavaClass, IJavaMethod

class DecryptStrings(IScript):
    def run(self, ctx):
        prj = ctx.getMainProject()
        assert prj, 'Need a project'
        print('Decompiling code units of %s...' % prj)

        # first code unit
        self.codeUnit = prj.findUnit(ICodeUnit)
        print('Code unit: %s' % self.codeUnit)

        # self.targetClass = 'CYFManager'
        self.targetClass = 'Lcom/cyberfend/cyfsecurity/CYFManager;'
        # self.decryptMethod = 'ddr'
        self.decryptMethod = 'tOh'

        # enumerate the decompiled classes, find and process the target class
        for unit in prj.findUnits(IJavaSourceUnit):
            javaClass = unit.getClassElement() #  获取 Java 类的 AST 根节点
            print(javaClass.getName())
            if javaClass.getName() == self.targetClass:
                self.cstbuilder = unit.getFactories().getConstantFactory() # 获取 AST 工厂，用于创建常量字符串（替换解密后的字符串）
                if self.processClass(javaClass):
                    unit.notifyGenericChange()
                break

    def processClass(self,javaClass):
        for javaMethod in javaClass.getMethods():
            print('Decrypting strings in method: %s' % javaMethod.getName())
            self.decryptMethodStrings(javaMethod) # 遍历引用ddr的函数
        return True

    def decryptMethodStrings(self,javaMethod):
        # 获取方法的代码块（AST 结构）
        block = javaMethod.getBody()
        i = 0
        while i < block.size():
            # 获取当前 AST 语句
            stm = block.get(i)
            self.checkElement(block, stm)
            i += 1

    def checkElement(self, parent, e):
        # 判断是否是方法调用
        if isinstance(e,IJavaCall):
            mname = e.getMethod().getName()
            if mname == self.decryptMethod:
                args = e.getArguments()
                if len(args) == 1 and isinstance(args[0], IJavaConstant): # 确保参数是单个字符串常量
                    encrypted_string = args[0].getString()
                    decrypted_string = self.realDecrypt(encrypted_string)
                    parent.replaceSubElement(e,self.cstbuilder.createString(decrypted_string))
                    print('Decrypted string: %s' % repr(decrypted_string))

        # 递归检查 所有子元素，确保找到嵌套的 ddr 调用。
        for subelt in e.getSubElements():
            if isinstance(subelt, IJavaClass) or isinstance(subelt, IJavaMethod):
                continue
            self.checkElement(e, subelt)


    ### 以下解密方式用于AkamaiBMP 4.0.0 / 4.1.0
    def initializeZW(self):
        self.ZW = [0] * 0x7FFF
        v1 = 3
        for v2 in range(0x7FFF):
            # v1 = (v1 + (v1 ^ v2) + 84) % 0x3F
            v1 = (v1 + (v1 ^ v2) + 90) % 0x3F
            self.ZW[v2] = v1

    def realDecrypt(self,encrypted_str):
        if not hasattr(self, 'ZW'):
            self.initializeZW()
        arr_c = []
        arr_c1 = list(encrypted_str)
        for v in range(len(arr_c1)):
            arr_c.append(chr(ord(arr_c1[v]) ^ self.ZW[v]))
        return ''.join(arr_c)