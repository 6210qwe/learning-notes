const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const t = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");


// 检查路径或其任一子路径是否包含逗号表达式
function containsSequenceExpression(path) {
    let containsSequence = false;
    // 深度优先遍历当前路径及其所有子路径
    path.traverse({
        SequenceExpression(_path) {
            containsSequence = true;
            _path.stop(); // 找到逗号表达式后立即停止遍历
        }
    });
    return containsSequence;
}

//请使用学员专版babel库
const constantFold = {
    "BinaryExpression|UnaryExpression|MemberExpression|CallExpression"(path) {
        if (containsSequenceExpression(path)) {
            return;
        }
        if (path.isUnaryExpression({ operator: "-" }) ||
            path.isUnaryExpression({ operator: "void" })) {
            return;
        }
        const { confident, value } = path.evaluate();

        if (!confident || typeof value == "function")
            return;

        if (typeof value == 'number' && (!Number.isFinite(value))) {
            return;
        }

        console.log(path.toString(),"--->",value);

        path.replaceWith(types.valueToNode(value));
    },
}

traverse(ast, constantFold);


let ifNODETEP1 = template(`if(A){} else {B;}`);
let ifNODETEP2 = template(`if(A){B;}`);
const LogicalToIfStatement =
{
	ExpressionStatement(path) {
        const { expression } = path.node;
        if (!types.isLogicalExpression(expression)) {
			return;
        }

		let {left,operator,right} = expression;

		if (operator == "||")
		{
			let ifNode = ifNODETEP1({"A":left,"B":right});

			path.replaceWith(ifNode);

			return;
		}

		if (operator == "&&")
		{
			let ifNode = ifNODETEP2({"A":left,"B":right});

			path.replaceWith(ifNode);

			return;
		}
      },
};



const dealWithLogicalInIfStatement  = 
{
	IfStatement(path)
	{
		let {test,consequent,alternate} = path.node;

		if (!types.isLogicalExpression(test))
		{
			return;
		}

		let {left,operator,right} = test;

		if (operator == "&&" && consequent.body.length == 0)
		{
			path.node.test = left;
			path.node.consequent.body.push(types.ExpressionStatement(right));
			return;
		}
		if (operator == "&&" && consequent.body.length != 0)
		{
			path.node.test = left;
			path.node.consequent = types.BlockStatement([ifNODETEP2({"A":right,"B":consequent.body})]);
			
		}
		if (operator == "||")
		{
			path.node.test = left;
			path.node.consequent = consequent;
			if (alternate != null)
			{
				path.node.alternate = ifNODETEP1({"A":right,"B":alternate.body});
			}
			else
			{
				path.node.alternate = ifNODETEP1({"A":right,"B":null});
			}
			
			return;
		}

	}
}



for (let i=0; i<5; i++)
{

	traverse(ast,LogicalToIfStatement);
	ast = parser.parse(generator(ast).code);
	traverse(ast,dealWithLogicalInIfStatement);
}


const simplifyIfStatement = 
{
	IfStatement(path)
	{
		let {test,consequent,alternate} = path.node;

		if (!types.isIfStatement(alternate))
		{
			return;
		}

		let newTest =  alternate.test;
		let newConsequent = alternate.consequent;
		let newAlternate  = alternate.alternate;

		if (newConsequent.body.length == 0 && newAlternate.body.length == 0)
		{
			path.node.alternate = types.BlockStatement([types.ExpressionStatement(newTest)]);
		}
	}

}


traverse(ast,simplifyIfStatement);



const resolveSequence = 
{
	SequenceExpression(path)
	{
		let {scope,parentPath,node} = path;
		let expressions = node.expressions;
		if (parentPath.isExpressionStatement({"expression":node}))
		{
			let body = [];
			expressions.forEach(express=>{body.push(types.ExpressionStatement(express));});
            path.replaceWithMultiple(body);
		}
		else
		{
			return;
		}

		scope.crawl();
	}
}

traverse(ast, resolveSequence);


const removeDeadCode = 
{
	ExpressionStatement(path)
	{
		let expressPath = path.get("expression");

		if (expressPath.isLiteral() || expressPath.isIdentifier())
		{
			expressPath.remove();
		}
	}
}

traverse(ast, removeDeadCode);


console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });