﻿const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const { Console } = require('console');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");




function collectSwitchCase(ForStatement, name, referencePaths) {
	let ifNodes = new Object();

	ForStatement.traverse({
		"IfStatement"(path) {//遍历所有的ifStatement;
			let testPath = path.get('test');

			let traveFlag = false;
			for (let referPath of referencePaths) {
				if (testPath.isAncestor(referPath)) {
					traveFlag = true;
					break;
				}
			}

			if (!traveFlag) {
				return;
			}

			let { test, consequent, alternate } = path.node; //获取子节点

			let conseBody = consequent.body;
			let alterBody = alternate.body;

			let { left, operator, right } = test; // 必定是BinaryExpression

			
			let flag = false;
			if (types.isIdentifier(left, { "name": name }) && operator == "<" && types.isNumericLiteral(right)) {

				if (conseBody.length == 1 && types.isIfStatement(conseBody[0]) && types.isBinaryExpression(conseBody[0].test)) {
					if (conseBody[0].test.left.name == name || conseBody[0].test.right.name == name) {

						flag = true;
					}
				}
				if (!flag)
				{
					ifNodes[right.value - 1] = conseBody;
				}

				flag = false;
				if (alterBody.length == 1 && types.isIfStatement(alterBody[0]) && types.isBinaryExpression(alterBody[0].test)) {
					if (alterBody[0].test.left.name == name || alterBody[0].test.right.name == name) {

						flag = true;
					}
				}
				if (!flag) {
					ifNodes[right.value] = alterBody;
				}


				return;
			}

			if (types.isIdentifier(left, { "name": name }) && operator == ">" && types.isNumericLiteral(right)) {
				
				let flag = false;
				if (conseBody.length == 1 && types.isIfStatement(conseBody[0]) && types.isBinaryExpression(conseBody[0].test)) {
					if (conseBody[0].test.left.name == name || conseBody[0].test.right.name == name) {

						flag = true;
					} 
				}
				if (!flag) {
					ifNodes[right.value + 1] = conseBody;
				}
					
				
				flag = false;
				if (alterBody.length == 1 && types.isIfStatement(alterBody[0]) && types.isBinaryExpression(alterBody[0].test)) {
					if (alterBody[0].test.left.name == name || alterBody[0].test.right.name == name) {

						flag = true;
					}
				}

				if (!flag)
				{
					ifNodes[right.value] = alterBody;
				}

				return;
			}


			if (types.isIdentifier(right, { "name": name }) && operator == ">" && types.isNumericLiteral(left)) {//1 > p7

				flag = false;
				if (conseBody.length == 1 && types.isIfStatement(conseBody[0]) && types.isBinaryExpression(conseBody[0].test)) {
					if (conseBody[0].test.left.name == name || conseBody[0].test.right.name == name) {

						flag = true;
					}
				}


				if (!flag) 
				{
					ifNodes[left.value - 1] = conseBody;
				}

				flag = false;
				if (alterBody.length == 1 && types.isIfStatement(alterBody[0]) && types.isBinaryExpression(alterBody[0].test)) {
					if (alterBody[0].test.left.name == name || alterBody[0].test.right.name == name) {

						flag = true;
					}
				}
				if (!flag) 
				{
					ifNodes[left.value] = alterBody;
				}
				
				return;
			}

			if (types.isIdentifier(right, { "name": name }) && operator == "<" && types.isNumericLiteral(left)) {  //1 < p7

				flag = false;
				if (conseBody.length == 1 && types.isIfStatement(conseBody[0]) && types.isBinaryExpression(conseBody[0].test)) {
					if (conseBody[0].test.left.name == name || conseBody[0].test.right.name == name) {

						flag = true;
					}
				}
				if (!flag){
					ifNodes[left.value + 1] = conseBody;
				}
				

				flag = false;
				if (alterBody.length == 1 && types.isIfStatement(alterBody[0]) && types.isBinaryExpression(alterBody[0].test)) {
					if (alterBody[0].test.left.name == name || alterBody[0].test.right.name == name) {

						flag = true;
					}
				}

				if (!flag){
					ifNodes[left.value] = alterBody;
				}

				
				return;
			}


		},
	})

	return ifNodes;
}




const IfToSwitchNode = {

	"WhileStatement": {
		exit(path) {
			let { scope, node } = path;
			let { test, body } = node;

			if (test.value != 1 || body.body.length != 1) {//条件过滤
				return;
			}



			let blockBody = body.body;

			if (!types.isIfStatement(blockBody[0])) {//条件过滤
				return;
			}


			let name = "p7"   //变量名

			let binding = scope.getBinding(name);

			if (!binding) {
				return;
			}


			let ifNodes = collectSwitchCase(path, name, binding.referencePaths);   //收集case

			let keys = Object.keys(ifNodes);

			if (keys.length == 0) {
				return;
			}

			for (let i = 0; i < 646; i++) {
				if (!keys.includes(i + "")) {
					console.log(i)
				}
			}

			let casesArray = [];

			for (let key of keys) {
				let SwitchCase = ifNodes[key];
				SwitchCase.push(types.BreakStatement());
				let SwitchCaseNode = types.SwitchCase(test = types.valueToNode(Number(key)), consequent = SwitchCase);
				casesArray.push(SwitchCaseNode);
			}

			let switchNode = types.SwitchStatement(types.Identifier("p7"), casesArray);   //生成SwitchCase节点

			path.node.body.body = [switchNode]; //最后的while节点只有一个Switch Node;

		}
	},
}


traverse(ast, IfToSwitchNode);

console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = {
	"compact": 0,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});


files.writeFile(decodeFile, code, (err) => { });