typeof window === "undefined" && Object.assign(globalThis, {
  "exports": exports,
  "require": require,
  "module": module,
  "__filename": __filename,
  "__dirname": __dirname
});
(function (p, p2, p3, p4, p5, p6) {
  f(67, p);
  '';
  function f(p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61) {
    function f2(p62) {
      let vP10 = p10;
      for (let vLN1 = 1; vLN1 < p62; ++vLN1) {
        vP10 = vP10.__proto__;
      }
      return vP10;
    }
    function f3() {
      if (p11) {
        return p11;
      }
      let vO = {};
      Object.defineProperties(vO, {
        "ﱣﹱ": {
          get() {
            return p13;
          },
          set(p63) {
            p13 = p63;
          }
        },
        "ءﹱ": {
          get() {
            return p14;
          },
          set(p64) {
            p14 = p64;
          }
        },
        "ﱡיּ": {
          get() {
            return p15;
          },
          set(p65) {
            p15 = p65;
          }
        },
        "ﹱﱟ": {
          get() {
            return p16;
          },
          set(p66) {
            p16 = p66;
          }
        },
        "ﹱﱡ": {
          get() {
            return p17;
          },
          set(p67) {
            p17 = p67;
          }
        },
        "ﱞﱣ": {
          get() {
            return p18;
          },
          set(p68) {
            p18 = p68;
          }
        },
        "ﱡ": {
          get() {
            return p19;
          },
          set(p69) {
            p19 = p69;
          }
        },
        "ﱣ": {
          get() {
            return p20;
          },
          set(p70) {
            p20 = p70;
          }
        },
        "ﱢﹰ": {
          get() {
            return p21;
          },
          set(p71) {
            p21 = p71;
          }
        },
        "ࢭﹱ": {
          get() {
            return p22;
          },
          set(p72) {
            p22 = p72;
          }
        },
        "יּﱞ": {
          get() {
            return p23;
          },
          set(p73) {
            p23 = p73;
          }
        },
        "ﹰﱟ": {
          get() {
            return p24;
          },
          set(p74) {
            p24 = p74;
          }
        },
        "ﱡﹱ": {
          get() {
            return p25;
          },
          set(p75) {
            p25 = p75;
          }
        },
        "ءࢭ": {
          get() {
            return p26;
          },
          set(p76) {
            p26 = p76;
          }
        },
        "ءﱠ": {
          get() {
            return p27;
          },
          set(p77) {
            p27 = p77;
          }
        },
        "ﱠﹰ": {
          get() {
            return p28;
          },
          set(p78) {
            p28 = p78;
          }
        },
        "ﱡﱢ": {
          get() {
            return p29;
          },
          set(p79) {
            p29 = p79;
          }
        },
        "ﹱיּ": {
          get() {
            return p30;
          },
          set(p80) {
            p30 = p80;
          }
        },
        "ﱣﱠ": {
          get() {
            return p31;
          },
          set(p81) {
            p31 = p81;
          }
        },
        "ﹲﱟ": {
          get() {
            return p32;
          },
          set(p82) {
            p32 = p82;
          }
        },
        "ﱡࢭ": {
          get() {
            return p33;
          },
          set(p83) {
            p33 = p83;
          }
        },
        "ﱞﱠ": {
          get() {
            return p34;
          },
          set(p84) {
            p34 = p84;
          }
        },
        "ﱣࢭ": {
          get() {
            return p35;
          },
          set(p85) {
            p35 = p85;
          }
        }
      });
      vO.__proto__ = p10;
      p11 = vO;
      return vO;
    }
    while (1) {
      if (162 > p7) {
        if (p7 > 120) {
          if (132 > p7) {
            if (127 < p7) {
              if (p7 > 130) {
                p7 = 111;
              } else {
                if (p7 < 130) {
                  if (128 < p7) {
                    p7 = 103;
                    p48 = p50;
                  } else {
                    p7 = 172;
                    p41 = new p["Uint32Array"](p29);
                  }
                } else {
                  ++p10.ءﹱ;
                  p7 = 446;
                }
              }
            } else {
              if (p7 < 124) {
                if (p7 < 122) {
                  p7 = 62;
                  p44 = p10.ءﹱ;
                } else {
                  if (123 > p7) {
                    p7 = 129;
                    p50 = p34 === 1;
                  } else {
                    p7 += 488;
                    p46 = p34 < p7 - 606;
                  }
                }
              } else {
                if (126 > p7) {
                  if (124 < p7) {
                    let vLN12 = 12;
                    try {
                      const vO2 = {
                        "יּﹱ": p2
                      };
                      const vF = f(p7 + 356, p8, p9, f3(), p6, vO2);
                      if (vO2.יּﹱ) {
                        return vF;
                      }
                      if (vO2.ءﱞ !== p6) {
                        vLN12 = vO2.ءﱞ;
                        if (vO2.ﱢﹱ > 1) {
                          p12.ءﱞ = vLN12;
                          p12.ﱢﹱ = --vO2.ﱢﹱ;
                          return p12.יּﹱ = p3;
                        }
                      }
                    } catch (e) {
                      const vO3 = {
                        "יּﹱ": p2
                      };
                      const vF2 = f(241, p8, p9, f3(), p6, vO3, e);
                      if (vO3.יּﹱ) {
                        return vF2;
                      }
                      if (vO3.ءﱞ !== p6) {
                        vLN12 = vO3.ءﱞ;
                        if (vO3.ﱢﹱ > 1) {
                          p12.ءﱞ = vLN12;
                          p12.ﱢﹱ = --vO3.ﱢﹱ;
                          return p12.יּﹱ = p3;
                        }
                      }
                    } finally {
                      const vO4 = {
                        "יּﹱ": p2
                      };
                      const vF3 = f(120, p8, p9, f3(), p6, vO4);
                      if (vO4.יּﹱ) {
                        return vF3;
                      }
                      if (vO4.ءﱞ !== p6) {
                        vLN12 = vO4.ءﱞ;
                        if (vO4.ﱢﹱ > 1) {
                          p12.ءﱞ = vLN12;
                          p12.ﱢﹱ = --vO4.ﱢﹱ;
                          return p12.יּﹱ = p3;
                        }
                      }
                      p7 = vLN12;
                    }
                  } else {
                    p7 = 148;
                    p13 = p42;
                  }
                } else {
                  if (127 > p7) {
                    p44 += 6;
                    p7 = 493;
                  } else {
                    p7 = 407;
                    p48 = p20 + p21;
                  }
                }
              }
            }
          } else {
            if (142 > p7) {
              if (138 < p7) {
                if (p7 > 140) {
                  p7 = 184;
                  p50 = p34 === 3;
                } else {
                  if (139 < p7) {
                    p7 = 149;
                    p41 = p40[149, "toString"];
                  } else {
                    p7 = 371;
                    f2(2).ﹱﱡ[p44] = 36;
                  }
                }
              } else {
                if (p7 < 135) {
                  if (p7 < 133) {
                    if (p40) {
                      p7 = 340;
                    } else {
                      p7 += 192;
                    }
                  } else {
                    if (p7 > 133) {
                      p7 += 168;
                      p43 = p29[p7, "slice"];
                    } else {
                      p7 = 190;
                      p49 = p33 === 1;
                    }
                  }
                } else {
                  if (137 > p7) {
                    if (p7 < 136) {
                      p7 += 280;
                      p41[p7 - 415] = "click";
                    } else {
                      p7 = 517;
                      p52[0] = 1518500249;
                    }
                  } else {
                    if (137 < p7) {
                      p7 = 369;
                      p50 = p47[369, "length"];
                    } else {
                      p7 = 99;
                      p32 = 0;
                    }
                  }
                }
              }
            } else {
              if (p7 > 151) {
                if (158 < p7) {
                  if (160 < p7) {
                    p7 = 321;
                    p40 = p4(p39, p16)(...p41);
                  } else {
                    if (p7 < 160) {
                      p7 = 591;
                      p46 = p15[591, "call"];
                    } else {
                      p7 = 467;
                      p10.ﹱﱡ[467, p40] = p16;
                    }
                  }
                } else {
                  if (155 > p7) {
                    if (153 < p7) {
                      p7 = 462;
                      p41 = p40 + 8;
                    } else {
                      if (153 > p7) {
                        p7 = 71;
                        ++p33;
                      } else {
                        p7 = 615;
                        p43 = p15[615, p34];
                      }
                    }
                  } else {
                    if (p7 < 157) {
                      if (p7 < 156) {
                        p7 = 377;
                      } else {
                        p7 = 436;
                        p45 = p29[436, p21];
                      }
                    } else {
                      if (p7 > 157) {
                        p7 = 556;
                      } else {
                        p7 -= 98;
                        p50 = function (...ﹲיּ) {
                          return f(25, this, arguments, f3(), p6, p6, ...ﹲיּ);
                        };
                      }
                    }
                  }
                }
              } else {
                if (p7 > 148) {
                  if (p7 > 150) {
                    p7 = 218;
                    p41[1] = p44;
                  } else {
                    if (p7 < 150) {
                      p7 = 177;
                      p15 = p41;
                    } else {
                      p7 = 213;
                      p53 = p52 & p54;
                    }
                  }
                } else {
                  if (146 < p7) {
                    if (p7 > 147) {
                      p7 = 370;
                      p42 = p13;
                    } else {
                      p7 = 583;
                      p46 = p35;
                    }
                  } else {
                    if (144 < p7) {
                      if (145 < p7) {
                        p7 = 374;
                        p34 = 0;
                      } else {
                        p7 = 468;
                        p44[0] = p45;
                      }
                    } else {
                      if (143 < p7) {
                        p7 = 445;
                      } else {
                        if (p7 > 142) {
                          p7 = 429;
                          p39 = p16[429, "addEventListener"];
                        } else {
                          p7 = 441;
                          p49 = p33 === ('', 441) - 440;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if (p7 < 41) {
            if (30 < p7) {
              if (37 < p7) {
                if (p7 < 39) {
                  p7 = 502;
                  p40 = p15[502, "call"];
                } else {
                  if (p7 < 40) {
                    p7 = 315;
                    p17 = p6;
                  } else {
                    p7 = 318;
                    p42 = p41 << 3;
                  }
                }
              } else {
                if (34 > p7) {
                  if (p7 < 32) {
                    p7 += 589;
                    p46 = p50;
                  } else {
                    if (p7 < 33) {
                      p7 = 66;
                      p49 = p14;
                    } else {
                      p46 = p29[(p7 -= 16) - 17];
                    }
                  }
                } else {
                  if (35 < p7) {
                    if (p7 < 37) {
                      '';
                      p7 = 511;
                      p54 = p13;
                    } else {
                      p7 = 209;
                      p60 = p21 - 16;
                    }
                  } else {
                    if (p7 < 35) {
                      p7 = 287;
                      p42 = p4(p41, p["console"])("补环境需要过document.all检测喔");
                    } else {
                      p7 = 207;
                      p42 = p10.ﹱﱡ === p6;
                    }
                  }
                }
              }
            } else {
              if (11 > p7) {
                if (3 > p7) {
                  if (1 < p7) {
                    p7 = 495;
                    p40 += "";
                  } else {
                    if (1 > p7) {
                      p7 = 277;
                      p14 = 0;
                    } else {
                      p7 = 279;
                      p15[279, p42] = p43;
                    }
                  }
                } else {
                  if (p7 > 6) {
                    if (9 < p7) {
                      p7 = 30;
                      p55[0] = p56;
                    } else {
                      if (p7 < 9) {
                        if (7 < p7) {
                          p7 = 150;
                          p54 = p10.ﱡﱢ[3];
                        } else {
                          p7 = 500;
                          p41 = p24[500, "buffer"];
                        }
                      } else {
                        p7 = 0;
                        p17 = p6;
                      }
                    }
                  } else {
                    if (4 < p7) {
                      if (p7 < 6) {
                        p7 = 296;
                        p53 = p16 >> 6;
                      } else {
                        return p47;
                      }
                    } else {
                      if (p7 < 4) {
                        p7 = 183;
                        f2(2).ﹱﱡ[p44] = 78;
                      } else {
                        p7 = 414;
                        p16 = p46;
                      }
                    }
                  }
                }
              } else {
                if (20 < p7) {
                  if (p7 > 27) {
                    if (29 > p7) {
                      p7 = 320;
                      p53 = p16 >> 6;
                    } else {
                      if (p7 > 29) {
                        p7 = 572;
                        p60 = p16 >> 12;
                      } else {
                        return p12.יּﹱ = p3;
                      }
                    }
                  } else {
                    if (p7 < 24) {
                      if (22 < p7) {
                        p52 = p47 + p53;
                        p7 = 56;
                      } else {
                        if (p7 > 21) {
                          p56 = p54 + p59;
                          p7 = 79;
                        } else {
                          p7 = 578;
                          p49 = p48[578, "call"];
                        }
                      }
                    } else {
                      if (p7 > 25) {
                        if (p7 < 27) {
                          if (p51) {
                            p7 = 600;
                          } else {
                            p7 = 496;
                          }
                        } else {
                          p7 = 202;
                          p58 = p25[202, p57];
                        }
                      } else {
                        if (p7 > 24) {
                          p7 = 36;
                          p52 = p13 << p14;
                        } else {
                          p7 = 360;
                          p17 = p49;
                        }
                      }
                    }
                  }
                } else {
                  if (14 > p7) {
                    if (p7 < 12) {
                      p7 = 203;
                      p56 = p16 & 63;
                    } else {
                      if (p7 > 12) {
                        p7 = 21;
                        p48 = p["Function"][21, "prototype"];
                      } else {
                        p7 = 401;
                        p40 = "@";
                      }
                    }
                  } else {
                    if (16 > p7) {
                      if (15 > p7) {
                        p7 = 535;
                        p43 = p4(p42, p22)(p44);
                      } else {
                        p7 = 204;
                        p43 = p42['', 204, "apply"];
                      }
                    } else {
                      if (17 < p7) {
                        if (p7 < 19) {
                          p7 = 47;
                          p10.ﹱﱟ = p46;
                        } else {
                          if (19 < p7) {
                            p7 += 329;
                            p55 = p7 - 125 + p57;
                          } else {
                            p7 += 23;
                            p56 = p16 >> p7 - 30;
                          }
                        }
                      } else {
                        if (p7 < 17) {
                          p7 = 76;
                          p41 = p40[76, "apply"];
                        } else {
                          p7 = 640;
                          p45 = p27(p46, 5);
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if (p7 > 80) {
              if (p7 > 111) {
                if (p7 > 118) {
                  if (p7 > 119) {
                    return p12.יּﹱ = p3;
                  } else {
                    p7 = 18;
                  }
                } else {
                  if (116 < p7) {
                    if (117 < p7) {
                      p7 = 432;
                      ++p32;
                    } else {
                      p7 = 453;
                      p15[453, p40] = p42;
                    }
                  } else {
                    if (115 > p7) {
                      if (113 > p7) {
                        if (p44) {
                          p7 -= 2;
                        } else {
                          p7 += 533;
                        }
                      } else {
                        if (p7 > 113) {
                          p7 = 565;
                          p43 += "";
                        } else {
                          p7 = 549;
                          p14 = 1;
                        }
                      }
                    } else {
                      if (p7 > 115) {
                        p7 = 268;
                        p57 = p56 & p58;
                      } else {
                        p7 = 465;
                        p10.ﱡיּ[465, "value"] = p44;
                      }
                    }
                  }
                }
              } else {
                if (p7 > 101) {
                  if (105 > p7) {
                    if (103 < p7) {
                      p7 += 261;
                      p40 = p14;
                    } else {
                      if (p7 < 103) {
                        p7 = 118;
                        p46 = p32;
                      } else {
                        if (p48) {
                          p7 = 144;
                        } else {
                          p7 = 418;
                        }
                      }
                    }
                  } else {
                    if (108 < p7) {
                      if (110 > p7) {
                        p7 = 593;
                        p43 = p32;
                      } else {
                        if (110 < p7) {
                          p7 = 451;
                          p40 = p20 < 5;
                        } else {
                          p7 = 464;
                          p46 = p["console"][464, "log"];
                        }
                      }
                    } else {
                      if (106 < p7) {
                        if (p7 > 107) {
                          p7 = 281;
                          p51 = "";
                        } else {
                          p7 = 539;
                          p40 = [];
                        }
                      } else {
                        if (106 > p7) {
                          p7 = 348;
                        } else {
                          p7 = 281;
                        }
                      }
                    }
                  }
                } else {
                  if (92 > p7) {
                    if (p7 < 84) {
                      if (82 < p7) {
                        p7 = 185;
                        p40 = p40 < p41;
                      } else {
                        if (81 < p7) {
                          p7 = 602;
                          p41 = p40[602, "map"];
                        } else {
                          p7 = 394;
                          p43 = p16[394, p32];
                        }
                      }
                    } else {
                      if (86 > p7) {
                        if (84 < p7) {
                          p7 = 642;
                          p40 = p40 < p41;
                        } else {
                          p7 = 155;
                          ++p21;
                        }
                      } else {
                        if (88 > p7) {
                          if (86 < p7) {
                            p7 = 492;
                            p46 = p10.ﱡﱢ[1];
                          } else {
                            p7 = 263;
                            p40 = p20;
                          }
                        } else {
                          if (p7 > 90) {
                            p7 += 514;
                            p39 = p14[p7, "getElementById"];
                          } else {
                            if (90 > p7) {
                              if (p7 < 89) {
                                p7 = 14;
                                p44 = p20 << 2;
                              } else {
                                p7 = 458;
                                p32 = 0;
                              }
                            } else {
                              p7 = 525;
                              ++p14;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if (98 < p7) {
                      if (100 > p7) {
                        p7 = 569;
                        p40 = p32;
                      } else {
                        if (101 > p7) {
                          if (p46) {
                            p7 = 240;
                          } else {
                            p7 = 102;
                          }
                        } else {
                          p7 = 561;
                          p45 = p21 < 16;
                        }
                      }
                    } else {
                      if (95 > p7) {
                        if (93 > p7) {
                          p7 = 452;
                          p45 = p44 - 30;
                        } else {
                          if (93 < p7) {
                            p7 = 294;
                            p56 = -271733879;
                          } else {
                            p7 = 515;
                            p39 = function (...ﹲיּ) {
                              return f(440, this, arguments, f3(), p6, p6, ...ﹲיּ);
                            };
                          }
                        }
                      } else {
                        if (p7 > 96) {
                          if (p7 < 98) {
                            p7 += 358;
                          } else {
                            p7 = 599;
                            p46 = p32;
                          }
                        } else {
                          if (p7 > 95) {
                            if (p49) {
                              p7 += 316;
                            } else {
                              p7 = 248;
                            }
                          } else {
                            p7 = 238;
                            p40 = [];
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if (p7 > 71) {
                if (78 < p7) {
                  if (p7 < 80) {
                    p7 = 226;
                    p60 = p56 | 0;
                  } else {
                    p7 = 265;
                    p10.ﹱﱡ[265, p40] = p16;
                  }
                } else {
                  if (76 < p7) {
                    if (p7 < 78) {
                      if (p45) {
                        p7 = 513;
                      } else {
                        '';
                        p7 = 49;
                      }
                    } else {
                      p7 = 277;
                    }
                  } else {
                    if (p7 < 75) {
                      if (73 > p7) {
                        p53 = p52 | p54;
                        p7 = 61;
                      } else {
                        if (p7 > 73) {
                          p7 = 499;
                          p53 = p15[499, "push"];
                        } else {
                          p7 = 266;
                          p50 = p26[266, p49];
                        }
                      }
                    } else {
                      if (76 > p7) {
                        p7 = 607;
                        p44 = "@";
                      } else {
                        p7 = 235;
                        p43 = [];
                      }
                    }
                  }
                }
              } else {
                if (61 < p7) {
                  if (65 > p7) {
                    if (63 > p7) {
                      p7 = 3;
                      ++p10.ءﹱ;
                    } else {
                      if (63 < p7) {
                        if (p45) {
                          p7 = 355;
                        } else {
                          p7 = 52;
                        }
                      } else {
                        p7 += 265;
                        p51[p7 - 327] = p55;
                      }
                    }
                  } else {
                    if (68 < p7) {
                      if (70 > p7) {
                        p7 = 229;
                        p21 = function (...ﹲיּ) {
                          return f(484, this, arguments, f3(), p6, p6, ...ﹲיּ);
                        };
                      } else {
                        if (p7 < 71) {
                          p7 = 554;
                          p41[0] = p42;
                        } else {
                          p7 = 338;
                        }
                      }
                    } else {
                      if (67 > p7) {
                        if (65 < p7) {
                          p7 = 78;
                          ++p14;
                        } else {
                          p7 = 297;
                          p41 = p13[297, "length"];
                        }
                      } else {
                        if (p7 < 68) {
                          p7 = 195;
                          p36 = function (...ﹲיּ) {
                            return f(289, this, arguments, f3(), p6, p6, ...ﹲיּ);
                          };
                        } else {
                          p7 = 43;
                          p15 = p40;
                        }
                      }
                    }
                  }
                } else {
                  if (52 > p7) {
                    if (p7 < 44) {
                      if (42 < p7) {
                        p7 = 9;
                        p16 = p6;
                      } else {
                        if (42 > p7) {
                          p7 = 282;
                          p40 = p10.ﱞﱣ();
                        } else {
                          p57 = p56 & (p7 -= 22) - 5;
                        }
                      }
                    } else {
                      if (46 > p7) {
                        if (45 > p7) {
                          p7 = 257;
                          p47 = p46 * 8;
                        } else {
                          return p15;
                        }
                      } else {
                        if (p7 > 47) {
                          if (50 < p7) {
                            p7 = 424;
                            p52[2] = p53;
                          } else {
                            if (50 > p7) {
                              if (p7 > 48) {
                                p7 = 18;
                                p46 = 79;
                              } else {
                                p7 = 253;
                                p13 = function (...ﹲיּ) {
                                  return f(196, this, arguments, f3(), p6, p6, ...ﹲיּ);
                                };
                              }
                            } else {
                              p50 = p48 & p51;
                              p7 = 210;
                            }
                          }
                        } else {
                          if (47 > p7) {
                            p7 = 99;
                          } else {
                            p7 = 410;
                            p45 = p10.ءﹱ;
                          }
                        }
                      }
                    }
                  } else {
                    if (p7 < 55) {
                      if (53 > p7) {
                        p7 = 182;
                        p47 = p16 < 2048;
                      } else {
                        if (54 > p7) {
                          p7 = 86;
                          p20 = 0;
                        } else {
                          return;
                        }
                      }
                    } else {
                      if (p7 < 57) {
                        if (p7 < 56) {
                          p7 = 483;
                          p48 = p10.ﱡﱢ[1];
                        } else {
                          p7 = 375;
                          p55 = p25[375, p21];
                        }
                      } else {
                        if (58 < p7) {
                          if (p7 > 60) {
                            return p53;
                          } else {
                            if (p7 > 59) {
                              p7 = 314;
                              p56 = p4(p55, p13)(p14);
                            } else {
                              p7 += 562;
                            }
                          }
                        } else {
                          if (58 > p7) {
                            p7 = 519;
                            p58 = p57 & 7;
                          } else {
                            p7 = 576;
                            p40 = p40 - p45;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if (p7 > 483) {
          if (p7 > 604) {
            if (p7 > 635) {
              if (639 > p7) {
                if (637 < p7) {
                  p7 = 374;
                } else {
                  if (p7 > 636) {
                    p7 = 618;
                    p49 = p45 + 62;
                  } else {
                    p7 = 634;
                    p20 += 16;
                  }
                }
              } else {
                if (p7 > 642) {
                  if (645 > p7) {
                    if (p7 < 644) {
                      p7 = 256;
                      p42 = p20;
                    } else {
                      ++p10.ﱞﱣ;
                      p7 = 510;
                    }
                  } else {
                    if (p7 < 646) {
                      p7 = 115;
                      p44 = p10.ࢭﹱ(p13);
                    } else {
                      p7 = 610;
                      p40 = p15[610, "length"];
                    }
                  }
                } else {
                  if (p7 > 640) {
                    if (642 > p7) {
                      p7 = 613;
                      ++p32;
                    } else {
                      if (p40) {
                        p7 -= 508;
                      } else {
                        p7 = 107;
                      }
                    }
                  } else {
                    if (639 < p7) {
                      p7 = 527;
                      p48 = p21 / 20;
                    } else {
                      p7 = 392;
                      p22 = p40;
                    }
                  }
                }
              }
            } else {
              if (p7 > 625) {
                if (p7 > 632) {
                  if (634 > p7) {
                    p7 -= 540;
                  } else {
                    if (635 > p7) {
                      p7 = 86;
                    } else {
                      p7 = 449;
                      p29 = p55;
                    }
                  }
                } else {
                  if (629 > p7) {
                    if (627 > p7) {
                      p7 = 558;
                      p55 = [];
                    } else {
                      if (p7 < 628) {
                        p7 = 323;
                        p52 = p10.ﱡﱢ[2];
                      } else {
                        if (p43) {
                          p7 = 101;
                        } else {
                          p7 = 616;
                        }
                      }
                    }
                  } else {
                    if (p7 < 631) {
                      if (629 < p7) {
                        p7 = 393;
                        p43 = p21 < 5;
                      } else {
                        ++p10.ءﹱ;
                        p7 = 139;
                      }
                    } else {
                      if (p7 > 631) {
                        p7 = 206;
                        p47 = p45 + p51;
                      } else {
                        p7 -= 526;
                        p48 = function (...ﹲיּ) {
                          return f(426, this, arguments, f3(), p6, p6, ...ﹲיּ);
                        };
                      }
                    }
                  }
                }
              } else {
                if (615 < p7) {
                  if (p7 < 619) {
                    if (p7 > 617) {
                      p7 -= 514;
                      p16 = p49;
                    } else {
                      if (617 > p7) {
                        p7 = 630;
                        p21 = 0;
                      } else {
                        p7 -= 212;
                        p42 = p4(p41, p40)(...p43);
                      }
                    }
                  } else {
                    if (622 < p7) {
                      if (624 < p7) {
                        p7 = 225;
                        p40 = p14;
                      } else {
                        if (623 < p7) {
                          p7 = 400;
                          p43 = p34;
                        } else {
                          p7 = 629;
                          p44 = p10.ءﹱ;
                        }
                      }
                    } else {
                      if (621 > p7) {
                        if (p7 > 619) {
                          p7 = 33;
                          p25[33, p21] = p46;
                        } else {
                          p7 = 383;
                          p45 = p27(p46, 30);
                        }
                      } else {
                        if (622 > p7) {
                          p7 = 339;
                          p27 = p50;
                        } else {
                          p7 = 639;
                          p40 = new p["DataView"](p42);
                        }
                      }
                    }
                  }
                } else {
                  if (608 > p7) {
                    if (606 < p7) {
                      p44 += p13;
                      p7 = 368;
                    } else {
                      if (605 < p7) {
                        p7 = 221;
                        p51 = p4(p50, p43)("");
                      } else {
                        p7 = 337;
                        p40 = p4(p39, p14)("userAgentText");
                      }
                    }
                  } else {
                    if (610 > p7) {
                      if (609 > p7) {
                        p7 = 199;
                        p41 = p4(p40, p["console"])("嘿嘿，找到正确的盐了吗？");
                      } else {
                        p7 = 526;
                        p22 = p40;
                      }
                    } else {
                      if (p7 < 612) {
                        if (611 > p7) {
                          p7 = 536;
                          p41 = p10.ﱣ + 66;
                        } else {
                          if (p46) {
                            p7 = 447;
                          } else {
                            p7 = 455;
                          }
                        }
                      } else {
                        if (p7 > 614) {
                          p44 = p43 + p34;
                          p7 = 92;
                        } else {
                          if (p7 < 614) {
                            if (p7 < 613) {
                              p7 = 378;
                              p41 = p24[378, "buffer"];
                            } else {
                              p7 = 458;
                            }
                          } else {
                            p7 = 123;
                            p34 = ('', 123) - 122;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if (525 > p7) {
              if (495 > p7) {
                if (487 > p7) {
                  if (p7 > 485) {
                    p7 = 7;
                    p24 = p40;
                  } else {
                    if (484 < p7) {
                      p7 = 587;
                      p44 = p20 << 2;
                    } else {
                      p7 = 329;
                      p40 = [];
                    }
                  }
                } else {
                  if (p7 < 489) {
                    if (488 > p7) {
                      p7 = 147;
                      p47 = p4(p46, p["console"])(p48);
                    } else {
                      p7 = 503;
                      p46 = p4(p45, p["console"])("请关闭开发者工具");
                    }
                  } else {
                    if (p7 > 490) {
                      if (493 < p7) {
                        p54 = p53 + p57;
                        p7 = 246;
                      } else {
                        if (493 > p7) {
                          if (491 < p7) {
                            p7 = 222;
                            p48 = p10.ﱡﱢ[2];
                          } else {
                            p7 = 606;
                            p50 = p43[606, "join"];
                          }
                        } else {
                          p7 = 384;
                          p44 += "";
                        }
                      }
                    } else {
                      if (490 > p7) {
                        p7 = 267;
                        p43 = p19[267, "buffer"];
                      } else {
                        if (p42) {
                          p7 += 54;
                        } else {
                          p7 = 510;
                        }
                      }
                    }
                  }
                }
              } else {
                if (p7 < 505) {
                  if (501 < p7) {
                    if (p7 > 503) {
                      p7 = 312;
                      p57 = p21 / 20;
                    } else {
                      if (p7 < 503) {
                        p7 += 79;
                        p42 = p["String"][p7, "prototype"];
                      } else {
                        p7 = 555;
                      }
                    }
                  } else {
                    if (498 > p7) {
                      if (p7 > 496) {
                        p7 = 545;
                        p19 = p6;
                      } else {
                        if (495 < p7) {
                          p7 = 19;
                          p53 = p15[19, "push"];
                        } else {
                          p7 = 220;
                          p40 += p18;
                        }
                      }
                    } else {
                      if (p7 > 499) {
                        if (p7 > 500) {
                          if (p42) {
                            '';
                            p7 = 75;
                          } else {
                            p7 = 408;
                          }
                        } else {
                          p7 += 109;
                          p40 = new p["DataView"](p41);
                        }
                      } else {
                        if (499 > p7) {
                          p53 = p52 ^ p55;
                          p7 = 284;
                        } else {
                          p7 = 559;
                          p55 = [];
                        }
                      }
                    }
                  }
                } else {
                  if (515 > p7) {
                    if (p7 < 508) {
                      if (p7 > 506) {
                        p7 = 589;
                        p40 = p23 - 1;
                      } else {
                        if (505 < p7) {
                          p7 = 568;
                        } else {
                          p7 = 643;
                          p29[643, p20] = p43;
                        }
                      }
                    } else {
                      if (p7 > 511) {
                        if (p7 > 513) {
                          p7 = 450;
                          p49 = p33 === ('', 450) - 446;
                        } else {
                          if (p7 < 513) {
                            p7 = 352;
                            p24 = p45;
                          } else {
                            p7 = 119;
                            p46 = 37;
                          }
                        }
                      } else {
                        if (509 < p7) {
                          if (510 < p7) {
                            p7 = 350;
                            p55 = 32 - p14;
                          } else {
                            p7 = 469;
                            p10.ﹱﱡ[1] = p10.ﱞﱣ;
                          }
                        } else {
                          if (p7 > 508) {
                            p44 = p43 + 16;
                            p7 = 571;
                          } else {
                            p7 = 112;
                            p44 = p35 <= 9;
                          }
                        }
                      }
                    }
                  } else {
                    if (518 > p7) {
                      if (516 < p7) {
                        p7 = 187;
                        p52[1] = 1859775393;
                      } else {
                        if (p7 > 515) {
                          p7 = 617;
                          p43[1] = p13;
                        } else {
                          p7 = 551;
                        }
                      }
                    } else {
                      if (520 > p7) {
                        if (p7 < 519) {
                          p7 = 478;
                          p41 = p29[1];
                        } else {
                          p7 = 10;
                          p56 = 240 + p58;
                        }
                      } else {
                        if (522 > p7) {
                          if (521 > p7) {
                            p7 = 259;
                            p40 = p40 < p41;
                          } else {
                            p7 = 635;
                            p55[4] = p57;
                          }
                        } else {
                          if (523 < p7) {
                            p7 = 357;
                            p44[1] = p48;
                          } else {
                            if (523 > p7) {
                              p7 = 35;
                              f2(2).ﹱﱡ[35, p45] = p10.ﹱﱟ;
                            } else {
                              p7 = 239;
                              p19 = p40;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if (p7 > 564) {
                if (595 < p7) {
                  if (p7 < 599) {
                    if (597 < p7) {
                      p7 = 346;
                      p40 = p15[346, "length"];
                    } else {
                      if (596 < p7) {
                        p42 = p42 === p43;
                        p7 = 293;
                      } else {
                        p7 = 313;
                        p42 = p42 | p43;
                      }
                    }
                  } else {
                    if (p7 < 601) {
                      if (599 < p7) {
                        p7 = 342;
                        p53 = p17 << 10;
                      } else {
                        p7 = 456;
                        p47 = p["Math"][456, "random"];
                      }
                    } else {
                      if (602 < p7) {
                        if (603 < p7) {
                          p7 = 44;
                          p46 = p45 & 3;
                        } else {
                          p7 = 592;
                          p16 = p42;
                        }
                      } else {
                        if (p7 < 602) {
                          ++p10.ﱞﱣ;
                          p7 = 391;
                        } else {
                          p7 = 227;
                          p42 = p41[227, "call"];
                        }
                      }
                    }
                  }
                } else {
                  if (p7 < 576) {
                    if (568 > p7) {
                      if (p7 < 566) {
                        p7 = 288;
                        p42 = p4(p41, p["console"])(p43);
                      } else {
                        if (p7 < 567) {
                          p7 = 550;
                          p43 = p42 === "undefined";
                        } else {
                          p7 = 444;
                        }
                      }
                    } else {
                      if (p7 < 570) {
                        if (p7 < 569) {
                          p7 = 631;
                          p41[2] = p46;
                        } else {
                          p7 = 520;
                          p41 = p16['', 520, "length"];
                        }
                      } else {
                        if (p7 < 572) {
                          if (p7 > 570) {
                            p7 = 272;
                            p23 = p44;
                          } else {
                            p7 -= 516;
                            p42 = p4(p41, p["console"])("===========================================");
                          }
                        } else {
                          if (574 > p7) {
                            if (p7 < 573) {
                              p7 = 402;
                              p61 = p60 & 63;
                            } else {
                              p7 = 158;
                              ++p20;
                            }
                          } else {
                            if (p7 > 574) {
                              p45 = p44 & p46;
                              p7 = 398;
                            } else {
                              p7 = 389;
                              p42 = function (...ﹲיּ) {
                                return f(245, this, arguments, f3(), p6, p6, ...ﹲיּ);
                              };
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if (p7 > 585) {
                      if (589 > p7) {
                        if (p7 < 587) {
                          p7 = 50;
                          p51 = p10.ﱡﱢ[3];
                        } else {
                          if (587 < p7) {
                            if (p44) {
                              p7 = 98;
                            } else {
                              p7 = 113;
                            }
                          } else {
                            p7 = 505;
                            p43 = p4(p42, p22)(p44);
                          }
                        }
                      } else {
                        if (591 > p7) {
                          if (590 > p7) {
                            p7 = 40;
                            p41 = p19[40, "length"];
                          } else {
                            p7 = 501;
                            p42 = p41[501, "prototype"];
                          }
                        } else {
                          if (593 > p7) {
                            if (p7 > 591) {
                              p7 = 353;
                              p40 = p16;
                            } else {
                              p7 = 416;
                              p47 = p4(p46, p15)(p["DataView"]);
                            }
                          } else {
                            if (p7 < 594) {
                              p7 = 46;
                              ++p32;
                            } else {
                              if (595 > p7) {
                                p7 = 248;
                                p48 = p50;
                              } else {
                                p7 = 58;
                                p45 = p42[58, "length"];
                              }
                            }
                          }
                        }
                      }
                    } else {
                      if (582 < p7) {
                        if (p7 > 584) {
                          ++p33;
                          p7 = 567;
                        } else {
                          if (p7 > 583) {
                            p7 = 164;
                            p44 = p10.ﱡיּ[164, "value"];
                          } else {
                            ++p35;
                            p7 = 299;
                          }
                        }
                      } else {
                        if (579 > p7) {
                          if (577 > p7) {
                            p7 = 4;
                            p46 = p40 + 36;
                          } else {
                            if (578 > p7) {
                              if (p40) {
                                p7 = 361;
                              } else {
                                p7 = 219;
                              }
                            } else {
                              p7 = 138;
                              p47 = p4(p46, p15)(p49);
                            }
                          }
                        } else {
                          if (p7 > 580) {
                            if (581 < p7) {
                              p7 = 82;
                              p40 = p["Array"][82, "prototype"];
                            } else {
                              p7 = 347;
                              p43 = p42[347, "charCodeAt"];
                            }
                          } else {
                            if (p7 > 579) {
                              p7 = 249;
                              p44 = p4(p43, p13)(p47);
                            } else {
                              p7 = 553;
                              p14 = 0;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                if (536 > p7) {
                  if (p7 > 531) {
                    if (p7 < 534) {
                      if (p7 < 533) {
                        p7 = 488;
                        p45 = p["console"][488, "log"];
                      } else {
                        p7 = 5;
                        p51 = [];
                      }
                    } else {
                      if (p7 > 534) {
                        p7 = 336;
                        p24[336, p20] = p43;
                      } else {
                        p7 = 548;
                        p40 = p["navigator"][548, "appCodeName"];
                      }
                    }
                  } else {
                    if (p7 > 529) {
                      if (p7 > 530) {
                        p7 = 15;
                        p42 = p["Function"][15, "prototype"];
                      } else {
                        return p12.יּﹱ = p3;
                      }
                    } else {
                      if (528 > p7) {
                        if (p7 < 526) {
                          p7 = 38;
                          p10.ﹱﱡ[38, p40] = p16;
                        } else {
                          if (p7 > 526) {
                            p7 = 73;
                            p49 = p48 | 0;
                          } else {
                            p7 = 556;
                            p20 = 0;
                          }
                        }
                      } else {
                        if (529 > p7) {
                          ++p33;
                          p7 = 309;
                        } else {
                          p7 = 586;
                          p48 = ~p49;
                        }
                      }
                    }
                  }
                } else {
                  if (p7 < 546) {
                    if (542 < p7) {
                      if (p7 > 544) {
                        p7 = 633;
                        p20 = 0;
                      } else {
                        if (543 < p7) {
                          p7 = 448;
                          p45 = p10.ءﹱ;
                        } else {
                          p7 = 64;
                          p45 = p16 < 128;
                        }
                      }
                    } else {
                      if (p7 > 540) {
                        if (542 > p7) {
                          p7 = 425;
                          p45 = p29[425, "unshift"];
                        } else {
                          p7 = 32;
                          p50 = p4(p49, p15)(...p51);
                        }
                      } else {
                        if (538 < p7) {
                          if (540 > p7) {
                            p7 = 146;
                            p10.ﱡ = p40;
                          } else {
                            p7 = 381;
                          }
                        } else {
                          if (p7 > 537) {
                            p49 = p47 ^ p50;
                            p7 = 179;
                          } else {
                            if (537 > p7) {
                              p7 = 117;
                              p42 = p41 % 128;
                            } else {
                              p7 = 390;
                              p54 = p21 - 8;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if (p7 > 555) {
                      if (p7 < 559) {
                        if (557 < p7) {
                          p7 = 94;
                          p55[0] = 1732584193;
                        } else {
                          if (557 > p7) {
                            p7 = 577;
                            p40 = p20 < p23;
                          } else {
                            p7 = 83;
                            p41 = p15[83, "length"];
                          }
                        }
                      } else {
                        if (561 > p7) {
                          if (559 < p7) {
                            p42 = p42 === p43;
                            p7 = 490;
                          } else {
                            p7 = 57;
                            p57 = p16 >> 18;
                          }
                        } else {
                          if (p7 > 562) {
                            if (p7 > 563) {
                              return p53;
                            } else {
                              p7 = 74;
                              p16 = p58;
                            }
                          } else {
                            if (562 > p7) {
                              if (p45) {
                                p7 = 127;
                              } else {
                                p7 = 471;
                              }
                            } else {
                              p7 = 590;
                              p41 = p40[590, "call"];
                            }
                          }
                        }
                      }
                    } else {
                      if (549 > p7) {
                        if (p7 > 547) {
                          p7 = 326;
                          p13 = p40;
                        } else {
                          if (547 > p7) {
                            p7 = 286;
                            p49 = p33 === 2;
                          } else {
                            p7 = 11;
                            p51[0] = p52;
                          }
                        }
                      } else {
                        if (552 < p7) {
                          if (554 > p7) {
                            p7 = 562;
                            p40 = p["Function"][562, "prototype"];
                          } else {
                            if (p7 > 554) {
                              p7 = 171;
                              p55 = p4(p54, p13)(16);
                            } else {
                              p7 = 358;
                              p44 = function (...ﹲיּ) {
                                return f(87, this, arguments, f3(), p6, p6, ...ﹲיּ);
                              };
                            }
                          }
                        } else {
                          if (551 > p7) {
                            if (549 < p7) {
                              if (p43) {
                                p7 -= 77;
                              } else {
                                p7 = 35;
                              }
                            } else {
                              p7 = 444;
                              p33 = 1;
                            }
                          } else {
                            if (551 < p7) {
                              p7 = 547;
                              p52 = 128 + p54;
                            } else {
                              p7 = 459;
                              p["globalThis"][459, "getTip"] = p39;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if (322 < p7) {
            if (p7 < 364) {
              if (334 > p7) {
                if (329 < p7) {
                  if (p7 > 332) {
                    p7 = 91;
                    p14 = p["document"];
                  } else {
                    if (331 < p7) {
                      p7 = 330;
                      p51[('', 330) - 330] = p52;
                    } else {
                      if (p7 > 330) {
                        p7 = 26;
                        p51 = p50 == 0;
                      } else {
                        p7 = 363;
                        p56 = p16 & 63;
                      }
                    }
                  }
                } else {
                  if (p7 > 327) {
                    if (p7 < 329) {
                      p7 = 228;
                      p50 = p4(p49, p15)(...p51);
                    } else {
                      p7 = 89;
                      p13 = p40;
                    }
                  } else {
                    if (p7 > 325) {
                      if (p7 > 326) {
                        p7 = 364;
                        p49 = p15[364, "push"];
                      } else {
                        p7 += 69;
                        p40 = [];
                      }
                    } else {
                      if (p7 > 324) {
                        p7 = 595;
                        p42 = p4(p41, p15)(p44);
                      } else {
                        if (p7 < 324) {
                          p7 = 388;
                          p51 = p50 ^ p52;
                        } else {
                          p7 = 608;
                          p40 = p["console"][608, "log"];
                        }
                      }
                    }
                  }
                }
              } else {
                if (p7 < 344) {
                  if (340 < p7) {
                    if (342 < p7) {
                      p7 = 366;
                      p52[3] = p54;
                    } else {
                      if (342 > p7) {
                        p7 = 125;
                        p18 = 1;
                      } else {
                        p7 = 379;
                        p55 = p13[379, "charCodeAt"];
                      }
                    }
                  } else {
                    if (337 > p7) {
                      if (p7 > 335) {
                        p7 = 573;
                        p42 = p20;
                      } else {
                        if (334 < p7) {
                          p7 = 34;
                          p41 = p["console"][34, "log"];
                        } else {
                          p7 = 159;
                          p44 = p41[159, "length"];
                        }
                      }
                    } else {
                      if (338 < p7) {
                        if (340 > p7) {
                          p7 = 136;
                          p52 = [];
                        } else {
                          p7 = 367;
                          p43 = p13[367, "push"];
                        }
                      } else {
                        if (337 < p7) {
                          p7 = 223;
                          p40 = p33 < p17;
                        } else {
                          p7 = 174;
                          p15 = p40;
                        }
                      }
                    }
                  }
                } else {
                  if (354 > p7) {
                    if (p7 > 350) {
                      if (p7 > 352) {
                        p7 = 359;
                        p41 = p15[359, "call"];
                      } else {
                        if (352 > p7) {
                          p7 += 189;
                          p54 = p4(p53, p15)(...p55);
                        } else {
                          p7 += 137;
                          p40 = p24[p7, "set"];
                        }
                      }
                    } else {
                      if (p7 < 347) {
                        if (345 < p7) {
                          p7 = 191;
                          p18 = p40;
                        } else {
                          if (p7 < 345) {
                            p7 = 130;
                            p45 = p10.ءﹱ;
                          } else {
                            p7 = 335;
                            p42 = p4(p41, p["console"])("==================小提示===================");
                          }
                        }
                      } else {
                        if (p7 > 348) {
                          if (p7 < 350) {
                            p7 = 381;
                            p54 = p4(p53, p15)(p55);
                          } else {
                            p54 = p54 >>> p55;
                            p7 = 72;
                          }
                        } else {
                          if (p7 < 348) {
                            p7 -= 13;
                            p41 = p4(p40, p15)(p43);
                          } else {
                            p7 = 211;
                            p41[3] = p48;
                          }
                        }
                      }
                    }
                  } else {
                    if (p7 < 357) {
                      if (p7 > 355) {
                        p7 = 542;
                        p51[1] = p55;
                      } else {
                        if (p7 < 355) {
                          p7 = 154;
                          p40 = p19[154, "length"];
                        } else {
                          p7 = 237;
                          p47 = p15[237, "push"];
                        }
                      }
                    } else {
                      if (p7 > 360) {
                        if (362 < p7) {
                          p7 = 63;
                          p55 = 128 + p56;
                        } else {
                          if (p7 < 362) {
                            p7 = 88;
                            p42 = p22[88, "getUint32"];
                          } else {
                            p7 = 377;
                            p21 = 0;
                          }
                        }
                      } else {
                        if (358 < p7) {
                          if (359 < p7) {
                            p50 = p17 >> (p7 -= 29) - 321;
                          } else {
                            p7 = 439;
                            p43 = p["Array"][439, "prototype"];
                          }
                        } else {
                          if (358 > p7) {
                            p7 = 491;
                            p43 = p4(p42, p41)(...p44);
                          } else {
                            p7 = 151;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if (404 > p7) {
                if (p7 > 394) {
                  if (398 > p7) {
                    if (p7 > 396) {
                      p7 = 145;
                      p45 = new p["Uint8Array"](p47);
                    } else {
                      if (p7 < 396) {
                        p7 = 579;
                        p10.ﹱﱡ = p40;
                      } else {
                        p7 = 298;
                        p44 = p41[298, "length"];
                      }
                    }
                  } else {
                    if (401 < p7) {
                      if (402 < p7) {
                        p7 = 31;
                        p50 = p27(p59, 1);
                      } else {
                        p7 = 214;
                        p59 = 128 + p61;
                      }
                    } else {
                      if (399 < p7) {
                        if (400 < p7) {
                          p40 += p13;
                          p7 = 2;
                        } else {
                          p7 = 638;
                          ++p34;
                        }
                      } else {
                        if (398 < p7) {
                          p7 = 574;
                          p41 = [];
                        } else {
                          p7 = 529;
                          p49 = p10.ﱡﱢ[1];
                        }
                      }
                    }
                  }
                } else {
                  if (p7 > 384) {
                    if (388 > p7) {
                      if (386 > p7) {
                        p7 = 524;
                      } else {
                        if (p7 < 387) {
                          p7 = 620;
                        } else {
                          p7 -= 117;
                          p40 = p4(p39, p14)("getUserAgentButton");
                        }
                      }
                    } else {
                      if (391 < p7) {
                        if (393 > p7) {
                          p7 = 111;
                          p20 = 0;
                        } else {
                          if (p7 < 394) {
                            if (p43) {
                              p7 = 156;
                            } else {
                              p7 = 636;
                            }
                          } else {
                            p7 = 109;
                            p15[109, p32] = p43;
                          }
                        }
                      } else {
                        if (389 < p7) {
                          if (390 < p7) {
                            p7 = 233;
                            p45 = p10.ءﹱ;
                          } else {
                            p7 = 498;
                            p55 = p25[498, p54];
                          }
                        } else {
                          if (389 > p7) {
                            p7 = 208;
                            p54 = p10.ﱡﱢ[3];
                          } else {
                            p7 = 70;
                          }
                        }
                      }
                    }
                  } else {
                    if (375 > p7) {
                      if (367 > p7) {
                        if (365 > p7) {
                          p7 = 28;
                          p51 = [];
                        } else {
                          if (366 > p7) {
                            p7 = 160;
                            ++p14;
                          } else {
                            p7 = 626;
                            p28 = p52;
                          }
                        }
                      } else {
                        if (369 > p7) {
                          if (368 > p7) {
                            p7 = 169;
                            p45 = p10.ﱡ[169, p32];
                          } else {
                            p7 = 126;
                            p44 += "";
                          }
                        } else {
                          if (p7 > 370) {
                            if (p7 < 373) {
                              if (372 > p7) {
                                p7 = 124;
                                p42 = p10.ﹱﱡ(1);
                              } else {
                                p7 = 260;
                                p41 = p10.ﱡ[260, "length"];
                              }
                            } else {
                              if (374 > p7) {
                                p7 = 537;
                                p52 = p25[537, p51];
                              } else {
                                p7 += 183;
                                p40 = p34;
                              }
                            }
                          } else {
                            if (370 > p7) {
                              p7 = 170;
                              p45 = p44 - p50;
                            } else {
                              p7 += 190;
                              p43 = p10.ﹱﱡ[p7 - 559];
                            }
                          }
                        }
                      }
                    } else {
                      if (p7 > 381) {
                        if (383 < p7) {
                          return p44;
                        } else {
                          if (383 > p7) {
                            p40 = ~p41;
                            p7 = 273;
                          } else {
                            p7 += 23;
                            p29[p7 - 405] = p45;
                          }
                        }
                      } else {
                        if (379 < p7) {
                          if (380 < p7) {
                            p7 = 533;
                            p49 = p15[533, "push"];
                          } else {
                            p7 = 264;
                            p40 = [];
                          }
                        } else {
                          if (377 < p7) {
                            if (378 < p7) {
                              p7 = 60;
                              ++p14;
                            } else {
                              p7 = 486;
                              p40 = new p["Uint32Array"](p41);
                            }
                          } else {
                            if (376 > p7) {
                              p54 = p52 + p55;
                              p7 = 504;
                            } else {
                              if (p7 < 377) {
                                p7 += 10;
                                p46 = p49;
                              } else {
                                p7 = 628;
                                p43 = p21 < 80;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                if (p7 > 443) {
                  if (p7 > 474) {
                    if (478 > p7) {
                      if (476 > p7) {
                        if (p42) {
                          p7 = 173;
                        } else {
                          p7 = 371;
                        }
                      } else {
                        if (476 < p7) {
                          p7 = 123;
                        } else {
                          p55[(p7 -= 168) - 305] = p5;
                        }
                      }
                    } else {
                      if (p7 < 480) {
                        if (479 > p7) {
                          p7 = 419;
                          p40 = ~p41;
                        } else {
                          p7 = 168;
                          p32 = 0;
                        }
                      } else {
                        if (p7 > 481) {
                          if (483 > p7) {
                            p7 = 292;
                            p43 = "sha1(value+盐):";
                          } else {
                            p7 = 319;
                            p50 = p10.ﱡﱢ[2];
                          }
                        } else {
                          if (481 > p7) {
                            p7 = 255;
                            p21 = p6;
                          } else {
                            p42 = typeof p10.ﹱﱡ;
                            p7 = 566;
                          }
                        }
                      }
                    }
                  } else {
                    if (464 < p7) {
                      if (p7 > 471) {
                        if (p7 < 473) {
                          p7 = 332;
                          p52 = 192 + p54;
                        } else {
                          if (p7 > 473) {
                            p7 = 161;
                            p41[1] = p42;
                          } else {
                            p7 = 77;
                            p45 = p10.ﱡיּ[77, "prototype"];
                          }
                        }
                      } else {
                        if (468 > p7) {
                          if (p7 < 466) {
                            return;
                          } else {
                            if (p7 > 466) {
                              p7 = 531;
                              p40 = p15[531, "call"];
                            } else {
                              p7 = 362;
                              p30 = p44;
                            }
                          }
                        } else {
                          if (470 > p7) {
                            if (469 > p7) {
                              p7 = 385;
                              p48 = function (...ﹲיּ) {
                                return f(215, this, arguments, f3(), p6, p6, ...ﹲיּ);
                              };
                            } else {
                              p7 = 461;
                              p42 = p13;
                            }
                          } else {
                            if (470 < p7) {
                              p7 = 373;
                              p51 = p21 - 3;
                            } else {
                              return p31;
                            }
                          }
                        }
                      }
                    } else {
                      if (p7 < 455) {
                        if (450 < p7) {
                          if (p7 > 453) {
                            p49 = p48 + p34;
                            p7 = 430;
                          } else {
                            if (452 < p7) {
                              p7 = 523;
                              p40 = new p["Uint8Array"](p15);
                            } else {
                              if (452 > p7) {
                                if (p40) {
                                  p7 = 411;
                                } else {
                                  p7 = 582;
                                }
                              } else {
                                p7 = 624;
                                p10.ﱡ[624, p34] = p45;
                              }
                            }
                          }
                        } else {
                          if (p7 < 447) {
                            if (p7 < 445) {
                              p7 = 180;
                              p44 = p33 < 5;
                            } else {
                              if (446 > p7) {
                                p7 = 413;
                              } else {
                                p7 = 201;
                                f2(2).ﹱﱡ[p45] = 69;
                              }
                            }
                          } else {
                            if (p7 > 448) {
                              if (450 > p7) {
                                p7 = 382;
                                p41 = p29[0];
                              } else {
                                p7 = 438;
                                p48 = p49;
                              }
                            } else {
                              if (447 < p7) {
                                p7 = 305;
                                ++p10.ءﹱ;
                              } else {
                                p7 = 454;
                                p48 = p10.ﱣ + p33;
                              }
                            }
                          }
                        }
                      } else {
                        if (458 > p7) {
                          if (p7 < 456) {
                            p7 = 528;
                            p46 = p33;
                          } else {
                            if (456 < p7) {
                              p7 = 234;
                              p41 = p13 + p14;
                            } else {
                              p7 = 274;
                              p48 = p4(p47, p["Math"])();
                            }
                          }
                        } else {
                          if (p7 < 460) {
                            if (p7 < 459) {
                              p7 = 372;
                              p40 = p32;
                            } else {
                              p7 -= 316;
                            }
                          } else {
                            if (p7 < 462) {
                              if (p7 < 461) {
                                p7 = 508;
                                p35 = 1;
                              } else {
                                p7 = 597;
                                p43 = p10.ﹱﱡ[1];
                              }
                            } else {
                              if (p7 < 463) {
                                p7 = 310;
                                p42 = p41 >>> 6;
                              } else {
                                if (463 < p7) {
                                  p48 = "请关闭开发者工具" + p35;
                                  p7 = 487;
                                } else {
                                  p7 = 1;
                                  p43 = p10.ﹱﱡ[1, p33];
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if (434 < p7) {
                    if (p7 > 441) {
                      if (p7 < 443) {
                        if (p49) {
                          p7 = 141;
                        } else {
                          p7 = 175;
                        }
                      } else {
                        ++p34;
                        p7 = 477;
                      }
                    } else {
                      if (p7 > 439) {
                        if (p7 > 440) {
                          p7 = 96;
                          p48 = p49;
                        } else {
                          p7 = 345;
                          p41 = p["console"][345, "log"];
                        }
                      } else {
                        if (p7 < 438) {
                          if (p7 < 436) {
                            p7 = 8;
                            p52 = p10.ﱡﱢ[1];
                          } else {
                            if (436 < p7) {
                              p7 = 84;
                              p45 = p21;
                            } else {
                              p7 = 189;
                              p47 = p30[189, p21];
                            }
                          }
                        } else {
                          if (p7 > 438) {
                            p7 = 325;
                            p44 = p43[325, "map"];
                          } else {
                            if (p49) {
                              p7 = 122;
                            } else {
                              p7 = 103;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if (p7 > 424) {
                      if (431 < p7) {
                        if (p7 < 433) {
                          p7 = 168;
                        } else {
                          if (p7 < 434) {
                            ++p10.ءﹱ;
                            p7 = 269;
                          } else {
                            return;
                          }
                        }
                      } else {
                        if (428 > p7) {
                          if (p7 < 426) {
                            p7 = 437;
                            p46 = p4(p45, p29)(p22);
                          } else {
                            if (p7 < 427) {
                              p7 = 627;
                              p50 = p10.ﱡﱢ[1];
                            } else {
                              p48 = p46 | (p7 -= 124) - 303;
                            }
                          }
                        } else {
                          if (p7 > 429) {
                            if (430 < p7) {
                              ++p21;
                              p7 = 242;
                            } else {
                              p7 = 142;
                              p10.ﱣ = p49;
                            }
                          } else {
                            if (429 > p7) {
                              if (p50) {
                                p7 = 295;
                              } else {
                                p7 = 108;
                              }
                            } else {
                              p7 = 135;
                              p41 = [];
                            }
                          }
                        }
                      }
                    } else {
                      if (415 > p7) {
                        if (407 > p7) {
                          if (p7 > 405) {
                            p7 = 163;
                            p45 = p29[163, "pop"];
                          } else {
                            if (p7 > 404) {
                              return p42;
                            } else {
                              p7 = 137;
                              p17 = p40;
                            }
                          }
                        } else {
                          if (p7 < 409) {
                            if (407 < p7) {
                              p7 = 140;
                              p40 = p["Function"][140, "prototype"];
                            } else {
                              p7 = 376;
                              p49 = p24[376, p48];
                            }
                          } else {
                            if (411 > p7) {
                              if (p7 < 410) {
                                p42 = p18 + p33;
                                p7 = 463;
                              } else {
                                ++p10.ءﹱ;
                                p7 = 166;
                              }
                            } else {
                              if (p7 > 413) {
                                p7 = 90;
                                p40 = p14;
                              } else {
                                if (412 < p7) {
                                  p15 = (p7 -= 162) - 249;
                                } else {
                                  if (p7 < 412) {
                                    p7 = 485;
                                    p42 = p22[485, "getUint32"];
                                  } else {
                                    p7 = 594;
                                    p50 = p34 === 2;
                                  }
                                }
                              }
                            }
                          }
                        }
                      } else {
                        if (421 < p7) {
                          if (p7 > 423) {
                            p7 = 343;
                            p54 = -899497514;
                          } else {
                            if (422 < p7) {
                              p7 = 403;
                              p59 = p56 ^ p61;
                            } else {
                              p7 = 192;
                              p48 = p50;
                            }
                          }
                        } else {
                          if (419 < p7) {
                            if (p7 < 421) {
                              p7 = 418;
                            } else {
                              p7 = 625;
                              p16 = p51;
                            }
                          } else {
                            if (p7 > 417) {
                              if (p7 < 419) {
                                p7 = 443;
                                p48 = p34;
                              } else {
                                p7 = 53;
                                p29[3] = p40;
                              }
                            } else {
                              if (p7 < 416) {
                                p7 = 205;
                                p42 = function (...ﹲיּ) {
                                  return f(584, this, arguments, f3(), p6, p6, ...ﹲיּ);
                                };
                              } else {
                                if (p7 < 417) {
                                  p7 = 250;
                                  p48 = p47[250, "length"];
                                } else {
                                  p7 = 114;
                                  p43 += p44;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if (p7 < 203) {
              if (p7 < 173) {
                if (p7 < 165) {
                  if (163 < p7) {
                    p7 = 479;
                    p13 = p44;
                  } else {
                    if (162 < p7) {
                      p7 = 541;
                      p46 = p4(p45, p29)();
                    } else {
                      p7 = 596;
                      p43 = 128 << p44;
                    }
                  }
                } else {
                  if (168 < p7) {
                    if (171 > p7) {
                      if (170 > p7) {
                        p46 = p45 - p32;
                        p7 = 217;
                      } else {
                        p51 = p45 + 65;
                        p7 = 421;
                      }
                    } else {
                      if (171 < p7) {
                        p7 = 622;
                        p42 = p41[622, "buffer"];
                      } else {
                        p53 = p51 + p55;
                        p7 = 564;
                      }
                    }
                  } else {
                    if (167 > p7) {
                      if (165 < p7) {
                        p7 = 601;
                        f2(2).ﹱﱡ[p45] = 89;
                      } else {
                        return p53;
                      }
                    } else {
                      if (168 > p7) {
                        p7 = 543;
                        p16 = p44;
                      } else {
                        p7 = 588;
                        p44 = p32 < 1200;
                      }
                    }
                  }
                }
              } else {
                if (p7 > 192) {
                  if (p7 < 196) {
                    if (p7 > 194) {
                      p7 = 262;
                    } else {
                      if (p7 < 194) {
                        p7 += 85;
                      } else {
                        p7 = 193;
                        p37 = function (...ﹲיּ) {
                          return f(48, this, arguments, f3(), p6, p6, ...ﹲיּ);
                        };
                      }
                    }
                  } else {
                    if (198 > p7) {
                      if (p7 > 196) {
                        p7 = 275;
                        p43 = p13[275, "charCodeAt"];
                      } else {
                        p7 = 178;
                        p14 = p6;
                      }
                    } else {
                      if (200 > p7) {
                        if (p7 < 199) {
                          p7 = 575;
                          p46 = p10.ﱡﱢ[2];
                        } else {
                          p40 = p["String"][p7 -= 183, "fromCharCode"];
                        }
                      } else {
                        if (p7 > 201) {
                          p7 = 37;
                          p56 = p53 ^ p58;
                        } else {
                          if (200 < p7) {
                            ++p10.ﱞﱣ;
                            p7 = 530;
                          } else {
                            p7 += 197;
                            p47 = p46[p7, "buffer"];
                          }
                        }
                      }
                    }
                  }
                } else {
                  if (183 > p7) {
                    if (176 > p7) {
                      if (p7 > 174) {
                        if (p48) {
                          p7 += 101;
                        } else {
                          p7 = 546;
                        }
                      } else {
                        if (p7 < 174) {
                          p7 = 212;
                          p44 = p10.ﱞﱣ;
                        } else {
                          p7 += 213;
                          p39 = p14[p7, "getElementById"];
                        }
                      }
                    } else {
                      if (p7 < 178) {
                        if (p7 < 177) {
                          p59 = p28[p7 -= 154, p58];
                        } else {
                          p7 = 317;
                          p40 = p15[317, "call"];
                        }
                      } else {
                        if (180 > p7) {
                          if (179 > p7) {
                            p7 = 68;
                            p40 = [];
                          } else {
                            return p49;
                          }
                        } else {
                          if (p7 < 181) {
                            if (p44) {
                              p7 = 614;
                            } else {
                              p7 = 445;
                            }
                          } else {
                            if (182 > p7) {
                              p7 = 224;
                              p41 = p40 >> 2;
                            } else {
                              if (p47) {
                                p7 = 327;
                              } else {
                                p7 = 322;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if (189 < p7) {
                      if (p7 < 191) {
                        p7 = 442;
                        p48 = p49;
                      } else {
                        if (p7 < 192) {
                          p7 = 338;
                          p33 = ('', 338) - 338;
                        } else {
                          if (p48) {
                            p7 = 97;
                          } else {
                            p7 = 514;
                          }
                        }
                      }
                    } else {
                      if (p7 > 187) {
                        if (p7 > 188) {
                          p7 = 427;
                          p46 = p45 + p47;
                        } else {
                          if (p49) {
                            p7 = 280;
                          } else {
                            p7 = 192;
                          }
                        }
                      } else {
                        if (p7 < 186) {
                          if (p7 < 184) {
                            p42 = p10.ﹱﱡ == p6;
                            p7 = 475;
                          } else {
                            if (184 < p7) {
                              if (p40) {
                                p7 = 153;
                              } else {
                                p7 += 106;
                              }
                            } else {
                              p7 = 175;
                              p48 = p50;
                            }
                          }
                        } else {
                          if (p7 > 186) {
                            p7 = 51;
                            p53 = -1894007588;
                          } else {
                            p7 = 604;
                            p45 = p19[604, "length"];
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if (p7 > 282) {
                if (p7 > 313) {
                  if (p7 < 317) {
                    if (p7 > 315) {
                      p7 = 431;
                      p45 = p21;
                    } else {
                      if (p7 < 315) {
                        p7 = 494;
                        p57 = p56 ^ 56320;
                      } else {
                        p7 = 497;
                      }
                    }
                  } else {
                    if (p7 < 319) {
                      if (p7 > 317) {
                        p7 = 95;
                        p24[95, p40] = p42;
                      } else {
                        p7 -= 6;
                        p41 = p4(p40, p15)(p["Uint8Array"]);
                      }
                    } else {
                      if (321 > p7) {
                        if (p7 < 320) {
                          p7 = 435;
                          p49 = p48 & p50;
                        } else {
                          p7 = 472;
                          p54 = p53 & 31;
                        }
                      } else {
                        if (p7 > 321) {
                          p7 = 24;
                          p49 = p16 ^ 55296;
                        } else {
                          return;
                        }
                      }
                    }
                  }
                } else {
                  if (294 > p7) {
                    if (286 > p7) {
                      if (284 < p7) {
                        p7 = 612;
                        p41 = p4(p40, p24)(p42);
                      } else {
                        if (284 > p7) {
                          return p40;
                        } else {
                          p7 = 27;
                          p57 = p21 - 14;
                        }
                      }
                    } else {
                      if (p7 < 288) {
                        if (p7 < 287) {
                          p7 = 188;
                          p48 = p49;
                        } else {
                          p7 = 482;
                          p41 = p["console"][482, "log"];
                        }
                      } else {
                        if (290 > p7) {
                          if (289 > p7) {
                            p7 = 570;
                            p41 = p["console"]['', 570, "log"];
                          } else {
                            p38 = p["console"][p7 -= 35, "log"];
                          }
                        } else {
                          if (292 < p7) {
                            if (p42) {
                              p7 = 344;
                            } else {
                              p7 = 530;
                            }
                          } else {
                            if (p7 > 291) {
                              p7 = 417;
                              p44 = p10.ﱢﹰ();
                            } else {
                              if (p7 < 291) {
                                return p55;
                              } else {
                                p7 = 128;
                                p10.ﱣ = 0;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if (304 > p7) {
                      if (300 < p7) {
                        if (302 > p7) {
                          p36 = !p39;
                          p7 = 434;
                        } else {
                          if (p7 < 303) {
                            p7 = 466;
                            p44 = p4(p43, p29)(0);
                          } else {
                            p7 = 316;
                            p29[316, p21] = p48;
                          }
                        }
                      } else {
                        if (298 < p7) {
                          if (p7 < 300) {
                            p7 = 508;
                          } else {
                            p7 = 538;
                            p50 = p10.ﱡﱢ[3];
                          }
                        } else {
                          if (297 > p7) {
                            if (p7 > 295) {
                              p7 = 552;
                              p54 = p53 & 63;
                            } else {
                              if (p7 < 295) {
                                p7 = 216;
                                p55[1] = p56;
                              } else {
                                p7 -= 189;
                                p51 = "0";
                              }
                            }
                          } else {
                            if (p7 < 298) {
                              p7 = 304;
                              p40 = p40 < p41;
                            } else {
                              p7 = 13;
                              p46 = p15[13, "call"];
                            }
                          }
                        }
                      }
                    } else {
                      if (p7 < 307) {
                        if (p7 < 305) {
                          if (p40) {
                            p7 = 197;
                          } else {
                            p7 = 45;
                          }
                        } else {
                          if (p7 < 306) {
                            p7 = 644;
                            f2(2).ﹱﱡ[p45] = 119;
                          } else {
                            p7 = 32;
                          }
                        }
                      } else {
                        if (309 > p7) {
                          if (p7 > 307) {
                            p7 = 521;
                            p57 = -1009589776;
                          } else {
                            p10.ﱞﱣ = (p7 -= 278) - 29;
                          }
                        } else {
                          if (310 < p7) {
                            if (312 > p7) {
                              p7 = 603;
                              p42 = p41[603, "length"];
                            } else {
                              if (312 < p7) {
                                p7 = 507;
                                p24[507, p41] = p42;
                              } else {
                                p7 = 176;
                                p58 = p57 | 0;
                              }
                            }
                          } else {
                            if (p7 > 309) {
                              p7 = 509;
                              p43 = p42 << 4;
                            } else {
                              p7 = 585;
                              p46 = p33;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                if (242 < p7) {
                  if (273 < p7) {
                    if (p7 > 280) {
                      if (p7 < 282) {
                        p7 = 555;
                        p54 = p13[555, "toString"];
                      } else {
                        p7 = 380;
                        p14 = p40;
                      }
                    } else {
                      if (277 > p7) {
                        if (275 < p7) {
                          p7 = 309;
                        } else {
                          if (275 > p7) {
                            p32 = p46 + p48;
                            p7 = 258;
                          } else {
                            p7 = 167;
                            p44 = p4(p43, p13)(p14);
                          }
                        }
                      } else {
                        if (279 > p7) {
                          if (278 > p7) {
                            p7 = 65;
                            p40 = p14;
                          } else {
                            p7 = 301;
                            p39 = p37();
                          }
                        } else {
                          if (p7 > 279) {
                            p7 = 422;
                            p50 = p34 === 2;
                          } else {
                            p7 = 152;
                            p42 = p33;
                          }
                        }
                      }
                    }
                  } else {
                    if (p7 < 254) {
                      if (p7 < 246) {
                        if (244 > p7) {
                          p7 -= 43;
                          p46 = new p["Uint32Array"](p29);
                        } else {
                          if (p7 < 245) {
                            p7 = 619;
                            p46 = p29[1];
                          } else {
                            p7 = 198;
                            p44 = p10.ﱡﱢ[1];
                          }
                        }
                      } else {
                        if (248 > p7) {
                          if (246 < p7) {
                            p7 = 333;
                          } else {
                            p7 = 563;
                            p58 = p54 + 65536;
                          }
                        } else {
                          if (249 < p7) {
                            if (252 < p7) {
                              p7 = 69;
                              p18 = function (...ﹲיּ) {
                                return f(534, this, arguments, f3(), p6, p6, ...ﹲיּ);
                              };
                            } else {
                              if (251 < p7) {
                                p7 = 404;
                                p40 = p10.ﹱﱡ[404, "length"];
                              } else {
                                if (250 < p7) {
                                  if (p3) {
                                    p7 = 532;
                                  } else {
                                    p7 = 460;
                                  }
                                } else {
                                  p45 = p44 - p48;
                                  p7 = 637;
                                }
                              }
                            }
                          } else {
                            if (p7 > 248) {
                              p7 = 641;
                              p43 = p32;
                            } else {
                              if (p48) {
                                p7 += 172;
                              } else {
                                p7 -= 115;
                              }
                            }
                          }
                        }
                      }
                    } else {
                      if (p7 < 264) {
                        if (p7 > 260) {
                          if (p7 < 262) {
                            return;
                          } else {
                            if (263 > p7) {
                              p7 -= 68;
                              p38 = p36();
                            } else {
                              p7 = 85;
                              p41 = p24[85, "length"];
                            }
                          }
                        } else {
                          if (257 > p7) {
                            if (255 > p7) {
                              p7 = 261;
                              p39 = p4(p38, p["console"])("[测试]:常规版\n[作者微信]: CyyWon\n[微信公众号]: https://mp.weixin.qq.com/s/FY7Qy4FXP1yXSGHtSSnnvg");
                            } else {
                              if (p7 > 255) {
                                p7 = 131;
                                ++p20;
                              } else {
                                p7 = 354;
                                p22 = p6;
                              }
                            }
                          } else {
                            if (259 > p7) {
                              if (257 < p7) {
                                p7 = 100;
                                p46 = p32 > 999;
                              } else {
                                p7 = 162;
                                p44 = 24 - p47;
                              }
                            } else {
                              if (260 > p7) {
                                if (p40) {
                                  p7 = 81;
                                } else {
                                  p7 = 598;
                                }
                              } else {
                                p40 = p40 < p41;
                                p7 = 132;
                              }
                            }
                          }
                        }
                      } else {
                        if (p7 > 270) {
                          if (272 > p7) {
                            p7 = 252;
                            p16 = p40;
                          } else {
                            if (p7 > 272) {
                              p7 = 518;
                              p29[2] = p40;
                            } else {
                              p7 = 230;
                              p46 = p23 << 2;
                            }
                          }
                        } else {
                          if (p7 < 267) {
                            if (265 < p7) {
                              p7 = 632;
                              p51 = p4(p50, p26)();
                            } else {
                              if (p7 < 265) {
                                p7 = 457;
                                p15 = p40;
                              } else {
                                p7 = 231;
                                p40 = p10.ءﹱ[231, "all"];
                              }
                            }
                          } else {
                            if (269 > p7) {
                              if (p7 > 267) {
                                p7 = 290;
                                p55 = p51 | p57;
                              } else {
                                p7 = 285;
                                p42 = new p["Uint8Array"](p43);
                              }
                            } else {
                              if (p7 < 270) {
                                p7 = 307;
                                f2(2).ﹱﱡ[p42] = 42;
                              } else {
                                p7 = 39;
                                p16 = p40;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if (p7 < 214) {
                    if (206 > p7) {
                      if (p7 < 204) {
                        p7 = 356;
                        p55 = 128 + p56;
                      } else {
                        if (p7 < 205) {
                          p7 = 396;
                          p41 = p4(p40, p15)(p43);
                        } else {
                          p7 = 474;
                        }
                      }
                    } else {
                      if (p7 < 208) {
                        if (p7 > 206) {
                          if (p42) {
                            p7 = 121;
                          } else {
                            p7 = 183;
                          }
                        } else {
                          p7 = 23;
                          p53 = p29[4];
                        }
                      } else {
                        if (p7 > 209) {
                          if (212 < p7) {
                            p51 = p49 | p53;
                            p7 = 232;
                          } else {
                            if (p7 < 212) {
                              if (p7 > 210) {
                                p7 = 157;
                                p26 = p41;
                              } else {
                                p7 = 6;
                                p47 = p45 | p50;
                              }
                            } else {
                              ++p10.ﱞﱣ;
                              p7 = 623;
                            }
                          }
                        } else {
                          if (208 < p7) {
                            p7 = 423;
                            p61 = p25[423, p60];
                          } else {
                            p7 = 165;
                            p53 = p51 ^ p54;
                          }
                        }
                      }
                    }
                  } else {
                    if (p7 < 224) {
                      if (217 > p7) {
                        if (215 > p7) {
                          p7 = 351;
                          p55[1] = p59;
                        } else {
                          if (216 > p7) {
                            p7 = 428;
                            p50 = p13 < 16;
                          } else {
                            p7 = 476;
                            p55[2] = p5;
                          }
                        }
                      } else {
                        if (219 > p7) {
                          if (218 > p7) {
                            p7 = 580;
                            p47 = p46 + 30;
                          } else {
                            p7 = 506;
                            p46 = function (...ﹲיּ) {
                              return f(55, this, arguments, f3(), p6, p6, ...ﹲיּ);
                            };
                          }
                        } else {
                          if (220 < p7) {
                            if (222 > p7) {
                              p7 = 470;
                              p31 = p51;
                            } else {
                              if (p7 < 223) {
                                p47 = p46 ^ p48;
                                p7 = 300;
                              } else {
                                if (p40) {
                                  p7 = 409;
                                } else {
                                  p7 = 646;
                                }
                              }
                            }
                          } else {
                            if (220 > p7) {
                              p7 = 181;
                              p40 = p19[181, "length"];
                            } else {
                              p40 += "";
                              p7 = 283;
                            }
                          }
                        }
                      }
                    } else {
                      if (p7 < 234) {
                        if (p7 < 227) {
                          if (p7 < 225) {
                            p7 = 186;
                            p42 = p24[186, p41];
                          } else {
                            if (p7 < 226) {
                              ++p14;
                              p7 = 80;
                            } else {
                              p7 = 244;
                              p22 = p60;
                            }
                          }
                        } else {
                          if (p7 < 229) {
                            if (228 > p7) {
                              p7 = 243;
                              p44 = [];
                            } else {
                              p7 = 32;
                            }
                          } else {
                            if (p7 > 230) {
                              if (232 < p7) {
                                ++p10.ءﹱ;
                                p7 = 522;
                              } else {
                                if (232 > p7) {
                                  p7 = 341;
                                  p17 = p40;
                                } else {
                                  p7 = 236;
                                  p56 = p10.ﱡﱢ[2];
                                }
                              }
                            } else {
                              if (p7 < 230) {
                                p7 = 247;
                                p22 = function (...ﹲיּ) {
                                  return f(41, this, arguments, f3(), p6, p6, ...ﹲיּ);
                                };
                              } else {
                                p7 = 512;
                                p45 = new p["Uint8Array"](p46);
                              }
                            }
                          }
                        }
                      } else {
                        if (240 < p7) {
                          if (241 < p7) {
                            p7 = 630;
                          } else {
                            p7 = 433;
                            p42 = p10.ءﹱ;
                          }
                        } else {
                          if (237 > p7) {
                            if (235 < p7) {
                              p7 = 116;
                              p58 = p10.ﱡﱢ[3];
                            } else {
                              if (p7 > 234) {
                                p7 = 516;
                                p43[0] = p5;
                              } else {
                                p7 = 271;
                                p40 = p10.ﱣﹱ(p41);
                              }
                            }
                          } else {
                            if (p7 < 239) {
                              if (p7 < 238) {
                                p7 = 306;
                                p48 = p4(p47, p15)(p16);
                              } else {
                                p7 = 399;
                                p25 = p40;
                              }
                            } else {
                              if (240 > p7) {
                                p7 = 480;
                                p20 = p6;
                              } else {
                                p7 = 113;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
})(globalThis, true, false, (() => {}).call.bind((() => {}).bind), null);