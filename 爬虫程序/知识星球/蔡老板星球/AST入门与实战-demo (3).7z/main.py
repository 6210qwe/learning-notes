import os
import mitmproxy.http
 
 
print('脚本初始化成功')
 
 
def request(flow: mitmproxy.http.HTTPFlow):
    pass
 
 
def response(flow: mitmproxy.http.HTTPFlow):
    if flow.request.method == "GET" and "g-Then-And" in flow.request.url:
        with open("ob.js","w",encoding = "utf-8") as fp:
            fp.write(flow.response.text)
        
        os.system("node main.js ob.js ok.js")
        with open("ok.js","r",encoding = "utf-8") as fp:
            flow.response.text = fp.read();
        print (flow.request.method,flow.request.url)
       # html = flow.response.text
       # flow.response.text = html
