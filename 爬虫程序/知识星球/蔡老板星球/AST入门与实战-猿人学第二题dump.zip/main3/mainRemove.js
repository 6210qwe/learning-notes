﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const { assignmentExpression, ifStatement } = require('babel-types');
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const template = require("@babel/template").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./decodeResult.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });

let ast = parser.parse(sourceCode);


console.time("处理完毕，耗时");

let count = 0;

const SimplifyifStatement =
{

    IfStatement: {
        /**  @param  {NodePath} path */
        enter(path) {

            let { test, consequent, alternate } = path.node;

            let consePath = path.get('consequent.body.0');

            let sourceCode1 = consePath.toString();

            let alterPath = path.get('alternate.body.0');

            if (!alterPath) {
                if (!sourceCode1.includes("newArray")) {
                    path.remove();
                }
                else {
                    path.replaceWithMultiple(consequent.body);
                }
            }

            else {
                let sourceCode2 = alterPath.toString();
                if (!sourceCode1.includes("newArray") && !sourceCode2.includes("newArray")) {
                    path.remove();
                    return;
                }
                if (sourceCode1.includes("newArray") && !sourceCode2.includes("newArray")) {
                    path.replaceWithMultiple(consequent.body);
                    return;
                }
                if (!sourceCode1.includes("newArray") && sourceCode2.includes("newArray")) {
                    path.replaceWithMultiple(alternate.body);
                    return;
                }
            }




        },
    }
}


traverse(ast, SimplifyifStatement);

const removeDeadCode1 =
{
    AssignmentExpression(path) {
        if (path.get("left").toString().includes("newArray")) {
            path.remove();
        }
    },

}

traverse(ast, removeDeadCode1);


const removeDeadCode2 =
{
    IfStatement(path) {

        let { test, consequent, alternate } = path.node;

        if (alternate && alternate.body.length == 0)
        {
            //if (!types.isIdentifier(test))
            //{
            //    console.log(path.toString())
            //    path.insertBefore(types.ExpressionStatement(expression = test));
            //}
            //path.replaceWithMultiple(consequent.body);

            path.node.alternate = null;
        }
    },
        
}

traverse(ast, removeDeadCode2);



console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });






fs.writeFile(decodeFile, code, (err) => { });