﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const template = require("@babel/template").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./decodeResult.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });

let ast = parser.parse(sourceCode);


console.time("处理完毕，耗时");

let callName = types.Identifier("clb");
let CallNODE = template(`A[B] = 1;`);


const addAlternateNode =
{
	/**  @param  {NodePath} path */  //每个插件前都要加哈。
	IfStatement(path) {
		if (path.node.alternate == null) {
			path.node.alternate = types.BlockStatement([]);
		}
	}
}
traverse(ast, addAlternateNode);


let count = 0;
const dumpifStatement =
{
	/**  @param  {NodePath} path */  //每个插件前都要加哈。
	IfStatement(path) {


		let { test, consequent, alternate } = path.node;



		let A = types.identifier("newArray");
		let B = types.numericLiteral(count);

		let CallNode = CallNODE({ "A": A, "B": B, });



		consequent.body.unshift(CallNode);

		count++;

		B = types.numericLiteral(count);

		CallNode = CallNODE({ "A": A, "B": B, });

		alternate.body.unshift(CallNode);

		count++;

	}

}


traverse(ast, dumpifStatement);





console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });

code = `if (!window.top.newArray)
{
	window.top.newArray = new Array();
}\n` + code;




fs.writeFile(decodeFile, code, (err) => { });