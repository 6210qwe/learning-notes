import random
import threading
import time

import requests

cap_key = ""
requests.packages.urllib3.disable_warnings()


def cap_create_task(websiteURL, websiteKey, taskType, isInvisible=False) -> str:
    url = "https://api.ez-captcha.com/createTask"
    data = {
        "clientKey": cap_key,
        "task": {
            "websiteURL": websiteURL,
            "websiteKey": websiteKey,
            "type": taskType,
        }
    }
    try:
        result = requests.post(url, json=data, verify=False, timeout=8)
        result = result.json()
        #print(result)
        taskId = result.get('taskId')
        if taskId is not None:
            return taskId

    except Exception as e:
        print(e)


def cap_get_response(taskID: str):
    times = 0
    start_time = time.time()
    while times < 120:
        try:
            url = "https://api.ez-captcha.com/getTaskResult"
            data = {
                "clientKey": cap_key,
                "taskId": taskID
            }
            print ("结果获取中.....")
            result = requests.post(url, json=data, verify=False, timeout=8).json()
            solution = result.get('solution', {})
            if solution:
                response = solution.get('token')
                if response:
                    #print(f"消耗时间 {time.time()-start_time}s", response)
                    return response
        except Exception as e:
            print(e)
        times += 1
        time.sleep(1)
    return ""


def demo():
    sitekey = "a5f74b19-9e45-40e0-b45d-47ff91b7a6c2"
    url = "https://accounts.hcaptcha.com"
    type = "HcaptchaTaskProxyless"
    taskId = cap_create_task(url, sitekey, type, False)
    res = cap_get_response(taskId)
    if res != "":
        data = {"email":"","g-recaptcha-response":res,"h-captcha-response":res}
        url = "https://accounts.hcaptcha.com/demo"

        result = requests.post(url, data=data, verify=False, timeout=8)

        print(result.text)




if __name__ == '__main__':
    demo()
