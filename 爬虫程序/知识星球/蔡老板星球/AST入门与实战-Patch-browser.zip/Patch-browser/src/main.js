import fs from 'fs';
import {VM, VMScript} from 'vm2';
import catvm2 from './environment/browser_settings.js';
import path from 'path';
import {fileURLToPath} from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const catvm2code = catvm2({proxy: true});
const codefile = `${__dirname}/code.js`;
//定义一个沙箱的全局变量，用来输出沙箱的运行结果
const caigou = {};
const vm = new VM({
    sandbox: {caigou},
})
const script = new VMScript(catvm2code + fs.readFileSync(codefile), `${__dirname}/调试.js`);
debugger
vm.run(script);
console.log(caigou)
debugger


