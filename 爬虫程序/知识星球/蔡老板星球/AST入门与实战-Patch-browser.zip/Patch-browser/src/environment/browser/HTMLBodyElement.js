HTMLBodyElement = function HTMLBodyElement() {
    environment.error()
};
environment.safefunction(HTMLBodyElement);
environment.rename(HTMLBodyElement);

Object.defineProperty(HTMLBodyElement.prototype, "text", {
    value: ``,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "link", {
    value: ``,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "vLink", {
    value: ``,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "aLink", {
    value: ``,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "bgColor", {
    value: ``,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "background", {
    value: ``,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onblur", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onerror", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onfocus", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onload", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onresize", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onscroll", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onafterprint", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onbeforeprint", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onbeforeunload", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onhashchange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onlanguagechange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onmessage", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onmessageerror", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onoffline", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "ononline", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onpagehide", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onpageshow", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onpopstate", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onrejectionhandled", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onstorage", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onunhandledrejection", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(HTMLBodyElement.prototype, "onunload", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});

environment.safefunction(Element.prototype.after);
environment.rename(Element.prototype.after, "after");
environment.safefunction(Element.prototype.animate);
environment.rename(Element.prototype.animate, "animate");
environment.safefunction(Element.prototype.append);
environment.rename(Element.prototype.append, "append");
environment.safefunction(Element.prototype.attachShadow);
environment.rename(Element.prototype.attachShadow, "attachShadow");
environment.safefunction(Element.prototype.before);
environment.rename(Element.prototype.before, "before");
environment.safefunction(Element.prototype.closest);
environment.rename(Element.prototype.closest, "closest");
environment.safefunction(Element.prototype.computedStyleMap);
environment.rename(Element.prototype.computedStyleMap, "computedStyleMap");
environment.safefunction(Element.prototype.getAttribute);
environment.rename(Element.prototype.getAttribute, "getAttribute");
environment.safefunction(Element.prototype.getAttributeNS);
environment.rename(Element.prototype.getAttributeNS, "getAttributeNS");
environment.safefunction(Element.prototype.getAttributeNames);
environment.rename(Element.prototype.getAttributeNames, "getAttributeNames");
environment.safefunction(Element.prototype.getAttributeNode);
environment.rename(Element.prototype.getAttributeNode, "getAttributeNode");
environment.safefunction(Element.prototype.getAttributeNodeNS);
environment.rename(Element.prototype.getAttributeNodeNS, "getAttributeNodeNS");
environment.safefunction(Element.prototype.getBoundingClientRect);
environment.rename(Element.prototype.getBoundingClientRect, "getBoundingClientRect");
environment.safefunction(Element.prototype.getClientRects);
environment.rename(Element.prototype.getClientRects, "getClientRects");
environment.safefunction(Element.prototype.getElementsByClassName);
environment.rename(Element.prototype.getElementsByClassName, "getElementsByClassName");
environment.safefunction(Element.prototype.getElementsByTagName);
environment.rename(Element.prototype.getElementsByTagName, "getElementsByTagName");
environment.safefunction(Element.prototype.getElementsByTagNameNS);
environment.rename(Element.prototype.getElementsByTagNameNS, "getElementsByTagNameNS");
environment.safefunction(Element.prototype.hasAttribute);
environment.rename(Element.prototype.hasAttribute, "hasAttribute");
environment.safefunction(Element.prototype.hasAttributeNS);
environment.rename(Element.prototype.hasAttributeNS, "hasAttributeNS");
environment.safefunction(Element.prototype.hasAttributes);
environment.rename(Element.prototype.hasAttributes, "hasAttributes");
environment.safefunction(Element.prototype.hasPointerCapture);
environment.rename(Element.prototype.hasPointerCapture, "hasPointerCapture");
environment.safefunction(Element.prototype.insertAdjacentElement);
environment.rename(Element.prototype.insertAdjacentElement, "insertAdjacentElement");
environment.safefunction(Element.prototype.insertAdjacentHTML);
environment.rename(Element.prototype.insertAdjacentHTML, "insertAdjacentHTML");
environment.safefunction(Element.prototype.insertAdjacentText);
environment.rename(Element.prototype.insertAdjacentText, "insertAdjacentText");
environment.safefunction(Element.prototype.matches);
environment.rename(Element.prototype.matches, "matches");
environment.safefunction(Element.prototype.prepend);
environment.rename(Element.prototype.prepend, "prepend");
environment.safefunction(Element.prototype.querySelector);
environment.rename(Element.prototype.querySelector, "querySelector");
environment.safefunction(Element.prototype.querySelectorAll);
environment.rename(Element.prototype.querySelectorAll, "querySelectorAll");
environment.safefunction(Element.prototype.releasePointerCapture);
environment.rename(Element.prototype.releasePointerCapture, "releasePointerCapture");
environment.safefunction(Element.prototype.remove);
environment.rename(Element.prototype.remove, "remove");
environment.safefunction(Element.prototype.removeAttribute);
environment.rename(Element.prototype.removeAttribute, "removeAttribute");
environment.safefunction(Element.prototype.removeAttributeNS);
environment.rename(Element.prototype.removeAttributeNS, "removeAttributeNS");
environment.safefunction(Element.prototype.removeAttributeNode);
environment.rename(Element.prototype.removeAttributeNode, "removeAttributeNode");
environment.safefunction(Element.prototype.replaceWith);
environment.rename(Element.prototype.replaceWith, "replaceWith");
environment.safefunction(Element.prototype.requestFullscreen);
environment.rename(Element.prototype.requestFullscreen, "requestFullscreen");
environment.safefunction(Element.prototype.requestPointerLock);
environment.rename(Element.prototype.requestPointerLock, "requestPointerLock");
environment.safefunction(Element.prototype.scroll);
environment.rename(Element.prototype.scroll, "scroll");
environment.safefunction(Element.prototype.scrollBy);
environment.rename(Element.prototype.scrollBy, "scrollBy");
environment.safefunction(Element.prototype.scrollIntoView);
environment.rename(Element.prototype.scrollIntoView, "scrollIntoView");
environment.safefunction(Element.prototype.scrollIntoViewIfNeeded);
environment.rename(Element.prototype.scrollIntoViewIfNeeded, "scrollIntoViewIfNeeded");
environment.safefunction(Element.prototype.scrollTo);
environment.rename(Element.prototype.scrollTo, "scrollTo");
environment.safefunction(Element.prototype.setAttribute);
environment.rename(Element.prototype.setAttribute, "setAttribute");
environment.safefunction(Element.prototype.setAttributeNS);
environment.rename(Element.prototype.setAttributeNS, "setAttributeNS");
environment.safefunction(Element.prototype.setAttributeNode);
environment.rename(Element.prototype.setAttributeNode, "setAttributeNode");
environment.safefunction(Element.prototype.setAttributeNodeNS);
environment.rename(Element.prototype.setAttributeNodeNS, "setAttributeNodeNS");
environment.safefunction(Element.prototype.setPointerCapture);
environment.rename(Element.prototype.setPointerCapture, "setPointerCapture");
environment.safefunction(Element.prototype.toggleAttribute);
environment.rename(Element.prototype.toggleAttribute, "toggleAttribute");
environment.safefunction(Element.prototype.webkitMatchesSelector);
environment.rename(Element.prototype.webkitMatchesSelector, "webkitMatchesSelector");
environment.safefunction(Element.prototype.webkitRequestFullScreen);
environment.rename(Element.prototype.webkitRequestFullScreen, "webkitRequestFullScreen");
environment.safefunction(Element.prototype.webkitRequestFullscreen);
environment.rename(Element.prototype.webkitRequestFullscreen, "webkitRequestFullscreen");
environment.safefunction(Element.prototype.getAnimations);
environment.rename(Element.prototype.getAnimations, "getAnimations");
environment.safefunction(Element.prototype.replaceChildren);
environment.rename(Element.prototype.replaceChildren, "replaceChildren");
Object.setPrototypeOf(HTMLBodyElement.prototype, HTMLElement.prototype);

Object.setPrototypeOf(document.body, HTMLBodyElement.prototype);
document = environment.proxy(document, "document");
