Element = function Element (){environment.error()};
environment.safefunction(Element);
environment.rename(Element);

Object.defineProperty(Element.prototype,"namespaceURI",{value: `http://www.w3.org/1999/xhtml`,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"prefix",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"localName",{value: `body`,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"tagName",{value: `BODY`,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"id",{value: ``,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"className",{value: ``,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"classList",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"slot",{value: ``,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"attributes",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"shadowRoot",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"part",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"assignedSlot",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"innerHTML",{value: `
<div class="waper">
  <div class="main">
    <h2><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAABwCAYAAACXdMcoAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAE4FJREFUeNrkXWlwFNe17hmN9gXQBggMKMISDouQgswSyQg/E+OYQJxA4jzzMBHYVPHAC/i5HF4BdnkJXorCD8ckGIP1w0sqMY4hhhSbcQRCsjYjZBZH1oKEEFosJNACGs2887V1hzut7tHMdI96ZnKqbs3W093znXO/e865594xWK1WQWsxGAwOP3d0zcG+Kz1co1t2GgTcu4v3KPu7TYIXiRM/yODia3dBtmpkGIpi8gHADQ6eG1xUgFXmubX/eKva3uBTwDsAXQ5wg0KTHiM8/vjjEcnJyRF4/swzzzQqAG+VKEDuuUeUYNCT450AXQ5kIx4J2MgHHngg8c4775wSFxc3JyQkJCEiImKO0WiMcnBd8/Xr14+azeb2tra2srq6uvILFy5Uv/nmm5fp0cwBbpFRjlWtAuywxgutm0s3IA86wA3o75GB1IKphb7xxhs/qKqq+l1vb2+9VWMhRXzy9ddf/3dubm4qXSsM1+u/bmD/fQQwpUt6mkvA2zDSA3gHgPOgi4BnZ2dHffnllw+RpR63DpGQYq/W1ta++t577zElhFALUlCATwPPg86sPOTUqVMPeMK6XZGenp7zJSUlyzIzM4dLFOAy+N4KPAM9aMmSJcNbWlr2WL1IYADFxcUPZ2RkRPZTkMvgexvwdqCvWbMmtru7u9TqpXLr1q0aUsDC1NTUUAn4PgW8HafPmzcvqrOz8wurDwhRUHF6enqIhPN9DniR06urq5+z+pAcOHBgav+9uwy8Uc/YiffLd+7cOYHk94IPyaRJkzIHiaAVxajzvbObDnjkkUf+T/AxiYmJyXLXrzfqDLho8e+//35KZGTkfF8DPioq6l53v+sNFm9csGDBc4IPSkBAwMhp06YF+ArwdnmYTZs2xUZHR/9a64v09fUJ165dE27cuCGQC+ixH0N+faAvZSdtNLN48eIfa3nixsZG4cqVK0JXV9f3lmU0MusURowYAV4WH7XIqyPpVlpaestBNtOrspO2ARWK7+joOET8PleL63777bci8CaTSQgMDBQfGfD4nRaLRewJuL9hw4YJsbGx4Gm3r9fW1rabeusadDBnwNdzBsqOZlauXBmlFehNTU1CQ0ODEBoaKoSEhNgBD6B54NHQI6qqqsSeQPdg+x4eg4KCBr1ec3PzH1977bWN7qaITTrSjGHp0qU/1IrPz507JwIXFhYmBAcHi+DJAc/A55XQ3d0tjgXsczR8jykASkT75JNPfvLdd981fPTRR5crKyt7nLV0b5uBMkycOHGOFie6evWqCCCAAvhKwCuBzwOOxo7jKQoDdEJCwtj169cX0tu9/ZMl0lkr3xhc4+PjNfHdL126JAIN2gDoUuB5jpWCLAWbf5SOW6mpqb+ip39xMDPl/VSTnJwcGBERodqjAVejhYeH2wZV1qAIqcXzTQlwpZwT0diCRx99NCw3N/eaGmsfaj/ebvJ6+fLlsQSIasUzLwYNQPPPWQP47Dn7nFcSegca6y2gK0ZZ/Hs4JicnZ7q7YOtp8bacxtSpU8doccLW1lYbkACYgcwsnXdtmeWz93jLVnqUSkpKykJ6+FztfeuWqxkzZswEtSfp7e0VvRFm4TzYUtB58FljiuJ7hFzP4Bv5/v+Vnp4e4IvAi1ZPvvNYtSci124ArYi5bhlrdxTsKSlDrtE1hpP/nuirFi/QwDpe7TkocrTjdADDqESrUjs5SUpKmi6orNvUjWooQhyl9iQdHR12ESpzHT0JOiQ6Ovo+X7N4W9RKHsKowfIasOienh7Zz/E+gh+p96KmmteF3rooLi5OqabTu6mGQIpU+sxsNgsFBQVCYWGhcOLECaGkpEQcSHlBylfqr6OxiNOT4NN1Yp9++ulwNXSjG9UQWIrAV1RUCO3t7XaDaHFxsV1e/fr166JfzYBH87Sl85KRkRHvrrXrbfHBcu/DPURQxJJTyBaiQZBN5HMnLC3A52RYj/G0REVFRfpSAMUDL5sIR3oXwiJJ3qIBNqyfpxjeo2HgM7rxZtErVwNwOgioEOmH4G6AyQPPrBqgMk+GVwijGdagIIT4npSurq5uXwPeYUbv5s2bIpAMcDk6Ad0w4PnAh1ENS/XymUmthQygyycDKPJSWhQoaEAYz2cc+R7AHysNmpTcUK2kurr6uppkmVEna0fxZ73cAaAXPpRXCNvteJ23dvaInuPBQfbW22+/fd0XLd7a2tqaL/cB8urS3LicInh6UUqKwUPyBPh0zm9IrL4GvGjx5BoWyH2I8gt+Sk46IyTldEeZSHwH/r7WlRTd3d0lgg9NhPBTZZZXX321CHUp0oNQ8wIeB/CwVjReCTyIrmQgtRRSZomv5WpsCjh69GgPBUq75UCaMGGCDXQGPJo7peAYhLWW5ubmCl8EnoHf9/HHH++Q+3Ds2LFIRImgI0fDgJdavjMKwCDsAY+mRlA59aebV4O2bt26GiWrnzZtmujDM8pRohs9gN+7d2+jGldSb4tHXN/3yiuvvECADnC6AXpqaqoNfL4MwxXwtQae3NR/7t+/3+yLVGM3yO7YsaO1qKhohdyBAD05OXlAPYyeFk8D6zG1Ho0IvNQl06K5qIC+WbNmHbhy5cof5Q5CSR4KTKVW7gz4npgCpIG1yO0kFT+3qyPVMLoR25IlSza2tbUdVIpm+ZIMV36o1lJaWnpW0GAzCb1XhNi4Pj8/v3vhwoXL2tvbP5NLnLnRozQHnpR+7amnnmpSO7DqDbxVCfyOjo5/sINQnoeEl1JOZiiF+H1fS0uL1V8s3g78kydP9mRnZz/c1NT0p87OzpN1dXVXpCUczoKudaqAQD8saLB9itvAa7ykXlp5aykrK7s5cuTIDfPnz1+cl5f3AksFs/y7s+BrPRN14cKFUjVg8/jobfEOuf/06dM3o6Ojl16+fFnM30jpxhlBDKCR3NqyZUudFvzubcBLd2ESVqxYEUPu5H8gw1hfXz9gis8ZBWgF/I0bN/5aXFxsFjTaHsvkRYADbOORI0d+nJKSstxsNluoa19mVo65VqxxuuOOO1w6OXI9zqxpGkzo2n9WGJ98FngGvvHYsWOZWVlZR1k+Hrn5s2fPipPXsHbU2oAjx48f7xLwWlSXnThxokDQcDM4b9nLwEj+cczcuXP38/OsKOHDLBIr44DlwrVEfY0rno3aBcbU+ypWr179naBi6Y03cry4SVBOTs5iAjgMgDK3saamxjbHylZu4BHZSqzyc9aDQgCmRug+NmrlRnoD8DZrj4yMDExOTv4fPjBiRavMfWQWzxSA1+fPn3cKVNCWtPbSBao6t2zZssNaWrs3AC/uzrR169a7goODE/lQHxErW4XNFy5J1y2BdjDwesrqS0pKVhYWFvZpae16Da4GnmKE77fEul9uUOQzeoxy+PfYc3g7WCQ8atQoRfrB+VwtciIX9nezZ88u1dra9QB+wN6S48aNC01KSlolPZAtq+GrCxyVdaD0D17PxIkTFcHF2OCsa0m96BhFzn8QVObelQxBU6pxENTY/HTh9g6qQffcc8/wvLy8TQTGAOcceXh+5on9CCn18Esl8dnFixfFwlY17iN5QS1PPPHEyv5tbz0iJq0AdzIaFellxowZYTt37vx1WlraCwRetNwXASab8OarDPgegeuyyJSnpObmZhF86kkuKwDnO3Xq1Lu5ubkdgn3tu6ZUYxxCCw+cMmVKBAUiv8zPzz9D4O9QAp0Jqg0wKMIPZ9UGdommfm+HNWb9aOglZLEiBbF7xIDtyKfHZ9jrJjQ09A5h4M56Bt0t3kULDyDAQ8nCF82cOfNl8khGO3sdzLdiDxoETcyFZMEUfw/sNcDmy/zQW7DBBKwfqQaco7OzU1Qm21qFCfJBcF9xflL4XO7+0SxeZfGDWTi2g6Vu+xtMl2VmZu5xBXQIVoKkp6eLlgqvhVk/436+10kXBvPcjx4CtxNKZMWsUAAG49raWuHTTz8VQWduanh4+JhFixbFCbd3UnVrE2dPcrwsh2dlZYVv27btV9OnT99EIMSruQCqyuAutrS02E2EACCpW8l7O8z68R0oCsrAe8hygragQCgTCkBaAsdCSUyBdP//S0azobW1lU/qszli1ZxvVAm4kffHCfBhRUVFv/3888/Pg8PVgs5k1qxZYhUxQGJTgQAPlit1N5m/L90sgud/fnMIFg2zxQ5s0oWo6T8rKyv3v/7663cJ3++gHdjfmwO43z5kq/54C7e5hRg0QSnHjx8/68yg6fJNEpjkeoqAwDoZ9UjB56kHjQdeqgT+Ee8z4Pkl+lFRURkbNmw43djYuOedd95JE25v5B8oGQM8tuGnHOCBFCmGHjp06KcUVpfNmTNnt1YWLicAhSLcAeCDMgA+P80nraFnPUC6aE26xEe6iI3R2MiRI3+xatWqk+QhHaTx4F78bkF5I3+DM56f0UVasf11xL59+7KpKx5fsGDBX+QCIE8ILDQ7O1sEiIEP2uHBl6MeaZPb7UNpaQ8P2rBhwzJp0P07DdRfklu8pH8zf56GHCrAFeB5K8fJg3bt2pVKmv/0oYceOki8mzbUiR6AD8uH5cIFBO8zj4flY6Qej1QJ7D2mJBwP91IJcBlv6865c+fmEviVFCtsJBnP0ZDiX1nw5zQ6a+Vr164dTT5x7mOPPXaaND9PzwQ+QKcfLirBEfjSVST8D2fHsMAMWyC6WjBFvSYiJSVl48svv3yBsNm9d+/e6cIgf2XBzh/gIHsocnlCQkLI0aNHH165cuVnFMJPFbxEQBWYAkSkydxBqXsptTIGNqgJSmL7mcHaJ02apOp+qPdPIfd51Zo1ayaFhYUVffHFF52O3M4AB8GQacWKFdEHDhz4W1JS0lot9g/TWkANAB9WDz9fblDjJ1aYhQN0jA1QGHoL3FVYvBZCCriLqHDd8uXLe8vLy4tramr65MAPUJqcWLduXfz27duPkJX/SPBiAbDUK8XnqL9RohYAjwFYGjilpaUJ48aN0/y+RowYkU2eXttbb71VJJfPD1AYSIMOHjy4m/zYLMFHBPsEI5WMPSilW6cAdLayhFEMQAe9IB/kKSHws5qamt4pLi7ulgJvlHEvAz788MO0mJiYnws+JrBcuJtsmSWsGpTCcjx4DmsH8ImJiap53QkqDFm9evUvuEBrwEDKrN1EXBfc0NBwjCgmQ/BRgWV/9dVXIu8j1cCykCw5FhcXJybfhkLa29tPDh8+fAGyzsL3exFbpBYv8vuePXsyfBl0liaeMWMGIk6bqwlrh6UjP0Pex5DdC4KuZcuWDeewNgiSFyLN3Hfffc8JfiJYOci2LAf4aKAjT+7qIScUbP5Q6tPzGTbD5s2bE6hbzPcX4OHro/KAgQ6rB/UMtUyePDlbms20s3jSzP2CnwlmngA4SyWzbbaGUmhMSZfmcHjgDeQPZ/ob8BhIMbgyF1OLymE3eP5uhxZPA88YfwMevnx8/O1sNdsPZ4gpL3rp0qWRPK2rmkXxFWGRrXSSfChl9uzZsXJejeDPCkBUqxfNMBk9enS0HNWwbmnyR+CxBw4reNVR+XF2sQb/gm4syh+Bh99ObvKQ+++8hIWFhTrK1fitgG70tHhSunKSTG6rKn8RWLzOwNtVo9kBTwFGh78Cjx1A9BxcOzs7sQeCDfx/G6phm8zpIWCSgoKCCoFbwS4FvtdfgQfoav5QUYWlF+7bty9j48aNLcLt8j87r8bqz1TD0gdDId3d3f/65ptv3j58+PChZ5999hK9ZRYkf1Fn4gnf34H3VIIMVNLc3PxxdXX18fz8/IL169dXCbcnPfqEgf8LaLN467+DxaNOHmlitdLX13ejtbX1s0uXLp0sKSkpfP755ysbGxtvCberia0SsAdMdttRTXt7e7U/A09W+QIBv8XV73V1dZU3NTWdqKqqOp2Xl3eGgL4s3P5LUYsCyA4XrPEWbyHg6/0Z+Nra2vKpUx3XZHV0dBSQgrBB0Vck5z744IO6oqKiHokVW5wA2WH9vB3w5eXlWLnht8CXlZVVL1y40Pb62rVrR65evVpE3Fx25syZi9u3b68nyuiVAZdfjOAW0ANKydlzagEU3QUSb2n2H9reJODlbdu23TtlypSRxcXF/9q8eXODjOVaJKA6ooxBV4QorXG1++PH/mAqKCcnZ9TNmzcvWf1ALBZLL1n0R+TW/WzmzJkxyFVRw5+HYDaElVebBPs6d2mptfMbaQ6yZZjS1mGsiiz4ySefHEPd8Lgvgt3S0vJ34uS1u3btmpWUlDSCfk94P9j8QgLVILsCtDPA28BPSEiIpC75uNlsbvVmoNva2g6XlpZuePfdd+cQjcCqIzjLli4aMA41yErAG2TAF7ibNM2bNy9869atP588efIaPRYi8N4G9cISGvy+rq+vr6SBsvall166IuNpWBzws9VZkD0p/OCqZP382lXjpk2bxsyfP39mYmLiPfHx8fd7YgkOPA0CuYr85goa6C9WVFTUbdmypWEQV84tb8PTALsDPG/9/NJCu5Vud999d8iDDz4Ym56e/gOTyRRIP8QwevToRArNhzm6MLlvFQizydO4RZFfNT32vfjii40KHoYcqI4s2aq3RasFXk4BBoXXBpljFX+3zHMlMJ0B1uuBlgPemclt/scbFBQiOAG4s0pQAtNp9LwNaEeRq7tAGQRtN1fQbCMeb5f/F2AALhRrj5BR6yAAAAAASUVORK5CYII=" alt="">当前您正在使用隐身窗口</h2>
    <p>隐身窗口可以：</p>
    <p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAMCAYAAAC5tzfZAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAShJREFUeNpi/P//PwM6EA9glAJSGUA8/+WG//fR5ZkYsAAuHs4KQxv9cF5+ngps8kxYbFHRNddxUdRQYNC10HEA8rXR1bBAFTIDKQ0gluET4A2XUpAE8RkkZMUZBEQEKoDyy4Hch0B8F+jcH4xi/gyJjIyMFfzC/AzcvFwMIBvEpEXhpr55/obh3vUHDF8+fWX4/OEzw98/fytZVHWVnwCd8xcoz4zN/SKSImAMA2cPnf/MdKT5zm5gCFYC+X8ZCIO6U10Pd4MDYobvxo1QjXg1TPfZsBIl9M4ePH8Ln47zRy7ewgjyj+8/aeLT9PHdJzUMTQLC/MpIal4C8VQgfgIT4Bfiw9TEK8B7A6qo+fvXH85A90/6+vmbB5DfAMSX+IT4rsLUAgQYADbCXZfik88/AAAAAElFTkSuQmCC" alt="">上网不留痕迹，隐身模式上网不留任何记录</p>
    <p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAMCAYAAAC5tzfZAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAShJREFUeNpi/P//PwM6EA9glAJSGUA8/+WG//fR5ZkYsAAuHs4KQxv9cF5+ngps8kxYbFHRNddxUdRQYNC10HEA8rXR1bBAFTIDKQ0gluET4A2XUpAE8RkkZMUZBEQEKoDyy4Hch0B8F+jcH4xi/gyJjIyMFfzC/AzcvFwMIBvEpEXhpr55/obh3vUHDF8+fWX4/OEzw98/fytZVHWVnwCd8xcoz4zN/SKSImAMA2cPnf/MdKT5zm5gCFYC+X8ZCIO6U10Pd4MDYobvxo1QjXg1TPfZsBIl9M4ePH8Ln47zRy7ewgjyj+8/aeLT9PHdJzUMTQLC/MpIal4C8VQgfgIT4Bfiw9TEK8B7A6qo+fvXH85A90/6+vmbB5DfAMSX+IT4rsLUAgQYADbCXZfik88/AAAAAElFTkSuQmCC" alt="">小号多开，新建隐身窗口再打开网站小号，不串号</p>
    <p class="mt27">隐身窗口不会记录任何上网痕迹，但会保留您下载的文件和添加的收藏。</p>
    <p>隐身窗口会默认禁用所有扩展以保护隐私，如有需启用的扩展，可以在扩展管理页面设置。</p>
  </div>
</div>

<script src="chrome://resources/js/cr.js"></script>

<script type="text/javascript">
    cr.define('ntp', function () {
        'use strict';
        /**
        * Invoked at startup once the DOM is available to initialize the app.
        */
        function initialize() {
            // Load the current theme colors.
            themeChanged();
        }

        function themeChanged(hasAttribution) {
            chrome.send('getWallpaper')
        }
        function loadWallpaper(installed, x, y) {
            if (installed == true) {
                document.body.style.backgroundImage = "url(chrome://theme/IDR_THEME_NTP_BACKGROUND?" + Date.now() + ")";
                updateWallpaperOffset(x, y);
            }
            else {
                document.body.style.backgroundImage = "";
                document.body.style.backgroundPosition = "";
            }
        }

        function updateWallpaperOffset(x, y) {
            document.body.style.backgroundPosition = (-x) + "px " + (-y) + "px";
        }

        // Return an object with all the exports
        return {
            initialize: initialize,
            themeChanged: themeChanged,
            loadWallpaper: loadWallpaper,
            updateWallpaperOffset: updateWallpaperOffset
        };
    });

    // publish ntp globals
    var themeChanged = ntp.themeChanged;
    var loadWallpaper = ntp.loadWallpaper;
    var updateWallpaperOffset = ntp.updateWallpaperOffset;

    document.addEventListener('DOMContentLoaded', ntp.initialize);
</script>

`,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"outerHTML",{value: `<body>
<div class="waper">
  <div class="main">
    <h2><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAABwCAYAAACXdMcoAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAE4FJREFUeNrkXWlwFNe17hmN9gXQBggMKMISDouQgswSyQg/E+OYQJxA4jzzMBHYVPHAC/i5HF4BdnkJXorCD8ckGIP1w0sqMY4hhhSbcQRCsjYjZBZH1oKEEFosJNACGs2887V1hzut7tHMdI96ZnKqbs3W093znXO/e865594xWK1WQWsxGAwOP3d0zcG+Kz1co1t2GgTcu4v3KPu7TYIXiRM/yODia3dBtmpkGIpi8gHADQ6eG1xUgFXmubX/eKva3uBTwDsAXQ5wg0KTHiM8/vjjEcnJyRF4/swzzzQqAG+VKEDuuUeUYNCT450AXQ5kIx4J2MgHHngg8c4775wSFxc3JyQkJCEiImKO0WiMcnBd8/Xr14+azeb2tra2srq6uvILFy5Uv/nmm5fp0cwBbpFRjlWtAuywxgutm0s3IA86wA3o75GB1IKphb7xxhs/qKqq+l1vb2+9VWMhRXzy9ddf/3dubm4qXSsM1+u/bmD/fQQwpUt6mkvA2zDSA3gHgPOgi4BnZ2dHffnllw+RpR63DpGQYq/W1ta++t577zElhFALUlCATwPPg86sPOTUqVMPeMK6XZGenp7zJSUlyzIzM4dLFOAy+N4KPAM9aMmSJcNbWlr2WL1IYADFxcUPZ2RkRPZTkMvgexvwdqCvWbMmtru7u9TqpXLr1q0aUsDC1NTUUAn4PgW8HafPmzcvqrOz8wurDwhRUHF6enqIhPN9DniR06urq5+z+pAcOHBgav+9uwy8Uc/YiffLd+7cOYHk94IPyaRJkzIHiaAVxajzvbObDnjkkUf+T/AxiYmJyXLXrzfqDLho8e+//35KZGTkfF8DPioq6l53v+sNFm9csGDBc4IPSkBAwMhp06YF+ArwdnmYTZs2xUZHR/9a64v09fUJ165dE27cuCGQC+ixH0N+faAvZSdtNLN48eIfa3nixsZG4cqVK0JXV9f3lmU0MusURowYAV4WH7XIqyPpVlpaestBNtOrspO2ARWK7+joOET8PleL63777bci8CaTSQgMDBQfGfD4nRaLRewJuL9hw4YJsbGx4Gm3r9fW1rabeusadDBnwNdzBsqOZlauXBmlFehNTU1CQ0ODEBoaKoSEhNgBD6B54NHQI6qqqsSeQPdg+x4eg4KCBr1ec3PzH1977bWN7qaITTrSjGHp0qU/1IrPz507JwIXFhYmBAcHi+DJAc/A55XQ3d0tjgXsczR8jykASkT75JNPfvLdd981fPTRR5crKyt7nLV0b5uBMkycOHGOFie6evWqCCCAAvhKwCuBzwOOxo7jKQoDdEJCwtj169cX0tu9/ZMl0lkr3xhc4+PjNfHdL126JAIN2gDoUuB5jpWCLAWbf5SOW6mpqb+ip39xMDPl/VSTnJwcGBERodqjAVejhYeH2wZV1qAIqcXzTQlwpZwT0diCRx99NCw3N/eaGmsfaj/ebvJ6+fLlsQSIasUzLwYNQPPPWQP47Dn7nFcSegca6y2gK0ZZ/Hs4JicnZ7q7YOtp8bacxtSpU8doccLW1lYbkACYgcwsnXdtmeWz93jLVnqUSkpKykJ6+FztfeuWqxkzZswEtSfp7e0VvRFm4TzYUtB58FljiuJ7hFzP4Bv5/v+Vnp4e4IvAi1ZPvvNYtSci124ArYi5bhlrdxTsKSlDrtE1hpP/nuirFi/QwDpe7TkocrTjdADDqESrUjs5SUpKmi6orNvUjWooQhyl9iQdHR12ESpzHT0JOiQ6Ovo+X7N4W9RKHsKowfIasOienh7Zz/E+gh+p96KmmteF3rooLi5OqabTu6mGQIpU+sxsNgsFBQVCYWGhcOLECaGkpEQcSHlBylfqr6OxiNOT4NN1Yp9++ulwNXSjG9UQWIrAV1RUCO3t7XaDaHFxsV1e/fr166JfzYBH87Sl85KRkRHvrrXrbfHBcu/DPURQxJJTyBaiQZBN5HMnLC3A52RYj/G0REVFRfpSAMUDL5sIR3oXwiJJ3qIBNqyfpxjeo2HgM7rxZtErVwNwOgioEOmH4G6AyQPPrBqgMk+GVwijGdagIIT4npSurq5uXwPeYUbv5s2bIpAMcDk6Ad0w4PnAh1ENS/XymUmthQygyycDKPJSWhQoaEAYz2cc+R7AHysNmpTcUK2kurr6uppkmVEna0fxZ73cAaAXPpRXCNvteJ23dvaInuPBQfbW22+/fd0XLd7a2tqaL/cB8urS3LicInh6UUqKwUPyBPh0zm9IrL4GvGjx5BoWyH2I8gt+Sk46IyTldEeZSHwH/r7WlRTd3d0lgg9NhPBTZZZXX321CHUp0oNQ8wIeB/CwVjReCTyIrmQgtRRSZomv5WpsCjh69GgPBUq75UCaMGGCDXQGPJo7peAYhLWW5ubmCl8EnoHf9/HHH++Q+3Ds2LFIRImgI0fDgJdavjMKwCDsAY+mRlA59aebV4O2bt26GiWrnzZtmujDM8pRohs9gN+7d2+jGldSb4tHXN/3yiuvvECADnC6AXpqaqoNfL4MwxXwtQae3NR/7t+/3+yLVGM3yO7YsaO1qKhohdyBAD05OXlAPYyeFk8D6zG1Ho0IvNQl06K5qIC+WbNmHbhy5cof5Q5CSR4KTKVW7gz4npgCpIG1yO0kFT+3qyPVMLoR25IlSza2tbUdVIpm+ZIMV36o1lJaWnpW0GAzCb1XhNi4Pj8/v3vhwoXL2tvbP5NLnLnRozQHnpR+7amnnmpSO7DqDbxVCfyOjo5/sINQnoeEl1JOZiiF+H1fS0uL1V8s3g78kydP9mRnZz/c1NT0p87OzpN1dXVXpCUczoKudaqAQD8saLB9itvAa7ykXlp5aykrK7s5cuTIDfPnz1+cl5f3AksFs/y7s+BrPRN14cKFUjVg8/jobfEOuf/06dM3o6Ojl16+fFnM30jpxhlBDKCR3NqyZUudFvzubcBLd2ESVqxYEUPu5H8gw1hfXz9gis8ZBWgF/I0bN/5aXFxsFjTaHsvkRYADbOORI0d+nJKSstxsNluoa19mVo65VqxxuuOOO1w6OXI9zqxpGkzo2n9WGJ98FngGvvHYsWOZWVlZR1k+Hrn5s2fPipPXsHbU2oAjx48f7xLwWlSXnThxokDQcDM4b9nLwEj+cczcuXP38/OsKOHDLBIr44DlwrVEfY0rno3aBcbU+ypWr179naBi6Y03cry4SVBOTs5iAjgMgDK3saamxjbHylZu4BHZSqzyc9aDQgCmRug+NmrlRnoD8DZrj4yMDExOTv4fPjBiRavMfWQWzxSA1+fPn3cKVNCWtPbSBao6t2zZssNaWrs3AC/uzrR169a7goODE/lQHxErW4XNFy5J1y2BdjDwesrqS0pKVhYWFvZpae16Da4GnmKE77fEul9uUOQzeoxy+PfYc3g7WCQ8atQoRfrB+VwtciIX9nezZ88u1dra9QB+wN6S48aNC01KSlolPZAtq+GrCxyVdaD0D17PxIkTFcHF2OCsa0m96BhFzn8QVObelQxBU6pxENTY/HTh9g6qQffcc8/wvLy8TQTGAOcceXh+5on9CCn18Esl8dnFixfFwlY17iN5QS1PPPHEyv5tbz0iJq0AdzIaFellxowZYTt37vx1WlraCwRetNwXASab8OarDPgegeuyyJSnpObmZhF86kkuKwDnO3Xq1Lu5ubkdgn3tu6ZUYxxCCw+cMmVKBAUiv8zPzz9D4O9QAp0Jqg0wKMIPZ9UGdommfm+HNWb9aOglZLEiBbF7xIDtyKfHZ9jrJjQ09A5h4M56Bt0t3kULDyDAQ8nCF82cOfNl8khGO3sdzLdiDxoETcyFZMEUfw/sNcDmy/zQW7DBBKwfqQaco7OzU1Qm21qFCfJBcF9xflL4XO7+0SxeZfGDWTi2g6Vu+xtMl2VmZu5xBXQIVoKkp6eLlgqvhVk/436+10kXBvPcjx4CtxNKZMWsUAAG49raWuHTTz8VQWduanh4+JhFixbFCbd3UnVrE2dPcrwsh2dlZYVv27btV9OnT99EIMSruQCqyuAutrS02E2EACCpW8l7O8z68R0oCsrAe8hygragQCgTCkBaAsdCSUyBdP//S0azobW1lU/qszli1ZxvVAm4kffHCfBhRUVFv/3888/Pg8PVgs5k1qxZYhUxQGJTgQAPlit1N5m/L90sgud/fnMIFg2zxQ5s0oWo6T8rKyv3v/7663cJ3++gHdjfmwO43z5kq/54C7e5hRg0QSnHjx8/68yg6fJNEpjkeoqAwDoZ9UjB56kHjQdeqgT+Ee8z4Pkl+lFRURkbNmw43djYuOedd95JE25v5B8oGQM8tuGnHOCBFCmGHjp06KcUVpfNmTNnt1YWLicAhSLcAeCDMgA+P80nraFnPUC6aE26xEe6iI3R2MiRI3+xatWqk+QhHaTx4F78bkF5I3+DM56f0UVasf11xL59+7KpKx5fsGDBX+QCIE8ILDQ7O1sEiIEP2uHBl6MeaZPb7UNpaQ8P2rBhwzJp0P07DdRfklu8pH8zf56GHCrAFeB5K8fJg3bt2pVKmv/0oYceOki8mzbUiR6AD8uH5cIFBO8zj4flY6Qej1QJ7D2mJBwP91IJcBlv6865c+fmEviVFCtsJBnP0ZDiX1nw5zQ6a+Vr164dTT5x7mOPPXaaND9PzwQ+QKcfLirBEfjSVST8D2fHsMAMWyC6WjBFvSYiJSVl48svv3yBsNm9d+/e6cIgf2XBzh/gIHsocnlCQkLI0aNHH165cuVnFMJPFbxEQBWYAkSkydxBqXsptTIGNqgJSmL7mcHaJ02apOp+qPdPIfd51Zo1ayaFhYUVffHFF52O3M4AB8GQacWKFdEHDhz4W1JS0lot9g/TWkANAB9WDz9fblDjJ1aYhQN0jA1QGHoL3FVYvBZCCriLqHDd8uXLe8vLy4tramr65MAPUJqcWLduXfz27duPkJX/SPBiAbDUK8XnqL9RohYAjwFYGjilpaUJ48aN0/y+RowYkU2eXttbb71VJJfPD1AYSIMOHjy4m/zYLMFHBPsEI5WMPSilW6cAdLayhFEMQAe9IB/kKSHws5qamt4pLi7ulgJvlHEvAz788MO0mJiYnws+JrBcuJtsmSWsGpTCcjx4DmsH8ImJiap53QkqDFm9evUvuEBrwEDKrN1EXBfc0NBwjCgmQ/BRgWV/9dVXIu8j1cCykCw5FhcXJybfhkLa29tPDh8+fAGyzsL3exFbpBYv8vuePXsyfBl0liaeMWMGIk6bqwlrh6UjP0Pex5DdC4KuZcuWDeewNgiSFyLN3Hfffc8JfiJYOci2LAf4aKAjT+7qIScUbP5Q6tPzGTbD5s2bE6hbzPcX4OHro/KAgQ6rB/UMtUyePDlbms20s3jSzP2CnwlmngA4SyWzbbaGUmhMSZfmcHjgDeQPZ/ob8BhIMbgyF1OLymE3eP5uhxZPA88YfwMevnx8/O1sNdsPZ4gpL3rp0qWRPK2rmkXxFWGRrXSSfChl9uzZsXJejeDPCkBUqxfNMBk9enS0HNWwbmnyR+CxBw4reNVR+XF2sQb/gm4syh+Bh99ObvKQ+++8hIWFhTrK1fitgG70tHhSunKSTG6rKn8RWLzOwNtVo9kBTwFGh78Cjx1A9BxcOzs7sQeCDfx/G6phm8zpIWCSgoKCCoFbwS4FvtdfgQfoav5QUYWlF+7bty9j48aNLcLt8j87r8bqz1TD0gdDId3d3f/65ptv3j58+PChZ5999hK9ZRYkf1Fn4gnf34H3VIIMVNLc3PxxdXX18fz8/IL169dXCbcnPfqEgf8LaLN467+DxaNOHmlitdLX13ejtbX1s0uXLp0sKSkpfP755ysbGxtvCberia0SsAdMdttRTXt7e7U/A09W+QIBv8XV73V1dZU3NTWdqKqqOp2Xl3eGgL4s3P5LUYsCyA4XrPEWbyHg6/0Z+Nra2vKpUx3XZHV0dBSQgrBB0Vck5z744IO6oqKiHokVW5wA2WH9vB3w5eXlWLnht8CXlZVVL1y40Pb62rVrR65evVpE3Fx25syZi9u3b68nyuiVAZdfjOAW0ANKydlzagEU3QUSb2n2H9reJODlbdu23TtlypSRxcXF/9q8eXODjOVaJKA6ooxBV4QorXG1++PH/mAqKCcnZ9TNmzcvWf1ALBZLL1n0R+TW/WzmzJkxyFVRw5+HYDaElVebBPs6d2mptfMbaQ6yZZjS1mGsiiz4ySefHEPd8Lgvgt3S0vJ34uS1u3btmpWUlDSCfk94P9j8QgLVILsCtDPA28BPSEiIpC75uNlsbvVmoNva2g6XlpZuePfdd+cQjcCqIzjLli4aMA41yErAG2TAF7ibNM2bNy9869atP588efIaPRYi8N4G9cISGvy+rq+vr6SBsvall166IuNpWBzws9VZkD0p/OCqZP382lXjpk2bxsyfP39mYmLiPfHx8fd7YgkOPA0CuYr85goa6C9WVFTUbdmypWEQV84tb8PTALsDPG/9/NJCu5Vud999d8iDDz4Ym56e/gOTyRRIP8QwevToRArNhzm6MLlvFQizydO4RZFfNT32vfjii40KHoYcqI4s2aq3RasFXk4BBoXXBpljFX+3zHMlMJ0B1uuBlgPemclt/scbFBQiOAG4s0pQAtNp9LwNaEeRq7tAGQRtN1fQbCMeb5f/F2AALhRrj5BR6yAAAAAASUVORK5CYII=" alt="">当前您正在使用隐身窗口</h2>
    <p>隐身窗口可以：</p>
    <p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAMCAYAAAC5tzfZAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAShJREFUeNpi/P//PwM6EA9glAJSGUA8/+WG//fR5ZkYsAAuHs4KQxv9cF5+ngps8kxYbFHRNddxUdRQYNC10HEA8rXR1bBAFTIDKQ0gluET4A2XUpAE8RkkZMUZBEQEKoDyy4Hch0B8F+jcH4xi/gyJjIyMFfzC/AzcvFwMIBvEpEXhpr55/obh3vUHDF8+fWX4/OEzw98/fytZVHWVnwCd8xcoz4zN/SKSImAMA2cPnf/MdKT5zm5gCFYC+X8ZCIO6U10Pd4MDYobvxo1QjXg1TPfZsBIl9M4ePH8Ln47zRy7ewgjyj+8/aeLT9PHdJzUMTQLC/MpIal4C8VQgfgIT4Bfiw9TEK8B7A6qo+fvXH85A90/6+vmbB5DfAMSX+IT4rsLUAgQYADbCXZfik88/AAAAAElFTkSuQmCC" alt="">上网不留痕迹，隐身模式上网不留任何记录</p>
    <p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAMCAYAAAC5tzfZAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAShJREFUeNpi/P//PwM6EA9glAJSGUA8/+WG//fR5ZkYsAAuHs4KQxv9cF5+ngps8kxYbFHRNddxUdRQYNC10HEA8rXR1bBAFTIDKQ0gluET4A2XUpAE8RkkZMUZBEQEKoDyy4Hch0B8F+jcH4xi/gyJjIyMFfzC/AzcvFwMIBvEpEXhpr55/obh3vUHDF8+fWX4/OEzw98/fytZVHWVnwCd8xcoz4zN/SKSImAMA2cPnf/MdKT5zm5gCFYC+X8ZCIO6U10Pd4MDYobvxo1QjXg1TPfZsBIl9M4ePH8Ln47zRy7ewgjyj+8/aeLT9PHdJzUMTQLC/MpIal4C8VQgfgIT4Bfiw9TEK8B7A6qo+fvXH85A90/6+vmbB5DfAMSX+IT4rsLUAgQYADbCXZfik88/AAAAAElFTkSuQmCC" alt="">小号多开，新建隐身窗口再打开网站小号，不串号</p>
    <p class="mt27">隐身窗口不会记录任何上网痕迹，但会保留您下载的文件和添加的收藏。</p>
    <p>隐身窗口会默认禁用所有扩展以保护隐私，如有需启用的扩展，可以在扩展管理页面设置。</p>
  </div>
</div>

<script src="chrome://resources/js/cr.js"></script>

<script type="text/javascript">
    cr.define('ntp', function () {
        'use strict';
        /**
        * Invoked at startup once the DOM is available to initialize the app.
        */
        function initialize() {
            // Load the current theme colors.
            themeChanged();
        }

        function themeChanged(hasAttribution) {
            chrome.send('getWallpaper')
        }
        function loadWallpaper(installed, x, y) {
            if (installed == true) {
                document.body.style.backgroundImage = "url(chrome://theme/IDR_THEME_NTP_BACKGROUND?" + Date.now() + ")";
                updateWallpaperOffset(x, y);
            }
            else {
                document.body.style.backgroundImage = "";
                document.body.style.backgroundPosition = "";
            }
        }

        function updateWallpaperOffset(x, y) {
            document.body.style.backgroundPosition = (-x) + "px " + (-y) + "px";
        }

        // Return an object with all the exports
        return {
            initialize: initialize,
            themeChanged: themeChanged,
            loadWallpaper: loadWallpaper,
            updateWallpaperOffset: updateWallpaperOffset
        };
    });

    // publish ntp globals
    var themeChanged = ntp.themeChanged;
    var loadWallpaper = ntp.loadWallpaper;
    var updateWallpaperOffset = ntp.updateWallpaperOffset;

    document.addEventListener('DOMContentLoaded', ntp.initialize);
</script>

</body>`,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollTop",{value: 0,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollLeft",{value: 0,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollWidth",{value: 987,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollHeight",{value: 411,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"clientTop",{value: 0,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"clientLeft",{value: 0,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"clientWidth",{value: 987,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"clientHeight",{value: 150,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"attributeStyleMap",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onbeforecopy",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onbeforecut",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onbeforepaste",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onsearch",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"elementTiming",{value: ``,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onfullscreenchange",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onfullscreenerror",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onwebkitfullscreenchange",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onwebkitfullscreenerror",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"onbeforexrselect",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"children",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"firstElementChild",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"lastElementChild",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"childElementCount",{value: 3,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"previousElementSibling",{value: {},writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"nextElementSibling",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"after",{value: function after(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"animate",{value: function animate(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"append",{value: function append(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"attachShadow",{value: function attachShadow(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"before",{value: function before(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"closest",{value: function closest(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"computedStyleMap",{value: function computedStyleMap(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getAttribute",{value: function getAttribute(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getAttributeNS",{value: function getAttributeNS(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getAttributeNames",{value: function getAttributeNames(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getAttributeNode",{value: function getAttributeNode(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getAttributeNodeNS",{value: function getAttributeNodeNS(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getBoundingClientRect",{value: function getBoundingClientRect(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getClientRects",{value: function getClientRects(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getElementsByClassName",{value: function getElementsByClassName(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getElementsByTagName",{value: function getElementsByTagName(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getElementsByTagNameNS",{value: function getElementsByTagNameNS(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"hasAttribute",{value: function hasAttribute(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"hasAttributeNS",{value: function hasAttributeNS(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"hasAttributes",{value: function hasAttributes(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"hasPointerCapture",{value: function hasPointerCapture(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"insertAdjacentElement",{value: function insertAdjacentElement(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"insertAdjacentHTML",{value: function insertAdjacentHTML(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"insertAdjacentText",{value: function insertAdjacentText(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"matches",{value: function matches(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"prepend",{value: function prepend(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"querySelector",{value: function querySelector(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"querySelectorAll",{value: function querySelectorAll(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"releasePointerCapture",{value: function releasePointerCapture(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"remove",{value: function remove(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"removeAttribute",{value: function removeAttribute(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"removeAttributeNS",{value: function removeAttributeNS(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"removeAttributeNode",{value: function removeAttributeNode(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"replaceWith",{value: function replaceWith(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"requestFullscreen",{value: function requestFullscreen(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"requestPointerLock",{value: function requestPointerLock(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scroll",{value: function scroll(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollBy",{value: function scrollBy(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollIntoView",{value: function scrollIntoView(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollIntoViewIfNeeded",{value: function scrollIntoViewIfNeeded(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"scrollTo",{value: function scrollTo(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"setAttribute",{value: function setAttribute(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"setAttributeNS",{value: function setAttributeNS(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"setAttributeNode",{value: function setAttributeNode(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"setAttributeNodeNS",{value: function setAttributeNodeNS(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"setPointerCapture",{value: function setPointerCapture(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"toggleAttribute",{value: function toggleAttribute(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"webkitMatchesSelector",{value: function webkitMatchesSelector(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"webkitRequestFullScreen",{value: function webkitRequestFullScreen(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"webkitRequestFullscreen",{value: function webkitRequestFullscreen(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaDescription",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaAtomic",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaAutoComplete",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaBusy",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaChecked",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaColCount",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaColIndex",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaColSpan",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaCurrent",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaDisabled",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaExpanded",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaHasPopup",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaHidden",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaKeyShortcuts",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaLabel",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaLevel",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaLive",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaModal",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaMultiLine",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaMultiSelectable",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaOrientation",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaPlaceholder",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaPosInSet",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaPressed",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaReadOnly",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaRelevant",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaRequired",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaRoleDescription",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaRowCount",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaRowIndex",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaRowSpan",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaSelected",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaSetSize",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaSort",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaValueMax",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaValueMin",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaValueNow",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"ariaValueText",{value: null,writable:undefined,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"getAnimations",{value: function getAnimations(){debugger;},writable:true,enumerable:true,configurable:true});
Object.defineProperty(Element.prototype,"replaceChildren",{value: function replaceChildren(){debugger;},writable:true,enumerable:true,configurable:true});

environment.safefunction(Element.prototype.after);
environment.rename(Element.prototype.after,"after");
environment.safefunction(Element.prototype.animate);
environment.rename(Element.prototype.animate,"animate");
environment.safefunction(Element.prototype.append);
environment.rename(Element.prototype.append,"append");
environment.safefunction(Element.prototype.attachShadow);
environment.rename(Element.prototype.attachShadow,"attachShadow");
environment.safefunction(Element.prototype.before);
environment.rename(Element.prototype.before,"before");
environment.safefunction(Element.prototype.closest);
environment.rename(Element.prototype.closest,"closest");
environment.safefunction(Element.prototype.computedStyleMap);
environment.rename(Element.prototype.computedStyleMap,"computedStyleMap");
environment.safefunction(Element.prototype.getAttribute);
environment.rename(Element.prototype.getAttribute,"getAttribute");
environment.safefunction(Element.prototype.getAttributeNS);
environment.rename(Element.prototype.getAttributeNS,"getAttributeNS");
environment.safefunction(Element.prototype.getAttributeNames);
environment.rename(Element.prototype.getAttributeNames,"getAttributeNames");
environment.safefunction(Element.prototype.getAttributeNode);
environment.rename(Element.prototype.getAttributeNode,"getAttributeNode");
environment.safefunction(Element.prototype.getAttributeNodeNS);
environment.rename(Element.prototype.getAttributeNodeNS,"getAttributeNodeNS");
environment.safefunction(Element.prototype.getBoundingClientRect);
environment.rename(Element.prototype.getBoundingClientRect,"getBoundingClientRect");
environment.safefunction(Element.prototype.getClientRects);
environment.rename(Element.prototype.getClientRects,"getClientRects");
environment.safefunction(Element.prototype.getElementsByClassName);
environment.rename(Element.prototype.getElementsByClassName,"getElementsByClassName");
environment.safefunction(Element.prototype.getElementsByTagName);
environment.rename(Element.prototype.getElementsByTagName,"getElementsByTagName");
environment.safefunction(Element.prototype.getElementsByTagNameNS);
environment.rename(Element.prototype.getElementsByTagNameNS,"getElementsByTagNameNS");
environment.safefunction(Element.prototype.hasAttribute);
environment.rename(Element.prototype.hasAttribute,"hasAttribute");
environment.safefunction(Element.prototype.hasAttributeNS);
environment.rename(Element.prototype.hasAttributeNS,"hasAttributeNS");
environment.safefunction(Element.prototype.hasAttributes);
environment.rename(Element.prototype.hasAttributes,"hasAttributes");
environment.safefunction(Element.prototype.hasPointerCapture);
environment.rename(Element.prototype.hasPointerCapture,"hasPointerCapture");
environment.safefunction(Element.prototype.insertAdjacentElement);
environment.rename(Element.prototype.insertAdjacentElement,"insertAdjacentElement");
environment.safefunction(Element.prototype.insertAdjacentHTML);
environment.rename(Element.prototype.insertAdjacentHTML,"insertAdjacentHTML");
environment.safefunction(Element.prototype.insertAdjacentText);
environment.rename(Element.prototype.insertAdjacentText,"insertAdjacentText");
environment.safefunction(Element.prototype.matches);
environment.rename(Element.prototype.matches,"matches");
environment.safefunction(Element.prototype.prepend);
environment.rename(Element.prototype.prepend,"prepend");
environment.safefunction(Element.prototype.querySelector);
environment.rename(Element.prototype.querySelector,"querySelector");
environment.safefunction(Element.prototype.querySelectorAll);
environment.rename(Element.prototype.querySelectorAll,"querySelectorAll");
environment.safefunction(Element.prototype.releasePointerCapture);
environment.rename(Element.prototype.releasePointerCapture,"releasePointerCapture");
environment.safefunction(Element.prototype.remove);
environment.rename(Element.prototype.remove,"remove");
environment.safefunction(Element.prototype.removeAttribute);
environment.rename(Element.prototype.removeAttribute,"removeAttribute");
environment.safefunction(Element.prototype.removeAttributeNS);
environment.rename(Element.prototype.removeAttributeNS,"removeAttributeNS");
environment.safefunction(Element.prototype.removeAttributeNode);
environment.rename(Element.prototype.removeAttributeNode,"removeAttributeNode");
environment.safefunction(Element.prototype.replaceWith);
environment.rename(Element.prototype.replaceWith,"replaceWith");
environment.safefunction(Element.prototype.requestFullscreen);
environment.rename(Element.prototype.requestFullscreen,"requestFullscreen");
environment.safefunction(Element.prototype.requestPointerLock);
environment.rename(Element.prototype.requestPointerLock,"requestPointerLock");
environment.safefunction(Element.prototype.scroll);
environment.rename(Element.prototype.scroll,"scroll");
environment.safefunction(Element.prototype.scrollBy);
environment.rename(Element.prototype.scrollBy,"scrollBy");
environment.safefunction(Element.prototype.scrollIntoView);
environment.rename(Element.prototype.scrollIntoView,"scrollIntoView");
environment.safefunction(Element.prototype.scrollIntoViewIfNeeded);
environment.rename(Element.prototype.scrollIntoViewIfNeeded,"scrollIntoViewIfNeeded");
environment.safefunction(Element.prototype.scrollTo);
environment.rename(Element.prototype.scrollTo,"scrollTo");
environment.safefunction(Element.prototype.setAttribute);
environment.rename(Element.prototype.setAttribute,"setAttribute");
environment.safefunction(Element.prototype.setAttributeNS);
environment.rename(Element.prototype.setAttributeNS,"setAttributeNS");
environment.safefunction(Element.prototype.setAttributeNode);
environment.rename(Element.prototype.setAttributeNode,"setAttributeNode");
environment.safefunction(Element.prototype.setAttributeNodeNS);
environment.rename(Element.prototype.setAttributeNodeNS,"setAttributeNodeNS");
environment.safefunction(Element.prototype.setPointerCapture);
environment.rename(Element.prototype.setPointerCapture,"setPointerCapture");
environment.safefunction(Element.prototype.toggleAttribute);
environment.rename(Element.prototype.toggleAttribute,"toggleAttribute");
environment.safefunction(Element.prototype.webkitMatchesSelector);
environment.rename(Element.prototype.webkitMatchesSelector,"webkitMatchesSelector");
environment.safefunction(Element.prototype.webkitRequestFullScreen);
environment.rename(Element.prototype.webkitRequestFullScreen,"webkitRequestFullScreen");
environment.safefunction(Element.prototype.webkitRequestFullscreen);
environment.rename(Element.prototype.webkitRequestFullscreen,"webkitRequestFullscreen");
environment.safefunction(Element.prototype.getAnimations);
environment.rename(Element.prototype.getAnimations,"getAnimations");
environment.safefunction(Element.prototype.replaceChildren);
environment.rename(Element.prototype.replaceChildren,"replaceChildren");
Object.setPrototypeOf(Element.prototype, Node.prototype);
