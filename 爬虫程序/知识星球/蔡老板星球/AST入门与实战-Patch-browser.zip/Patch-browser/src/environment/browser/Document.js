Document = function Document() {
};
environment.safefunction(Document);
environment.rename(Document);

Object.defineProperty(Document.prototype, "implementation", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "URL", {
    value: "chrome://newtab/",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "documentURI", {
    value: "chrome://newtab/",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "compatMode", {
    value: "CSS1Compat",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "characterSet", {
    value: "UTF-8",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "charset", {
    value: "UTF-8",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "inputEncoding", {
    value: "UTF-8",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "contentType", {
    value: "text/html",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "doctype", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "documentElement", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "xmlEncoding", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "xmlVersion", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "xmlStandalone", {
    value: false,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "domain", {
    value: "newtab",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "referrer", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "cookie", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "lastModified", {
    value: "08/25/2022 14:58:59",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "readyState", {
    value: "complete",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "title", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "dir", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "body", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "head", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "images", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "embeds", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "plugins", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "links", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "forms", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "scripts", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "currentScript", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "defaultView", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "designMode", {
    value: "off",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onreadystatechange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "anchors", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "applets", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "fgColor", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "linkColor", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "vlinkColor", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "alinkColor", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "bgColor", {
    value: "",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "all", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "scrollingElement", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerlockchange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerlockerror", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "hidden", {
    value: false,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "visibilityState", {
    value: "visible",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "wasDiscarded", {
    value: false,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "featurePolicy", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "webkitVisibilityState", {
    value: "visible",
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "webkitHidden", {
    value: false,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onbeforecopy", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onbeforecut", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onbeforepaste", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onfreeze", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onresume", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onsearch", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onsecuritypolicyviolation", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onvisibilitychange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "fullscreenEnabled", {
    value: true,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "fullscreen", {
    value: false,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onfullscreenchange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onfullscreenerror", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "webkitIsFullScreen", {
    value: false,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "webkitCurrentFullScreenElement", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "webkitFullscreenEnabled", {
    value: true,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "webkitFullscreenElement", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwebkitfullscreenchange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwebkitfullscreenerror", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "rootElement", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onabort", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onblur", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oncancel", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oncanplay", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oncanplaythrough", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onchange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onclick", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onclose", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oncontextmenu", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oncuechange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondblclick", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondrag", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondragend", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondragenter", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondragleave", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondragover", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondragstart", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondrop", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ondurationchange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onemptied", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onended", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onerror", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onfocus", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onformdata", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oninput", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oninvalid", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onkeydown", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onkeypress", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onkeyup", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onload", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onloadeddata", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onloadedmetadata", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onloadstart", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmousedown", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmouseenter", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmouseleave", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmousemove", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmouseout", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmouseover", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmouseup", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onmousewheel", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpause", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onplay", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onplaying", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onprogress", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onratechange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onreset", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onresize", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onscroll", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onseeked", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onseeking", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onselect", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onstalled", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onsubmit", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onsuspend", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ontimeupdate", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ontoggle", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onvolumechange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwaiting", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwebkitanimationend", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwebkitanimationiteration", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwebkitanimationstart", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwebkittransitionend", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onwheel", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onauxclick", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ongotpointercapture", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onlostpointercapture", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerdown", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointermove", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerup", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointercancel", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerover", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerout", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerenter", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerleave", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onselectstart", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onselectionchange", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onanimationend", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onanimationiteration", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onanimationstart", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "ontransitionend", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oncopy", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "oncut", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpaste", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "children", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "firstElementChild", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "lastElementChild", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "childElementCount", {
    value: 1,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "activeElement", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "styleSheets", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "pointerLockElement", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "fullscreenElement", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "adoptedStyleSheets", {
    value: [],
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "fonts", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "adoptNode", {
    value: function adoptNode() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "append", {
    value: function append() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "captureEvents", {
    value: function captureEvents() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "caretRangeFromPoint", {
    value: function caretRangeFromPoint() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "clear", {
    value: function clear() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "close", {
    value: function close() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createAttribute", {
    value: function createAttribute() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createAttributeNS", {
    value: function createAttributeNS() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createCDATASection", {
    value: function createCDATASection() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createComment", {
    value: function createComment() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createDocumentFragment", {
    value: function createDocumentFragment() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createElement", {
    value: function createElement(tagName, options) {
        if (tagName == 'canvas') return {
        }
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createElementNS", {
    value: function createElementNS() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createEvent", {
    value: function createEvent() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createExpression", {
    value: function createExpression() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createNSResolver", {
    value: function createNSResolver() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createNodeIterator", {
    value: function createNodeIterator() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createProcessingInstruction", {
    value: function createProcessingInstruction() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createRange", {
    value: function createRange() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createTextNode", {
    value: function createTextNode() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "createTreeWalker", {
    value: function createTreeWalker() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "elementFromPoint", {
    value: function elementFromPoint() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "elementsFromPoint", {
    value: function elementsFromPoint() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "evaluate", {
    value: function evaluate() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "execCommand", {
    value: function execCommand() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "exitFullscreen", {
    value: function exitFullscreen() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "exitPointerLock", {
    value: function exitPointerLock() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "getElementById", {
    value: function getElementById() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "getElementsByClassName", {
    value: function getElementsByClassName() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "getElementsByName", {
    value: function getElementsByName() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "getElementsByTagName", {
    value: function getElementsByTagName() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "getElementsByTagNameNS", {
    value: function getElementsByTagNameNS() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "getSelection", {
    value: function getSelection() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "hasFocus", {
    value: function hasFocus() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "importNode", {
    value: function importNode() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "open", {
    value: function open() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "prepend", {
    value: function prepend() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "queryCommandEnabled", {
    value: function queryCommandEnabled() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "queryCommandIndeterm", {
    value: function queryCommandIndeterm() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "queryCommandState", {
    value: function queryCommandState() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "queryCommandSupported", {
    value: function queryCommandSupported() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "queryCommandValue", {
    value: function queryCommandValue() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "querySelector", {
    value: function querySelector() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "querySelectorAll", {
    value: function querySelectorAll() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "releaseEvents", {
    value: function releaseEvents() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "webkitCancelFullScreen", {
    value: function webkitCancelFullScreen() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "webkitExitFullscreen", {
    value: function webkitExitFullscreen() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "write", {
    value: function write() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "writeln", {
    value: function writeln() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "fragmentDirective", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "onpointerrawupdate", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "timeline", {
    value: {},
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "pictureInPictureEnabled", {
    value: true,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "pictureInPictureElement", {
    value: null,
    writable: undefined,
    enumerable: true,
    configurable: true
});
Object.defineProperty(Document.prototype, "getAnimations", {
    value: function getAnimations() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "exitPictureInPicture", {
    value: function exitPictureInPicture() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});
Object.defineProperty(Document.prototype, "replaceChildren", {
    value: function replaceChildren() {
        debugger;
    }, writable: true, enumerable: true, configurable: true
});

environment.safefunction(Document.prototype.adoptNode);
environment.rename(Document.prototype.adoptNode, "adoptNode");
environment.safefunction(Document.prototype.append);
environment.rename(Document.prototype.append, "append");
environment.safefunction(Document.prototype.captureEvents);
environment.rename(Document.prototype.captureEvents, "captureEvents");
environment.safefunction(Document.prototype.caretRangeFromPoint);
environment.rename(Document.prototype.caretRangeFromPoint, "caretRangeFromPoint");
environment.safefunction(Document.prototype.clear);
environment.rename(Document.prototype.clear, "clear");
environment.safefunction(Document.prototype.close);
environment.rename(Document.prototype.close, "close");
environment.safefunction(Document.prototype.createAttribute);
environment.rename(Document.prototype.createAttribute, "createAttribute");
environment.safefunction(Document.prototype.createAttributeNS);
environment.rename(Document.prototype.createAttributeNS, "createAttributeNS");
environment.safefunction(Document.prototype.createCDATASection);
environment.rename(Document.prototype.createCDATASection, "createCDATASection");
environment.safefunction(Document.prototype.createComment);
environment.rename(Document.prototype.createComment, "createComment");
environment.safefunction(Document.prototype.createDocumentFragment);
environment.rename(Document.prototype.createDocumentFragment, "createDocumentFragment");
environment.safefunction(Document.prototype.createElement);
environment.rename(Document.prototype.createElement, "createElement");
environment.safefunction(Document.prototype.createElementNS);
environment.rename(Document.prototype.createElementNS, "createElementNS");
environment.safefunction(Document.prototype.createEvent);
environment.rename(Document.prototype.createEvent, "createEvent");
environment.safefunction(Document.prototype.createExpression);
environment.rename(Document.prototype.createExpression, "createExpression");
environment.safefunction(Document.prototype.createNSResolver);
environment.rename(Document.prototype.createNSResolver, "createNSResolver");
environment.safefunction(Document.prototype.createNodeIterator);
environment.rename(Document.prototype.createNodeIterator, "createNodeIterator");
environment.safefunction(Document.prototype.createProcessingInstruction);
environment.rename(Document.prototype.createProcessingInstruction, "createProcessingInstruction");
environment.safefunction(Document.prototype.createRange);
environment.rename(Document.prototype.createRange, "createRange");
environment.safefunction(Document.prototype.createTextNode);
environment.rename(Document.prototype.createTextNode, "createTextNode");
environment.safefunction(Document.prototype.createTreeWalker);
environment.rename(Document.prototype.createTreeWalker, "createTreeWalker");
environment.safefunction(Document.prototype.elementFromPoint);
environment.rename(Document.prototype.elementFromPoint, "elementFromPoint");
environment.safefunction(Document.prototype.elementsFromPoint);
environment.rename(Document.prototype.elementsFromPoint, "elementsFromPoint");
environment.safefunction(Document.prototype.evaluate);
environment.rename(Document.prototype.evaluate, "evaluate");
environment.safefunction(Document.prototype.execCommand);
environment.rename(Document.prototype.execCommand, "execCommand");
environment.safefunction(Document.prototype.exitFullscreen);
environment.rename(Document.prototype.exitFullscreen, "exitFullscreen");
environment.safefunction(Document.prototype.exitPointerLock);
environment.rename(Document.prototype.exitPointerLock, "exitPointerLock");
environment.safefunction(Document.prototype.getElementById);
environment.rename(Document.prototype.getElementById, "getElementById");
environment.safefunction(Document.prototype.getElementsByClassName);
environment.rename(Document.prototype.getElementsByClassName, "getElementsByClassName");
environment.safefunction(Document.prototype.getElementsByName);
environment.rename(Document.prototype.getElementsByName, "getElementsByName");
environment.safefunction(Document.prototype.getElementsByTagName);
environment.rename(Document.prototype.getElementsByTagName, "getElementsByTagName");
environment.safefunction(Document.prototype.getElementsByTagNameNS);
environment.rename(Document.prototype.getElementsByTagNameNS, "getElementsByTagNameNS");
environment.safefunction(Document.prototype.getSelection);
environment.rename(Document.prototype.getSelection, "getSelection");
environment.safefunction(Document.prototype.hasFocus);
environment.rename(Document.prototype.hasFocus, "hasFocus");
environment.safefunction(Document.prototype.importNode);
environment.rename(Document.prototype.importNode, "importNode");
environment.safefunction(Document.prototype.open);
environment.rename(Document.prototype.open, "open");
environment.safefunction(Document.prototype.prepend);
environment.rename(Document.prototype.prepend, "prepend");
environment.safefunction(Document.prototype.queryCommandEnabled);
environment.rename(Document.prototype.queryCommandEnabled, "queryCommandEnabled");
environment.safefunction(Document.prototype.queryCommandIndeterm);
environment.rename(Document.prototype.queryCommandIndeterm, "queryCommandIndeterm");
environment.safefunction(Document.prototype.queryCommandState);
environment.rename(Document.prototype.queryCommandState, "queryCommandState");
environment.safefunction(Document.prototype.queryCommandSupported);
environment.rename(Document.prototype.queryCommandSupported, "queryCommandSupported");
environment.safefunction(Document.prototype.queryCommandValue);
environment.rename(Document.prototype.queryCommandValue, "queryCommandValue");
environment.safefunction(Document.prototype.querySelector);
environment.rename(Document.prototype.querySelector, "querySelector");
environment.safefunction(Document.prototype.querySelectorAll);
environment.rename(Document.prototype.querySelectorAll, "querySelectorAll");
environment.safefunction(Document.prototype.releaseEvents);
environment.rename(Document.prototype.releaseEvents, "releaseEvents");
environment.safefunction(Document.prototype.webkitCancelFullScreen);
environment.rename(Document.prototype.webkitCancelFullScreen, "webkitCancelFullScreen");
environment.safefunction(Document.prototype.webkitExitFullscreen);
environment.rename(Document.prototype.webkitExitFullscreen, "webkitExitFullscreen");
environment.safefunction(Document.prototype.write);
environment.rename(Document.prototype.write, "write");
environment.safefunction(Document.prototype.writeln);
environment.rename(Document.prototype.writeln, "writeln");
environment.safefunction(Document.prototype.getAnimations);
environment.rename(Document.prototype.getAnimations, "getAnimations");
environment.safefunction(Document.prototype.exitPictureInPicture);
environment.rename(Document.prototype.exitPictureInPicture, "exitPictureInPicture");
environment.safefunction(Document.prototype.replaceChildren);
environment.rename(Document.prototype.replaceChildren, "replaceChildren");
Object.setPrototypeOf(Document.prototype, Node.prototype);
