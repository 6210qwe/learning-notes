﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./step1.js";  //默认的js文件
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./step1_ok.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");

// 检查路径或其任一子路径是否包含逗号表达式
function containsSequenceExpression(path) {
    let containsSequence = false;
    // 深度优先遍历当前路径及其所有子路径
    path.traverse({
        SequenceExpression(_path) {
            containsSequence = true;
            _path.stop(); // 找到逗号表达式后立即停止遍历
        }
    });
    return containsSequence;
}

//请使用学员专版babel库
const constantFold = {
    "BinaryExpression|UnaryExpression|MemberExpression|CallExpression"(path) {
        if (containsSequenceExpression(path)) {
            return;
        }
        if (path.isUnaryExpression({ operator: "-" }) ||
            path.isUnaryExpression({ operator: "void" })) {
            return;
        }
        const { confident, value } = path.evaluate();

        if (!confident || typeof value == "function")
            return;

        if (typeof value == 'number' && (!Number.isFinite(value))) {
            return;
        }

        console.log(path.toString(),"--->",value);

        path.replaceWith(types.valueToNode(value));
    },
}

traverse(ast, constantFold);


const restoreSpFunctionDeclaration = 
{
	FunctionDeclaration(path)
	{
		let {scope,node} = path;
		let {id,params,body} = node;
		
		if (params.length != 0 || body.body.length != 1 || !types.isExpressionStatement(body.body[0]))
		{
			return;
		}
		
		
		let binding = scope.getBinding(id.name);
		
		if (!binding || !binding.constant || binding.referencePaths.length != 1)
		{
			return;
		}
		
		let referPath  = binding.referencePaths[0];
		let referNode  = referPath.node;
		let parentPath = referPath.parentPath;
		if (!parentPath.isCallExpression({"callee":referNode}))
		{
			return;
		}
		
		if (!parentPath.parentPath.isExpressionStatement())
		{
			return;
		}
		
		parentPath.parentPath.replaceWith(body.body[0]);
		console.log(path.toString())
		path.remove();
		
	},
}

traverse(ast, restoreSpFunctionDeclaration);

function isBaseLiteral(node) {

    let literalList = ['window','document','navigator','location','history','screen',];

    if (types.isLiteral(node)) {
        return true;
    }

    if(types.isIdentifier(node) && literalList.includes(node.name))
    {
        return true;
    }

    if (types.isIdentifier(node) && typeof globalThis[node.name] != "undefined")
    {
        return true;
    }

    if (types.isUnaryExpression(node)) 
    {
        return isBaseLiteral(node.argument);
    }

    return false;
}

const restoreAssignConstant = 
{//常量还原插件
    AssignmentExpression(path)
    {
        let {scope,node,parentPath} = path;

        let {left,operator,right} = node;

        if (!types.isIdentifier(left) || operator != "=" || !isBaseLiteral(right))
        {
            return;
        }

        let binding = scope.getBinding(left.name);

        if (!binding)
        {//如果没有binding,或者赋值语句本身改变了它，因此这里判断只有一处改变。
            return;
        }

        let {referencePaths,constantViolations} = binding;

        let canVisit = false;

        if (constantViolations.length == 1 && constantViolations[0] == path)
        {
            canVisit = true;
        }
        if (constantViolations.length == 2 && constantViolations[0] == binding.path && binding.path.isVariableDeclarator({init:null}) &&
            constantViolations[1] == path)
        {//针对循环体里面定义的变量
            canVisit = true;
        }

        if (!canVisit) return;


        for (let referPath of binding.referencePaths)
        {
            referPath.replaceWith(right);
        }

        if(parentPath.isExpressionStatement() || parentPath.isSequenceExpression())
        {
            path.remove();
        }
    },

}

traverse(ast, restoreAssignConstant);



for (let i=0;i<10 ;i++)
{
	traverse(ast, restoreAssignConstant);
	ast = parser.parse(generator(ast).code);
	traverse(ast, constantFold);
}


const reStoreUnaryExpressionOfReturn = 
{
	VariableDeclarator(path)
	{
		let {scope,node} = path;
		let {id,init} = node;
		
		if (!types.isFunctionExpression(init))
		{
			return;
		}
		
		let {params,body} = init;
		if (params.length != 1 || body.body.length != 1 || 
		   !types.isReturnStatement(body.body[0]) ||
		   !types.isUnaryExpression(body.body[0].argument))
		{
			return;
		}
		
		let {operator,argument} = body.body[0].argument;
		if (!types.isIdentifier(argument))
		{
			return;
		}
		
		let binding = scope.getBinding(id.name);
		
		if (!binding || !binding.constant)
		{
			return;
		}
		
		console.log(path.toString())//手动确认是否都符合还原条件
		
		let canRemoved = true;
		for(let referPath of binding.referencePaths.reverse())
		{
			let {parentPath,node} = referPath;
			
			if (!parentPath.isCallExpression({"callee":node}))
			{
				canRemoved = false;
				continue;
			}
			
			let {arguments} = parentPath.node;
			
			if (arguments.length != 1)
			{
				canRemoved = false;
				continue;
			}
			
			//console.log(parentPath.toString())
			
			parentPath.replaceWith(types.UnaryExpression(operator,arguments[0],prefix = true));
			
		}
		
		canRemoved && path.remove();
		
	},
}

traverse(ast, reStoreUnaryExpressionOfReturn);


ast = parser.parse(generator(ast).code);



const reStoreBinaryExpressionOfReturn = 
{
	VariableDeclarator(path)
	{
		let {scope,node} = path;
		let {id,init} = node;
		
		if (!types.isFunctionExpression(init))
		{
			return;
		}
		
		let {params,body} = init;
		if (params.length != 2 || body.body.length != 1 || 
		   !types.isReturnStatement(body.body[0]) ||
		   !types.isBinaryExpression(body.body[0].argument))
		{
			return;
		}
		
		let {operator,left,right} = body.body[0].argument;
		if (!types.isIdentifier(left) || !types.isIdentifier(right))
		{
			return;
		}
		
		let binding = scope.getBinding(id.name);
		
		if (!binding || !binding.constant)
		{
			return;
		}
		
		console.log(path.toString())//手动确认是否都符合还原条件
		
		let canRemoved = true;
		for(let referPath of binding.referencePaths.reverse())
		{
			let {parentPath,node} = referPath;
			
			if (!parentPath.isCallExpression({"callee":node}))
			{
				canRemoved = false;
				continue;
			}
			
			let {arguments} = parentPath.node;
			
			if (arguments.length != 2)
			{
				canRemoved = false;
				continue;
			}
			
			console.log(parentPath.toString())
			
			parentPath.replaceWith(types.BinaryExpression(operator,arguments[0],arguments[1]));
			
			//console.log(parentPath.toString())
			
		}
		canRemoved && path.remove();
		scope.crawl();//我的电脑环境不加这行报错，不知道啥原因
		
		
	},
}
traverse(ast, reStoreBinaryExpressionOfReturn);



ast = parser.parse(generator(ast).code);



const simpliySwitchCase =
{
    SwitchCase({ node }) {

        let len = node.consequent.length;
        let retBody = [];
        for (let i = 0; i < len; i++) {
            if (types.isBlockStatement(node.consequent[i])) {
                retBody.push(...node.consequent[i].body);
            }
            else {
                retBody.push(node.consequent[i]);
            }
        }
        node.consequent = retBody;
    }
}

traverse(ast, simpliySwitchCase);


const changeForCallExpression =
{
    CallExpression(path) {

        let { callee, arguments } = path.node;

        if (!types.isMemberExpression(callee) || arguments.length < 2) {
            return;
        }

        let { object, property, computed } = callee;

        let key = computed ? property.value : property.name;
        
        if (key == "call") {
            let firstArg = arguments[0];
            if (types.isIdentifier(firstArg, { "name": "undefined" }) || types.isNullLiteral(firstArg)) {
                
                let callNode = types.CallExpression(object, arguments.slice(1));
                path.replaceWith(callNode);
            }

            return;
        }
        if (key == "apply" && arguments.length == 2 && types.isArrayExpression(arguments[1])) {
            let firstArg = arguments[0];

            if (types.isIdentifier(firstArg, { "name": "undefined" }) || types.isNullLiteral(firstArg)) {
                let callNode = types.CallExpression(object, arguments[1].elements);
                path.replaceWith(callNode);
            }

            return;
        }

    }
}


traverse(ast, changeForCallExpression);


traverse(ast, constantFold);





console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

fs.writeFile(decodeFile, code, (err) => { });