import time
import execjs
import requests
 
 
session = requests.Session()

session.headers = {
    "User-Agent": "yuanrenxue.project",
    }
 
 
url = "http://match.yuanrenxue.com/match/2"

r = session.get(url)

with open("2.js",'r') as fp:
    jscode = fp.read()

ctx = execjs.compile(jscode)

timestamp = str(int(time.time()*1000))

cookie = ctx.call("_0x3e163b",timestamp)


session.cookies.set("m",cookie[2:])

sum = 0
 
 
for i in range(1,2):
    api_url =f"http://match.yuanrenxue.com/api/match/2?page={i}"
    r = session.get(api_url)
    print (r.text)
    data = r.json()
    values = data["data"]
    for value in values:
        print (value)
        sum += value["value"]
 
 
print (sum)
