﻿const file = require('fs');
const parser = require("@babel/parser");
const traverse = require("@babel/traverse").default;
const types = require("@babel/types");
const { callExpression, ifStatement } = require('babel-types');
const template = require("@babel/template").default;
const generator = require("@babel/generator").default;

//将源代码解析为AST
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./decodeResult.js";


let sourceCode = file.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);

console.time("处理完毕，耗时");



//以下代码为删除垃圾代码，编写的专用插件。一个字，爽。


const deleteYRSDeadCode =
{
	TryStatement(path) {

		let { param, body } = path.node.handler;

		if (body.body.length == 1 && types.isReturnStatement(body.body[0])) {
			let functionParent = path.getFunctionParent();

			let binding = functionParent.scope.getBinding(functionParent.node.id.name);

			if (!binding) {
				return;
			}

			for (let referPath of binding.referencePaths) {
				let { parentPath } = referPath;

				if (parentPath.isCallExpression()) {
					parentPath.replaceWith(types.valueToNode(""));
				}
			}
			functionParent.remove();
		}
	},
	CallExpression(path) {
		if (path.node.callee.name == "setInterval") {
			path.remove();
			return;
		}
		if (types.isMemberExpression(path.node.callee)) {
			let { object, property } = path.node.callee;
			if (types.isIdentifier(object, { "name": "location" }) && types.isStringLiteral(property, { "value": "reload" })) {
				path.remove();
			}
		}

	},
	IfStatement(path) {
		let { test, consequent, alternate } = path.node;
		if (test.name == "qz") {
			path.replaceWithMultiple(consequent.body);
		}
	},
	AssignmentExpression(path) {
		let { parentPath, node, scope } = path;
		if (!parentPath.isExpressionStatement()) {
			return;
		}
		let { left, operator, right } = node;
		if (types.isMemberExpression(left)) {
			let { object, property } = left;
			if (types.isIdentifier(object, { "name": "document" }) && types.isStringLiteral(property, { "value": "cookie" })) {
				path.node.left = types.Identifier(property.value);
				parentPath.insertAfter(types.ReturnStatement(path.node.left));
			}
		}

	},
	ExpressionStatement(path)
	{
		let {parentPath,node} = path;
		if (!parentPath.isProgram())
		{
			return;
		}
		let {expression} = path.node;
		if (types.isCallExpression(expression) && types.isFunctionExpression(expression.callee))
		{
			path.replaceWithMultiple(expression.callee.body.body);
		}
	},
}

traverse(ast, deleteYRSDeadCode);



console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });

file.writeFile(decodeFile, code, (err) => { });