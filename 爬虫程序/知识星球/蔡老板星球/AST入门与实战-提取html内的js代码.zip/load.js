
const fs        = require('fs');
const types     = require("@babel/types");
const parser    = require("@babel/parser");
const template  = require("@babel/template").default;
const traverse  = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const cheerio   = require('cheerio');

const encodeHtml = process.argv.length > 2 ? process.argv[2] : "./encode.html";  //默认的html文件
// Load html into Cheerio
let sourceCode = fs.readFileSync(encodeHtml, { encoding: "utf-8" });
const $ = cheerio.load(sourceCode);


const keyToLiteral = {
	MemberExpression:
	{
		exit({ node }) {
			const prop = node.property;
			if (node.computed && types.isArrayExpression(prop) && prop.elements.length == 1) {//0327直播新增
				if (types.isStringLiteral(prop.elements[0])) {
					node.property = prop.elements[0];
					node.computed = true;
				}
			}
		}
	},
	ObjectProperty:
	{
		exit({ node }) {
			const key = node.key;
			if (!node.computed && types.isIdentifier(key)) {
				node.key = types.StringLiteral(key.name);
				return;
			}
			if (node.computed && types.isStringLiteral(key)) {
				node.computed = false;
			}
		}
	},
}





const standardLoop =
{
	"ForStatement|WhileStatement|ForInStatement|ForOfStatement"({ node }) {
		if (!types.isBlockStatement(node.body)) {
			node.body = types.BlockStatement([node.body]);
		}
	},
	IfStatement(path) {
		const consequent = path.get("consequent");
		const alternate = path.get("alternate");
		if (!consequent.isBlockStatement()) {
			consequent.replaceWith(types.BlockStatement([consequent.node]));
		}
		if (alternate.node !== null && !alternate.isBlockStatement()) {
			alternate.replaceWith(types.BlockStatement([alternate.node]));
		}
	},
}




const DeclaratorToDeclaration =
{
	VariableDeclaration(path) {
		let { parentPath, node } = path;
		if (!parentPath.isBlock()) {
			return;
		}
		let { declarations, kind } = node;

		if (declarations.length == 1) {
			return;
		}

		let newNodes = [];

		for (const varNode of declarations) {
			let newDeclartionNode = types.VariableDeclaration(kind, [varNode]);
			newNodes.push(newDeclartionNode);
		}

		path.replaceWithMultiple(newNodes);

	},
}




const simplifyLiteral = {
	NumericLiteral({ node }) {
		if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
	StringLiteral({ node }) {
		if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
}


// Extract JS from each script tag
$('script').each((index, element) => {
	
	let eleCode = $(element).html();
	if (eleCode.length == 0)
	{
		return;
	}
	let ast = parser.parse(eleCode);

	if (1) {

		traverse(ast, keyToLiteral);

		traverse(ast, standardLoop);

		traverse(ast, DeclaratorToDeclaration);
	}


	traverse(ast, simplifyLiteral);

	let { code } = generator(ast, opts = {
		"compact": false,  // 是否压缩代码
		"comments": false,  // 是否保留注释
		"jsescOption": { "minimal": true },  //Unicode转义
	});

	console.log(`第${index}个文件已处理完毕！`);

	let resFileName = encodeHtml.replace(".html","") + `_${index}.js`;

	fs.writeFile(resFileName, code, (err) => { });
});
