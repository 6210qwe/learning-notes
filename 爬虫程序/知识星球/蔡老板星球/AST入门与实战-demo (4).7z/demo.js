
/*
console.log(2*5+8);

如何给这个语句设计一个 jsvmp 代码。

首先要搞懂 栈 的规则 后进先出。

理解Array类型的push与pop操作。


语句的运算顺序

1.   2 * 5 = 10;    这里就需要把 2 和 5 分别出栈，赋值给不同的变量，op 为 * ，计算结果 10，再将结果 10 入栈

2.   10 + 8 = 18;   这里将 8 入栈，然后分别出栈，op为 + ，计算结果 18，再将结果 18 入栈

3.  console.log(18);  //打印栈顶元素即可。




然后设计指令

入栈操作   push      指令为 1
操作运算符 op  *     指令为 2
操作运算符 op  +     指令为 3
函数调用 console.log     指令为 4


手动生成指令集

第一步 2 和 5 分别入栈
入栈指令为1

1 2 1 5

第二步，需要用到 op *，因此，这里需要 指令 2

1 2 1 5 2

第三步 8入栈

1 2 1 5 2 1 8


第四步 需要用到 op +，因此，这里需要 指令 3

1 2 1 5 2 1 8 3

第五步 调用打印函数

1 2 1 5 2 1 8 3 4

*/


function vmFunc(instList)
{
    function vm(pc,stack)
    {
        stack = stack || [];
        let left,right,top;

        while(1)
        {
            let inst = instList[pc++];  //取栈顶元素，指针迁移
            if(inst == undefined)
            {//元素已取完，退出循环
                break;
            }
            
            switch(inst)
            {
                case 1:
                    stack.push(instList[pc++]); //入栈，pc指针 +1
                    break;
                case 2://操作运算符 op  *
                    right = stack.pop();
                    left  = stack.pop();
                    stack.push(left * right);
                    break;
                case 3://操作运算符 op  +
                    right = stack.pop();
                    left  = stack.pop();
                    stack.push(left + right);
                    break;                   
                case 4://函数调用 console.log 
                    top = stack.pop();
                    console.log(top);
                    break;
                default:
                    console.log(`${init} 指令未实现!`);
                    throw {};
            }
        }



    }

    vm(0);
}

vmFunc([1,2,1,5,2,1,8,3,4]);

