const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const { callExpression } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";




//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");

//下面三行代码为专用代码，不同的混淆代码请进行更改。

const funcCode = files.readFileSync('./ob.js', { encoding: "utf-8" });
eval(funcCode);
let funcName = "C2amS";





//下面代码可通用，请勿更改

const deleteRepeatDefine = {

	VariableDeclarator(path) {
		let { node, scope } = path;

		let { id, init } = node;

		if (!types.isIdentifier(init, { name: funcName })) {
			return;
		}

		const binding = scope.getBinding(id.name);

		if (!binding || !binding.constant)//如果被更改则不能进行替换
			return;

		for (let referPath of binding.referencePaths) {
			referPath.node.name = funcName;
		}
		path.remove();
	},
}

traverse(ast, deleteRepeatDefine);


function isExpressionConstant(PathOrNode) {

	let node = PathOrNode.node || PathOrNode;

	let BrowList = ['window', 'document', 'navigator', 'location', 'history', 'screen',];

	if (types.isLiteral(node) && node.value != null) {
		return true;
	}

	if (types.isIdentifier(node) && BrowList.includes(node.name)) {
		return true;
	}

	if (types.isIdentifier(node) && typeof globalThis[node.name] != "undefined") {
		return true;
	}

	if (types.isMemberExpression(node)) {
		let { object, property } = node;

		if (types.isIdentifier(object) && typeof globalThis[object.name] != "undefined") {
			let properName = types.isIdentifier(property) ? property.name : property.value;
			if (typeof globalThis[object.name][properName] != "undefined") {
				return true;
			}
		}

		if (types.isMemberExpression(object)) {
			return isExpressionConstant(object);
		}

	}

	if (types.isUnaryExpression(node) && ["+", "-", "!", "typeof", "~"].includes(node.operator)) {
		return isExpressionConstant(node.argument);
	}

	return false;
}

const restoreVarDeclarator =
{//预处理
	VariableDeclarator(path) {
		let scope = path.scope;
		let { id, init } = path.node;

		if (!types.isIdentifier(id) || init == null || !isExpressionConstant(init)) {
			return;
		}

		const binding = scope.getBinding(id.name);

		if (!binding) return;

		let { constant, referencePaths, constantViolations } = binding;

		if (constantViolations.length > 1) {
			return;
		}

		if (constant || constantViolations[0] == path) {
			for (let referPath of referencePaths) {
				referPath.replaceWith(init);
			}
		}
	},
}



function isNodeLiteral(node) {
	if (Array.isArray(node)) {
		return node.every(ele => isNodeLiteral(ele));
	}

	if (types.isThisExpression(node)) {
		return true;
	}

	if (types.isLiteral(node)) {
		if (node.value == null) {
			return false;
		}
		return true;
	}
	if (types.isBinaryExpression(node)) {
		return isNodeLiteral(node.left) && isNodeLiteral(node.right);
	}
	if (types.isUnaryExpression(node, {
		"operator": "-"
	}) || types.isUnaryExpression(node, {
		"operator": "+"
	})) {
		return isNodeLiteral(node.argument);
	}

	if (types.isObjectExpression(node)) {
		let { properties } = node;
		if (properties.length == 0) {
			return true;
		}

		return properties.every(property => isNodeLiteral(property));

	}
	if (types.isArrayExpression(node)) {
		let { elements } = node;
		if (elements.length == 0) {
			return true;
		}
		return elements.every(element => isNodeLiteral(element));
	}

	return false;
}


const callToString =
{
	CallExpression(path) {
		let { callee, arguments } = path.node;

		let sourceCode = path.toString();

		if (!types.isMemberExpression(callee) || arguments.length == 0 || !isNodeLiteral(arguments)) {
			return;
		}

		if (callee.object.name != funcName) {
			return;
		}

		let value = eval(sourceCode); //计算结果
		//if(value == undefined) return;   //自行决定是否要屏蔽
		console.log(sourceCode, "-->", value);
		path.replaceWith(types.valueToNode(value)); //替换
	}
}

for (let i = 0; i < 3; i++) {
	traverse(ast, restoreVarDeclarator);
	ast = parser.parse(generator(ast).code)
	traverse(ast, callToString);

}



const simplifyLiteral = {
	/**  @param  {NodePath} path */  //每个插件前都要加哈。
	NumericLiteral(path) {
		let { node } = path;
		if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
	/**  @param  {NodePath} path */
	StringLiteral(path) {
		let { node } = path;
		if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
}


//traverse(ast, simplifyLiteral);


console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
});

files.writeFile(decodeFile, code, (err) => { });