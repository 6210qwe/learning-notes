function test(u, d, N, a, q, R, k) {
    for (R = 59; R != void 0;) {
      switch (R) {
        case 75:
          R = h ? 76 : 77;
          break;
        case 77:
          q = l;
          l = function () {
            q();
            g(k);
          };
          R = void 0;
        case 59:
          k = function () {
            h(function (X) {
              g(function () {
                u(X);
              });
            }, N);
          };
          R = 26;
          break;
        case 12:
          a = L(N);
          if (u) {
            u(a);
          }
          return a;
        case 76:
          k();
          R = void 0;
        case 26:
          R = d ? 75 : 12;
          break;
      }
    }
  }