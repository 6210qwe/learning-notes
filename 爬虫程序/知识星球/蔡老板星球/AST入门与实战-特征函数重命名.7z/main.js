const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./step1.js";  //默认的js文件
const decodeFile = "./step2.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");


function getRandomName(length) {

	let initArr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
	let puzzleArr = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
	let ranInx = Math.floor(Math.random() * initArr.length);
	let randomName = initArr[ranInx];

	for (var i = 1; i < length; i++) {
		ranInx = Math.floor(Math.random() * puzzleArr.length);
		randomName += puzzleArr[ranInx];
	}

	return randomName;
}

let allNewNames = new Map();  //定义一个全局变量，保存需要处理的函数

function getUnusedIdentifier() {//获取未被使用的名称,返回 Identifier 类型。
	do {
		var newName = "$C_" + getRandomName(3);

	} while (allNewNames.has(newName))

	allNewNames.set(newName, 1);

	let UnusedIdentifier = types.Identifier(newName);

	return UnusedIdentifier;
}

const renameFunc =
{
	FunctionDeclaration(path) {
		let { node, parentPath } = path;
		let { id, params, body } = node;
		let name = id.name;

		if (params.length != 2 || body.body.length != 1 ||
			!types.isReturnStatement(body.body[0]) || !types.isCallExpression(body.body[0].argument)) {//PX3特征函数
			return;
		}

		let argument = body.body[0].argument;
		if (!types.isIdentifier(argument.callee)) { //20240617新增，防止非ob混淆特征函数也被处理
			return false;
		}

		//console.log(argument.callee.name)  //查看处理的是否为ob混淆特征函数

		let binding = parentPath.scope.getBinding(name);

		if (!binding || !binding.constant) {
			return;
		}

		let newNameId = getUnusedIdentifier();
		for (let referPath of binding.referencePaths) {
			referPath.replaceWith(newNameId);
		}

		let newName = newNameId.name;
		allNewNames.set(newName, name)
		path.node.id.name = newName;
	}
}

traverse(ast, renameFunc);

allNewNames.clear();







console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });