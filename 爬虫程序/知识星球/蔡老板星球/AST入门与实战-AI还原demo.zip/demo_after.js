// 判断 ot 是否小于 503
if (ot = Ht < 503) {
    // 赋值 it，判断 Ht 是否小于 243
    it = Ht < 243;
    if (it) {
        // 赋值 Q，判断 Ht 是否小于 143
        Q = Ht < 143;
        if (Q) {
            // 赋值 L，判断 Ht 是否小于 71
            L = Ht < 71;
            if (L) {
                // 赋值 d，判断 Ht 是否小于 30
                d = Ht < 30;
                if (d) {
                    // 赋值 v，判断 Ht 是否小于 10
                    v = Ht < 10;
                    if (v) {
                        // 赋值 I，判断 Ht 是否小于 9
                        I = Ht < 9;
                        if (I) {
                            // 赋值 c，判断 Ht 是否小于 6
                            c = Ht < 6;
                            if (c) {
                                // 当 c 为真时执行
                                st = h[t++];
                                at = h[t++];
                                gt(at, st);
                            } else if (!c) {
                                // 当 c 为假时执行
                                st = h[t++];
                                if (st || h[774] > h[418]) {
                                    at = h[t++];
                                    if (!at) {
                                        // 执行一些操作
                                        h[575];
                                        h[282];
                                        ct = mt(st);
                                        ft = mt(at);
                                        if (a || (s[ct] *= ft) && a) {
                                            // 执行代码
                                        }
                                    }
                                }
                            }
                        } else if (!I) {
                            // 当 I 为假时执行
                            st = h[t++];
                            at = h[t++];
                            ct = h[t++];
                            if (a || (ft = h[t++])) {
                                vt = mt(ct);
                                if (h[73] > h[308] || (It = mt(ft)) && h[719] < h[494] || h[376] > h[338]) {
                                    if ((lt = mt(st)) || h[695] < h[920]) {
                                        if (a || gt(at, vt.apply(It, lt)) && a) {
                                            // 执行代码
                                        }
                                    }
                                }
                            }
                        }
                    } else if (!v) {
                        // 当 v 为假时执行
                        c = Ht < 11;
                        if (c) {
                            t += ct;
                            vt = h[t++];
                            st = h[t++];
                        } else if (!c) {
                            st = h[t++];
                            if (a || (at = h[t++])) {
                                ct = h[t++];
                                ft = mt(ct);
                                vt = mt(at);
                                gt(st, ft & vt);
                            }
                        }
                    }
                } else if (!d) {
                    // 当 d 为假时执行
                    I = Ht < 61;
                    if (I) {
                        v = Ht < 52;
                        if (v) {
                            st = h[t++];
                            if (a || (at = h[t++]) && a) {
                                if (a || (ct = h[t++]) && a) {
                                    if (h[698] < h[365]) {
                                        // 执行代码
                                    } else if (gt(ct, Math.pow(mt(at), mt(st))) && h[105] < h[692]) {
                                        // 执行代码
                                    }
                                }
                            }
                        } else if (!v) {
                            st = h[t++];
                            at = h[t++];
                            gt(st, mt(st) - mt(at));
                        }
                    } else if (!I) {
                        d = Ht < 70;
                        if (d) {
                            gt(h[t++], o);
                        } else if (!d) {
                            st = h[t++];
                            at = h[t++];
                            ct = h[t++];
                            ft = mt(at);
                            vt = mt(st);
                            if (!vt) {
                                h[119];
                                h[686];
                            }
                            gt(ct, ft >> vt);
                        }
                    }
                }
            } else if (!L) {
                // 当 L 为假时执行
                d = Ht < 117;
                if (d) {
                    L = Ht < 96;
                    if (L) {
                        l = Ht < 78;
                        if (l) {
                            st = h[t++];
                            if (a || (at = h[t++])) {
                                ct = h[t++];
                                gt(ct, mt(st) != mt(at));
                            }
                        } else if (!l) {
                            st = h[t++];
                            at = h[t++];
                            ct = h[t++];
                            ft = mt(st);
                            vt = mt(at);
                            if ((vt || h[300] < h[329]) && h[270] > h[527]) {
                                // 执行代码
                            } else if (gt(ct, ft << vt) && h[594] < h[936]) {
                                // 执行代码
                            }
                        }
                    } else if (!L) {
                        l = Ht < 105;
                        if (l) {
                            st = h[t++];
                            at = h[t++];
                            ct = h[t++];
                            if (a || (ft = mt(ct)) && a) {
                                if (h[828] > h[298]) {
                                    // 执行代码
                                } else if ((vt = mt(st)) && (h[97], h[924])) {
                                    gt(at, ft instanceof vt);
                                }
                            }
                        } else if (!l) {
                            st = g[t++];
                            at = g[t++];
                            if (a || gt(st, at) && a) {
                                // 执行代码
                            }
                        }
                    }
                } else if (!d) {
                    // 当 d 为假时执行
                    L = Ht < 131;
                    if (L) {
                        p = Ht < 121;
                        if (p) {
                            gt(h[t++], o[o["length"] - 1]);
                        } else if (!p) {
                            st = h[t++];
                            at = h[t++];
                            Ht = 253;
                            gt(st, Et());
                        }
                    } else if (!L) {
                        p = Ht < 138;
                        if (p) {
                            st = h[t++];
                            at = h[t++];
                            if (a || (ct = mt(st)) && a) {
                                ft = mt(at);
                                s[ct] |= ft;
                            }
                        } else if (!p) {
                            st = h[t++];
                            at = h[t++];
                            gt(st, mt(st) - 1);
                            gt(at, mt(st));
                        }
                    }
                }
            }
        } else if (!Q) {
            // 当 Q 为假时执行
            L = Ht < 193;
            if (L) {
                Q = Ht < 159;
                if (Q) {
                    y = Ht < 155;
                    if (y) {
                        w = Ht < 152;
                        if (w) {
                            Y = Ht < 147;
                            if (Y) {
                                st = h[t++];
                                if (a || (at = h[t++]) && a) {
                                    s[mt(at)] += mt(st);
                                }
                            } else if (!Y) {
                                st = h[t++];
                                at = h[t++];
                                ct = h[t++];
                                gt(ct, at / Ct(10, st));
                            }
                        } else if (!w) {
                            st = h[t++];
                            if (a || (at = h[t++]) && a) {
                                gt(at, e[st]);
                            }
                        }
                    } else if (!y) {
                        Y = Ht < 158;
                        if (Y) {
                            st = h[t++];
                            if (a || (at = h[t++]) && a) {
                                gt(st, void mt(at));
                            }
                        } else if (!Y) {
                            st = h[t++];
                            gt(st, []);
                        }
                    }
                } else if (!Q) {
                    w = Ht < 177;
                    if (w) {
                        y = Ht < 176;
                        if (y) {
                            st = h[t++];
                            at = h[t++];
                            gt(at, !mt(st));
                        } else if (!y) {
                            st = h[t++];
                            at = h[t++];
                            ct = mt(at);
                            gt(st, mt(st) | ct);
                        }
                    } else if (!w) {
                        Q = Ht < 180;
                        if (Q) {
                            st = h[t++];
                            if (h[58] > h[167]) {
                                at = h[t++];
                            }
                            ct = h[t++];
                            if (mt(ct)) {
                                t += st;
                                gt(at, mt(ct));
                            }
                        } else if (!Q) {
                            st = h[t++];
                            at = h[t++];
                            gt(st, mt(st) + 1);
                            gt(at, mt(st));
                        }
                    }
                }
            } else if (!L) {
                // 当 L 为假时执行
                Q = Ht < 236;
                if (Q) {
                    H = Ht < 227;
                    if (H) {
                        m = Ht < 194;
                        if (m) {
                            st = h[t++];
                            if (a || (ct = h[t++]) && a) {
                                if (h[851] < h[842]) {
                                    // 执行代码
                                } else if ((ct = h[t++]) && h[46] > h[984]) {
                                    // 执行代码
                                }
                            }
                        } else if (!m) {
                            st = h[t++];
                            if (h[814] < h[546]) {
                                at = h[t++];
                            }
                            if (h[423] > h[984]) {
                                gt(st, mt(at));
                            }
                        }
                    } else if (!H) {
                        m = Ht < 228;
                        if (m) {
                            st = h[t++];
                            at = h[t++];
                            if (h[573] < h[787]) {
                                ct = mt(st);
                            }
                            ft = mt(at);
                            s[ct] ^= ft;
                        } else if (!m) {
                            st = h[t++];
                            if (a || (at = h[t++]) && a) {
                                // 执行代码
                            }
                        }
                    }
                } else if (!Q) {
                    H = Ht < 239;
                    if (H) {
                        Q = Ht < 238;
                        if (Q) {
                            st = h[t++];
                            if (a || (at = h[t++])) {
                                gt(st, mt(st) + mt(at));
                            }
                        } else if (!Q) {
                            st = h[t++];
                            gt(st, true);
                        }
                    } else if (!H) {
                        Q = Ht < 240;
                        if (Q) {
                            st = h[t++];
                            if (h[46] > h[249]) {
                                at = h[t++];
                            }
                            ct = h[t++];
                            gt(ct, mt(st) > mt(at));
                        } else if (!Q) {
                            st = h[t++];
                            at = h[t++];
                            gt(st, mt(at));
                            gt(at, mt(at) + 1);
                        }
                    }
                }
            }
        }
    }
}
