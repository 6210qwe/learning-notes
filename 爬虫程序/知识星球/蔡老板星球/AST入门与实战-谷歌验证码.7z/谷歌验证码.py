import time
import requests
requests.packages.urllib3.disable_warnings()


cap_key = ""  #客户端秘钥  https://dashboard.ez-captcha.com/#/dashboard  右侧可以看到


def cap_create_task(websiteURL, websiteKey, taskType, isInvisible, pageAction=None) -> str:
    url = "https://api.ez-captcha.com/createTask"
    data = {
        "clientKey": cap_key,
        "task": {
            "websiteURL": websiteURL,
            "websiteKey": websiteKey,
            "type": taskType,
            "isInvisible": isInvisible,
            # "pageAction": pageAction
        }
    }
    try:
        result = requests.post(url, json=data, verify=False, timeout=8)
        result = result.json()
        taskId = result.get('taskId')
        if taskId is not None:
            return taskId

    except Exception as e:
        print(e)


def cap_get_response(taskID: str):
    times = 0
    start_time = time.time()
    while times < 120:
        try:
            url = "https://api.ez-captcha.com/getTaskResult"
            data = {
                "clientKey": cap_key,
                "taskId": taskID
            }
            result = requests.post(url, json=data, verify=False, timeout=8).json()
            solution = result.get('solution', {})
            if solution:
                response = solution.get('gRecaptchaResponse')
                if response:
                    print(f"消耗时间 {time.time()-start_time}s")
                    print(response)
                    return response
        except Exception as e:
            print(e)

        times += 1
        time.sleep(1)
    return ""


def get_token():
    type = "RecaptchaV2TaskProxyless"
    websiteURL = ""  # 控制台执行获取,见最后的注释
    websiteKey = ""  # 控制台执行获取,见最后的注释
    isInvisible = False

    taskId = cap_create_task(websiteURL, websiteKey, type, isInvisible, None)
    result = cap_get_response(taskId)
    return result



if __name__ == '__main__':

    re_token = get_token()
    print (re_token)
    
    
"""
含有谷歌验证码的页面，按下F12,输入如下代码并回车:

function findRecaptchaClients() {
  // eslint-disable-next-line camelcase
  if (typeof (___grecaptcha_cfg) !== 'undefined') {
    // eslint-disable-next-line camelcase, no-undef
    return Object.entries(___grecaptcha_cfg.clients).map(([cid, client]) => {
      const data = { id: cid, version: cid >= 10000 ? 'V3' : 'V2' };
      const objects = Object.entries(client).filter(([_, value]) => value && typeof value === 'object');

      objects.forEach(([toplevelKey, toplevel]) => {
        const found = Object.entries(toplevel).find(([_, value]) => (
          value && typeof value === 'object' && 'sitekey' in value && 'size' in value
        ));
     
        if (typeof toplevel === 'object' && toplevel instanceof HTMLElement && toplevel['tagName'] === 'DIV'){
            data.pageurl = toplevel.baseURI;
        }
        
        if (found) {
          const [sublevelKey, sublevel] = found;

          data.sitekey = sublevel.sitekey;
          const callbackKey = data.version === 'V2' ? 'callback' : 'promise-callback';
          const callback = sublevel[callbackKey];
          if (!callback) {
            data.callback = null;
            data.function = null;
          } else {
            data.function = callback;
            const keys = [cid, toplevelKey, sublevelKey, callbackKey].map((key) => `['${key}']`).join('');
            data.callback = `___grecaptcha_cfg.clients${keys}`;
          }
        }
      });
      return data;
    });
  }
  return [];
}
findRecaptchaClients()

"""
