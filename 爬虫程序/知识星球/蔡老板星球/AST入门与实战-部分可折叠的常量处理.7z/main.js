﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./decodeResult.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });

let ast = parser.parse(sourceCode);


console.time("处理完毕，耗时");


const calcPartBinaryExpression =
{
	"BinaryExpression"(path) {

		let { parent, parentPath, node } = path;

		let { left, operator, right } = node;

		if (types.isLiteral(left) && types.isLiteral(right)) {
			const { confident, value } = path.evaluate();
			if (!confident || value == "Infinity") return;
			path.replaceWith(types.valueToNode(value));
			return;
		}

		if (types.isBinaryExpression(left) && operator == "+" && types.isNumericLiteral(right)) {

			let curLeft = left.left;
			let curOp = left.operator;
			let curRight = left.right;

			if (curOp == "+" && types.isNumericLiteral(curRight)) {

				let newValue = curRight.value + right.value;

				path.node.left = curLeft;
				path.node.operator = "+";
				path.node.right = types.valueToNode(newValue);
				return;
			}
			if (curOp == "-" && types.isNumericLiteral(curRight)) {

				let newValue = right.value - curRight.value;

				path.node.left = curLeft;
				path.node.operator = newValue > 0 ? "+" : "-";
				path.node.right = types.valueToNode(Math.abs(newValue));

				return;
			}
			if (curOp == "+" && types.isNumericLiteral(curLeft)) {
				let newValue = curLeft.value + right.value;
				path.node.left = types.valueToNode(newValue);
				path.node.operator = "+";
				path.node.right = curRight;
				return;
			}
			if (curOp == "-" && types.isNumericLiteral(curLeft)) {
				let newValue = curLeft.value + right.value;
				path.node.left = types.valueToNode(newValue);
				path.node.operator = "-";
				path.node.right = curRight;
				return;
			}
			return;
		}
		if (types.isBinaryExpression(left) && operator == "-" && types.isNumericLiteral(right)) {

			let curLeft = left.left;
			let curOp = left.operator;
			let curRight = left.right;

			if (curOp == "+" && types.isNumericLiteral(curRight)) {

				let newValue = curRight.value - right.value;

				path.node.left = curLeft;
				path.node.operator = newValue > 0 ? "+" : "-";
				path.node.right = types.valueToNode(Math.abs(newValue));
				return;
			}
			if (curOp == "-" && types.isNumericLiteral(curRight)) {

				let newValue = curRight.value + right.value;

				path.node.left = curLeft;
				path.node.operator = "-";
				path.node.right = types.valueToNode(newValue);

				return;
			}
			if (curOp == "+" && types.isNumericLiteral(curLeft)) {//1 + b - 2 ==> b -1;

				let newValue = curLeft.value - right.value;

				if (newValue > 0) {
					path.node.left = types.valueToNode(newValue);
					path.node.operator = "+";
					path.node.right = curRight;
				}
				else if (newValue == 0) {
					path.replaceWith(curRight);
				}
				else {
					path.node.left = curRight;
					path.node.operator = "-";
					path.node.right = types.valueToNode(-newValue);;
				}

				return;
			}
			if (curOp == "-" && types.isNumericLiteral(curLeft)) {

				let newValue = curLeft.value - right.value;
				path.node.left = types.valueToNode(newValue);
				path.node.operator = "-";
				path.node.right = curRight;
				return;
			}
		}

		if (types.isBinaryExpression(left) && operator == "+" && types.isStringLiteral(right)) {

			let curLeft = left.left;
			let curOp = left.operator;
			let curRight = left.right;

			if (curOp == "+" && types.isLiteral(curRight)) {

				let newValue = curRight.value + right.value;

				path.node.left = curLeft;
				path.node.operator = "+";
				path.node.right = types.valueToNode(newValue);
				return;
			}

			return;
		}
	},



}





for (let i = 0; i < 10; i++) {
	traverse(ast, calcPartBinaryExpression);
	ast = parser.parse(generator(ast).code);
}







console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });

fs.writeFile(decodeFile, code, (err) => { });