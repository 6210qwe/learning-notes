var a = 1 + aa + 2 + 3 - 15;
var b = 1 + bb - 2 - 3;
var c = 6 + cc + 2;
