﻿const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");


function createNewFunction(name,initValue,firstNode,switchNode,params)
{
	let {cases} = switchNode;

	let funcBody = [];

	let newfuncName = types.identifier(name + "_" + initValue);

	while (true)
	{
		for (let i=0; i< cases.length;i++)
		{
			let {test,consequent} = cases[i];

			if (test.value != initValue)
			{
				continue;
			}

			let length = consequent.length;

			let lastNode = consequent.at(-1);

			if (types.isContinueStatement(lastNode))
			{
				
				lastNode = consequent.at(-2);
				if (types.isExpressionStatement(lastNode))
				{
					initValue = consequent.at(-2).expression.right.value;
					funcBody = funcBody.concat(consequent.slice(0, length - 2));
					i = -1;
					continue;
				}
				else
				{
					console.log(2222222222222222222)  //标记
				}

			}
			else
			{
				console.log(lastNode.type)
				funcBody.push(...consequent);
				break;
			}
		}
		break;
	}

	funcBody.unshift(firstNode);


	let newFuncNode = types.FunctionDeclaration(newfuncName,params,types.BlockStatement(funcBody));

	return newFuncNode;

}


const dealWithSwitch = 
{
	FunctionDeclaration(path)
	{


		let {id,params,body} = path.node;

		if (id.name != "_$SU" || body.body.length != 2)
		{
			return;
		}

		let [firstNode,secondNode] = body.body;
		if (!types.isWhileStatement(secondNode))
		{
			return;
		}

		

		let whileBody = secondNode.body.body;


		if (whileBody.length != 2 || !types.isSwitchStatement(whileBody[0]))
		{
			return;
		}
		

		let scope = path.parentPath.scope;

		let binding = scope.getBinding(id.name);

		for (let referPath of binding.referencePaths)
		{
			let {parentPath,node} = referPath;
			if (parentPath.isCallExpression({"callee":node}))
			{
				let {arguments} = parentPath.node;

				if (arguments.length > 0 && types.isNumericLiteral(arguments[0]))
				{
					let newFuncNode = createNewFunction(id.name,arguments[0].value,firstNode,whileBody[0],params);

					path.insertBefore(newFuncNode);

					parentPath.node.callee.name = newFuncNode.id.name;
				}
			}
		}



		
	}
}


traverse(ast,dealWithSwitch)

console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });

files.writeFile(decodeFile, code, (err) => { });