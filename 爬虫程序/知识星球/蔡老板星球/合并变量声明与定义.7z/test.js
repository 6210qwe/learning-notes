var a,b;
a = 1;
b = 2;