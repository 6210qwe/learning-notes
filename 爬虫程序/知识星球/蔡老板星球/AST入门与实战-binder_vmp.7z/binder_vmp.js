// 多线程+vmp的风控, 可以防止插桩分析
// 任务调度部分应该放到vmp中
// new class in关键字自己的vmp还未实现，因此部分任务调度就没放入vmp
// 正常应该把所有方法都放入vmp
// 可在此文件中尝试vmp插桩分析
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

// vmp函数
function asmRun(il_langauge) {
    function parseInstructions(instructionString) {
        var lines = instructionString.split('\n');
        var instructions = lines.map(line => {
            var [op, ...args] = line.split(' ');
            switch (op) {
                case 'PUSH':
                    args = [args.join(' ')];
                    break;
                case 'OBJECT':
                    args = [args[0].split(',')]
                    break;
                case 'FUNC':
                    args = args[0].split(',');
                    if (args[1] !== ''){
                        args[1] = args.slice(1);
                        args.splice(2);
                    } else {
                        args[1] = [];
                    }
            }
            function switchToNumber(arg) {
                if (Array.isArray(arg)) {
                    return arg.map(switchToNumber);
                } else if (typeof arg === 'string' && arg.startsWith('vm0xi')) {
                    return parseInt(arg.slice(5), 16);
                } else if (typeof arg === 'string' && arg.startsWith('vmbl')) {
                    if (arg === 'vmbl-1') return true;
                    else if (arg === 'vmbl-0') return false;
                } else {
                    return arg;
                }
            }
            args = args.map(switchToNumber);
            return { op, args };
        });
        return instructions;
    }
    function run_zhiling(il_zhiling, functions = {}, localVars = {}, context = globalThis) {
        if (Object.keys(localVars).length === 0){
            Object.getOwnPropertyNames(globalThis).forEach(winKey => {
                localVars[winKey] = globalThis[winKey];
            });
        }
        var stack = [];
        var ip = 0;
        while (ip < il_zhiling.length) {
            var instr = il_zhiling[ip];
            switch (instr.op) {
                case 'VAR':
                    localVars[instr.args[0]] = localVars[instr.args[0]] || undefined;
                    break;
                case 'PUSH':
                    stack.push(instr.args[0]);
                    break;
                case 'STORE':
                    localVars[instr.args[0]] = stack.pop();
                    break;
                case 'LOAD':
                    stack.push(localVars[instr.args[0]]);
                    break;
                case 'ADD':
                    right = stack.pop();
                    left = stack.pop();
                    stack.push(left + right);
                    break;
                case 'SUB':
                    var subtrahend = stack.pop();
                    var minuend = stack.pop();
                    stack.push(minuend - subtrahend);
                    break;
                case 'CALL':
                    var func = stack.pop();
                    if (typeof func === 'function') {
                        var args = [];
                        for (var i = 0; i < instr.args[0]; i++) {
                            args.push(stack.pop());
                        }
                        args.reverse();
                        stack.push(func.apply(func.thisContext, args));
                    } else if (func && func.body && func.params) {
                        var args = [];
                        var newLocalVars = {};
                        for (var i = 0; i < instr.args[0]; i++) {
                            args.push(stack.pop());
                        }
                        var record_args = [];
                        for (var i=0; i<args.length; i++) {
                            record_args.push(args[i]);
                        }
                        record_args.reverse();
                        Object.getOwnPropertyNames(localVars).forEach(varName => {
                            newLocalVars[varName] = localVars[varName];
                        });
                        for (var i = 0; i < func.params.length; i++) {
                            newLocalVars[func.params[i]] = args.pop();
                        }
                        newLocalVars.arguments = record_args;
                        stack.push(run_zhiling(func.body, functions, newLocalVars, func.thisContext));
                    } else {
                        throw new Error(`Unsupported function: ${func}`);
                    }
                    break;
                case 'FUNC':
                    !function(){
                        var params = instr.args[1];
                        var funcName = instr.args[0];
                        functions[instr.args[0]] = { params: params, body: [] };
                        while (il_zhiling[++ip].op !== 'ENDFUNC' || il_zhiling[ip].args[0] !== instr.args[0]) {
                            functions[instr.args[0]].body.push(il_zhiling[ip]);
                        }
                        var newFunc = function(...args) {
                            var newLocalVars = {};
                            Object.getOwnPropertyNames(localVars).forEach(varName => {
                                newLocalVars[varName] = localVars[varName];
                            });
                            for (var i = 0; i < params.length; i++) {
                                newLocalVars[params[i]] = args[i];
                            }
                            var newFunctions = {};
                            for (var old_stack_func in functions) {
                                newFunctions[old_stack_func] = functions[old_stack_func];
                            }
                            newLocalVars.arguments = args;
                            return run_zhiling(functions[funcName].body, newFunctions, newLocalVars, this);
                        };
                        localVars[funcName] = newFunc;
                    }()
                    break;
                case 'OBJECT':
                    var obj = {};
                    arg_len = instr.args[0].length;
                    for (var i = 0; i < arg_len; i++) {
                        obj[instr.args[0][arg_len-i-1]] = stack.pop();
                    }
                    delete obj[''];
                    stack.push(obj);
                    break;
                case 'JMP':
                    ip += instr.args[0];
                    break;
                case 'JMP_IF_FALSE':
                    if (!stack.pop()) {
                        ip += instr.args[0] - 1;
                    }
                    break;
                case 'INC':
                    localVars[instr.args[0]]++;
                    break;
                case 'UNARY':
                    var arg = stack.pop();
                    switch (instr.args[0]) {
                        case '-':
                            stack.push(-arg);
                            break;
                        case '+':
                            stack.push(+arg);
                            break;
                        case '!':
                            stack.push(!arg);
                            break;
                        case '~':
                            stack.push(~arg);
                            break;
                        case 'typeof':
                            stack.push(typeof arg);
                            break;
                        default:
                            throw new Error(`Unsupported unary operator: ${instr.args[0]}`);
                    }
                    break;
                case 'LOAD_MEMBER':
                    var member = stack.pop();
                    var objRef = stack.pop();
                    if (Array.isArray(objRef) && localVars[member] !== undefined && typeof localVars[member] == 'number') {
                        stack.push(objRef[localVars[member]]);
                        objRef[localVars[member]].thisContext = objRef;
                    } else {
                        stack.push(objRef[member]);
                        objRef[member].thisContext = objRef;
                    }
                    break;
                case 'LT':
                    var b = stack.pop();
                    var a = stack.pop();
                    stack.push(a < b);
                    break;
                case 'SHL':
                    var shiftAmount = stack.pop();
                    var value = stack.pop();
                    stack.push(value << shiftAmount);
                    break;
                case 'ANDB':
                    var andbRight = stack.pop();
                    var andbLeft = stack.pop();
                    stack.push(andbLeft & andbRight);
                    break;
                case 'RETURN':
                    return stack.pop();
                case 'GT':
                    var gtRight = stack.pop();
                    var gtLeft = stack.pop();
                    stack.push(gtLeft > gtRight);
                    break;
                case 'ENDFUNC':
                    break;
                case 'EQ':
                    var eqRight = stack.pop();
                    var eqLeft = stack.pop();
                    stack.push(eqLeft == eqRight);
                    break;
                case 'NEQ':
                    var neqRight = stack.pop();
                    var neqLeft = stack.pop();
                    stack.push(neqLeft !== neqRight);
                    break;
                case 'ARRAY':
                    arg_len = instr.args[0];
                    array = [];
                    for (var i = 0; i < arg_len; i++) {
                        array.push(stack.pop());
                    }
                    array.reverse();
                    stack.push(array);
                    break;
                case 'PUSHTHIS':
                    stack.push(context);
                    break;
                case 'DBG':
                    debugger;
                    break;
                case '':
                    return;
                case 'MUL':
                    var mulRight = stack.pop();
                    var mulLeft = stack.pop();
                    stack.push(mulLeft * mulRight);
                    break;
                case 'STORE_MEMBER':
                    var value = stack.pop();
                    var objRef = stack.pop();
                    var member = instr.args[0];
                    objRef[member] = value;
                    break;
                case 'MOD':
                    var modRight = stack.pop();
                    var modLeft = stack.pop();
                    stack.push(modLeft % modRight);
                    break;
                case 'DIV':
                    var divRight = stack.pop();
                    var divLeft = stack.pop();
                    stack.push(divLeft / divRight);
                    break;
                case 'GE':
                    var geRight = stack.pop();
                    var geLeft = stack.pop();
                    stack.push(geLeft >= geRight);
                    break;
                case 'ORB':
                    var orbRight = stack.pop();
                    var orbLeft = stack.pop();
                    stack.push(orbLeft | orbRight);
                    break;
                case 'SHR':
                    var shrRight = stack.pop();
                    var shrLeft = stack.pop();
                    stack.push(shrLeft >>> shrRight);
                    break;
                case 'LE':
                    var leRight = stack.pop();
                    var leLeft = stack.pop();
                    stack.push(leLeft <= leRight);
                    break;
                default:
                    throw new Error(`Unsupported operation: ${instr.op}`);
            }
            ip++;
        }
        return stack.pop();
    }
    global.rz = run_zhiling;
    var op_list = parseInstructions(il_langauge);
    return run_zhiling(op_list);
}
// vmp字节码
let asmcode = `VAR a
PUSH charCodeAt
PUSH reverse
PUSH 
PUSH length
LOAD setInterval
LOAD atob
LOAD escape
LOAD decodeURIComponent
LOAD eval
ARRAY vm0xi9
STORE a
FUNC b,c,d
LOAD c
PUSH vm0xi0
SUB 
STORE c
VAR e
LOAD a
LOAD c
LOAD_MEMBER 
STORE e
LOAD e
RETURN 
ENDFUNC b
FUNC gi,
VAR ud
PUSH 
STORE ud
VAR i
PUSH vm0xi1
STORE i
LOAD i
PUSH vm0xi20
LE 
JMP_IF_FALSE vm0xi37
VAR n
PUSH vm0xi10
LOAD Math
PUSH random
LOAD_MEMBER 
CALL vm0xi0
PUSH vm0xi10
MUL 
LOAD Math
PUSH floor
LOAD_MEMBER 
CALL vm0xi1
PUSH toString
LOAD_MEMBER 
CALL vm0xi1
STORE n
VAR as
PUSH 
STORE as
LOAD i
PUSH vm0xi8
EQ 
JMP_IF_FALSE vm0xi3
PUSH -
STORE as
LOAD i
PUSH vm0xic
EQ 
JMP_IF_FALSE vm0xi3
PUSH -
STORE as
LOAD i
PUSH vm0xi10
EQ 
JMP_IF_FALSE vm0xi3
PUSH -
STORE as
LOAD i
PUSH vm0xi14
EQ 
JMP_IF_FALSE vm0xi3
PUSH -
STORE as
LOAD ud
LOAD as
ADD 
STORE ud
LOAD ud
LOAD n
ADD 
STORE ud
LOAD i
INC i
JMP vm0xi-3a
LOAD ud
RETURN 
ENDFUNC gi
FUNC stop,
PUSH de
PUSH b
ADD 
PUSH u
ADD 
PUSH g
ADD 
PUSH ge
ADD 
PUSH r
ADD 
PUSH vm0xi8
LOAD b
CALL vm0xi1
CALL vm0xi1
DBG 
ENDFUNC stop
LOAD stop
PUSH vm0xi1
PUSH vm0xi4
LOAD b
CALL vm0xi1
CALL vm0xi2
FUNC st,d,e
LOAD parseInt
LOAD Date
LOAD st
LOAD String
ARRAY vm0xi4
STORE v
LOAD e
LOAD undefined
EQ 
JMP_IF_FALSE vm0xi8
LOAD d
PUSH vm0xi1
LOAD v
PUSH vm0xi2
LOAD_MEMBER 
CALL vm0xi2
RETURN 
VAR f
LOAD v
PUSH vm0xi1
LOAD_MEMBER 
PUSH now
LOAD_MEMBER 
CALL vm0xi0
LOAD v
PUSH vm0xi0
LOAD_MEMBER 
CALL vm0xi1
STORE f
LOAD e
PUSH vm0xia
GE 
JMP_IF_FALSE vm0xi3
LOAD d
RETURN 
VAR g
PUSH vm0xi0
STORE g
VAR j
PUSH vm0xi0
STORE j
LOAD j
LOAD d
PUSH 0x3
LOAD b
CALL vm0xi1
LOAD_MEMBER 
LT 
JMP_IF_FALSE vm0xi1b
PUSH 0x0
LOAD b
CALL vm0xi1
STORE q
VAR k
LOAD j
LOAD d
LOAD q
LOAD_MEMBER 
CALL vm0xi1
STORE k
LOAD g
PUSH vm0xi5
SHL 
LOAD g
SUB 
LOAD k
ADD 
STORE g
LOAD g
PUSH vm0xi0
ORB 
STORE g
LOAD j
INC j
JMP vm0xi-22
LOAD g
PUSH vm0xi0
SHR 
STORE g
PUSH vm0xi10
LOAD g
PUSH toString
LOAD_MEMBER 
CALL vm0xi1
STORE g
PUSH vm0xi2
LOAD b
CALL vm0xi1
PUSH vm0xi2
LOAD b
CALL vm0xi1
LOAD g
PUSH split
LOAD_MEMBER 
CALL vm0xi1
PUSH 0x1
LOAD b
CALL vm0xi1
LOAD_MEMBER 
CALL vm0xi0
PUSH join
LOAD_MEMBER 
CALL vm0xi1
STORE g
LOAD g
LOAD v
PUSH vm0xi3
LOAD_MEMBER 
CALL vm0xi1
LOAD e
PUSH vm0xi1
ADD 
LOAD v
PUSH vm0xi2
LOAD_MEMBER 
CALL vm0xi2
RETURN 
ENDFUNC st
LOAD stop
PUSH toS
PUSH tr
ADD 
PUSH in
ADD 
PUSH g
ADD 
LOAD_MEMBER 
CALL vm0xi0
LOAD st
CALL vm0xi1
PUSH vm0xi1
PUSH c
ADD 
PUSH vm0xi5
ADD 
PUSH fb
ADD 
PUSH vm0xi4e
ADD 
PUSH e
ADD 
NEQ 
JMP_IF_FALSE vm0xi61
PUSH vm0xi5
PUSH om
ADD 
PUSH T
ADD 
PUSH vm0xi5
ADD 
PUSH Y
ADD 
PUSH vm0xi2
ADD 
PUSH w
ADD 
PUSH vm0xi6
ADD 
PUSH L
ADD 
PUSH +
ADD 
PUSH Z
ADD 
PUSH vm0xi6
ADD 
PUSH KG
ADD 
PUSH M
ADD 
PUSH vm0xi6
ADD 
PUSH K
ADD 
PUSH +
ADD 
PUSH 0
ADD 
PUSH vm0xi5
ADD 
PUSH pi
ADD 
PUSH O
ADD 
PUSH vm0xi5
ADD 
PUSH L2
ADD 
PUSH g
ADD 
PUSH vm0xi5
ADD 
PUSH L
ADD 
PUSH iN
ADD 
PUSH vm0xi5
ADD 
PUSH piv
ADD 
PUSH 5L
ADD 
PUSH uA
ADD 
PUSH vm0xi5
ADD 
PUSH LmI
ADD 
PUSH vm0xi5
ADD 
PUSH aW
ADD 
PUSH vm0xi5f
ADD 
PUSH Lq
ADD 
PUSH vm0xi6
ADD 
PUSH vm0xi5
LOAD b
CALL vm0xi1
CALL vm0xi1
PUSH vm0xi6
LOAD b
CALL vm0xi1
CALL vm0xi1
PUSH vm0xi7
LOAD b
CALL vm0xi1
CALL vm0xi1
LOAD console
PUSH log
LOAD_MEMBER 
CALL vm0xi1
PUSH vm0xi3
LOAD process
PUSH exit
LOAD_MEMBER 
CALL vm0xi1
PUSH rz
LOAD globalThis
PUSH hasOwnProperty
LOAD_MEMBER 
CALL vm0xi1
UNARY !
JMP_IF_FALSE vm0xi61
PUSH vm0xi5
PUSH om
ADD 
PUSH T
ADD 
PUSH vm0xi5
ADD 
PUSH Y
ADD 
PUSH vm0xi2
ADD 
PUSH w
ADD 
PUSH vm0xi6
ADD 
PUSH L
ADD 
PUSH +
ADD 
PUSH Z
ADD 
PUSH vm0xi6
ADD 
PUSH KG
ADD 
PUSH M
ADD 
PUSH vm0xi6
ADD 
PUSH K
ADD 
PUSH +
ADD 
PUSH 0
ADD 
PUSH vm0xi5
ADD 
PUSH pi
ADD 
PUSH O
ADD 
PUSH vm0xi5
ADD 
PUSH L2
ADD 
PUSH g
ADD 
PUSH vm0xi5
ADD 
PUSH L
ADD 
PUSH iN
ADD 
PUSH vm0xi5
ADD 
PUSH piv
ADD 
PUSH 5L
ADD 
PUSH uA
ADD 
PUSH vm0xi5
ADD 
PUSH LmI
ADD 
PUSH vm0xi5
ADD 
PUSH aW
ADD 
PUSH vm0xi5f
ADD 
PUSH Lq
ADD 
PUSH vm0xi6
ADD 
PUSH vm0xi5
LOAD b
CALL vm0xi1
CALL vm0xi1
PUSH vm0xi6
LOAD b
CALL vm0xi1
CALL vm0xi1
PUSH vm0xi7
LOAD b
CALL vm0xi1
CALL vm0xi1
LOAD console
PUSH log
LOAD_MEMBER 
CALL vm0xi1
PUSH vm0xi4
LOAD process
PUSH exit
LOAD_MEMBER 
CALL vm0xi1
LOAD rz
PUSH toString
LOAD_MEMBER 
CALL vm0xi0
LOAD st
CALL vm0xi1
PUSH vm0xi49
PUSH b
ADD 
PUSH vm0xi4
ADD 
PUSH f
ADD 
PUSH a
ADD 
PUSH vm0xi8
ADD 
PUSH d
ADD 
NEQ 
JMP_IF_FALSE vm0xi61
PUSH vm0xi5
PUSH om
ADD 
PUSH T
ADD 
PUSH vm0xi5
ADD 
PUSH Y
ADD 
PUSH vm0xi2
ADD 
PUSH w
ADD 
PUSH vm0xi6
ADD 
PUSH L
ADD 
PUSH +
ADD 
PUSH Z
ADD 
PUSH vm0xi6
ADD 
PUSH KG
ADD 
PUSH M
ADD 
PUSH vm0xi6
ADD 
PUSH K
ADD 
PUSH +
ADD 
PUSH 0
ADD 
PUSH vm0xi5
ADD 
PUSH pi
ADD 
PUSH O
ADD 
PUSH vm0xi5
ADD 
PUSH L2
ADD 
PUSH g
ADD 
PUSH vm0xi5
ADD 
PUSH L
ADD 
PUSH iN
ADD 
PUSH vm0xi5
ADD 
PUSH piv
ADD 
PUSH 5L
ADD 
PUSH uA
ADD 
PUSH vm0xi5
ADD 
PUSH LmI
ADD 
PUSH vm0xi5
ADD 
PUSH aW
ADD 
PUSH vm0xi5f
ADD 
PUSH Lq
ADD 
PUSH vm0xi6
ADD 
PUSH vm0xi5
LOAD b
CALL vm0xi1
CALL vm0xi1
PUSH vm0xi6
LOAD b
CALL vm0xi1
CALL vm0xi1
PUSH vm0xi7
LOAD b
CALL vm0xi1
CALL vm0xi1
LOAD console
PUSH log
LOAD_MEMBER 
CALL vm0xi1
PUSH vm0xi5
LOAD process
PUSH exit
LOAD_MEMBER 
CALL vm0xi1
FUNC at,ts,rq,pt
VAR ti
LOAD gi
CALL vm0xi0
STORE ti
LOAD ti
LOAD ts
OBJECT id,data
LOAD rq
PUSH enqueue
LOAD_MEMBER 
CALL vm0xi1
LOAD pt
CALL vm0xi0
PUSH Task ID: 
LOAD ti
ADD 
PUSH  added: 
ADD 
LOAD ts
ADD 
LOAD console
PUSH log
LOAD_MEMBER 
CALL vm0xi1
LOAD ti
RETURN 
ENDFUNC at
LOAD globalThis
LOAD st
LOAD gi
LOAD at
OBJECT runTask,genId,addTask
STORE_MEMBER ASM_SDK`
asmRun(asmcode);
// 定义一个任务类
class Queue {
  constructor() {
    this.items = [];
  }
  enqueue(item) {
    this.items.push(item);
  }
  dequeue() {
    return this.items.shift() || null;
  }
  isEmpty() {
    return this.items.length === 0;
  }
  size() {
    return this.items.length;
  }
}
// 任务队列和结果队列
var requestQueue = new Queue();
var responseQueue = {};
// 线程池，并设置最多同时跑多少个任务
var maxWorkers = 10;
var runningTasks = 0;
// 处理任务队列
function processTasks() {
  while (runningTasks < maxWorkers && !requestQueue.isEmpty()) {
    const task = requestQueue.dequeue();
    runningTasks++;
    const worker = new Worker('./binder_vmp.js', {
      workerData: task.data
    });
    const work_id = worker.threadId;
    responseQueue[work_id] = new Queue();
    worker.on('message', (result) => {
      responseQueue[work_id].enqueue({ taskId: task.id, result });
      runningTasks--;
      processTasks();
    });
    worker.on('error', (error) => {
      console.error(`Worker error: ${error}`);
      runningTasks--;
      processTasks();
    });
    worker.on('exit', (code) => {
      if (code !== 0) {
        console.error(`Worker stopped with exit code ${code}`);
      }
      runningTasks--;
      processTasks();
    });
  }
}
// 如果是主线程，启动调度器
if (isMainThread) {
  // 添加示例任务
  task_dict = {
    ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    data: "pageNo=1&pageSize=20&uid=123456&nouce=f5c230",
    api: "https://www.xxx.com/api/v3/get_video_list",
    referer: "https://www.xxx.com/userPage?uid=123456",
    ts: "1718874027",
    env1: "function toString() { [native code] }",
    env2: "function split() { [native code] }",
    env3: "function join() { [native code] }",
    moreEnv: "略"
  }
  key_list = Object.keys(task_dict);
  signMap = {}
  keyTaskMap = {};
  for (const key in task_dict) {
    taskId = ASM_SDK.addTask(task_dict[key], requestQueue, processTasks);
    keyTaskMap[taskId] = key;
    signMap[key] = null;
  }
  // 定时检查结果队列(这一部分生产环境一定要放入vmp中, 或者在vmp中验证是否被篡改, 否则被修改成只发送一个任务, 就可以正常插桩分析)
  intervalId = setInterval(() => {
    for (const work_id in responseQueue) {
      if (!responseQueue[work_id].isEmpty()) {
        const { taskId, result } = responseQueue[work_id].dequeue();
        console.log(`Task ID ${taskId} completed: ${result}`);
        // 多运行几遍就会发现, 上面八个签名的执行完成顺序每次是不一样的
        // 因为使用了线程池, 所以任务是异步的, 完成顺序就不固定了
        // 如果直接在vmp中插桩, 得到的日志会是八份日志混在一起的
        signMap[keyTaskMap[taskId]] = result;
      }
    }
    // 判断是否所有任务都完成
    taskCompleted = 0;
    for (const index in key_list) {
      if (!signMap[key_list[index]]) {
        break;
      } else {
        taskCompleted++;
      }
    }
    if (taskCompleted === key_list.length) {
      // 全部完成, 输出最终结果
      yazong = "";
      for (const index in key_list) {
        yazong += signMap[key_list[index]];
      }
      console.log(`最终加密结果: ${yazong}`);
      clearInterval(intervalId)
    }
  }, 100);
} else {
  // 如果是工作线程，处理任务
  // 这里一定要用vmp保护
  const task = workerData;
  debugger
  const result = ASM_SDK.runTask(task);
  parentPort.postMessage(result);
}