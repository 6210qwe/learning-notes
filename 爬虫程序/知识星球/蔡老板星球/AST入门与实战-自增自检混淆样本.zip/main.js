const files     = require('fs');  //导入文件库，防止与fs变量名冲突
const types     = require("@babel/types");
const parser    = require("@babel/parser");
const template  = require("@babel/template").default;
const traverse  = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath  = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");



const standardLoop =
{
    "ForStatement|WhileStatement|ForInStatement|ForOfStatement|DoWhileStatement"({ node }) {
        if (!types.isBlockStatement(node.body)) {
            node.body = types.BlockStatement([node.body]);
        }
    },
    IfStatement(path)
    {
    	const consequent = path.get("consequent");
    	const alternate  = path.get("alternate");
    	if (!consequent.isBlockStatement()) 
    	{
    		consequent.replaceWith(types.BlockStatement([consequent.node]));
    	}
    	if (alternate.node !== null && !alternate.isBlockStatement()) {
    		alternate.replaceWith(types.BlockStatement([alternate.node]));
    	}
    },
}

traverse(ast, standardLoop);


const DeclaratorToDeclaration =
{
    VariableDeclaration(path) {
        let { parentPath, node } = path;
        if (parentPath.isFor()) {
            return;
        }
        let { declarations, kind } = node;

        if (declarations.length == 1) {
            return;
        }

        let newNodes = [];

        for (const varNode of declarations) {
            let newDeclartionNode = types.VariableDeclaration(kind, [varNode]);
            newNodes.push(newDeclartionNode);
        }

        path.replaceWithMultiple(newNodes);

    },
}

traverse(ast, DeclaratorToDeclaration);



const ConditionalToIf =
{
    ConditionalExpression(path) {
        let {parentPath,node} = path;
        let { test, consequent, alternate } = node;
        if (parentPath.isExpressionStatement({"expression":node})) {
            if (!types.isExpressionStatement(consequent)) {
                consequent = types.BlockStatement([types.ExpressionStatement(consequent)]);
            }
            if (!types.isExpressionStatement(alternate)) {
                alternate = types.BlockStatement([types.ExpressionStatement(alternate)]);
            }
            parentPath.replaceWith(types.IfStatement(test, consequent, alternate));
        }
    }
}

traverse(ast,ConditionalToIf);


const resolveSequence = 
{
	SequenceExpression(path)
	{
		let {scope,parentPath,node} = path;
		let expressions = node.expressions;
		if (parentPath.isReturnStatement({"argument":node}))
		{
			let lastExpression = expressions.pop();
			for (let expression of expressions)
			{
				parentPath.insertBefore(types.ExpressionStatement(expression=expression));
			}

			path.replaceInline(lastExpression);
		}
		else if (parentPath.isExpressionStatement({"expression":node}))
		{
			let body = [];
			expressions.forEach(express=>{body.push(types.ExpressionStatement(express));});
            path.replaceWithMultiple(body);
		}
		else
		{
			return;
		}

		scope.crawl();
	}
}

traverse(ast, resolveSequence);



const simplifyLiteral = {
	/**  @param  {NodePath} path */  //每个插件前都要加哈。
	NumericLiteral(path) {
		let {node} = path;
		if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
	/**  @param  {NodePath} path */
	StringLiteral(path) {
		let {node} = path;
		if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
}


//traverse(ast, simplifyLiteral);


console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });