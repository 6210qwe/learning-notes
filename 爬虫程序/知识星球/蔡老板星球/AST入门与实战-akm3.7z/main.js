﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./step2.js";  //默认的js文件
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./step3.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");


// 检查路径或其任一子路径是否包含逗号表达式
function containsSequenceExpression(path) {
    let containsSequence = false;
    // 深度优先遍历当前路径及其所有子路径
    path.traverse({
        SequenceExpression(_path) {
            containsSequence = true;
            _path.stop(); // 找到逗号表达式后立即停止遍历
        }
    });
    return containsSequence;
}

//请使用学员专版babel库
const constantFold = {
    "BinaryExpression|UnaryExpression|MemberExpression|CallExpression"(path) {
        if (containsSequenceExpression(path)) {
            return;
        }
        if (path.isUnaryExpression({ operator: "-" }) ||
            path.isUnaryExpression({ operator: "void" })) {
            return;
        }
        const { confident, value } = path.evaluate();

        if (!confident || typeof value == "function")
            return;

        if (typeof value == 'number' && (!Number.isFinite(value))) {
            return;
        }

        console.log(path.toString(), "--->", value);

        path.replaceWith(types.valueToNode(value));
    },
}

traverse(ast, constantFold);



function isExpressionConstant(PathOrNode) {

    let node = PathOrNode.node || PathOrNode;

    let BrowList = ['window', 'document', 'navigator', 'location', 'history', 'screen',];

    if (types.isLiteral(node) && node.value != null) {
        return true;
    }

    if (types.isIdentifier(node) && BrowList.includes(node.name)) {
        return true;
    }

    if (types.isIdentifier(node) && typeof globalThis[node.name] != "undefined") {
        return true;
    }

    if (types.isMemberExpression(node)) {
        let { object, property } = node;

        if (types.isIdentifier(object) && typeof globalThis[object.name] != "undefined") {
            let properName = types.isIdentifier(property) ? property.name : property.value;
            if (typeof globalThis[object.name][properName] != "undefined") {
                return true;
            }
        }

        if (types.isMemberExpression(object)) {
            return isExpressionConstant(object);
        }

    }

    if (types.isUnaryExpression(node) && ["+", "-", "!", "typeof", "~"].includes(node.operator)) {
        return isExpressionConstant(node.argument);
    }

    return false;
}

const restoreAssignConstant =
{//常量还原插件
    AssignmentExpression(path) {
        let { scope, node, parentPath } = path;

        let { left, operator, right } = node;

        if (!types.isIdentifier(left) || operator != "=" || !isExpressionConstant(right)) {
            return;
        }

        let binding = scope.getBinding(left.name);

        if (!binding) {//如果没有binding,或者赋值语句本身改变了它，因此这里判断只有一处改变。
            return;
        }

        let { referencePaths, constantViolations } = binding;

        let canVisit = false;

        if (constantViolations.length == 1 && constantViolations[0] == path) {
            canVisit = true;
        }
        if (constantViolations.length == 2 && constantViolations[0] == binding.path && binding.path.isVariableDeclarator({ init: null }) &&
            constantViolations[1] == path) {//针对循环体里面定义的变量
            canVisit = true;
        }

        if (!canVisit) return;

        let { start } = binding.constantViolations[0].node;

        let referStart = start;

        for (let referPath of binding.referencePaths) {
            if (referPath.node.start < referStart) {
                referStart = referPath.node.start;
            }
        }

        if (start > referStart) {//防止在更改前被引用
            return;
        }

        for (let referPath of binding.referencePaths) {
            referPath.replaceWith(right);
        }

        if (parentPath.isExpressionStatement() || parentPath.isSequenceExpression()) {
            path.remove();
        }
    },

}

traverse(ast, restoreAssignConstant);



const simpliySwitchCase =
{
    SwitchCase({ node }) {

        let len = node.consequent.length;
        let retBody = [];
        for (let i = 0; i < len; i++) {
            if (types.isBlockStatement(node.consequent[i])) {
                retBody.push(...node.consequent[i].body);
            }
            else {
                retBody.push(node.consequent[i]);
            }
        }
        node.consequent = retBody;
    }
}

traverse(ast, simpliySwitchCase);


const changeForCallExpression =
{
    CallExpression(path) {

        let { callee, arguments } = path.node;

        if (!types.isMemberExpression(callee) || arguments.length < 2) {
            return;
        }

        let { object, property, computed } = callee;

        let key = computed ? property.value : property.name;
        
        if (key == "call") {
            let firstArg = arguments[0];
            if (types.isIdentifier(firstArg, { "name": "undefined" }) || types.isNullLiteral(firstArg)) {
                
                let callNode = types.CallExpression(object, arguments.slice(1));
                path.replaceWith(callNode);
            }

            return;
        }
        if (key == "apply" && arguments.length == 2 && types.isArrayExpression(arguments[1])) {
            let firstArg = arguments[0];

            if (types.isIdentifier(firstArg, { "name": "undefined" }) || types.isNullLiteral(firstArg)) {
                let callNode = types.CallExpression(object, arguments[1].elements);
                path.replaceWith(callNode);
            }

            return;
        }

    }
}


traverse(ast, changeForCallExpression);


traverse(ast, constantFold);





console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
    "compact": false,  // 是否压缩代码
    "comments": false,  // 是否保留注释
    "jsescOption": { "minimal": true },  //Unicode转义
});

fs.writeFile(decodeFile, code, (err) => { });