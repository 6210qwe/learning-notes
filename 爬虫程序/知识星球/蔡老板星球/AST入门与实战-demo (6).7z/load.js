
const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


const cheerio = require('cheerio');
const encodeHtml = process.argv.length > 2 ? process.argv[2] : "./encode.html";  //默认的html文件
// Load html into Cheerio
let sourceCode = fs.readFileSync(encodeHtml, { encoding: "utf-8" });
const $ = cheerio.load(sourceCode);


const keyToLiteral = {
	MemberExpression:
	{
		exit({ node }) {
			const prop = node.property;
			if (node.computed && types.isArrayExpression(prop) && prop.elements.length == 1) {//0327直播新增
				if (types.isStringLiteral(prop.elements[0])) {
					node.property = prop.elements[0];
					node.computed = true;
				}
			}
		}
	},
	ObjectProperty:
	{
		exit({ node }) {
			const key = node.key;
			if (!node.computed && types.isIdentifier(key)) {
				node.key = types.StringLiteral(key.name);
				return;
			}
			if (node.computed && types.isStringLiteral(key)) {
				node.computed = false;
			}
		}
	},
}





const standardLoop =
{
	"ForStatement|WhileStatement|ForInStatement|ForOfStatement"({ node }) {
		if (!types.isBlockStatement(node.body)) {
			node.body = types.BlockStatement([node.body]);
		}
	},
	IfStatement(path) {
		const consequent = path.get("consequent");
		const alternate = path.get("alternate");
		if (!consequent.isBlockStatement()) {
			consequent.replaceWith(types.BlockStatement([consequent.node]));
		}
		if (alternate.node !== null && !alternate.isBlockStatement()) {
			alternate.replaceWith(types.BlockStatement([alternate.node]));
		}
	},
}




const DeclaratorToDeclaration =
{
	VariableDeclaration(path) {
		let { parentPath, node } = path;
		if (!parentPath.isBlock()) {
			return;
		}
		let { declarations, kind } = node;

		if (declarations.length == 1) {
			return;
		}

		let newNodes = [];

		for (const varNode of declarations) {
			let newDeclartionNode = types.VariableDeclaration(kind, [varNode]);
			newNodes.push(newDeclartionNode);
		}

		path.replaceWithMultiple(newNodes);

	},
}


const varDeclarToFuncDeclar =
{
	VariableDeclaration(path) {
		let { parentPath, node, scope } = path;
		if (!parentPath.isBlock()) {//过滤掉部分特殊情况，例如for循环里的变量定义
			return;
		}
		let { declarations, kind } = node;
		if (declarations.length != 1) {
			return;
		}

		let { id, init } = declarations[0];
		if (!types.isFunctionExpression(init, { id: null })) {
			return;
		}

		let { params, body } = init;
		let newNode = types.FunctionDeclaration(id, params, body);
		path.replaceWith(newNode);
	}
}



function SequenceOfStatement(path) {
	let { scope, parentPath, node } = path;
	if (parentPath.parentPath.isLabeledStatement()) {//标签节点无法往前插入。
		return;
	}
	let expressions = node.expressions;
	if (parentPath.isReturnStatement({ "argument": node }) ||
		parentPath.isThrowStatement({ "argument": node })) {
		parentPath.node.argument = expressions.pop();
	}
	else if (parentPath.isIfStatement({ "test": node }) ||
		parentPath.isWhileStatement({ "test": node })) {
		parentPath.node.test = expressions.pop();
	}
	else if (parentPath.isForStatement({ "init": node })) {
		parentPath.node.init = expressions.pop();
	}
	else if (parentPath.isForInStatement({ "right": node }) ||
		parentPath.isForOfStatement({ "right": node })) {
		parentPath.node.right = expressions.pop();
	}
	else if (parentPath.isSwitchStatement({ "discriminant": node })) {
		parentPath.node.discriminant = expressions.pop();
	}

	else if (parentPath.isExpressionStatement({ "expression": node })) {
		parentPath.node.expression = expressions.pop();
	}
	else {
		return;
	}

	for (let expression of expressions) {
		parentPath.insertBefore(types.ExpressionStatement(expression = expression));
	}
}

function SequenceOfExpression(path) {
	let { scope, parentPath, node, parent } = path;
	let ancestorPath = parentPath.parentPath;
	let expressions = node.expressions;
	if (parentPath.isConditionalExpression({ "test": node }) &&
		ancestorPath.isExpressionStatement({ "expression": parent })) {
		parentPath.node.test = expressions.pop();
	}
	else if (parentPath.isVariableDeclarator({ "init": node }) &&
		ancestorPath.parentPath.isBlock()) {
		parentPath.node.init = expressions.pop();
	}
	else if (parentPath.isUnaryExpression({ "argument": node }) &&
		ancestorPath.isExpressionStatement({ "expression": parent })) {
		parentPath.node.argument = expressions.pop();
	}
	else if (parentPath.isAssignmentExpression({ "right": node }) &&
		ancestorPath.isExpressionStatement({ "expression": parent })) {
		parentPath.node.right = expressions.pop();
	}
	else if ((parentPath.isCallExpression({ "callee": node }) ||
		parentPath.isNewExpression({ "callee": node })) &&
		ancestorPath.isExpressionStatement({ "expression": parent })) {
		parentPath.node.callee = expressions.pop();
	}
	else {
		return;
	}

	for (let expression of expressions) {
		ancestorPath.insertBefore(types.ExpressionStatement(expression = expression));
	}
}

const resolveSequence =
{
	SequenceExpression:
	{//对同一节点遍历多个方法
		exit: [SequenceOfStatement, SequenceOfExpression]
	}
}


const removeDeadCode = {
	"IfStatement|ConditionalExpression"(path) {
		let { consequent, alternate } = path.node;
		let testPath = path.get('test');
		const evaluateTest = testPath.evaluateTruthy();
		if (evaluateTest === true) {
			if (types.isBlockStatement(consequent)) {
				consequent = consequent.body;
			}
			path.replaceWithMultiple(consequent);
			return;
		}
		if (evaluateTest === false) {
			if (alternate != null) {
				if (types.isBlockStatement(alternate)) {
					alternate = alternate.body;
				}
				path.replaceWithMultiple(alternate);
			}
			else {
				path.remove();
			}
		}
	},
	"LogicalExpression"(path) {
		let { left, operator, right } = path.node;

		let leftPath = path.get('left');

		const evaluateLeft = leftPath.evaluateTruthy();

		if ((operator == "||" && evaluateLeft == true) ||
			(operator == "&&" && evaluateLeft == false)) {
			path.replaceWith(left);
			return;
		}
		if ((operator == "||" && evaluateLeft == false) ||
			(operator == "&&" && evaluateLeft == true)) {
			path.replaceWith(right);
		}
	},
	"EmptyStatement|DebuggerStatement"(path) {
		path.remove();
	},
}
// 检查路径或其任一子路径是否包含逗号表达式
function containsSequenceExpression(path) {
	let containsSequence = false;
	// 深度优先遍历当前路径及其所有子路径
	path.traverse({
		SequenceExpression() {
			containsSequence = true;
			path.stop(); // 找到逗号表达式后立即停止遍历
		}
	});
	return containsSequence;
}



const constantFold = {
	"BinaryExpression|UnaryExpression|MemberExpression|CallExpression"(path) {

		if (containsSequenceExpression(path)) {
			return;
		}
		if (path.isUnaryExpression({ operator: "-" }) ||
			path.isUnaryExpression({ operator: "void" })) {
			return;
		}

		// 处理含副作用的序列表达式
		if (path.isSequenceExpression()) {
			return;
		}

		const { confident, value } = path.evaluate();

		if (!confident || typeof value == "function")
			return;

		if (typeof value == 'number' && (!Number.isFinite(value))) {
			return;
		}

		path.replaceWith(types.valueToNode(value));
	},
}

const simplifyLiteral = {
	NumericLiteral({ node }) {
		if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
	StringLiteral({ node }) {
		if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
}


// Extract JS from each script tag
$('script').each((index, element) => {
	
	let eleCode = $(element).html();
	if (eleCode.length == 0)
	{
		return;
	}
	let ast = parser.parse(eleCode);

	if (1) {

		traverse(ast, keyToLiteral);

		traverse(ast, standardLoop);

		traverse(ast, DeclaratorToDeclaration);

		traverse(ast, varDeclarToFuncDeclar);

		traverse(ast, resolveSequence);

		ast = parser.parse(generator(ast).code);

		traverse(ast, constantFold); //需要使用专版babel库,如果不是，请将其屏蔽

		traverse(ast, removeDeadCode);
	}


	traverse(ast, simplifyLiteral);

	let { code } = generator(ast, opts = {
		"compact": false,  // 是否压缩代码
		"comments": false,  // 是否保留注释
		"jsescOption": { "minimal": true },  //Unicode转义
	});
	console.log(`第${index}个文件已处理完毕！`);

	let resFileName = encodeHtml.slice(0, encodeHtml.length - 3) + `_${index}.js`;

	fs.writeFile(resFileName, code, (err) => { });
});
