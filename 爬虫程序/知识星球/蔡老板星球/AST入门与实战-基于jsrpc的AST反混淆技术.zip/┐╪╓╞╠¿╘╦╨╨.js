(function() {


    function isAllEnglishLetters (str) {
        if (str.length == 0) return true;
        return /^[\x20-\x7E]+$/.test(str);
    }

    if (window.WebSocket) {
        //这个if判断是可以去掉的。这里为了好看，在if语句外可以随便做你想做的事情，不报错即可。
        window.ws = new WebSocket('ws://127.0.0.1:10512/');
        window.ws.onopen = function(e) {
            console.log("连接服务器成功");
            window.ws.send("Browser");
        }
        window.ws.onclose = function(e) {
            console.log("服务器关闭");
        }
        window.ws.onerror = function() {
            console.log("连接出错");
        }
        window.ws.onmessage = function(e) {
            //发送服务在这里，函数可以随便掉。不报错即可。
            try {

                var result = eval(e.data);

                if (isAllEnglishLetters(result)) {
                    console.log(e.data, result);
                    //发送给Python
                    window.ws.send(e.data + '"""' + result);
                }

            } catch (e) {}
            ;
        }
    }
}
)();