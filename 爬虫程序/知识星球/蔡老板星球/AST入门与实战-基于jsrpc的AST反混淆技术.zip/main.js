﻿const file = require('fs');
const parser = require("@babel/parser");
const traverse = require("@babel/traverse").default;
const types = require("@babel/types");
const t = require("@babel/types");
const generator = require("@babel/generator").default;


//将源代码解析为AST
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";

let sourceCode = file.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);

ast = parser.parse(generator(ast).code);


let CallExpress = {};


const collectCall =
{
	CallExpression:
	{
		exit(path) {

			let sourceCode = path.toString();

			if (sourceCode.length < 13 || sourceCode.slice(2, 4) != "()") {
				return;
			}

			CallExpress[path.toString()] = path;
		}
	}
}


traverse(ast, collectCall);

console.log(Object.keys(CallExpress))


var ws = require("nodejs-websocket");
const { exit } = require('process');

console.log("开始建立连接...")



var server = ws.createServer(function (conn) {
	let cached = {};
	let strtmp = "";


	conn.on("text", function (msg) {
		if (!msg) return;
		let info = msg.split('"""');

		if (typeof info[1] == "string") {
			console.log(info[0], info[1])
			CallExpress[info[0]].replaceWith(types.valueToNode(info[1]));
		}
		var key = conn.key;
		if ((msg === "Browser") || (msg === "Python")) {
			// browser或者python第一次连接
			for (const ele of Object.keys(CallExpress)) {
				conn.send(ele);
			}
			cached[msg] = key;
			console.log("cached", cached);
			return;
		}

	})
	conn.on("close", function (code, reason) {
		let retCode = generator(ast).code;
		file.writeFile("ok.js", retCode, (err) => { });
		console.log("关闭连接")
	});
	conn.on("error", function (code, reason) {
		console.log("异常关闭")
	});
}).listen(10512)

console.log("WebSocket建立完毕");







