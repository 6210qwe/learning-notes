const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const { Console } = require('console');
const { identifier } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode, {
	sourceType: "script",
	createParenthesizedExpressions: true
});
console.time("处理完毕，耗时");



let ifNODETEP = template(`if(A){B;}`);

const LogicalToIfStatement =
{
	LogicalExpression: {
		exit(path) {
			let { node, parentPath } = path;

			if (!parentPath.isLogicalExpression({ "left": node })) {
				//return;
			}

			let statePath = path.findParent(p => p.isExpressionStatement());

			if (!statePath) {
				return;
			}

			let { left, operator, right } = node;

			if (operator !== "&&") {
				return;
			}

			let leftCode = generator(left).code;
			let rightCode = generator(right).code;
			let allCode = statePath.toString();

			if (allCode.startsWith(leftCode)) {

				let index = allCode.indexOf(rightCode) - 1;

				let newCode = allCode.slice(index);


				let B = template.statement.ast(newCode);

				let ifNode = ifNODETEP({ "A": left, "B": B });

				statePath.replaceWith(ifNode);

			}


		}
	},

}



const resolveSequence =
{
    SequenceExpression:
    {
        /**  @param  {NodePath} path */
        exit(path) {

            let statementPath = path.getStatementParent();
            if (!statementPath || path.parentPath.isArrowFunctionExpression()) 
            {
                return;
            }

            let canVisitFlag = true;

            statementPath.traverse({
                "LogicalExpression|ConditionalExpression"(_path) {
                    if (!_path.isAncestor(path)) {

                        return;
                    }

                    let key = _path.isLogicalExpression() ? "left" : "test";

                    let execPath = _path.get(key);

                    if (execPath != path && !execPath.isAncestor(path)) {
                        canVisitFlag = false;
                        _path.stop();
                    }
                },
            })

            if (!canVisitFlag) return;

            if (statementPath.isLoop()) {//循环表达式内的test节点，不能随意插在该表达式前面

                let initPath = statementPath.get('init');

                if (initPath.node == undefined || (initPath != path && !initPath.isAncestor(path))) {
                    return
                }
            }

            let expressions = path.node.expressions;
            let lastNode = expressions.pop();

            for (let expression of expressions) {
                statementPath.insertBefore(types.ExpressionStatement(expression = expression));
            }

            path.replaceWith(lastNode);

        }
    }
}





for (let i = 0; i < 10; i++) {

	ast = parser.parse(generator(ast).code, {
		sourceType: "script",
		createParenthesizedExpressions: true
	});

	traverse(ast, LogicalToIfStatement);

	traverse(ast, resolveSequence);

}

console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });