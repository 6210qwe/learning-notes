function G(b, e, f, a, c, l, m, I) {
    if (null == l) {
        l = this;
    }

    var C,
        q,
        w,
        S = [],
        R = 0;
    m && (C = m);
    var x,
        z,
        O = e,
        E = O + 2 * f;

    if (!I) {
        for (; O < E;) {
            var j = parseInt("" + b[O] + b[O + 1], 16);
            O += 2;
            var A = 3 & (x = 13 * j % 241);
            x >>= 4;
            A = x;

            switch (j) {
                case 0:
                    return [1, S[R--]];
                    break;

                case 1:
                    S[R] = !S[R];
                    break;

                case 2:
                    for (z = v(b, O), C = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        C += String.fromCharCode(r ^ i.p[P]);
                    }

                    S[++R] = C, O += 4;
                    break;

                case 3:
                    var D = 0,
                        T = S[R].length,
                        $ = S[R];

                    S[++R] = function() {
                        var b = D < T;

                        if (b) {
                            var e = $[D++];
                            S[++R] = e;
                        }

                        S[++R] = b;
                    };

                    break;

                case 4:
                    q = S[R--], (A = S[R]).x === G ? A.y >= 1 ? S[R] = K(b, A.c, A.l, [q], A.z, w, null, 1) : (S[R] = K(b, A.c, A.l, [q], A.z, w, null, 0), A.y++) : S[R] = A(q);
                    break;

                case 5:
                    z = s(b, O);

                    try {
                        if (t[o][2] = 1, 1 == (C = G(b, O + 4, z - 3, [], c, l, null, 0))[0]) {
                            return C;
                        }
                    } catch (m) {
                        if (t[o] && t[o][1] && 1 == (C = G(b, t[o][1][0], t[o][1][1], [], c, l, m, 0))[0]) {
                            return C;
                        }
                    } finally {
                        if (t[o] && t[o][0] && 1 == (C = G(b, t[o][0][0], t[o][0][1], [], c, l, null, 0))[0]) {
                            return C;
                        }

                        t[o] = 0, o--;
                    }

                    O += 2 * z - 2;
                    break;

                case 6:
                    z = s(b, O), t[o][0] && !t[o][2] ? t[o][1] = [O + 4, z - 3] : t[o++] = [0, [O + 4, z - 3], 0], O += 2 * z - 2;
                    break;

                case 8:
                    S[R] = h(S[R]);
                    break;

                case 9:
                    q = S[R--], C = delete S[R--][q];
                    break;

                case 10:
                    z = v(b, O), O += 4, q = R + 1, S[R -= z - 1] = z ? S.slice(R, q) : [];
                    break;

                case 11:
                    z = y(b, O), O += 2, S[R] = S[R][z];
                    break;

                case 13:
                    C = S[R -= 2][S[R + 1]] = S[R + 2], R--;
                    break;

                case 16:
                    q = S[R--], w = S[R--], (A = S[R--]).x === G ? A.y >= 1 ? S[++R] = K(b, A.c, A.l, q, A.z, w, null, 1) : (S[++R] = K(b, A.c, A.l, q, A.z, w, null, 0), A.y++) : S[++R] = A.apply(w, q);
                    break;

                case 17:
                    S[++R] = l;
                    break;

                case 18:
                    S[++R] = !1;
                    break;

                case 19:
                    S[++R] = g;
                    break;

                case 20:
                    for (z = v(b, O), A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        A += String.fromCharCode(r ^ i.p[P]);
                    }

                    A = +A, O += 4, S[++R] = A;
                    break;

                case 22:
                    if ((z = s(b, O)) < 0) {
                        I = 1, F(b, e, 2 * f), O += 2 * z - 2;
                        break;
                    }

                    O += 2 * z - 2;
                    break;

                case 23:
                    if (S[R--]) {
                        O += 4;
                    } else {
                        if ((z = s(b, O)) < 0) {
                            I = 1, F(b, e, 2 * f), O += 2 * z - 2;
                            break;
                        }

                        O += 2 * z - 2;
                    }

                    break;

                case 24:
                    z = y(b, O), O += 2, C = c[z], S[++R] = C;
                    break;

                case 25:
                    S[R -= 1] = S[R][S[R + 1]];
                    break;

                case 26:
                    z = y(b, O), O += 2, S[R -= z] = 0 === z ? new S[R]() : d(S[R], n(S.slice(R + 1, R + z + 1)));
                    break;

                case 27:
                    z = y(b, O), O += 2, S[++R] = c["$" + z];
                    break;

                case 28:
                    C = S[R--];
                    break;

                case 29:
                    for (C = S[R--], z = v(b, O), A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        A += String.fromCharCode(r ^ i.p[P]);
                    }

                    O += 4, S[R--][A] = C;
                    break;

                case 30:
                    for (z = v(b, O), A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        A += String.fromCharCode(r ^ i.p[P]);
                    }

                    O += 4, S[R] = S[R][A];
                    break;

                case 31:
                    z = y(b, O), O += 2, C = S[R--], c[z] = C;
                    break;

                case 32:
                    S[++R] = !0;
                    break;

                case 33:
                    S[++R] = void 0;
                    break;

                case 34:
                    C = S[R], S[++R] = C;
                    break;

                case 35:
                    C = S[R - 1], q = S[R], S[++R] = C, S[++R] = q;
                    break;

                case 36:
                    C = S[R], S[R] = S[R - 1], S[R - 1] = C;
                    break;

                case 37:
                    z = s(b, O), (U = function e() {
                        var f = arguments;
                        return e.y > 0 ? K(b, e.c, e.l, f, e.z, this, null, 0) : (e.y++, K(b, e.c, e.l, f, e.z, this, null, 0));
                    }).c = O + 4, U.l = z - 2, U.x = G, U.y = 0, U.z = c, S[R] = U, O += 2 * z - 2;
                    break;

                case 38:
                    S[++R] = null;
                    break;

                case 39:
                    S[++R] = C;
                    break;

                case 40:
                    C = S[R--], S[R] = S[R] + C;
                    break;

                case 41:
                    C = S[R--], S[R] = S[R] - C;
                    break;

                case 42:
                    C = S[R--], S[R] = S[R] * C;
                    break;

                case 43:
                    C = S[R--], S[R] = S[R] / C;
                    break;

                case 44:
                    C = S[R--], S[R] = S[R] % C;
                    break;

                case 45:
                    S[R] = ++S[R];
                    break;

                case 46:
                    S[R] = --S[R];
                    break;

                case 47:
                    C = S[R--], S[R] = S[R] & C;
                    break;

                case 48:
                    C = S[R--], S[R] = S[R] | C;
                    break;

                case 49:
                    C = S[R--], S[R] = S[R] ^ C;
                    break;

                case 51:
                    C = S[R--], S[R] = S[R] << C;
                    break;

                case 52:
                    C = S[R--], S[R] = S[R] >> C;
                    break;

                case 53:
                    C = S[R--], S[R] = S[R] >>> C;
                    break;

                case 57:
                    C = S[R--], S[R] = S[R] > C;
                    break;

                case 58:
                    C = S[R--], S[R] = S[R] < C;
                    break;

                case 59:
                    C = S[R--], S[R] = S[R] >= C;
                    break;

                case 60:
                    C = S[R--], S[R] = S[R] <= C;
                    break;

                case 61:
                    C = S[R--], S[R] = S[R] == C;
                    break;

                case 62:
                    C = S[R--], S[R] = S[R] === C;
                    break;

                case 63:
                    C = S[R--], S[R] = S[R] != C;
                    break;

                case 64:
                    C = S[R--], S[R] = S[R] !== C;
                    break;

                case 65:
                    C = S[R--], S[R] = S[R] instanceof C;
                    break;

                case 66:
                    C = S[R--], S[R] = S[R] in C;
                    break;

                case 67:
                    C = S[R--], S[R] = typeof C;
                    break;

                case 70:
                    z = s(b, O), t[++o] = [
                        [O + 4, z - 3], 0, 0
                    ], O += 2 * z - 2;
                    break;

                case 72:
                    S[++R] = u(b, O), O += 2;
                    break;

                case 73:
                    S[++R] = s(b, O), O += 4;
                    break;

                case 74:
                    S[++R] = p(b, O), O += 8;
                    break;

                default:
                    return;
            }
        }
    }

    if (I) {
        for (; O < E;) {
            j = B[O];
            O += 2;
            A = 3 & (x = 13 * j % 241);
            x >>= 4;
            A = x;

            switch (j) {
                case 0:
                    return [1, S[R--]];
                    break;

                case 1:
                    S[R] = !S[R];
                    break;

                case 2:
                    for (z = W[O], C = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        C += String.fromCharCode(r ^ i.p[P]);
                    }

                    S[++R] = C, O += 4;
                    break;

                case 3:
                    D = 0, T = S[R].length, $ = S[R];

                    S[++R] = function() {
                        var b = D < T;

                        if (b) {
                            var e = $[D++];
                            S[++R] = e;
                        }

                        S[++R] = b;
                    };

                    break;

                case 4:
                    q = S[R--], (A = S[R]).x === G ? A.y >= 1 ? S[R] = K(b, A.c, A.l, [q], A.z, w, null, 1) : (S[R] = K(b, A.c, A.l, [q], A.z, w, null, 0), A.y++) : S[R] = A(q);
                    break;

                case 5:
                    z = W[O];

                    try {
                        if (t[o][2] = 1, 1 == (C = G(b, O + 4, z - 3, [], c, l, null, 0))[0]) {
                            return C;
                        }
                    } catch (m) {
                        if (t[o] && t[o][1] && 1 == (C = G(b, t[o][1][0], t[o][1][1], [], c, l, m, 0))[0]) {
                            return C;
                        }
                    } finally {
                        if (t[o] && t[o][0] && 1 == (C = G(b, t[o][0][0], t[o][0][1], [], c, l, null, 0))[0]) {
                            return C;
                        }

                        t[o] = 0, o--;
                    }

                    O += 2 * z - 2;
                    break;

                case 6:
                    z = W[O], t[o][0] && !t[o][2] ? t[o][1] = [O + 4, z - 3] : t[o++] = [0, [O + 4, z - 3], 0], O += 2 * z - 2;
                    break;

                case 8:
                    S[R] = h(S[R]);
                    break;

                case 9:
                    q = S[R--], C = delete S[R--][q];
                    break;

                case 10:
                    z = W[O], O += 4, q = R + 1, S[R -= z - 1] = z ? S.slice(R, q) : [];
                    break;

                case 11:
                    z = W[O], O += 2, S[R] = S[R][z];
                    break;

                case 13:
                    C = S[R -= 2][S[R + 1]] = S[R + 2], R--;
                    break;

                case 16:
                    q = S[R--], w = S[R--], (A = S[R--]).x === G ? A.y >= 1 ? S[++R] = K(b, A.c, A.l, q, A.z, w, null, 1) : (S[++R] = K(b, A.c, A.l, q, A.z, w, null, 0), A.y++) : S[++R] = A.apply(w, q);
                    break;

                case 17:
                    S[++R] = l;
                    break;

                case 18:
                    S[++R] = !1;
                    break;

                case 19:
                    S[++R] = g;
                    break;

                case 20:
                    for (z = W[O], A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        A += String.fromCharCode(r ^ i.p[P]);
                    }

                    A = +A, O += 4, S[++R] = A;
                    break;

                case 22:
                    O += 2 * (z = W[O]) - 2;
                    break;

                case 23:
                    if (S[R--]) {
                        O += 4;
                    } else {
                        O += 2 * (z = W[O]) - 2;
                    }

                    break;

                case 24:
                    z = W[O], O += 2, C = c[z], S[++R] = C;
                    break;

                case 25:
                    S[R -= 1] = S[R][S[R + 1]];
                    break;

                case 26:
                    z = W[O], O += 2, S[R -= z] = 0 === z ? new S[R]() : d(S[R], n(S.slice(R + 1, R + z + 1)));
                    break;

                case 27:
                    z = W[O], O += 2, S[++R] = c["$" + z];
                    break;

                case 28:
                    C = S[R--];
                    break;

                case 29:
                    for (C = S[R--], z = W[O], A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        A += String.fromCharCode(r ^ i.p[P]);
                    }

                    O += 4, S[R--][A] = C;
                    break;

                case 30:
                    for (z = W[O], A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
                        A += String.fromCharCode(r ^ i.p[P]);
                    }

                    O += 4, S[R] = S[R][A];
                    break;

                case 31:
                    z = W[O], O += 2, C = S[R--], c[z] = C;
                    break;

                case 32:
                    S[++R] = !0;
                    break;

                case 33:
                    S[++R] = void 0;
                    break;

                case 34:
                    C = S[R], S[++R] = C;
                    break;

                case 35:
                    C = S[R - 1], q = S[R], S[++R] = C, S[++R] = q;
                    break;

                case 36:
                    C = S[R], S[R] = S[R - 1], S[R - 1] = C;
                    break;

                case 37:
                    z = W[O], (U = function e() {
                        var f = arguments;
                        return e.y > 0 ? K(b, e.c, e.l, f, e.z, this, null, 0) : (e.y++, K(b, e.c, e.l, f, e.z, this, null, 0));
                    }).c = O + 4, U.l = z - 2, U.x = G, U.y = 0, U.z = c, S[R] = U, O += 2 * z - 2;
                    break;

                case 38:
                    S[++R] = null;
                    break;

                case 39:
                    S[++R] = C;
                    break;

                case 40:
                    C = S[R--], S[R] = S[R] + C;
                    break;

                case 41:
                    C = S[R--], S[R] = S[R] - C;
                    break;

                case 42:
                    C = S[R--], S[R] = S[R] * C;
                    break;

                case 43:
                    C = S[R--], S[R] = S[R] / C;
                    break;

                case 44:
                    C = S[R--], S[R] = S[R] % C;
                    break;

                case 45:
                    S[R] = ++S[R];
                    break;

                case 46:
                    S[R] = --S[R];
                    break;

                case 47:
                    C = S[R--], S[R] = S[R] & C;
                    break;

                case 48:
                    C = S[R--], S[R] = S[R] | C;
                    break;

                case 49:
                    C = S[R--], S[R] = S[R] ^ C;
                    break;

                case 51:
                    C = S[R--], S[R] = S[R] << C;
                    break;

                case 52:
                    C = S[R--], S[R] = S[R] >> C;
                    break;

                case 53:
                    C = S[R--], S[R] = S[R] >>> C;
                    break;

                case 57:
                    C = S[R--], S[R] = S[R] > C;
                    break;

                case 58:
                    C = S[R--], S[R] = S[R] < C;
                    break;

                case 59:
                    C = S[R--], S[R] = S[R] >= C;
                    break;

                case 60:
                    C = S[R--], S[R] = S[R] <= C;
                    break;

                case 61:
                    C = S[R--], S[R] = S[R] == C;
                    break;

                case 62:
                    C = S[R--], S[R] = S[R] === C;
                    break;

                case 63:
                    C = S[R--], S[R] = S[R] != C;
                    break;

                case 64:
                    C = S[R--], S[R] = S[R] !== C;
                    break;

                case 65:
                    C = S[R--], S[R] = S[R] instanceof C;
                    break;

                case 66:
                    C = S[R--], S[R] = S[R] in C;
                    break;

                case 67:
                    C = S[R--], S[R] = typeof C;
                    break;

                case 70:
                    z = W[O], t[++o] = [
                        [O + 4, z - 3], 0, 0
                    ], O += 2 * z - 2;
                    break;

                case 72:
                    S[++R] = W[O], O += 2;
                    break;

                case 73:
                    S[++R] = W[O], O += 4;
                    break;

                case 74:
                    S[++R] = W[O], O += 8;
                    break;

                default:
                    return;
            }
        }
    }

    return [0, null];
}