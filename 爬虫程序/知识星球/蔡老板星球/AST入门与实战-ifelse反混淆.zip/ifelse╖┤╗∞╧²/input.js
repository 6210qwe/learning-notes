function G(b, e, f, a, c, l, m, I) {
  if (null == l) {
    l = this;
  }

  var C,
      q,
      w,
      S = [],
      R = 0;
  m && (C = m);
  var x,
      z,
      O = e,
      E = O + 2 * f;
  if (!I) for (; O < E;) {
    var j = parseInt("" + b[O] + b[O + 1], 16);
    O += 2;
    var A = 3 & (x = 13 * j % 241);

    if (x >>= 2, A < 1) {
      A = 3 & x;
      if (x >>= 2, A > 2) {
        if ((A = x) > 10) {
          S[++R] = void 0;
        } else {
          if (A > 1) {
            C = S[R--], S[R] = S[R] >= C;
          } else {
            if (A > -1) {
              S[++R] = null;
            }
          }
        }
      } else if (A > 1) {
        if ((A = x) > 11) throw S[R--];

        if (A > 7) {
          for (C = S[R--], z = v(b, O), A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            A += String.fromCharCode(r ^ i.p[P]);
          }

          O += 4, S[R--][A] = C;
        } else if (A > 5) {
          S[R] = h(S[R]);
        }
      } else if (A > 0) {
        if ((A = x) > 8) {
          C = S[R--], S[R] = typeof C;
        } else {
          if (A > 6) {
            S[R] = --S[R];
          } else {
            if (A > 4) {
              S[R -= 1] = S[R][S[R + 1]];
            } else {
              if (A > 2) {
                q = S[R--], (A = S[R]).x === G ? A.y >= 1 ? S[R] = K(b, A.c, A.l, [q], A.z, w, null, 1) : (S[R] = K(b, A.c, A.l, [q], A.z, w, null, 0), A.y++) : S[R] = A(q);
              }
            }
          }
        }
      } else {
        if ((A = x) > 14) z = s(b, O), (U = function e() {
          var f = arguments;
          return e.y > 0 ? K(b, e.c, e.l, f, e.z, this, null, 0) : (e.y++, K(b, e.c, e.l, f, e.z, this, null, 0));
        }).c = O + 4, U.l = z - 2, U.x = G, U.y = 0, U.z = c, S[R] = U, O += 2 * z - 2;else if (A > 12) q = S[R--], w = S[R--], (A = S[R--]).x === G ? A.y >= 1 ? S[++R] = K(b, A.c, A.l, q, A.z, w, null, 1) : (S[++R] = K(b, A.c, A.l, q, A.z, w, null, 0), A.y++) : S[++R] = A.apply(w, q);else if (A > 5) C = S[R--], S[R] = S[R] != C;else if (A > 3) C = S[R--], S[R] = S[R] * C;else if (A > -1) return [1, S[R--]];
      }
    } else if (A < 2) {
      A = 3 & x;

      if (x >>= 2, A < 1) {
        if ((A = x) > 9) ;else if (A > 7) C = S[R--], S[R] = S[R] & C;else if (A > 5) z = y(b, O), O += 2, S[R -= z] = 0 === z ? new S[R]() : d(S[R], n(S.slice(R + 1, R + z + 1)));else if (A > 3) {
          z = s(b, O);

          try {
            if (t[o][2] = 1, 1 == (C = G(b, O + 4, z - 3, [], c, l, null, 0))[0]) return C;
          } catch (m) {
            if (t[o] && t[o][1] && 1 == (C = G(b, t[o][1][0], t[o][1][1], [], c, l, m, 0))[0]) return C;
          } finally {
            if (t[o] && t[o][0] && 1 == (C = G(b, t[o][0][0], t[o][0][1], [], c, l, null, 0))[0]) return C;
            t[o] = 0, o--;
          }

          O += 2 * z - 2;
        }
      } else if (A < 2) {
        if ((A = x) > 12) S[++R] = u(b, O), O += 2;else if (A > 10) C = S[R--], S[R] = S[R] << C;else if (A > 8) {
          for (z = v(b, O), A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            A += String.fromCharCode(r ^ i.p[P]);
          }

          O += 4, S[R] = S[R][A];
        } else if (A > 6) {
          q = S[R--], C = delete S[R--][q];
        }
      } else if (A < 3) {
        if ((A = x) < 2) {
          S[++R] = C;
        } else {
          if (A < 4) {
            C = S[R--], S[R] = S[R] <= C;
          } else {
            if (A < 11) {
              C = S[R -= 2][S[R + 1]] = S[R + 2], R--;
            } else {
              if (A < 13) {
                C = S[R], S[++R] = C;
              }
            }
          }
        }
      } else {
        if ((A = x) > 12) S[++R] = l;else if (A > 5) C = S[R--], S[R] = S[R] !== C;else if (A > 3) C = S[R--], S[R] = S[R] / C;else if (A > 1) {
          if ((z = s(b, O)) < 0) {
            I = 1, F(b, e, 2 * f), O += 2 * z - 2;
            break;
          }

          O += 2 * z - 2;
        } else if (A > -1) {
          S[R] = !S[R];
        }
      }
    } else if (A < 3) {
      A = 3 & x;
      if (x >>= 2, A > 2) {
        if ((A = x) > 7) {
          C = S[R--], S[R] = S[R] | C;
        } else {
          if (A > 5) {
            z = y(b, O), O += 2, S[++R] = c["$" + z];
          } else {
            if (A > 3) {
              z = s(b, O), t[o][0] && !t[o][2] ? t[o][1] = [O + 4, z - 3] : t[o++] = [0, [O + 4, z - 3], 0], O += 2 * z - 2;
            }
          }
        }
      } else if (A > 1) {
        if ((A = x) < 2) {
          for (z = v(b, O), C = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            C += String.fromCharCode(r ^ i.p[P]);
          }

          S[++R] = C, O += 4;
        } else if (A < 4) {
          if (S[R--]) O += 4;else {
            if ((z = s(b, O)) < 0) {
              I = 1, F(b, e, 2 * f), O += 2 * z - 2;
              break;
            }

            O += 2 * z - 2;
          }
        } else if (A < 6) {
          C = S[R--], S[R] = S[R] % C;
        } else {
          if (A < 8) {
            C = S[R--], S[R] = S[R] instanceof C;
          } else {
            if (A < 15) {
              S[++R] = !1;
            }
          }
        }
      } else if (A > 0) {
        if ((A = x) < 1) {
          S[++R] = g;
        } else {
          if (A < 3) {
            C = S[R--], S[R] = S[R] + C;
          } else {
            if (A < 5) {
              C = S[R--], S[R] = S[R] == C;
            } else {
              if (A < 14) {
                C = S[R - 1], q = S[R], S[++R] = C, S[++R] = q;
              }
            }
          }
        }
      } else {
        if ((A = x) < 2) {
          C = S[R--], S[R] = S[R] > C;
        } else {
          if (A < 9) {
            z = v(b, O), O += 4, q = R + 1, S[R -= z - 1] = z ? S.slice(R, q) : [];
          } else {
            if (A < 11) {
              z = y(b, O), O += 2, C = S[R--], c[z] = C;
            } else {
              if (A < 13) {
                C = S[R--], S[R] = S[R] >> C;
              } else {
                if (A < 15) {
                  S[++R] = s(b, O), O += 4;
                }
              }
            }
          }
        }
      }
    } else {
      A = 3 & x;
      if (x >>= 2, A > 2) {
        if ((A = x) > 13) {
          S[++R] = p(b, O), O += 8;
        } else {
          if (A > 11) {
            C = S[R--], S[R] = S[R] >>> C;
          } else {
            if (A > 9) {
              S[++R] = !0;
            } else {
              if (A > 7) {
                z = y(b, O), O += 2, S[R] = S[R][z];
              } else {
                if (A > 0) {
                  C = S[R--], S[R] = S[R] < C;
                }
              }
            }
          }
        }
      } else if (A > 1) {
        if ((A = x) > 10) {
          z = s(b, O), t[++o] = [[O + 4, z - 3], 0, 0], O += 2 * z - 2;
        } else {
          if (A > 8) {
            C = S[R--], S[R] = S[R] ^ C;
          } else {
            if (A > 6) {
              C = S[R--];
            }
          }
        }
      } else if (A > 0) {
        if ((A = x) < 3) {
          var D = 0,
              T = S[R].length,
              $ = S[R];

          S[++R] = function () {
            var b = D < T;

            if (b) {
              var e = $[D++];
              S[++R] = e;
            }

            S[++R] = b;
          };
        } else if (A < 5) {
          z = y(b, O), O += 2, C = c[z], S[++R] = C;
        } else {
          if (A < 7) {
            S[R] = ++S[R];
          } else {
            if (A < 9) {
              C = S[R--], S[R] = S[R] in C;
            }
          }
        }
      } else {
        if ((A = x) > 13) C = S[R], S[R] = S[R - 1], S[R - 1] = C;else if (A > 4) C = S[R--], S[R] = S[R] === C;else if (A > 2) C = S[R--], S[R] = S[R] - C;else if (A > 0) {
          for (z = v(b, O), A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            A += String.fromCharCode(r ^ i.p[P]);
          }

          A = +A, O += 4, S[++R] = A;
        }
      }
    }
  }
  if (I) for (; O < E;) {
    j = B[O];
    O += 2;
    A = 3 & (x = 13 * j % 241);

    if (x >>= 2, A < 1) {
      var U;
      A = 3 & x;

      if (x >>= 2, A < 1) {
        if ((A = x) > 14) z = W[O], (U = function e() {
          var f = arguments;
          return e.y > 0 ? K(b, e.c, e.l, f, e.z, this, null, 0) : (e.y++, K(b, e.c, e.l, f, e.z, this, null, 0));
        }).c = O + 4, U.l = z - 2, U.x = G, U.y = 0, U.z = c, S[R] = U, O += 2 * z - 2;else if (A > 12) q = S[R--], w = S[R--], (A = S[R--]).x === G ? A.y >= 1 ? S[++R] = K(b, A.c, A.l, q, A.z, w, null, 1) : (S[++R] = K(b, A.c, A.l, q, A.z, w, null, 0), A.y++) : S[++R] = A.apply(w, q);else if (A > 5) C = S[R--], S[R] = S[R] != C;else if (A > 3) C = S[R--], S[R] = S[R] * C;else if (A > -1) return [1, S[R--]];
      } else if (A < 2) {
        if ((A = x) < 4) {
          q = S[R--], (A = S[R]).x === G ? A.y >= 1 ? S[R] = K(b, A.c, A.l, [q], A.z, w, null, 1) : (S[R] = K(b, A.c, A.l, [q], A.z, w, null, 0), A.y++) : S[R] = A(q);
        } else {
          if (A < 6) {
            S[R -= 1] = S[R][S[R + 1]];
          } else {
            if (A < 8) {
              S[R] = --S[R];
            } else {
              if (A < 10) {
                C = S[R--], S[R] = typeof C;
              }
            }
          }
        }
      } else if (A < 3) {
        if ((A = x) > 11) throw S[R--];

        if (A > 7) {
          for (C = S[R--], z = W[O], A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            A += String.fromCharCode(r ^ i.p[P]);
          }

          O += 4, S[R--][A] = C;
        } else if (A > 5) {
          S[R] = h(S[R]);
        }
      } else {
        if ((A = x) < 1) {
          S[++R] = null;
        } else {
          if (A < 3) {
            C = S[R--], S[R] = S[R] >= C;
          } else {
            if (A < 12) {
              S[++R] = void 0;
            }
          }
        }
      }
    } else if (A < 2) {
      A = 3 & x;
      if (x >>= 2, A > 2) {
        if ((A = x) > 12) {
          S[++R] = l;
        } else {
          if (A > 5) {
            C = S[R--], S[R] = S[R] !== C;
          } else {
            if (A > 3) {
              C = S[R--], S[R] = S[R] / C;
            } else {
              if (A > 1) {
                O += 2 * (z = W[O]) - 2;
              } else {
                if (A > -1) {
                  S[R] = !S[R];
                }
              }
            }
          }
        }
      } else if (A > 1) {
        if ((A = x) < 2) {
          S[++R] = C;
        } else {
          if (A < 4) {
            C = S[R--], S[R] = S[R] <= C;
          } else {
            if (A < 11) {
              C = S[R -= 2][S[R + 1]] = S[R + 2], R--;
            } else {
              if (A < 13) {
                C = S[R], S[++R] = C;
              }
            }
          }
        }
      } else if (A > 0) {
        if ((A = x) < 8) q = S[R--], C = delete S[R--][q];else if (A < 10) {
          for (z = W[O], A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            A += String.fromCharCode(r ^ i.p[P]);
          }

          O += 4, S[R] = S[R][A];
        } else if (A < 12) {
          C = S[R--], S[R] = S[R] << C;
        } else {
          if (A < 14) {
            S[++R] = W[O], O += 2;
          }
        }
      } else {
        if ((A = x) < 5) {
          z = W[O];

          try {
            if (t[o][2] = 1, 1 == (C = G(b, O + 4, z - 3, [], c, l, null, 0))[0]) return C;
          } catch (m) {
            if (t[o] && t[o][1] && 1 == (C = G(b, t[o][1][0], t[o][1][1], [], c, l, m, 0))[0]) return C;
          } finally {
            if (t[o] && t[o][0] && 1 == (C = G(b, t[o][0][0], t[o][0][1], [], c, l, null, 0))[0]) return C;
            t[o] = 0, o--;
          }

          O += 2 * z - 2;
        } else if (A < 7) {
          z = W[O], O += 2, S[R -= z] = 0 === z ? new S[R]() : d(S[R], n(S.slice(R + 1, R + z + 1)));
        } else {
          if (A < 9) {
            C = S[R--], S[R] = S[R] & C;
          }
        }
      }
    } else if (A < 3) {
      A = 3 & x;
      if (x >>= 2, A < 1) {
        if ((A = x) < 2) {
          C = S[R--], S[R] = S[R] > C;
        } else {
          if (A < 9) {
            z = W[O], O += 4, q = R + 1, S[R -= z - 1] = z ? S.slice(R, q) : [];
          } else {
            if (A < 11) {
              z = W[O], O += 2, C = S[R--], c[z] = C;
            } else {
              if (A < 13) {
                C = S[R--], S[R] = S[R] >> C;
              } else {
                if (A < 15) {
                  S[++R] = W[O], O += 4;
                }
              }
            }
          }
        }
      } else if (A < 2) {
        if ((A = x) < 1) {
          S[++R] = g;
        } else {
          if (A < 3) {
            C = S[R--], S[R] = S[R] + C;
          } else {
            if (A < 5) {
              C = S[R--], S[R] = S[R] == C;
            } else {
              if (A < 14) {
                C = S[R - 1], q = S[R], S[++R] = C, S[++R] = q;
              }
            }
          }
        }
      } else if (A < 3) {
        if ((A = x) < 2) {
          for (z = W[O], C = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            C += String.fromCharCode(r ^ i.p[P]);
          }

          S[++R] = C, O += 4;
        } else if (A < 4) {
          if (S[R--]) {
            O += 4;
          } else {
            O += 2 * (z = W[O]) - 2;
          }
        } else {
          if (A < 6) {
            C = S[R--], S[R] = S[R] % C;
          } else {
            if (A < 8) {
              C = S[R--], S[R] = S[R] instanceof C;
            } else {
              if (A < 15) {
                S[++R] = !1;
              }
            }
          }
        }
      } else {
        if ((A = x) > 7) {
          C = S[R--], S[R] = S[R] | C;
        } else {
          if (A > 5) {
            z = W[O], O += 2, S[++R] = c["$" + z];
          } else {
            if (A > 3) {
              z = W[O], t[o][0] && !t[o][2] ? t[o][1] = [O + 4, z - 3] : t[o++] = [0, [O + 4, z - 3], 0], O += 2 * z - 2;
            }
          }
        }
      }
    } else {
      A = 3 & x;
      if (x >>= 2, A > 2) {
        if ((A = x) > 13) {
          S[++R] = W[O], O += 8;
        } else {
          if (A > 11) {
            C = S[R--], S[R] = S[R] >>> C;
          } else {
            if (A > 9) {
              S[++R] = !0;
            } else {
              if (A > 7) {
                z = W[O], O += 2, S[R] = S[R][z];
              } else {
                if (A > 0) {
                  C = S[R--], S[R] = S[R] < C;
                }
              }
            }
          }
        }
      } else if (A > 1) {
        if ((A = x) > 10) {
          z = W[O], t[++o] = [[O + 4, z - 3], 0, 0], O += 2 * z - 2;
        } else {
          if (A > 8) {
            C = S[R--], S[R] = S[R] ^ C;
          } else {
            if (A > 6) {
              C = S[R--];
            }
          }
        }
      } else if (A > 0) {
        if ((A = x) > 7) C = S[R--], S[R] = S[R] in C;else if (A > 5) S[R] = ++S[R];else if (A > 3) z = W[O], O += 2, C = c[z], S[++R] = C;else if (A > 1) {
          D = 0, T = S[R].length, $ = S[R];

          S[++R] = function () {
            var b = D < T;

            if (b) {
              var e = $[D++];
              S[++R] = e;
            }

            S[++R] = b;
          };
        }
      } else {
        if ((A = x) < 2) {
          for (z = W[O], A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            A += String.fromCharCode(r ^ i.p[P]);
          }

          A = +A, O += 4, S[++R] = A;
        } else if (A < 4) {
          C = S[R--], S[R] = S[R] - C;
        } else {
          if (A < 6) {
            C = S[R--], S[R] = S[R] === C;
          } else {
            if (A < 15) {
              C = S[R], S[R] = S[R - 1], S[R - 1] = C;
            }
          }
        }
      }
    }
  }
  return [0, null];
}