// https://astexplorer.net/
// monitor(Array.prototype.push)
/* 使用 MemoryInfra 进行启动跟踪
https://chromium.googlesource.com/chromium/src/+/refs/heads/main/docs/memory-infra/memory_infra_startup_tracing.md
$ chrome --no-sandbox \
         --trace-startup=-*,disabled-by-default-memory-infra \
         --trace-startup-file=/tmp/trace.json \
         --trace-startup-duration=7
 */
// unmonitor(Array.prototype.push)
const fs = require('fs');
const util = require('util');
const path = require('path');
const t = require("@babel/types");
const TNT = require("@babel/types");
// const babel = require("@babel/core");
const types = require("@babel/types");
const parser = require("@babel/parser");
const { parse } = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const WriteFile = util.promisify(fs.writeFile)
// const seen = Symbol("seen");
// const VM = require('vm');





/**
 *       需要自己手动添加进去的哦
 * (___________________________________________)
 */
let newJsCode = `
var case_node_map = new Map();
window.case_node_map = case_node_map;
function mxt_(sign, step) {
    case_node_map.set(sign, step)
}
`;
// var arr = Array.from(case_node_map); // 二维数组
// copy(arr);




/** 
 *         这个大数组是怎么来的呢
 * (_____________________________________________)
 *  https://lihautan.com/codemod-with-babel/
 *  基础操作：处理字符串编码、合并和数组内置方法
 */
let arr = [
    ['mxt_8017_5', 0],
    ['mxt_207_15', 0],
    ['mxt_207_32', 1],
    ['mxt_8017_20', 1],
    ['mxt_207_36', 2],
    ['mxt_8017_41', 2],
    ['mxt_207_58', 3],
    ['mxt_8017_60', 3],
    ['mxt_207_10', 4],
    ['mxt_8017_6', 4],
    ['mxt_207_19', 5],
    ['mxt_8017_29', 5],
    ['mxt_207_35', 6],
    ['mxt_8017_48', 6],
    ['mxt_207_6', 8],
    ['mxt_8017_12', 8],
    ['mxt_207_23', 9],
    ['mxt_8017_25', 9],
    ['mxt_207_46', 10],
    ['mxt_8017_33', 10],
    ['mxt_207_53', 11],
    ['mxt_8017_52', 11],
    ['mxt_207_26', 13],
    ['mxt_8017_23', 13],
    ['mxt_207_12', 16],
    ['mxt_8017_2', 16],
    ['mxt_207_28', 17],
    ['mxt_8017_16', 17],
    ['mxt_207_40', 18],
    ['mxt_8017_45', 18],
    ['mxt_207_41', 19],
    ['mxt_8017_37', 19],
    ['mxt_207_65', 20],
    ['mxt_8017_61', 20],
    ['mxt_207_31', 22],
    ['mxt_8017_19', 22],
    ['mxt_207_37', 23],
    ['mxt_8017_42', 23],
    ['mxt_207_59', 24],
    ['mxt_8017_59', 24],
    ['mxt_207_9', 25],
    ['mxt_8017_7', 25],
    ['mxt_207_18', 26],
    ['mxt_8017_30', 26],
    ['mxt_207_34', 27],
    ['mxt_8017_47', 27],
    ['mxt_207_57', 28],
    ['mxt_8017_56', 28],
    ['mxt_207_5', 29],
    ['mxt_8017_11', 29],
    ['mxt_207_22', 30],
    ['mxt_8017_26', 30],
    ['mxt_207_47', 31],
    ['mxt_8017_34', 31],
    ['mxt_207_52', 32],
    ['mxt_8017_51', 32],
    ['mxt_207_1', 33],
    ['mxt_8017_15', 33],
    ['mxt_207_27', 34],
    ['mxt_8017_24', 34],
    ['mxt_207_44', 35],
    ['mxt_8017_40', 35],
    ['mxt_207_62', 36],
    ['mxt_8017_64', 36],
    ['mxt_207_11', 37],
    ['mxt_8017_1', 37],
    ['mxt_207_3', 38],
    ['mxt_8017_13', 38],
    ['mxt_207_24', 39],
    ['mxt_8017_21', 39],
    ['mxt_207_42', 40],
    ['mxt_8017_38', 40],
    ['mxt_8017_62', 41],
    ['mxt_207_64', 41],
    ['mxt_207_14', 42],
    ['mxt_8017_4', 42],
    ['mxt_207_30', 43],
    ['mxt_8017_18', 43],
    ['mxt_207_38', 44],
    ['mxt_8017_43', 44],
    ['mxt_207_60', 45],
    ['mxt_8017_58', 45],
    ['mxt_207_8', 46],
    ['mxt_8017_8', 46],
    ['mxt_207_17', 47],
    ['mxt_8017_31', 47],
    ['mxt_8017_46', 48],
    ['mxt_207_33', 48],
    ['mxt_207_56', 49],
    ['mxt_8017_55', 49],
    ['mxt_8017_27', 51],
    ['mxt_207_21', 51],
    ['mxt_207_48', 52],
    ['mxt_8017_35', 52],
    ['mxt_207_51', 53],
    ['mxt_8017_50', 53],
    ['mxt_207_45', 57],
    ['mxt_8017_32', 57],
    ['mxt_207_54', 58],
    ['mxt_8017_53', 58],
    ['mxt_207_2', 59],
    ['mxt_8017_14', 59],
    ['mxt_8017_22', 60],
    ['mxt_207_25', 60],
    ['mxt_207_43', 61],
    ['mxt_8017_39', 61],
    ['mxt_207_63', 62],
    ['mxt_8017_63', 62],
    ['mxt_207_13', 63],
    ['mxt_8017_3', 63],
    ['mxt_207_29', 64],
    ['mxt_8017_17', 64],
    ['mxt_207_39', 65],
    ['mxt_8017_44', 65],
    ['mxt_8017_57', 66],
    ['mxt_207_61', 66],
    ['mxt_207_7', 67],
    ['mxt_8017_9', 67],
    ['mxt_207_55', 70],
    ['mxt_8017_54', 70],
    ['mxt_207_20', 72],
    ['mxt_8017_28', 72],
    ['mxt_207_49', 73],
    ['mxt_8017_36', 73],
    ['mxt_207_50', 74],
    ['mxt_8017_49', 74]
]
let case_node_map = new Map(arr);






// 测试目标站点
// https://trendinsight.oceanengine.com/arithmetic-index
let injection = false /*注解：注入函数获取大数组*/
MAIN('input.js', './_result_.js');





/**
 *              三目表达式 --> ifelse表达式
 * (________________________________________________________)
 */
function ConditionToIf(path) { // 大佬写的
    let { expression } = path.node;
    if (!t.isConditionalExpression(expression)) return;
    let { test, consequent, alternate } = expression;
    path.replaceWith(t.ifStatement(
        test,
        t.blockStatement([t.expressionStatement(consequent), ]),
        t.blockStatement([t.expressionStatement(alternate), ])
    ));
}





/**
 *                  主要反混淆逻辑代码
 * (________________________________________________________)
 * 
 */
function MAIN(input_path, output_path) {
    let jsCode = require("@babel/core").transformFileSync(input_path, {
        babelrc: false,
        configFile: false,
        compact: false, // 加上此项配置
    }).code;
    let ast = parser.parse(jsCode);


    // ****************************************************************************************************************************************************************************************************
    console.log("还原 - 三目表达式......")
    traverse(ast, { ExpressionStatement: ConditionToIf, });




    // ****************************************************************************************************************************************************************************************************
    console.log("还原 - 规范化节点......")
    traverse(ast, {
        /*
        for (C = S[R--], z = v(b, O), A = "", P = i.q[z][0]; P < i.q[z][1]; P++) A += String.fromCharCode(r ^ i.p[P]);
        格式化：
        for (C = S[R--], z = W[O], A = "", P = i.q[z][0]; P < i.q[z][1]; P++) {
            A += String.fromCharCode(r ^ i.p[P]);
        }
        */
        ForStatement(path) {
            let { init, test, update, body } = path.node;
            if (body && !TNT.isBlockStatement(body)) {
                path.get("body").replaceWith(TNT.BlockStatement([body]))
            }
        },
        /**
         * 
         * A > 5 && (S[R] = h(S[R])); 
         * 转为
         * if (A > 5) {
                S[R] = h(S[R]);
            }
         */
        ExpressionStatement(path) {
            let { expression } = path.node;
            if (!TNT.isLogicalExpression(expression)) return;
            let { left, operator, right } = expression;
            if (TNT.isBinaryExpression(left) && operator == "&&") {
                path.replaceWith(TNT.IfStatement(left, TNT.BlockStatement([TNT.ExpressionStatement(right)])));
            }
        },
        IfStatement(path) { // 就是规范ifelse节点
            var { test, consequent, alternate } = path.node;
            if (!TNT.isBlockStatement(consequent)) {
                path.get('consequent').replaceWith(TNT.BlockStatement([consequent]))
            }
            if (alternate && !TNT.isBlockStatement(alternate)) {
                path.get('alternate').replaceWith(TNT.BlockStatement([alternate]))
            }
        },
    });



    // ****************************************************************************************************************************************************************************************************
    console.log("注入代码获取大数组 或者 ifelse还原为switch节点......")
    traverse(ast, {
        ForStatement(ppath, sign = "mxt") {
            var { test, body, start, end } = ppath.node;
            if (TNT.isBinaryExpression(test) && TNT.isIdentifier(test.left) && TNT.isIdentifier(test.right)) {
                let num = 1;
                let elemtens = [];
                let elemtens_map = new Map();
                let IF_NODE, FUNC_NODE = template(`mxt_(SIGN,LEFT)`);
                ppath.traverse({
                    IfStatement(path) {
                        var { test, consequent, alternate } = path.node;
                        if (!injection && TNT.isSequenceExpression(test) && path.parentPath.parentPath.type == "ForStatement") {
                            let _PrevSibling = path.getPrevSibling()
                            path.insertBefore(template.ast("x >>= 4;"))
                            path.insertBefore(template.ast("A = x;"))
                            IF_NODE = path; // 这里是for节点的第一个if节点，要把这个换成switch节点
                        }

                        if (TNT.isBinaryExpression(path.node.test) && TNT.isAssignmentExpression(path.node.test.left)) {
                            path.scope.traverse(path.scope.block, {
                                IfStatement(_path) {
                                    var { test, consequent, alternate } = _path.node;
                                    if (TNT.isBinaryExpression(test) && ['>', '<'].includes(test.operator) &&
                                        (TNT.isIdentifier(test.left) || (TNT.isAssignmentExpression(test.left) && TNT.isIdentifier(test.left.left, { name: "A" })))) {
                                        let tmp = `${sign}_${start}_${num}`;
                                        if (injection) {
                                            _path.get('consequent.body.0').container.unshift(FUNC_NODE({
                                                SIGN: TNT.StringLiteral(tmp),
                                                LEFT: TNT.Identifier('j'),
                                            }))
                                        } else {
                                            if (case_node_map.has(tmp)) {
                                                let i = parseInt(case_node_map.get(tmp))
                                                // 这里不想改了(*_*),取消大括号后就出错，不知为啥子呢（所以就重写方法去掉大括号啦）
                                                // elemtens[i] = types.SwitchCase(types.NumericLiteral(i), [consequent.body[0], types.BreakStatement()])
                                                elemtens[i] = types.SwitchCase(types.NumericLiteral(i), [consequent, types.BreakStatement()])
                                            }
                                        }
                                        num += 1;
                                    }
                                }
                            });
                            if (injection) {
                                console.log("+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
                                console.log(start, end, path.toString());
                            }
                        }
                    },
                });
                // console.log(elemtens)
                if (IF_NODE && !injection) {
                    // IF_NODE.remove();
                    let newArr = elemtens.filter(item => item); // 去掉数组空字符串、undefined、null
                    newArr.push(TNT.SwitchCase(null, [TNT.ReturnStatement()]))
                    IF_NODE.replaceWith(TNT.SwitchStatement(TNT.Identifier('j'), newArr))
                }
            }
        },
    });



    // ****************************************************************************************************************************************************************************************************
    console.log("去掉大括号......");
    traverse(ast, {
        SwitchCase(path) {
            let body = path.get('consequent.0');
            if (body.isBlockStatement()) {
                path.get('consequent.0').replaceWithMultiple(body.node.body);
            }
        },
    });



    // ****************************************************************************************************************************************************************************************************
    jsCode = generator(ast, opts = {
        // "concise": true, // 简洁的,tab会删除 【https://zhuanlan.zhihu.com/p/91948992】
        // "compact": true, // 代码压缩，变量赋值等号空格消失【https://blog.51cto.com/u_15072904/2579604】
        // "retainLines": true, // 删除空行
        // "comments": false, // 删除所有注释【https://blog.51cto.com/u_15072904/2579604】
        jsescOption: {
            "minimal": true, // Unicode转中文或者其他非ASCII码字符。【https://blog.51cto.com/u_15072904/2579604】
        },
    }, jsCode).code;

    // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    // ---------------------------------------------------------------------------------------
    WriteFile(path.resolve(__dirname, output_path), jsCode, 'utf-8', function(err) {
        if (!err) {
            console.log('操作成功完成.................................................')
        } else {
            console.error(Error(err.stack))
            next(Error(err.message))
        }
    });
}