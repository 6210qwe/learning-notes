// 这是一个 AES 算法，用于测试打包效果
window = typeof window == 'undefined' ? global : window;

(function () {
  var cilame_switch_1609 = "19|96|13|23|36|54".split("|"),
      cilame_indexer_1609 = 0;

  while (1) {
    switch (cilame_switch_1609[cilame_indexer_1609++]) {
      case "13":
        CryptoJS.lib.Cipher || function (undefined) {
          var cilame_switch_1880 = "96|124|122|32|100|116|6|33|105|4|64|22|106|56|25|97|92|68|61|91|21|113|82|9|119".split("|"),
              cilame_indexer_1880 = 0;

          while (1) {
            switch (cilame_switch_1880[cilame_indexer_1880++]) {
              case "116":
                var C_enc = C.enc;
                continue;

              case "68":
                var BlockCipher = C_lib.BlockCipher = Cipher.extend({
                  cfg: Cipher.cfg.extend({
                    mode: CBC,
                    padding: Pkcs7
                  }),
                  reset: function () {
                    var cilame_switch_1192 = "40|67|69|77|90|62".split("|"),
                        cilame_indexer_1192 = 0;

                    while (1) {
                      switch (cilame_switch_1192[cilame_indexer_1192++]) {
                        case "40":
                          Cipher.reset.call(this);
                          continue;

                        case "69":
                          var iv = cfg.iv;
                          continue;

                        case "90":
                          if (this._xformMode == this._ENC_XFORM_MODE) {
                            var modeCreator = mode.createEncryptor;
                          } else {
                            var modeCreator = mode.createDecryptor;
                            this._minBufferSize = 1;
                          }

                          continue;

                        case "67":
                          var cfg = this.cfg;
                          continue;

                        case "62":
                          if (this._mode && this._mode.__creator == modeCreator) {
                            this._mode.init(this, iv && iv.words);
                          } else {
                            this._mode = modeCreator.call(mode, this, iv && iv.words);
                            this._mode.__creator = modeCreator;
                          }

                          continue;

                        case "77":
                          var mode = cfg.mode;
                          continue;
                      }

                      break;
                    }
                  },
                  _doProcessBlock: function (words, offset) {
                    var cilame_switch_1118 = "14".split("|"),
                        cilame_indexer_1118 = 0;

                    while (1) {
                      switch (cilame_switch_1118[cilame_indexer_1118++]) {
                        case "14":
                          this._mode.processBlock(words, offset);

                          continue;
                      }

                      break;
                    }
                  },
                  _doFinalize: function () {
                    var cilame_switch_6673 = "25|43|33".split("|"),
                        cilame_indexer_6673 = 0;

                    while (1) {
                      switch (cilame_switch_6673[cilame_indexer_6673++]) {
                        case "25":
                          var padding = this.cfg.padding;
                          continue;

                        case "33":
                          return finalProcessedBlocks;
                          continue;

                        case "43":
                          if (this._xformMode == this._ENC_XFORM_MODE) {
                            padding.pad(this._data, this.blockSize);

                            var finalProcessedBlocks = this._process(!!'flush');
                          } else {
                            var finalProcessedBlocks = this._process(!!'flush');

                            padding.unpad(finalProcessedBlocks);
                          }

                          continue;
                      }

                      break;
                    }
                  },
                  blockSize: 128 / 32
                });
                continue;

              case "100":
                var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm;
                continue;

              case "105":
                var C_algo = C.algo;
                continue;

              case "97":
                var C_pad = C.pad = {};
                continue;

              case "82":
                var C_kdf = C.kdf = {};
                continue;

              case "4":
                var EvpKDF = C_algo.EvpKDF;
                continue;

              case "64":
                var Cipher = C_lib.Cipher = BufferedBlockAlgorithm.extend({
                  cfg: Base.extend(),
                  createEncryptor: function (key, cfg) {
                    var cilame_switch_3246 = "6".split("|"),
                        cilame_indexer_3246 = 0;

                    while (1) {
                      switch (cilame_switch_3246[cilame_indexer_3246++]) {
                        case "6":
                          return this.create(this._ENC_XFORM_MODE, key, cfg);
                          continue;
                      }

                      break;
                    }
                  },
                  createDecryptor: function (key, cfg) {
                    var cilame_switch_1396 = "76".split("|"),
                        cilame_indexer_1396 = 0;

                    while (1) {
                      switch (cilame_switch_1396[cilame_indexer_1396++]) {
                        case "76":
                          return this.create(this._DEC_XFORM_MODE, key, cfg);
                          continue;
                      }

                      break;
                    }
                  },
                  init: function (xformMode, key, cfg) {
                    var cilame_switch_2046 = "4|59|27|100".split("|"),
                        cilame_indexer_2046 = 0;

                    while (1) {
                      switch (cilame_switch_2046[cilame_indexer_2046++]) {
                        case "27":
                          this._key = key;
                          continue;

                        case "59":
                          this._xformMode = xformMode;
                          continue;

                        case "4":
                          this.cfg = this.cfg.extend(cfg);
                          continue;

                        case "100":
                          this.reset();
                          continue;
                      }

                      break;
                    }
                  },
                  reset: function () {
                    var cilame_switch_196 = "40|84".split("|"),
                        cilame_indexer_196 = 0;

                    while (1) {
                      switch (cilame_switch_196[cilame_indexer_196++]) {
                        case "40":
                          BufferedBlockAlgorithm.reset.call(this);
                          continue;

                        case "84":
                          this._doReset();

                          continue;
                      }

                      break;
                    }
                  },
                  process: function (dataUpdate) {
                    var cilame_switch_902 = "36|20".split("|"),
                        cilame_indexer_902 = 0;

                    while (1) {
                      switch (cilame_switch_902[cilame_indexer_902++]) {
                        case "36":
                          this._append(dataUpdate);

                          continue;

                        case "20":
                          return this._process();
                          continue;
                      }

                      break;
                    }
                  },
                  finalize: function (dataUpdate) {
                    var cilame_switch_4469 = "42|74|52".split("|"),
                        cilame_indexer_4469 = 0;

                    while (1) {
                      switch (cilame_switch_4469[cilame_indexer_4469++]) {
                        case "42":
                          if (dataUpdate) {
                            this._append(dataUpdate);
                          }

                          continue;

                        case "52":
                          return finalProcessedData;
                          continue;

                        case "74":
                          var finalProcessedData = this._doFinalize();

                          continue;
                      }

                      break;
                    }
                  },
                  keySize: 128 / 32,
                  ivSize: 128 / 32,
                  _ENC_XFORM_MODE: 1,
                  _DEC_XFORM_MODE: 2,
                  _createHelper: function () {
                    var cilame_switch_276 = "65".split("|"),
                        cilame_indexer_276 = 0;

                    while (1) {
                      switch (cilame_switch_276[cilame_indexer_276++]) {
                        case "65":
                          return function (cipher) {
                            var cilame_switch_5760 = "46".split("|"),
                                cilame_indexer_5760 = 0;

                            while (1) {
                              switch (cilame_switch_5760[cilame_indexer_5760++]) {
                                case "46":
                                  return {
                                    encrypt: function (message, key, cfg) {
                                      var cilame_switch_5073 = "4".split("|"),
                                          cilame_indexer_5073 = 0;

                                      while (1) {
                                        switch (cilame_switch_5073[cilame_indexer_5073++]) {
                                          case "4":
                                            return selectCipherStrategy(key).encrypt(cipher, message, key, cfg);
                                            continue;
                                        }

                                        break;
                                      }
                                    },
                                    decrypt: function (ciphertext, key, cfg) {
                                      var cilame_switch_377 = "50".split("|"),
                                          cilame_indexer_377 = 0;

                                      while (1) {
                                        switch (cilame_switch_377[cilame_indexer_377++]) {
                                          case "50":
                                            return selectCipherStrategy(key).decrypt(cipher, ciphertext, key, cfg);
                                            continue;
                                        }

                                        break;
                                      }
                                    }
                                  };
                                  continue;
                              }

                              break;
                            }
                          };
                          continue;
                      }

                      break;
                    }

                    function selectCipherStrategy(key) {
                      var cilame_switch_7502 = "91".split("|"),
                          cilame_indexer_7502 = 0;

                      while (1) {
                        switch (cilame_switch_7502[cilame_indexer_7502++]) {
                          case "91":
                            if (typeof key == 'string') {
                              return PasswordBasedCipher;
                            } else {
                              return SerializableCipher;
                            }

                            continue;
                        }

                        break;
                      }
                    }
                  }()
                });
                continue;

              case "91":
                var C_format = C.format = {};
                continue;

              case "61":
                var CipherParams = C_lib.CipherParams = Base.extend({
                  init: function (cipherParams) {
                    var cilame_switch_4592 = "16".split("|"),
                        cilame_indexer_4592 = 0;

                    while (1) {
                      switch (cilame_switch_4592[cilame_indexer_4592++]) {
                        case "16":
                          this.mixIn(cipherParams);
                          continue;
                      }

                      break;
                    }
                  },
                  toString: function (formatter) {
                    var cilame_switch_6083 = "18".split("|"),
                        cilame_indexer_6083 = 0;

                    while (1) {
                      switch (cilame_switch_6083[cilame_indexer_6083++]) {
                        case "18":
                          return (formatter || this.formatter).stringify(this);
                          continue;
                      }

                      break;
                    }
                  }
                });
                continue;

              case "6":
                var Utf8 = C_enc.Utf8;
                continue;

              case "33":
                var Base64 = C_enc.Base64;
                continue;

              case "113":
                var SerializableCipher = C_lib.SerializableCipher = Base.extend({
                  cfg: Base.extend({
                    format: OpenSSLFormatter
                  }),
                  encrypt: function (cipher, message, key, cfg) {
                    var cilame_switch_3931 = "23|44|50|38|52".split("|"),
                        cilame_indexer_3931 = 0;

                    while (1) {
                      switch (cilame_switch_3931[cilame_indexer_3931++]) {
                        case "44":
                          var encryptor = cipher.createEncryptor(key, cfg);
                          continue;

                        case "23":
                          cfg = this.cfg.extend(cfg);
                          continue;

                        case "38":
                          var cipherCfg = encryptor.cfg;
                          continue;

                        case "50":
                          var ciphertext = encryptor.finalize(message);
                          continue;

                        case "52":
                          return CipherParams.create({
                            ciphertext: ciphertext,
                            key: key,
                            iv: cipherCfg.iv,
                            algorithm: cipher,
                            mode: cipherCfg.mode,
                            padding: cipherCfg.padding,
                            blockSize: cipher.blockSize,
                            formatter: cfg.format
                          });
                          continue;
                      }

                      break;
                    }
                  },
                  decrypt: function (cipher, ciphertext, key, cfg) {
                    var cilame_switch_1855 = "3|95|22|14".split("|"),
                        cilame_indexer_1855 = 0;

                    while (1) {
                      switch (cilame_switch_1855[cilame_indexer_1855++]) {
                        case "14":
                          return plaintext;
                          continue;

                        case "95":
                          ciphertext = this._parse(ciphertext, cfg.format);
                          continue;

                        case "22":
                          var plaintext = cipher.createDecryptor(key, cfg).finalize(ciphertext.ciphertext);
                          continue;

                        case "3":
                          cfg = this.cfg.extend(cfg);
                          continue;
                      }

                      break;
                    }
                  },
                  _parse: function (ciphertext, format) {
                    var cilame_switch_1872 = "12".split("|"),
                        cilame_indexer_1872 = 0;

                    while (1) {
                      switch (cilame_switch_1872[cilame_indexer_1872++]) {
                        case "12":
                          if (typeof ciphertext == 'string') {
                            return format.parse(ciphertext, this);
                          } else {
                            return ciphertext;
                          }

                          continue;
                      }

                      break;
                    }
                  }
                });
                continue;

              case "9":
                var OpenSSLKdf = C_kdf.OpenSSL = {
                  execute: function (password, keySize, ivSize, salt) {
                    var cilame_switch_5311 = "98|87|13|63|40".split("|"),
                        cilame_indexer_5311 = 0;

                    while (1) {
                      switch (cilame_switch_5311[cilame_indexer_5311++]) {
                        case "98":
                          if (!salt) {
                            salt = WordArray.random(64 / 8);
                          }

                          continue;

                        case "87":
                          var key = EvpKDF.create({
                            keySize: keySize + ivSize
                          }).compute(password, salt);
                          continue;

                        case "40":
                          return CipherParams.create({
                            key: key,
                            iv: iv,
                            salt: salt
                          });
                          continue;

                        case "63":
                          key.sigBytes = keySize * 4;
                          continue;

                        case "13":
                          var iv = WordArray.create(key.words.slice(keySize), ivSize * 4);
                          continue;
                      }

                      break;
                    }
                  }
                };
                continue;

              case "106":
                var C_mode = C.mode = {};
                continue;

              case "96":
                var C = CryptoJS;
                continue;

              case "56":
                var BlockCipherMode = C_lib.BlockCipherMode = Base.extend({
                  createEncryptor: function (cipher, iv) {
                    var cilame_switch_807 = "24".split("|"),
                        cilame_indexer_807 = 0;

                    while (1) {
                      switch (cilame_switch_807[cilame_indexer_807++]) {
                        case "24":
                          return this.Encryptor.create(cipher, iv);
                          continue;
                      }

                      break;
                    }
                  },
                  createDecryptor: function (cipher, iv) {
                    var cilame_switch_7401 = "4".split("|"),
                        cilame_indexer_7401 = 0;

                    while (1) {
                      switch (cilame_switch_7401[cilame_indexer_7401++]) {
                        case "4":
                          return this.Decryptor.create(cipher, iv);
                          continue;
                      }

                      break;
                    }
                  },
                  init: function (cipher, iv) {
                    var cilame_switch_2080 = "17|28".split("|"),
                        cilame_indexer_2080 = 0;

                    while (1) {
                      switch (cilame_switch_2080[cilame_indexer_2080++]) {
                        case "17":
                          this._cipher = cipher;
                          continue;

                        case "28":
                          this._iv = iv;
                          continue;
                      }

                      break;
                    }
                  }
                });
                continue;

              case "25":
                var CBC = C_mode.CBC = function () {
                  var cilame_switch_5932 = "40|78|66|87".split("|"),
                      cilame_indexer_5932 = 0;

                  while (1) {
                    switch (cilame_switch_5932[cilame_indexer_5932++]) {
                      case "66":
                        CBC.Decryptor = CBC.extend({
                          processBlock: function (words, offset) {
                            var cilame_switch_8467 = "104|41|30|8|49|15".split("|"),
                                cilame_indexer_8467 = 0;

                            while (1) {
                              switch (cilame_switch_8467[cilame_indexer_8467++]) {
                                case "15":
                                  this._prevBlock = thisBlock;
                                  continue;

                                case "8":
                                  cipher.decryptBlock(words, offset);
                                  continue;

                                case "30":
                                  var thisBlock = words.slice(offset, offset + blockSize);
                                  continue;

                                case "104":
                                  var cipher = this._cipher;
                                  continue;

                                case "49":
                                  xorBlock.call(this, words, offset, blockSize);
                                  continue;

                                case "41":
                                  var blockSize = cipher.blockSize;
                                  continue;
                              }

                              break;
                            }
                          }
                        });
                        continue;

                      case "40":
                        var CBC = BlockCipherMode.extend();
                        continue;

                      case "78":
                        CBC.Encryptor = CBC.extend({
                          processBlock: function (words, offset) {
                            var cilame_switch_1165 = "101|56|2|24|4".split("|"),
                                cilame_indexer_1165 = 0;

                            while (1) {
                              switch (cilame_switch_1165[cilame_indexer_1165++]) {
                                case "56":
                                  var blockSize = cipher.blockSize;
                                  continue;

                                case "24":
                                  cipher.encryptBlock(words, offset);
                                  continue;

                                case "4":
                                  this._prevBlock = words.slice(offset, offset + blockSize);
                                  continue;

                                case "101":
                                  var cipher = this._cipher;
                                  continue;

                                case "2":
                                  xorBlock.call(this, words, offset, blockSize);
                                  continue;
                              }

                              break;
                            }
                          }
                        });
                        continue;

                      case "87":
                        return CBC;
                        continue;
                    }

                    break;
                  }

                  function xorBlock(words, offset, blockSize) {
                    var cilame_switch_5261 = "38|87|80".split("|"),
                        cilame_indexer_5261 = 0;

                    while (1) {
                      switch (cilame_switch_5261[cilame_indexer_5261++]) {
                        case "87":
                          if (iv) {
                            var block = iv;
                            this._iv = undefined;
                          } else {
                            var block = this._prevBlock;
                          }

                          continue;

                        case "80":
                          for (var i = 0; i < blockSize; i++) {
                            var cilame_switch_5918 = "96".split("|"),
                                cilame_indexer_5918 = 0;

                            while (1) {
                              switch (cilame_switch_5918[cilame_indexer_5918++]) {
                                case "96":
                                  words[offset + i] ^= block[i];
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "38":
                          var iv = this._iv;
                          continue;
                      }

                      break;
                    }
                  }
                }();

                continue;

              case "122":
                var Base = C_lib.Base;
                continue;

              case "119":
                var PasswordBasedCipher = C_lib.PasswordBasedCipher = SerializableCipher.extend({
                  cfg: SerializableCipher.cfg.extend({
                    kdf: OpenSSLKdf
                  }),
                  encrypt: function (cipher, message, password, cfg) {
                    var cilame_switch_5121 = "20|88|69|34|32|101".split("|"),
                        cilame_indexer_5121 = 0;

                    while (1) {
                      switch (cilame_switch_5121[cilame_indexer_5121++]) {
                        case "88":
                          var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize);
                          continue;

                        case "20":
                          cfg = this.cfg.extend(cfg);
                          continue;

                        case "101":
                          return ciphertext;
                          continue;

                        case "34":
                          var ciphertext = SerializableCipher.encrypt.call(this, cipher, message, derivedParams.key, cfg);
                          continue;

                        case "69":
                          cfg.iv = derivedParams.iv;
                          continue;

                        case "32":
                          ciphertext.mixIn(derivedParams);
                          continue;
                      }

                      break;
                    }
                  },
                  decrypt: function (cipher, ciphertext, password, cfg) {
                    var cilame_switch_2338 = "105|21|13|12|1|28".split("|"),
                        cilame_indexer_2338 = 0;

                    while (1) {
                      switch (cilame_switch_2338[cilame_indexer_2338++]) {
                        case "1":
                          var plaintext = SerializableCipher.decrypt.call(this, cipher, ciphertext, derivedParams.key, cfg);
                          continue;

                        case "105":
                          cfg = this.cfg.extend(cfg);
                          continue;

                        case "13":
                          var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize, ciphertext.salt);
                          continue;

                        case "12":
                          cfg.iv = derivedParams.iv;
                          continue;

                        case "28":
                          return plaintext;
                          continue;

                        case "21":
                          ciphertext = this._parse(ciphertext, cfg.format);
                          continue;
                      }

                      break;
                    }
                  }
                });
                continue;

              case "92":
                var Pkcs7 = C_pad.Pkcs7 = {
                  pad: function (data, blockSize) {
                    var cilame_switch_3135 = "69|87|54|22|77|83|26".split("|"),
                        cilame_indexer_3135 = 0;

                    while (1) {
                      switch (cilame_switch_3135[cilame_indexer_3135++]) {
                        case "22":
                          var paddingWords = [];
                          continue;

                        case "87":
                          var nPaddingBytes = blockSizeBytes - data.sigBytes % blockSizeBytes;
                          continue;

                        case "83":
                          var padding = WordArray.create(paddingWords, nPaddingBytes);
                          continue;

                        case "26":
                          data.concat(padding);
                          continue;

                        case "69":
                          var blockSizeBytes = blockSize * 4;
                          continue;

                        case "77":
                          for (var i = 0; i < nPaddingBytes; i += 4) {
                            var cilame_switch_701 = "36".split("|"),
                                cilame_indexer_701 = 0;

                            while (1) {
                              switch (cilame_switch_701[cilame_indexer_701++]) {
                                case "36":
                                  paddingWords.push(paddingWord);
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "54":
                          var paddingWord = nPaddingBytes << 24 | nPaddingBytes << 16 | nPaddingBytes << 8 | nPaddingBytes;
                          continue;
                      }

                      break;
                    }
                  },
                  unpad: function (data) {
                    var cilame_switch_8508 = "42|56".split("|"),
                        cilame_indexer_8508 = 0;

                    while (1) {
                      switch (cilame_switch_8508[cilame_indexer_8508++]) {
                        case "56":
                          data.sigBytes -= nPaddingBytes;
                          continue;

                        case "42":
                          var nPaddingBytes = data.words[data.sigBytes - 1 >>> 2] & 0xff;
                          continue;
                      }

                      break;
                    }
                  }
                };
                continue;

              case "22":
                var StreamCipher = C_lib.StreamCipher = Cipher.extend({
                  _doFinalize: function () {
                    var cilame_switch_3060 = "28|74".split("|"),
                        cilame_indexer_3060 = 0;

                    while (1) {
                      switch (cilame_switch_3060[cilame_indexer_3060++]) {
                        case "28":
                          var finalProcessedBlocks = this._process(!!'flush');

                          continue;

                        case "74":
                          return finalProcessedBlocks;
                          continue;
                      }

                      break;
                    }
                  },
                  blockSize: 1
                });
                continue;

              case "21":
                var OpenSSLFormatter = C_format.OpenSSL = {
                  stringify: function (cipherParams) {
                    var cilame_switch_8864 = "100|53|19|79".split("|"),
                        cilame_indexer_8864 = 0;

                    while (1) {
                      switch (cilame_switch_8864[cilame_indexer_8864++]) {
                        case "53":
                          var salt = cipherParams.salt;
                          continue;

                        case "19":
                          if (salt) {
                            var wordArray = WordArray.create([0x53616c74, 0x65645f5f]).concat(salt).concat(ciphertext);
                          } else {
                            var wordArray = ciphertext;
                          }

                          continue;

                        case "100":
                          var ciphertext = cipherParams.ciphertext;
                          continue;

                        case "79":
                          return wordArray.toString(Base64);
                          continue;
                      }

                      break;
                    }
                  },
                  parse: function (openSSLStr) {
                    var cilame_switch_4887 = "49|48|96|82|53".split("|"),
                        cilame_indexer_4887 = 0;

                    while (1) {
                      switch (cilame_switch_4887[cilame_indexer_4887++]) {
                        case "82":
                          var salt = undefined;
                          continue;

                        case "96":
                          if (ciphertextWords[0] == 0x53616c74 && ciphertextWords[1] == 0x65645f5f) {
                            var salt = WordArray.create(ciphertextWords.slice(2, 4));
                            ciphertextWords.splice(0, 4);
                            ciphertext.sigBytes -= 16;
                          }

                          continue;

                        case "53":
                          return CipherParams.create({
                            ciphertext: ciphertext,
                            salt: salt
                          });
                          continue;

                        case "49":
                          var ciphertext = Base64.parse(openSSLStr);
                          continue;

                        case "48":
                          var ciphertextWords = ciphertext.words;
                          continue;
                      }

                      break;
                    }
                  }
                };
                continue;

              case "32":
                var WordArray = C_lib.WordArray;
                continue;

              case "124":
                var C_lib = C.lib;
                continue;
            }

            break;
          }
        }();
        continue;

      case "19":
        window.CryptoJS = function (Math, undefined) {
          var cilame_switch_6059 = "111|101|30|21|44|92|74|52|61|104|81|33|82".split("|"),
              cilame_indexer_6059 = 0;

          while (1) {
            switch (cilame_switch_6059[cilame_indexer_6059++]) {
              case "104":
                var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm = Base.extend({
                  reset: function () {
                    var cilame_switch_5835 = "94|16".split("|"),
                        cilame_indexer_5835 = 0;

                    while (1) {
                      switch (cilame_switch_5835[cilame_indexer_5835++]) {
                        case "94":
                          this._data = new WordArray.init();
                          continue;

                        case "16":
                          this._nDataBytes = 0;
                          continue;
                      }

                      break;
                    }
                  },
                  _append: function (data) {
                    var cilame_switch_5084 = "23|49|60".split("|"),
                        cilame_indexer_5084 = 0;

                    while (1) {
                      switch (cilame_switch_5084[cilame_indexer_5084++]) {
                        case "49":
                          this._data.concat(data);

                          continue;

                        case "23":
                          if (typeof data == 'string') {
                            data = Utf8.parse(data);
                          }

                          continue;

                        case "60":
                          this._nDataBytes += data.sigBytes;
                          continue;
                      }

                      break;
                    }
                  },
                  _process: function (doFlush) {
                    var cilame_switch_1383 = "104|39|74|65|89|5|38|79|27|70|73".split("|"),
                        cilame_indexer_1383 = 0;

                    while (1) {
                      switch (cilame_switch_1383[cilame_indexer_1383++]) {
                        case "38":
                          if (doFlush) {
                            nBlocksReady = Math.ceil(nBlocksReady);
                          } else {
                            nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);
                          }

                          continue;

                        case "5":
                          var nBlocksReady = dataSigBytes / blockSizeBytes;
                          continue;

                        case "89":
                          var blockSizeBytes = blockSize * 4;
                          continue;

                        case "65":
                          var blockSize = this.blockSize;
                          continue;

                        case "70":
                          if (nWordsReady) {
                            for (var offset = 0; offset < nWordsReady; offset += blockSize) {
                              var cilame_switch_4781 = "72".split("|"),
                                  cilame_indexer_4781 = 0;

                              while (1) {
                                switch (cilame_switch_4781[cilame_indexer_4781++]) {
                                  case "72":
                                    this._doProcessBlock(dataWords, offset);

                                    continue;
                                }

                                break;
                              }
                            }

                            var processedWords = dataWords.splice(0, nWordsReady);
                            data.sigBytes -= nBytesReady;
                          }

                          continue;

                        case "104":
                          var data = this._data;
                          continue;

                        case "73":
                          return new WordArray.init(processedWords, nBytesReady);
                          continue;

                        case "39":
                          var dataWords = data.words;
                          continue;

                        case "74":
                          var dataSigBytes = data.sigBytes;
                          continue;

                        case "27":
                          var nBytesReady = Math.min(nWordsReady * 4, dataSigBytes);
                          continue;

                        case "79":
                          var nWordsReady = nBlocksReady * blockSize;
                          continue;
                      }

                      break;
                    }
                  },
                  clone: function () {
                    var cilame_switch_7744 = "41|87|65".split("|"),
                        cilame_indexer_7744 = 0;

                    while (1) {
                      switch (cilame_switch_7744[cilame_indexer_7744++]) {
                        case "65":
                          return clone;
                          continue;

                        case "87":
                          clone._data = this._data.clone();
                          continue;

                        case "41":
                          var clone = Base.clone.call(this);
                          continue;
                      }

                      break;
                    }
                  },
                  _minBufferSize: 0
                });
                continue;

              case "101":
                var C = {};
                continue;

              case "44":
                var WordArray = C_lib.WordArray = Base.extend({
                  init: function (words, sigBytes) {
                    var cilame_switch_4870 = "21|63".split("|"),
                        cilame_indexer_4870 = 0;

                    while (1) {
                      switch (cilame_switch_4870[cilame_indexer_4870++]) {
                        case "63":
                          if (sigBytes != undefined) {
                            this.sigBytes = sigBytes;
                          } else {
                            this.sigBytes = words.length * 4;
                          }

                          continue;

                        case "21":
                          words = this.words = words || [];
                          continue;
                      }

                      break;
                    }
                  },
                  toString: function (encoder) {
                    var cilame_switch_3448 = "87".split("|"),
                        cilame_indexer_3448 = 0;

                    while (1) {
                      switch (cilame_switch_3448[cilame_indexer_3448++]) {
                        case "87":
                          return (encoder || Hex).stringify(this);
                          continue;
                      }

                      break;
                    }
                  },
                  concat: function (wordArray) {
                    var cilame_switch_1314 = "99|97|51|102|61|6|16|75".split("|"),
                        cilame_indexer_1314 = 0;

                    while (1) {
                      switch (cilame_switch_1314[cilame_indexer_1314++]) {
                        case "61":
                          this.clamp();
                          continue;

                        case "75":
                          return this;
                          continue;

                        case "102":
                          var thatSigBytes = wordArray.sigBytes;
                          continue;

                        case "97":
                          var thatWords = wordArray.words;
                          continue;

                        case "16":
                          this.sigBytes += thatSigBytes;
                          continue;

                        case "99":
                          var thisWords = this.words;
                          continue;

                        case "51":
                          var thisSigBytes = this.sigBytes;
                          continue;

                        case "6":
                          if (thisSigBytes % 4) {
                            for (var i = 0; i < thatSigBytes; i++) {
                              var cilame_switch_7721 = "85|13".split("|"),
                                  cilame_indexer_7721 = 0;

                              while (1) {
                                switch (cilame_switch_7721[cilame_indexer_7721++]) {
                                  case "13":
                                    thisWords[thisSigBytes + i >>> 2] |= thatByte << 24 - (thisSigBytes + i) % 4 * 8;
                                    continue;

                                  case "85":
                                    var thatByte = thatWords[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
                                    continue;
                                }

                                break;
                              }
                            }
                          } else {
                            for (var i = 0; i < thatSigBytes; i += 4) {
                              var cilame_switch_86 = "86".split("|"),
                                  cilame_indexer_86 = 0;

                              while (1) {
                                switch (cilame_switch_86[cilame_indexer_86++]) {
                                  case "86":
                                    thisWords[thisSigBytes + i >>> 2] = thatWords[i >>> 2];
                                    continue;
                                }

                                break;
                              }
                            }
                          }

                          continue;
                      }

                      break;
                    }
                  },
                  clamp: function () {
                    var cilame_switch_1754 = "54|93|18|55".split("|"),
                        cilame_indexer_1754 = 0;

                    while (1) {
                      switch (cilame_switch_1754[cilame_indexer_1754++]) {
                        case "18":
                          words[sigBytes >>> 2] &= 0xffffffff << 32 - sigBytes % 4 * 8;
                          continue;

                        case "55":
                          words.length = Math.ceil(sigBytes / 4);
                          continue;

                        case "93":
                          var sigBytes = this.sigBytes;
                          continue;

                        case "54":
                          var words = this.words;
                          continue;
                      }

                      break;
                    }
                  },
                  clone: function () {
                    var cilame_switch_8229 = "23|19|34".split("|"),
                        cilame_indexer_8229 = 0;

                    while (1) {
                      switch (cilame_switch_8229[cilame_indexer_8229++]) {
                        case "23":
                          var clone = Base.clone.call(this);
                          continue;

                        case "19":
                          clone.words = this.words.slice(0);
                          continue;

                        case "34":
                          return clone;
                          continue;
                      }

                      break;
                    }
                  },
                  random: function (nBytes) {
                    var cilame_switch_1358 = "72|62|54|81".split("|"),
                        cilame_indexer_1358 = 0;

                    while (1) {
                      switch (cilame_switch_1358[cilame_indexer_1358++]) {
                        case "54":
                          for (var i = 0, rcache; i < nBytes; i += 4) {
                            var cilame_switch_2691 = "30|26|43".split("|"),
                                cilame_indexer_2691 = 0;

                            while (1) {
                              switch (cilame_switch_2691[cilame_indexer_2691++]) {
                                case "26":
                                  rcache = _r() * 0x3ade67b7;
                                  continue;

                                case "30":
                                  var _r = r((rcache || Math.random()) * 0x100000000);

                                  continue;

                                case "43":
                                  words.push(_r() * 0x100000000 | 0);
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "62":
                          var r = function (m_w) {
                            var cilame_switch_9393 = "97|44|12|51".split("|"),
                                cilame_indexer_9393 = 0;

                            while (1) {
                              switch (cilame_switch_9393[cilame_indexer_9393++]) {
                                case "97":
                                  var m_w = m_w;
                                  continue;

                                case "51":
                                  return function () {
                                    var cilame_switch_653 = "59|100|34|88|98|55".split("|"),
                                        cilame_indexer_653 = 0;

                                    while (1) {
                                      switch (cilame_switch_653[cilame_indexer_653++]) {
                                        case "59":
                                          m_z = 0x9069 * (m_z & 0xFFFF) + (m_z >> 0x10) & mask;
                                          continue;

                                        case "34":
                                          var result = (m_z << 0x10) + m_w & mask;
                                          continue;

                                        case "88":
                                          result /= 0x100000000;
                                          continue;

                                        case "98":
                                          result += 0.5;
                                          continue;

                                        case "55":
                                          return result * (Math.random() > .5 ? 1 : -1);
                                          continue;

                                        case "100":
                                          m_w = 0x4650 * (m_w & 0xFFFF) + (m_w >> 0x10) & mask;
                                          continue;
                                      }

                                      break;
                                    }
                                  };
                                  continue;

                                case "44":
                                  var m_z = 0x3ade68b1;
                                  continue;

                                case "12":
                                  var mask = 0xffffffff;
                                  continue;
                              }

                              break;
                            }
                          };

                          continue;

                        case "81":
                          return new WordArray.init(words, nBytes);
                          continue;

                        case "72":
                          var words = [];
                          continue;
                      }

                      break;
                    }
                  }
                });
                continue;

              case "111":
                var create = Object.create || function () {
                  var cilame_switch_7330 = "0|97".split("|"),
                      cilame_indexer_7330 = 0;

                  while (1) {
                    switch (cilame_switch_7330[cilame_indexer_7330++]) {
                      case "97":
                        return function (obj) {
                          var cilame_switch_8385 = "88|29|22|2|27".split("|"),
                              cilame_indexer_8385 = 0;

                          while (1) {
                            switch (cilame_switch_8385[cilame_indexer_8385++]) {
                              case "22":
                                subtype = new F();
                                continue;

                              case "2":
                                F.prototype = null;
                                continue;

                              case "29":
                                F.prototype = obj;
                                continue;

                              case "27":
                                return subtype;
                                continue;

                              case "88":
                                var subtype;
                                continue;
                            }

                            break;
                          }
                        };
                        continue;

                      case "0":
                        ;
                        continue;
                    }

                    break;
                  }

                  function F() {
                    var cilame_switch_4486 = "".split("|"),
                        cilame_indexer_4486 = 0;

                    while (1) {
                      switch (cilame_switch_4486[cilame_indexer_4486++]) {}

                      break;
                    }
                  }
                }();

                continue;

              case "74":
                var Hex = C_enc.Hex = {
                  stringify: function (wordArray) {
                    var cilame_switch_2287 = "40|2|58|84|33".split("|"),
                        cilame_indexer_2287 = 0;

                    while (1) {
                      switch (cilame_switch_2287[cilame_indexer_2287++]) {
                        case "40":
                          var words = wordArray.words;
                          continue;

                        case "84":
                          for (var i = 0; i < sigBytes; i++) {
                            var cilame_switch_7415 = "28|60|25".split("|"),
                                cilame_indexer_7415 = 0;

                            while (1) {
                              switch (cilame_switch_7415[cilame_indexer_7415++]) {
                                case "25":
                                  hexChars.push((bite & 0x0f).toString(16));
                                  continue;

                                case "28":
                                  var bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
                                  continue;

                                case "60":
                                  hexChars.push((bite >>> 4).toString(16));
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "33":
                          return hexChars.join('');
                          continue;

                        case "2":
                          var sigBytes = wordArray.sigBytes;
                          continue;

                        case "58":
                          var hexChars = [];
                          continue;
                      }

                      break;
                    }
                  },
                  parse: function (hexStr) {
                    var cilame_switch_3478 = "65|49|92|6".split("|"),
                        cilame_indexer_3478 = 0;

                    while (1) {
                      switch (cilame_switch_3478[cilame_indexer_3478++]) {
                        case "6":
                          return new WordArray.init(words, hexStrLength / 2);
                          continue;

                        case "65":
                          var hexStrLength = hexStr.length;
                          continue;

                        case "92":
                          for (var i = 0; i < hexStrLength; i += 2) {
                            var cilame_switch_7685 = "12".split("|"),
                                cilame_indexer_7685 = 0;

                            while (1) {
                              switch (cilame_switch_7685[cilame_indexer_7685++]) {
                                case "12":
                                  words[i >>> 3] |= parseInt(hexStr.substr(i, 2), 16) << 24 - i % 8 * 4;
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "49":
                          var words = [];
                          continue;
                      }

                      break;
                    }
                  }
                };
                continue;

              case "21":
                var Base = C_lib.Base = function () {
                  var cilame_switch_3809 = "83".split("|"),
                      cilame_indexer_3809 = 0;

                  while (1) {
                    switch (cilame_switch_3809[cilame_indexer_3809++]) {
                      case "83":
                        return {
                          extend: function (overrides) {
                            var cilame_switch_533 = "50|77|35|80|28|60".split("|"),
                                cilame_indexer_533 = 0;

                            while (1) {
                              switch (cilame_switch_533[cilame_indexer_533++]) {
                                case "35":
                                  if (!subtype.hasOwnProperty('init') || this.init === subtype.init) {
                                    subtype.init = function () {
                                      var cilame_switch_6386 = "65".split("|"),
                                          cilame_indexer_6386 = 0;

                                      while (1) {
                                        switch (cilame_switch_6386[cilame_indexer_6386++]) {
                                          case "65":
                                            subtype.$super.init.apply(this, arguments);
                                            continue;
                                        }

                                        break;
                                      }
                                    };
                                  }

                                  continue;

                                case "77":
                                  if (overrides) {
                                    subtype.mixIn(overrides);
                                  }

                                  continue;

                                case "50":
                                  var subtype = create(this);
                                  continue;

                                case "80":
                                  subtype.init.prototype = subtype;
                                  continue;

                                case "28":
                                  subtype.$super = this;
                                  continue;

                                case "60":
                                  return subtype;
                                  continue;
                              }

                              break;
                            }
                          },
                          create: function () {
                            var cilame_switch_6980 = "62|57|87".split("|"),
                                cilame_indexer_6980 = 0;

                            while (1) {
                              switch (cilame_switch_6980[cilame_indexer_6980++]) {
                                case "62":
                                  var instance = this.extend();
                                  continue;

                                case "57":
                                  instance.init.apply(instance, arguments);
                                  continue;

                                case "87":
                                  return instance;
                                  continue;
                              }

                              break;
                            }
                          },
                          init: function () {
                            var cilame_switch_323 = "".split("|"),
                                cilame_indexer_323 = 0;

                            while (1) {
                              switch (cilame_switch_323[cilame_indexer_323++]) {}

                              break;
                            }
                          },
                          mixIn: function (properties) {
                            var cilame_switch_6038 = "4|28".split("|"),
                                cilame_indexer_6038 = 0;

                            while (1) {
                              switch (cilame_switch_6038[cilame_indexer_6038++]) {
                                case "4":
                                  for (var propertyName in properties) {
                                    var cilame_switch_7239 = "82".split("|"),
                                        cilame_indexer_7239 = 0;

                                    while (1) {
                                      switch (cilame_switch_7239[cilame_indexer_7239++]) {
                                        case "82":
                                          if (properties.hasOwnProperty(propertyName)) {
                                            this[propertyName] = properties[propertyName];
                                          }

                                          continue;
                                      }

                                      break;
                                    }
                                  }

                                  continue;

                                case "28":
                                  if (properties.hasOwnProperty('toString')) {
                                    this.toString = properties.toString;
                                  }

                                  continue;
                              }

                              break;
                            }
                          },
                          clone: function () {
                            var cilame_switch_767 = "16".split("|"),
                                cilame_indexer_767 = 0;

                            while (1) {
                              switch (cilame_switch_767[cilame_indexer_767++]) {
                                case "16":
                                  return this.init.prototype.extend(this);
                                  continue;
                              }

                              break;
                            }
                          }
                        };
                        continue;
                    }

                    break;
                  }
                }();

                continue;

              case "81":
                var Hasher = C_lib.Hasher = BufferedBlockAlgorithm.extend({
                  cfg: Base.extend(),
                  init: function (cfg) {
                    var cilame_switch_9682 = "22|33".split("|"),
                        cilame_indexer_9682 = 0;

                    while (1) {
                      switch (cilame_switch_9682[cilame_indexer_9682++]) {
                        case "33":
                          this.reset();
                          continue;

                        case "22":
                          this.cfg = this.cfg.extend(cfg);
                          continue;
                      }

                      break;
                    }
                  },
                  reset: function () {
                    var cilame_switch_3125 = "65|79".split("|"),
                        cilame_indexer_3125 = 0;

                    while (1) {
                      switch (cilame_switch_3125[cilame_indexer_3125++]) {
                        case "65":
                          BufferedBlockAlgorithm.reset.call(this);
                          continue;

                        case "79":
                          this._doReset();

                          continue;
                      }

                      break;
                    }
                  },
                  update: function (messageUpdate) {
                    var cilame_switch_8897 = "28|32|76".split("|"),
                        cilame_indexer_8897 = 0;

                    while (1) {
                      switch (cilame_switch_8897[cilame_indexer_8897++]) {
                        case "32":
                          this._process();

                          continue;

                        case "28":
                          this._append(messageUpdate);

                          continue;

                        case "76":
                          return this;
                          continue;
                      }

                      break;
                    }
                  },
                  finalize: function (messageUpdate) {
                    var cilame_switch_7273 = "20|73|8".split("|"),
                        cilame_indexer_7273 = 0;

                    while (1) {
                      switch (cilame_switch_7273[cilame_indexer_7273++]) {
                        case "8":
                          return hash;
                          continue;

                        case "73":
                          var hash = this._doFinalize();

                          continue;

                        case "20":
                          if (messageUpdate) {
                            this._append(messageUpdate);
                          }

                          continue;
                      }

                      break;
                    }
                  },
                  blockSize: 512 / 32,
                  _createHelper: function (hasher) {
                    var cilame_switch_6315 = "73".split("|"),
                        cilame_indexer_6315 = 0;

                    while (1) {
                      switch (cilame_switch_6315[cilame_indexer_6315++]) {
                        case "73":
                          return function (message, cfg) {
                            var cilame_switch_4607 = "99".split("|"),
                                cilame_indexer_4607 = 0;

                            while (1) {
                              switch (cilame_switch_4607[cilame_indexer_4607++]) {
                                case "99":
                                  return new hasher.init(cfg).finalize(message);
                                  continue;
                              }

                              break;
                            }
                          };
                          continue;
                      }

                      break;
                    }
                  },
                  _createHmacHelper: function (hasher) {
                    var cilame_switch_1824 = "86".split("|"),
                        cilame_indexer_1824 = 0;

                    while (1) {
                      switch (cilame_switch_1824[cilame_indexer_1824++]) {
                        case "86":
                          return function (message, key) {
                            var cilame_switch_4898 = "74".split("|"),
                                cilame_indexer_4898 = 0;

                            while (1) {
                              switch (cilame_switch_4898[cilame_indexer_4898++]) {
                                case "74":
                                  return new C_algo.HMAC.init(hasher, key).finalize(message);
                                  continue;
                              }

                              break;
                            }
                          };
                          continue;
                      }

                      break;
                    }
                  }
                });
                continue;

              case "30":
                var C_lib = C.lib = {};
                continue;

              case "92":
                var C_enc = C.enc = {};
                continue;

              case "33":
                var C_algo = C.algo = {};
                continue;

              case "52":
                var Latin1 = C_enc.Latin1 = {
                  stringify: function (wordArray) {
                    var cilame_switch_1205 = "67|92|43|8|58".split("|"),
                        cilame_indexer_1205 = 0;

                    while (1) {
                      switch (cilame_switch_1205[cilame_indexer_1205++]) {
                        case "8":
                          for (var i = 0; i < sigBytes; i++) {
                            var cilame_switch_9893 = "52|0".split("|"),
                                cilame_indexer_9893 = 0;

                            while (1) {
                              switch (cilame_switch_9893[cilame_indexer_9893++]) {
                                case "52":
                                  var bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
                                  continue;

                                case "0":
                                  latin1Chars.push(String.fromCharCode(bite));
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "43":
                          var latin1Chars = [];
                          continue;

                        case "58":
                          return latin1Chars.join('');
                          continue;

                        case "92":
                          var sigBytes = wordArray.sigBytes;
                          continue;

                        case "67":
                          var words = wordArray.words;
                          continue;
                      }

                      break;
                    }
                  },
                  parse: function (latin1Str) {
                    var cilame_switch_9948 = "103|35|71|87".split("|"),
                        cilame_indexer_9948 = 0;

                    while (1) {
                      switch (cilame_switch_9948[cilame_indexer_9948++]) {
                        case "35":
                          var words = [];
                          continue;

                        case "71":
                          for (var i = 0; i < latin1StrLength; i++) {
                            var cilame_switch_3319 = "11".split("|"),
                                cilame_indexer_3319 = 0;

                            while (1) {
                              switch (cilame_switch_3319[cilame_indexer_3319++]) {
                                case "11":
                                  words[i >>> 2] |= (latin1Str.charCodeAt(i) & 0xff) << 24 - i % 4 * 8;
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "103":
                          var latin1StrLength = latin1Str.length;
                          continue;

                        case "87":
                          return new WordArray.init(words, latin1StrLength);
                          continue;
                      }

                      break;
                    }
                  }
                };
                continue;

              case "82":
                return C;
                continue;

              case "61":
                var Utf8 = C_enc.Utf8 = {
                  stringify: function (wordArray) {
                    var cilame_switch_6562 = "59".split("|"),
                        cilame_indexer_6562 = 0;

                    while (1) {
                      switch (cilame_switch_6562[cilame_indexer_6562++]) {
                        case "59":
                          try {
                            return decodeURIComponent(escape(Latin1.stringify(wordArray)));
                          } catch (e) {
                            throw new Error('Malformed UTF-8 data');
                          }

                          continue;
                      }

                      break;
                    }
                  },
                  parse: function (utf8Str) {
                    var cilame_switch_9189 = "5".split("|"),
                        cilame_indexer_9189 = 0;

                    while (1) {
                      switch (cilame_switch_9189[cilame_indexer_9189++]) {
                        case "5":
                          return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
                          continue;
                      }

                      break;
                    }
                  }
                };
                continue;
            }

            break;
          }
        }(Math);

        continue;

      case "36":
        window.myenc = function (pwd) {
          var cilame_switch_4709 = "82|101|33|55|77".split("|"),
              cilame_indexer_4709 = 0;

          while (1) {
            switch (cilame_switch_4709[cilame_indexer_4709++]) {
              case "55":
                var ciphertext = CryptoJS.AES.encrypt(pwd, key, {
                  mode: CryptoJS.mode.CBC,
                  padding: CryptoJS.pad.Pkcs7,
                  iv: iv
                }).toString();
                continue;

              case "101":
                var iv = CryptoJS.enc.Utf8.parse("1234567890123456");
                continue;

              case "82":
                var key = CryptoJS.enc.Utf8.parse("1234567890123456");
                continue;

              case "77":
                return ciphertext;
                continue;

              case "33":
                var pwd = CryptoJS.enc.Utf8.parse(pwd);
                continue;
            }

            break;
          }
        };

        continue;

      case "54":
        window.mydec = function (enc) {
          var cilame_switch_2163 = "90|57|61|56".split("|"),
              cilame_indexer_2163 = 0;

          while (1) {
            switch (cilame_switch_2163[cilame_indexer_2163++]) {
              case "90":
                var key = CryptoJS.enc.Utf8.parse("1234567890123456");
                continue;

              case "61":
                var ciphertext = CryptoJS.AES.decrypt(enc, key, {
                  mode: CryptoJS.mode.CBC,
                  padding: CryptoJS.pad.Pkcs7,
                  iv: iv
                }).toString(CryptoJS.enc.Utf8);
                continue;

              case "56":
                return ciphertext;
                continue;

              case "57":
                var iv = CryptoJS.enc.Utf8.parse("1234567890123456");
                continue;
            }

            break;
          }
        };

        continue;

      case "96":
        (function () {
          var cilame_switch_6240 = "46|4|81|98|97".split("|"),
              cilame_indexer_6240 = 0;

          while (1) {
            switch (cilame_switch_6240[cilame_indexer_6240++]) {
              case "4":
                var C_lib = C.lib;
                continue;

              case "98":
                var C_enc = C.enc;
                continue;

              case "97":
                var Base64 = C_enc.Base64 = {
                  stringify: function (wordArray) {
                    var cilame_switch_5065 = "15|67|58|66|53|81|51|12|47".split("|"),
                        cilame_indexer_5065 = 0;

                    while (1) {
                      switch (cilame_switch_5065[cilame_indexer_5065++]) {
                        case "47":
                          return base64Chars.join('');
                          continue;

                        case "51":
                          var paddingChar = map.charAt(64);
                          continue;

                        case "53":
                          var base64Chars = [];
                          continue;

                        case "81":
                          for (var i = 0; i < sigBytes; i += 3) {
                            var cilame_switch_1669 = "48|97|54|38|76".split("|"),
                                cilame_indexer_1669 = 0;

                            while (1) {
                              switch (cilame_switch_1669[cilame_indexer_1669++]) {
                                case "97":
                                  var byte2 = words[i + 1 >>> 2] >>> 24 - (i + 1) % 4 * 8 & 0xff;
                                  continue;

                                case "54":
                                  var byte3 = words[i + 2 >>> 2] >>> 24 - (i + 2) % 4 * 8 & 0xff;
                                  continue;

                                case "76":
                                  for (var j = 0; j < 4 && i + j * 0.75 < sigBytes; j++) {
                                    var cilame_switch_6282 = "36".split("|"),
                                        cilame_indexer_6282 = 0;

                                    while (1) {
                                      switch (cilame_switch_6282[cilame_indexer_6282++]) {
                                        case "36":
                                          base64Chars.push(map.charAt(triplet >>> 6 * (3 - j) & 0x3f));
                                          continue;
                                      }

                                      break;
                                    }
                                  }

                                  continue;

                                case "48":
                                  var byte1 = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
                                  continue;

                                case "38":
                                  var triplet = byte1 << 16 | byte2 << 8 | byte3;
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "15":
                          var words = wordArray.words;
                          continue;

                        case "58":
                          var map = this._map;
                          continue;

                        case "12":
                          if (paddingChar) {
                            while (base64Chars.length % 4) {
                              base64Chars.push(paddingChar);
                            }
                          }

                          continue;

                        case "66":
                          wordArray.clamp();
                          continue;

                        case "67":
                          var sigBytes = wordArray.sigBytes;
                          continue;
                      }

                      break;
                    }
                  },
                  parse: function (base64Str) {
                    var cilame_switch_197 = "101|48|44|65|7|77|106".split("|"),
                        cilame_indexer_197 = 0;

                    while (1) {
                      switch (cilame_switch_197[cilame_indexer_197++]) {
                        case "48":
                          var map = this._map;
                          continue;

                        case "44":
                          var reverseMap = this._reverseMap;
                          continue;

                        case "65":
                          if (!reverseMap) {
                            reverseMap = this._reverseMap = [];

                            for (var j = 0; j < map.length; j++) {
                              var cilame_switch_1143 = "6".split("|"),
                                  cilame_indexer_1143 = 0;

                              while (1) {
                                switch (cilame_switch_1143[cilame_indexer_1143++]) {
                                  case "6":
                                    reverseMap[map.charCodeAt(j)] = j;
                                    continue;
                                }

                                break;
                              }
                            }
                          }

                          continue;

                        case "7":
                          var paddingChar = map.charAt(64);
                          continue;

                        case "101":
                          var base64StrLength = base64Str.length;
                          continue;

                        case "77":
                          if (paddingChar) {
                            var paddingIndex = base64Str.indexOf(paddingChar);

                            if (paddingIndex !== -1) {
                              base64StrLength = paddingIndex;
                            }
                          }

                          continue;

                        case "106":
                          return parseLoop(base64Str, base64StrLength, reverseMap);
                          continue;
                      }

                      break;
                    }
                  },
                  _map: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
                };
                continue;

              case "81":
                var WordArray = C_lib.WordArray;
                continue;

              case "46":
                var C = CryptoJS;
                continue;
            }

            break;
          }

          function parseLoop(base64Str, base64StrLength, reverseMap) {
            var cilame_switch_8256 = "102|62|73|82".split("|"),
                cilame_indexer_8256 = 0;

            while (1) {
              switch (cilame_switch_8256[cilame_indexer_8256++]) {
                case "62":
                  var nBytes = 0;
                  continue;

                case "73":
                  for (var i = 0; i < base64StrLength; i++) {
                    var cilame_switch_2127 = "90".split("|"),
                        cilame_indexer_2127 = 0;

                    while (1) {
                      switch (cilame_switch_2127[cilame_indexer_2127++]) {
                        case "90":
                          if (i % 4) {
                            var bits1 = reverseMap[base64Str.charCodeAt(i - 1)] << i % 4 * 2;
                            var bits2 = reverseMap[base64Str.charCodeAt(i)] >>> 6 - i % 4 * 2;
                            words[nBytes >>> 2] |= (bits1 | bits2) << 24 - nBytes % 4 * 8;
                            nBytes++;
                          }

                          continue;
                      }

                      break;
                    }
                  }

                  continue;

                case "102":
                  var words = [];
                  continue;

                case "82":
                  return WordArray.create(words, nBytes);
                  continue;
              }

              break;
            }
          }
        })();

        continue;

      case "23":
        (function () {
          var cilame_switch_8048 = "117|28|8|110|79|87|12|23|95|115|113|17|31|96|29|35|37|42".split("|"),
              cilame_indexer_8048 = 0;

          while (1) {
            switch (cilame_switch_8048[cilame_indexer_8048++]) {
              case "35":
                var RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36];
                continue;

              case "110":
                var C_algo = C.algo;
                continue;

              case "113":
                var INV_SUB_MIX_0 = [];
                continue;

              case "28":
                var C_lib = C.lib;
                continue;

              case "23":
                var SUB_MIX_1 = [];
                continue;

              case "31":
                var INV_SUB_MIX_2 = [];
                continue;

              case "115":
                var SUB_MIX_3 = [];
                continue;

              case "8":
                var BlockCipher = C_lib.BlockCipher;
                continue;

              case "12":
                var SUB_MIX_0 = [];
                continue;

              case "96":
                var INV_SUB_MIX_3 = [];
                continue;

              case "79":
                var SBOX = [];
                continue;

              case "29":
                (function () {
                  var cilame_switch_3644 = "9|15|44|47|57".split("|"),
                      cilame_indexer_3644 = 0;

                  while (1) {
                    switch (cilame_switch_3644[cilame_indexer_3644++]) {
                      case "44":
                        var x = 0;
                        continue;

                      case "9":
                        var d = [];
                        continue;

                      case "47":
                        var xi = 0;
                        continue;

                      case "15":
                        for (var i = 0; i < 256; i++) {
                          var cilame_switch_7372 = "36".split("|"),
                              cilame_indexer_7372 = 0;

                          while (1) {
                            switch (cilame_switch_7372[cilame_indexer_7372++]) {
                              case "36":
                                if (i < 128) {
                                  d[i] = i << 1;
                                } else {
                                  d[i] = i << 1 ^ 0x11b;
                                }

                                continue;
                            }

                            break;
                          }
                        }

                        continue;

                      case "57":
                        for (var i = 0; i < 256; i++) {
                          var cilame_switch_8436 = "40|3|66|69|22|8|113|32|87|58|35|67|39|61|83|107|24|0".split("|"),
                              cilame_indexer_8436 = 0;

                          while (1) {
                            switch (cilame_switch_8436[cilame_indexer_8436++]) {
                              case "107":
                                INV_SUB_MIX_2[sx] = t << 8 | t >>> 24;
                                continue;

                              case "83":
                                INV_SUB_MIX_1[sx] = t << 16 | t >>> 16;
                                continue;

                              case "3":
                                sx = sx >>> 8 ^ sx & 0xff ^ 0x63;
                                continue;

                              case "113":
                                var x8 = d[x4];
                                continue;

                              case "0":
                                if (!x) {
                                  x = xi = 1;
                                } else {
                                  x = x2 ^ d[d[d[x8 ^ x2]]];
                                  xi ^= d[d[xi]];
                                }

                                continue;

                              case "87":
                                SUB_MIX_0[x] = t << 24 | t >>> 8;
                                continue;

                              case "67":
                                SUB_MIX_3[x] = t;
                                continue;

                              case "22":
                                var x2 = d[x];
                                continue;

                              case "35":
                                SUB_MIX_2[x] = t << 8 | t >>> 24;
                                continue;

                              case "40":
                                var sx = xi ^ xi << 1 ^ xi << 2 ^ xi << 3 ^ xi << 4;
                                continue;

                              case "69":
                                INV_SBOX[sx] = x;
                                continue;

                              case "61":
                                INV_SUB_MIX_0[sx] = t << 24 | t >>> 8;
                                continue;

                              case "24":
                                INV_SUB_MIX_3[sx] = t;
                                continue;

                              case "32":
                                var t = d[sx] * 0x101 ^ sx * 0x1010100;
                                continue;

                              case "8":
                                var x4 = d[x2];
                                continue;

                              case "58":
                                SUB_MIX_1[x] = t << 16 | t >>> 16;
                                continue;

                              case "66":
                                SBOX[x] = sx;
                                continue;

                              case "39":
                                var t = x8 * 0x1010101 ^ x4 * 0x10001 ^ x2 * 0x101 ^ x * 0x1010100;
                                continue;
                            }

                            break;
                          }
                        }

                        continue;
                    }

                    break;
                  }
                })();

                continue;

              case "87":
                var INV_SBOX = [];
                continue;

              case "42":
                C.AES = BlockCipher._createHelper(AES);
                continue;

              case "17":
                var INV_SUB_MIX_1 = [];
                continue;

              case "37":
                var AES = C_algo.AES = BlockCipher.extend({
                  _doReset: function () {
                    var cilame_switch_3569 = "107|23|63|28|71|91|58|99|70|83".split("|"),
                        cilame_indexer_3569 = 0;

                    while (1) {
                      switch (cilame_switch_3569[cilame_indexer_3569++]) {
                        case "23":
                          var key = this._keyPriorReset = this._key;
                          continue;

                        case "107":
                          if (this._nRounds && this._keyPriorReset === this._key) {
                            return;
                          }

                          continue;

                        case "63":
                          var keyWords = key.words;
                          continue;

                        case "70":
                          var invKeySchedule = this._invKeySchedule = [];
                          continue;

                        case "83":
                          for (var invKsRow = 0; invKsRow < ksRows; invKsRow++) {
                            var cilame_switch_7096 = "9|99|13".split("|"),
                                cilame_indexer_7096 = 0;

                            while (1) {
                              switch (cilame_switch_7096[cilame_indexer_7096++]) {
                                case "13":
                                  if (invKsRow < 4 || ksRow <= 4) {
                                    invKeySchedule[invKsRow] = t;
                                  } else {
                                    invKeySchedule[invKsRow] = INV_SUB_MIX_0[SBOX[t >>> 24]] ^ INV_SUB_MIX_1[SBOX[t >>> 16 & 0xff]] ^ INV_SUB_MIX_2[SBOX[t >>> 8 & 0xff]] ^ INV_SUB_MIX_3[SBOX[t & 0xff]];
                                  }

                                  continue;

                                case "99":
                                  if (invKsRow % 4) {
                                    var t = keySchedule[ksRow];
                                  } else {
                                    var t = keySchedule[ksRow - 4];
                                  }

                                  continue;

                                case "9":
                                  var ksRow = ksRows - invKsRow;
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "58":
                          var keySchedule = this._keySchedule = [];
                          continue;

                        case "99":
                          for (var ksRow = 0; ksRow < ksRows; ksRow++) {
                            var cilame_switch_3095 = "99".split("|"),
                                cilame_indexer_3095 = 0;

                            while (1) {
                              switch (cilame_switch_3095[cilame_indexer_3095++]) {
                                case "99":
                                  if (ksRow < keySize) {
                                    keySchedule[ksRow] = keyWords[ksRow];
                                  } else {
                                    var t = keySchedule[ksRow - 1];

                                    if (!(ksRow % keySize)) {
                                      t = t << 8 | t >>> 24;
                                      t = SBOX[t >>> 24] << 24 | SBOX[t >>> 16 & 0xff] << 16 | SBOX[t >>> 8 & 0xff] << 8 | SBOX[t & 0xff];
                                      t ^= RCON[ksRow / keySize | 0] << 24;
                                    } else if (keySize > 6 && ksRow % keySize == 4) {
                                      t = SBOX[t >>> 24] << 24 | SBOX[t >>> 16 & 0xff] << 16 | SBOX[t >>> 8 & 0xff] << 8 | SBOX[t & 0xff];
                                    }

                                    keySchedule[ksRow] = keySchedule[ksRow - keySize] ^ t;
                                  }

                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "28":
                          var keySize = key.sigBytes / 4;
                          continue;

                        case "71":
                          var nRounds = this._nRounds = keySize + 6;
                          continue;

                        case "91":
                          var ksRows = (nRounds + 1) * 4;
                          continue;
                      }

                      break;
                    }
                  },
                  encryptBlock: function (M, offset) {
                    var cilame_switch_2731 = "85".split("|"),
                        cilame_indexer_2731 = 0;

                    while (1) {
                      switch (cilame_switch_2731[cilame_indexer_2731++]) {
                        case "85":
                          this._doCryptBlock(M, offset, this._keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX);

                          continue;
                      }

                      break;
                    }
                  },
                  decryptBlock: function (M, offset) {
                    var cilame_switch_6875 = "62|5|2|49|41|52|82".split("|"),
                        cilame_indexer_6875 = 0;

                    while (1) {
                      switch (cilame_switch_6875[cilame_indexer_6875++]) {
                        case "52":
                          M[offset + 1] = M[offset + 3];
                          continue;

                        case "41":
                          var t = M[offset + 1];
                          continue;

                        case "49":
                          this._doCryptBlock(M, offset, this._invKeySchedule, INV_SUB_MIX_0, INV_SUB_MIX_1, INV_SUB_MIX_2, INV_SUB_MIX_3, INV_SBOX);

                          continue;

                        case "82":
                          M[offset + 3] = t;
                          continue;

                        case "2":
                          M[offset + 3] = t;
                          continue;

                        case "62":
                          var t = M[offset + 1];
                          continue;

                        case "5":
                          M[offset + 1] = M[offset + 3];
                          continue;
                      }

                      break;
                    }
                  },
                  _doCryptBlock: function (M, offset, keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX) {
                    var cilame_switch_793 = "47|23|27|63|40|85|102|92|6|4|72|57|103|21|29".split("|"),
                        cilame_indexer_793 = 0;

                    while (1) {
                      switch (cilame_switch_793[cilame_indexer_793++]) {
                        case "21":
                          M[offset + 2] = t2;
                          continue;

                        case "40":
                          var s3 = M[offset + 3] ^ keySchedule[3];
                          continue;

                        case "27":
                          var s1 = M[offset + 1] ^ keySchedule[1];
                          continue;

                        case "92":
                          var t0 = (SBOX[s0 >>> 24] << 24 | SBOX[s1 >>> 16 & 0xff] << 16 | SBOX[s2 >>> 8 & 0xff] << 8 | SBOX[s3 & 0xff]) ^ keySchedule[ksRow++];
                          continue;

                        case "103":
                          M[offset + 1] = t1;
                          continue;

                        case "4":
                          var t2 = (SBOX[s2 >>> 24] << 24 | SBOX[s3 >>> 16 & 0xff] << 16 | SBOX[s0 >>> 8 & 0xff] << 8 | SBOX[s1 & 0xff]) ^ keySchedule[ksRow++];
                          continue;

                        case "47":
                          var nRounds = this._nRounds;
                          continue;

                        case "57":
                          M[offset] = t0;
                          continue;

                        case "102":
                          for (var round = 1; round < nRounds; round++) {
                            var cilame_switch_200 = "32|35|69|39|98|106|19|11".split("|"),
                                cilame_indexer_200 = 0;

                            while (1) {
                              switch (cilame_switch_200[cilame_indexer_200++]) {
                                case "19":
                                  s2 = t2;
                                  continue;

                                case "106":
                                  s1 = t1;
                                  continue;

                                case "11":
                                  s3 = t3;
                                  continue;

                                case "98":
                                  s0 = t0;
                                  continue;

                                case "69":
                                  var t2 = SUB_MIX_0[s2 >>> 24] ^ SUB_MIX_1[s3 >>> 16 & 0xff] ^ SUB_MIX_2[s0 >>> 8 & 0xff] ^ SUB_MIX_3[s1 & 0xff] ^ keySchedule[ksRow++];
                                  continue;

                                case "32":
                                  var t0 = SUB_MIX_0[s0 >>> 24] ^ SUB_MIX_1[s1 >>> 16 & 0xff] ^ SUB_MIX_2[s2 >>> 8 & 0xff] ^ SUB_MIX_3[s3 & 0xff] ^ keySchedule[ksRow++];
                                  continue;

                                case "35":
                                  var t1 = SUB_MIX_0[s1 >>> 24] ^ SUB_MIX_1[s2 >>> 16 & 0xff] ^ SUB_MIX_2[s3 >>> 8 & 0xff] ^ SUB_MIX_3[s0 & 0xff] ^ keySchedule[ksRow++];
                                  continue;

                                case "39":
                                  var t3 = SUB_MIX_0[s3 >>> 24] ^ SUB_MIX_1[s0 >>> 16 & 0xff] ^ SUB_MIX_2[s1 >>> 8 & 0xff] ^ SUB_MIX_3[s2 & 0xff] ^ keySchedule[ksRow++];
                                  continue;
                              }

                              break;
                            }
                          }

                          continue;

                        case "72":
                          var t3 = (SBOX[s3 >>> 24] << 24 | SBOX[s0 >>> 16 & 0xff] << 16 | SBOX[s1 >>> 8 & 0xff] << 8 | SBOX[s2 & 0xff]) ^ keySchedule[ksRow++];
                          continue;

                        case "6":
                          var t1 = (SBOX[s1 >>> 24] << 24 | SBOX[s2 >>> 16 & 0xff] << 16 | SBOX[s3 >>> 8 & 0xff] << 8 | SBOX[s0 & 0xff]) ^ keySchedule[ksRow++];
                          continue;

                        case "85":
                          var ksRow = 4;
                          continue;

                        case "23":
                          var s0 = M[offset] ^ keySchedule[0];
                          continue;

                        case "63":
                          var s2 = M[offset + 2] ^ keySchedule[2];
                          continue;

                        case "29":
                          M[offset + 3] = t3;
                          continue;
                      }

                      break;
                    }
                  },
                  keySize: 256 / 32
                });
                continue;

              case "95":
                var SUB_MIX_2 = [];
                continue;

              case "117":
                var C = CryptoJS;
                continue;
            }

            break;
          }
        })();

        continue;
    }

    break;
  }
})();

console.log('测试加密:', window.myenc("1234567890123456111111111111111111111111111111"));
console.log('测试解密:', window.mydec(window.myenc("你好123")));