var a = "He";
a += "llo,";
a += "A";
a += "ST";
a += "!";

var b;

b = "AST ";
b += "is ";
b += "so ";
b += "easy!";