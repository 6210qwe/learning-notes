#include "node_main_instance.h"
#include <memory>
#include "debug_utils-inl.h"
#include "node_external_reference.h"
#include "node_internals.h"
#include "node_options-inl.h"
#include "node_snapshot_builder.h"
#include "node_snapshotable.h"
#include "node_v8_platform-inl.h"
#include "util-inl.h"
#if defined(LEAK_SANITIZER)
#include <sanitizer/lsan_interface.h>
#endif

#if HAVE_INSPECTOR
#include "inspector/worker_inspector.h"  // ParentInspectorHandle
#endif

namespace node {

using v8::Context;
using v8::HandleScope;
using v8::Isolate;
using v8::Local;
using v8::Locker;

NodeMainInstance::NodeMainInstance(Isolate* isolate,
                                   uv_loop_t* event_loop,
                                   MultiIsolatePlatform* platform,
                                   const std::vector<std::string>& args,
                                   const std::vector<std::string>& exec_args)
    : args_(args),
      exec_args_(exec_args),
      array_buffer_allocator_(nullptr),
      isolate_(isolate),
      platform_(platform),
      isolate_data_(nullptr),
      snapshot_data_(nullptr) {
  isolate_data_ =
      std::make_unique<IsolateData>(isolate_, event_loop, platform, nullptr);

  SetIsolateMiscHandlers(isolate_, {});
}

std::unique_ptr<NodeMainInstance> NodeMainInstance::Create(
    Isolate* isolate,
    uv_loop_t* event_loop,
    MultiIsolatePlatform* platform,
    const std::vector<std::string>& args,
    const std::vector<std::string>& exec_args) {
  return std::unique_ptr<NodeMainInstance>(
      new NodeMainInstance(isolate, event_loop, platform, args, exec_args));
}

NodeMainInstance::NodeMainInstance(const SnapshotData* snapshot_data,
                                   uv_loop_t* event_loop,
                                   MultiIsolatePlatform* platform,
                                   const std::vector<std::string>& args,
                                   const std::vector<std::string>& exec_args)
    : args_(args),
      exec_args_(exec_args),
      array_buffer_allocator_(ArrayBufferAllocator::Create()),
      isolate_(nullptr),
      platform_(platform),
      isolate_data_(),
      isolate_params_(std::make_unique<Isolate::CreateParams>()),
      snapshot_data_(snapshot_data) {
  isolate_params_->array_buffer_allocator = array_buffer_allocator_.get();
  if (snapshot_data != nullptr) {
    SnapshotBuilder::InitializeIsolateParams(snapshot_data,
                                             isolate_params_.get());
  }

  isolate_ = Isolate::Allocate();
  CHECK_NOT_NULL(isolate_);
  // Register the isolate on the platform before the isolate gets initialized,
  // so that the isolate can access the platform during initialization.
  platform->RegisterIsolate(isolate_, event_loop);
  SetIsolateCreateParamsForNode(isolate_params_.get());
  Isolate::Initialize(isolate_, *isolate_params_);

  // If the indexes are not nullptr, we are not deserializing
  isolate_data_ = std::make_unique<IsolateData>(
      isolate_,
      event_loop,
      platform,
      array_buffer_allocator_.get(),
      snapshot_data == nullptr ? nullptr
                               : &(snapshot_data->isolate_data_indices));
  IsolateSettings s;
  SetIsolateMiscHandlers(isolate_, s);
  if (snapshot_data == nullptr) {
    // If in deserialize mode, delay until after the deserialization is
    // complete.
    SetIsolateErrorHandlers(isolate_, s);
  }
  isolate_data_->max_young_gen_size =
      isolate_params_->constraints.max_young_generation_size_in_bytes();
}

void NodeMainInstance::Dispose() {
  // This should only be called on a main instance that does not own its
  // isolate.
  CHECK_NULL(isolate_params_);
  platform_->DrainTasks(isolate_);
}

NodeMainInstance::~NodeMainInstance() {
  if (isolate_params_ == nullptr) {
    return;
  }
  // This should only be done on a main instance that owns its isolate.
  platform_->UnregisterIsolate(isolate_);
  isolate_->Dispose();
}
// �����������
void printLog(Local<v8::Context> context,
              v8::Isolate* isolate,
              v8::Local<v8::Value> args[],
              int len) {
  Local<v8::String> consoleName =
      v8::String::NewFromUtf8(
          isolate, "console", v8::NewStringType::kInternalized)
          .ToLocalChecked();
  Local<v8::String> infoName =
      v8::String::NewFromUtf8(isolate, "info", v8::NewStringType::kInternalized)
          .ToLocalChecked();
  auto console = context->Global()->Get(context, consoleName).ToLocalChecked();
  auto logFunc =
      console.As<v8::Object>()->Get(context, infoName).ToLocalChecked();
  logFunc.As<v8::Function>()->Call(context, console, len, args);
}


void IndexGet(uint32_t index, const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.all]|get -> key:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  auto v8Num = v8::Number::New(isolate, index);
  v8::Local<v8::Value> args[] = {str1, v8Num.As<v8::Value>()};
  printLog(context, isolate, args, 2);
}
void IndexGet2(uint32_t index, const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.watch]|get -> key:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  auto v8Num = v8::Number::New(isolate, index);
  v8::Local<v8::Value> args[] = {str1, v8Num.As<v8::Value>()};
  printLog(context, isolate, args, 2);
}
void IndexSet(uint32_t index,
              v8::Local<v8::Value> value_obj,
              const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.all]|set -> this:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  auto str2 = v8::String::NewFromUtf8(
                  isolate, ",key:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto str3 = v8::String::NewFromUtf8(
                  isolate, ",value:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto v8Num = v8::Number::New(isolate, index);
  v8::Local<v8::Value> args[] = {
      str1, info.This(), str2, v8Num.As<v8::Value>(), str3, value_obj};
  printLog(context, isolate, args, 6);
}
void IndexSet2(uint32_t index,
              v8::Local<v8::Value> value_obj,
              const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.watch]|set -> this:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  auto str2 = v8::String::NewFromUtf8(
                  isolate, ",key:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto str3 = v8::String::NewFromUtf8(
                  isolate, ",value:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto v8Num = v8::Number::New(isolate, index);
  v8::Local<v8::Value> args[] = {
      str1, info.This(), str2, v8Num.As<v8::Value>(), str3, value_obj};
  printLog(context, isolate, args, 6);
}
void NameGet(v8::Local<v8::Name> name,
             const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  if (name->IsSymbol()) {
    return;
  }
  if (name.As<v8::String>() ==
      v8::String::NewFromUtf8(
          isolate, "constructor", v8::NewStringType::kInternalized)
          .ToLocalChecked()) {
    return;
  }
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.all]|get -> key:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  v8::Local<v8::Value> args[] = {str1, name.As<v8::Value>()};
  printLog(context, isolate, args, 2);
}
void NameGet2(v8::Local<v8::Name> name,
             const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  if (name->IsSymbol()) {
    return;
  }
  if (name.As<v8::String>() ==
      v8::String::NewFromUtf8(
          isolate, "constructor", v8::NewStringType::kInternalized)
          .ToLocalChecked()) {
    return;
  }
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.watch]|get -> key:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  v8::Local<v8::Value> args[] = {str1, name.As<v8::Value>()};
  printLog(context, isolate, args, 2);
}
void NameSet(v8::Local<v8::Name> name,
             v8::Local<v8::Value> value_obj,
             const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.all]|set -> this:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  auto str2 = v8::String::NewFromUtf8(
                  isolate, ",key:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto str3 = v8::String::NewFromUtf8(
                  isolate, ",value:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  v8::Local<v8::Value> args[] = {
      str1, info.This(), str2, name.As<v8::Value>(), str3, value_obj};
  printLog(context, isolate, args, 6);
}
void NameSet2(v8::Local<v8::Name> name,
             v8::Local<v8::Value> value_obj,
             const v8::PropertyCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.watch]|set -> this:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  auto str2 = v8::String::NewFromUtf8(
                  isolate, ",key:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto str3 = v8::String::NewFromUtf8(
                  isolate, ",value:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  v8::Local<v8::Value> args[] = {
      str1, info.This(), str2, name.As<v8::Value>(), str3, value_obj};
  printLog(context, isolate, args, 6);
}
void ldObjALLCall(const v8::FunctionCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto key = info[0];
  auto self = info.This();
  auto str1 =
      v8::String::NewFromUtf8(
          isolate, "[ldObj.all]|call -> this:", v8::NewStringType::kInternalized)
          .ToLocalChecked()
          .As<v8::Value>();
  auto str2 = v8::String::NewFromUtf8(
                  isolate, ",arg:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto str3 = v8::String::NewFromUtf8(
                  isolate, ",ret:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto value = self->Get(context, key).ToLocalChecked();
  v8::Local<v8::Value> args[] = {str1, info.This(), str2, key, str3, value};
  printLog(context, isolate, args, 6);
  info.GetReturnValue().Set(value);
}
void ldObjWatchCall(const v8::FunctionCallbackInfo<v8::Value>& info) {
  auto isolate = info.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto key = info[0];
  auto self = info.This();
  auto str1 = v8::String::NewFromUtf8(isolate,
                                      "[ldObj.watch]|call -> this:",
                                      v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto str2 = v8::String::NewFromUtf8(
                  isolate, ",arg:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto str3 = v8::String::NewFromUtf8(
                  isolate, ",ret:", v8::NewStringType::kInternalized)
                  .ToLocalChecked()
                  .As<v8::Value>();
  auto value = self->Get(context, key).ToLocalChecked();
  v8::Local<v8::Value> args[] = {str1, info.This(), str2, key, str3, value};
  printLog(context, isolate, args, 6);
}
// �ص��������κ�����
void voidFunc(const v8::FunctionCallbackInfo<v8::Value>& args) {}
// ����һ�����󣬾��м��ӹ���
void voidWatch(const v8::FunctionCallbackInfo<v8::Value>& args) {
  // ��ȡIsolate��context;
  auto isolate = args.GetIsolate();
  auto context = isolate->GetCurrentContext();
  // ��������ģ��
  Local<v8::ObjectTemplate> objTemplate = v8::ObjectTemplate::New(isolate);
  objTemplate->SetHandler(
      v8::IndexedPropertyHandlerConfiguration(IndexGet2, IndexSet2));
  objTemplate->SetHandler(
      v8::NamedPropertyHandlerConfiguration(NameGet2, NameSet2));
  objTemplate->SetInternalFieldCount(1);
  // ʵ����һ��ldObj����
  v8::Local<v8::Object> watchObj =
      objTemplate->NewInstance(context).ToLocalChecked();
  args.GetReturnValue().Set(watchObj);
}
// nativeCallback����
v8::Local<v8::Private> privateKey;
void nativeCallBack(const v8::FunctionCallbackInfo<v8::Value>& args) {
  // ��ȡIsolate��context;
  auto isolate = args.GetIsolate();
  auto context = isolate->GetCurrentContext();
  auto self = args.This();
  // ��ȡԭʼ����
  auto rawFunc = args.Data().As<v8::Function>();
  int argsLen = args.Length();
  // �ص�����
  v8::Local<v8::Value>* argList = new v8::Local<v8::Value>[argsLen];
  for (int i = 0; i < argsLen; i++) {
    *(argList+i) = args[i];
  }
  auto result = rawFunc->Call(context, self, argsLen, argList).ToLocalChecked();
  args.GetReturnValue().Set(result);
  delete[] argList;
}

// ����һ��native����
void setNative(const v8::FunctionCallbackInfo<v8::Value>& args) {
  // ��ȡIsolate��context;
  auto isolate = args.GetIsolate();
  auto context = isolate->GetCurrentContext();
  int argsLen = args.Length();
  // �жϲ��������Ƿ�Ϊ0�����ߵ�һ���������Ǻ���
  if (argsLen == 0 || !(args[0]->IsFunction())) {
    args.GetReturnValue().SetUndefined();
    return;
  }
  auto name = args[0].As<v8::Function>()->GetName().As<v8::String>();
  if (argsLen == 2 && args[1]->IsString()) {
    name = args[1].As<v8::String>();
  }
  // ��������ģ��
  Local<v8::FunctionTemplate> funcTemplate =
      v8::FunctionTemplate::New(isolate);
  // ���ûص����������Ұѵ�һ���������ݵ��ص������е�Data������
  funcTemplate->SetCallHandler(nativeCallBack, args[0]);
  auto nativeFunc = funcTemplate->GetFunction(context).ToLocalChecked();
  nativeFunc->SetName(name);
  args.GetReturnValue().Set(nativeFunc);
}
void addPlugins(Local<v8::Context> context, v8::Isolate* isolate) {
  privateKey = v8::Private::New(isolate);
  // ����һ������ģ��
  auto funcTemplate = v8::FunctionTemplate::New(isolate, voidFunc);
  // ��ȡ����ʵ����ģ��
  auto funcUndefinedInstance = funcTemplate->InstanceTemplate();
  // ����һ���ص�
  funcUndefinedInstance->SetCallAsFunctionHandler(ldObjALLCall);
  funcUndefinedInstance->SetHandler(
      v8::IndexedPropertyHandlerConfiguration(IndexGet, IndexSet));
  funcUndefinedInstance->SetHandler(
      v8::NamedPropertyHandlerConfiguration(NameGet, NameSet));
  // ����λ�ã�����Ϊundefiend����
  funcUndefinedInstance->SetInternalFieldCount(1);
  funcUndefinedInstance->MarkAsUndetectable();
  // ͨ��ģ���ȡ��Ӧ����
  auto all = funcTemplate->GetFunction(context).ToLocalChecked();
  // ����һ��v8�ַ���������
  Local<v8::String> name_all =
      v8::String::NewFromUtf8(
          isolate, "all", v8::NewStringType::kInternalized)
          .ToLocalChecked();
  // ���ú�������
  all->SetName(name_all);
  /*��ʼ���Ӽ�ض���*/
  // ����һ������ģ��
  auto func2Template = v8::FunctionTemplate::New(isolate, voidWatch);
  // ͨ��ģ���ȡ��Ӧ����
  auto watch = func2Template->GetFunction(context).ToLocalChecked();
  Local<v8::String> name_watch =
      v8::String::NewFromUtf8(isolate, "watch", v8::NewStringType::kInternalized)
          .ToLocalChecked();
  // ���ú�������
  watch->SetName(name_watch);
  // �����������
  Local<v8::String> name_ldObj =
      v8::String::NewFromUtf8(
          isolate, "ldObj", v8::NewStringType::kInternalized)
          .ToLocalChecked();
  Local<v8::ObjectTemplate> objTemplate = v8::ObjectTemplate::New(isolate);
  // ʵ����һ��ldObj����
  v8::Local<v8::Object> ldObj = objTemplate->NewInstance(context).ToLocalChecked();
  // ��ldObj��������all����
  ldObj->Set(context, name_all, all);
  ldObj->Set(context, name_watch, watch);
  // native��
  Local<v8::String> name_native =
      v8::String::NewFromUtf8(
          isolate, "setNative", v8::NewStringType::kInternalized)
          .ToLocalChecked();
  auto func3Template = v8::FunctionTemplate::New(isolate, setNative);
  auto set_native = func3Template->GetFunction(context).ToLocalChecked();
  set_native->SetName(name_native);
  ldObj->Set(context, name_native, set_native);
  // ����hideKey
  // Local<v8::String> hideKey =v8::String::NewFromUtf8(isolate, "hideKey", v8::NewStringType::kInternalized).ToLocalChecked();
  // ldObj->Set(context, hideKey, v8::Private::New(isolate).As<v8::Value>());
  // ��ldObj���õ�global�����ϣ�����ΪldObj
      context->Global()
      ->Set(context, name_ldObj, ldObj)
      .Check();
}
int NodeMainInstance::Run() {
  Locker locker(isolate_);
  Isolate::Scope isolate_scope(isolate_);
  HandleScope handle_scope(isolate_);

  int exit_code = 0;
  DeleteFnPtr<Environment, FreeEnvironment> env =
      CreateMainEnvironment(&exit_code);
  CHECK_NOT_NULL(env);

  Context::Scope context_scope(env->context());
  // ��ʼ�޸�λ�� 
  // ����ȫ�ֲ�� 
  auto context = env->context(); 
  auto isolate = isolate_; 
  addPlugins(context, isolate); 
  // �����޸�λ��
  Run(&exit_code, env.get());
  return exit_code;
}

void NodeMainInstance::Run(int* exit_code, Environment* env) {
  if (*exit_code == 0) {
    LoadEnvironment(env, StartExecutionCallback{});

    *exit_code = SpinEventLoop(env).FromMaybe(1);
  }

  ResetStdio();

  // TODO(addaleax): Neither NODE_SHARED_MODE nor HAVE_INSPECTOR really
  // make sense here.
#if HAVE_INSPECTOR && defined(__POSIX__) && !defined(NODE_SHARED_MODE)
  struct sigaction act;
  memset(&act, 0, sizeof(act));
  for (unsigned nr = 1; nr < kMaxSignal; nr += 1) {
    if (nr == SIGKILL || nr == SIGSTOP || nr == SIGPROF)
      continue;
    act.sa_handler = (nr == SIGPIPE) ? SIG_IGN : SIG_DFL;
    CHECK_EQ(0, sigaction(nr, &act, nullptr));
  }
#endif

#if defined(LEAK_SANITIZER)
  __lsan_do_leak_check();
#endif
}

DeleteFnPtr<Environment, FreeEnvironment>
NodeMainInstance::CreateMainEnvironment(int* exit_code) {
  *exit_code = 0;  // Reset the exit code to 0

  HandleScope handle_scope(isolate_);

  // TODO(addaleax): This should load a real per-Isolate option, currently
  // this is still effectively per-process.
  if (isolate_data_->options()->track_heap_objects) {
    isolate_->GetHeapProfiler()->StartTrackingHeapObjects(true);
  }

  Local<Context> context;
  DeleteFnPtr<Environment, FreeEnvironment> env;

  if (snapshot_data_ != nullptr) {
    env.reset(new Environment(isolate_data_.get(),
                              isolate_,
                              args_,
                              exec_args_,
                              &(snapshot_data_->env_info),
                              EnvironmentFlags::kDefaultFlags,
                              {}));
    context = Context::FromSnapshot(isolate_,
                                    kNodeContextIndex,
                                    {DeserializeNodeInternalFields, env.get()})
                  .ToLocalChecked();

    CHECK(!context.IsEmpty());
    Context::Scope context_scope(context);
    CHECK(InitializeContextRuntime(context).IsJust());
    SetIsolateErrorHandlers(isolate_, {});
    env->InitializeMainContext(context, &(snapshot_data_->env_info));
#if HAVE_INSPECTOR
    env->InitializeInspector({});
#endif
    env->DoneBootstrapping();
  } else {
    context = NewContext(isolate_);
    CHECK(!context.IsEmpty());
    Context::Scope context_scope(context);
    env.reset(new Environment(isolate_data_.get(),
                              context,
                              args_,
                              exec_args_,
                              nullptr,
                              EnvironmentFlags::kDefaultFlags,
                              {}));
#if HAVE_INSPECTOR
    env->InitializeInspector({});
#endif
    if (env->RunBootstrapping().IsEmpty()) {
      return nullptr;
    }
  }

  return env;
}

}  // namespace node
