var a;
a = 123;
b = a + 2;
a = a + b;
