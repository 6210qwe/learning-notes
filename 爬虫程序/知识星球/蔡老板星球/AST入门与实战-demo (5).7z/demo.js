const babel = require('@babel/core');

const code = `
while(1) {
  var a = 2;
  let b = 5;
  const c = 7;
}
var d = 13;
`;

const ast = babel.parse(code, {
  sourceType: 'module',
});

babel.traverse(ast, {
  VariableDeclarator(path) {
    if (path.node.id.name === 'a') {
      let binding = path.scope.getBinding('a');
      if (binding) {
        console.log(`Variable 'a' is a constant: ${binding.constant}`);
      }
      binding = path.scope.getBinding('b');
      if (binding) {
        console.log(`Variable 'b' is a constant: ${binding.constant}`);
      }

      binding = path.scope.getBinding('c');
      if (binding) {
        console.log(`Variable 'c' is a constant: ${binding.constant}`);
      }
      binding = path.scope.getBinding('d');
      if (binding) {
        console.log(`Variable 'd' is a constant: ${binding.constant}`);
      }
    }
  },
});

