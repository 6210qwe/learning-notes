import time
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class FileMonitorHandler(FileSystemEventHandler):
    def on_modified(self, event):
       # print(f'文件 {event.src_path} 已被修改')
       pass

    def on_created(self, event):
        if not event.is_directory:
            if not event.src_path.endswith("_ok.js"):
                print(f'创建了新文件: {event.src_path}')
                os.system(f"node main.js {event.src_path}")

if __name__ == "__main__":
    current_dir = os.path.dirname(__file__)
    event_handler = FileMonitorHandler()
    observer = Observer()
    observer.schedule(event_handler, path=current_dir, recursive=True)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
