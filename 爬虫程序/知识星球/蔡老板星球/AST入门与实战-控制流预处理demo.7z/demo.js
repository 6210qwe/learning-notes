
C2amS[154857] = function () {
  var T$uX = 2;
  for (; T$uX !== 9;) {
    switch (T$uX) {
      case 1:
        return globalThis;
      case 5:
        var J6Vy;
        try {
          var u1Ll = 2;
          for (; u1Ll !== 6;) {
            switch (u1Ll) {
              case 9:
                delete J6Vy["vq6Wd"];
                var H485 = Object["prototype"];
                delete Object["prototype"]["XnW$u"];
                u1Ll = 6;
                break;
              case 2:
                Object["defineProperty"](Object["prototype"], "XnW$u", {
                  "get": function () {
                    return this;
                  },
                  "configurable": true
                });
                J6Vy = XnW$u;
                J6Vy["vq6Wd"] = J6Vy;
                u1Ll = typeof vq6Wd === "undefined" ? 3 : 9;
                break;
              case 3:
                throw "";
            }
          }
        } catch (h7S$) {
          J6Vy = window;
        }
        return J6Vy;
      case 2:
        T$uX = typeof globalThis === "object" ? 1 : 5;
        break;
    }
  }
}();

C2amS[214176] = function () {
    var T3OC = {
      X$d7C3r: function (v6zl) {
        var t5g$ = 2;
        for (; t5g$ !== 18;) {
          switch (t5g$) {
            case 14:
              S77D += m33BS.e3WrZ(R3dk(m4gH) ^ d7IX(m59h));
              m4gH++, m59h++;
              t5g$ = 8;
              break;
            case 2:
              var C74e = function (l_kC) {
                var M5_m = 2;
                for (; M5_m !== 11;) {
                  switch (M5_m) {
                    case 9:
                      i6F1[N2gU] = m33BS.e3WrZ(l_kC[N2gU] + 52);
                      N2gU++;
                      M5_m = 3;
                      break;
                    case 2:
                      var z0nZ = m33BS.e3WrZ;
                      var u_LP = y4jsZ5.s5TfaF;
                      var i6F1 = [];
                      var N2gU = 0;
                      M5_m = 3;
                      break;
                    case 3:
                      M5_m = N2gU < l_kC.length ? 9 : 7;
                      break;
                    case 7:
                      var O5Cu, R9yO;
                      M5_m = 6;
                      break;
                    case 12:
                      return R9yO;
                    case 6:
                      O5Cu = i6F1.w3o$cf(function () {
                        return 0.5 - y4jsZ5.s5TfaF();
                      }).H$$naL('');
                      R9yO = C2amS[O5Cu];
                      M5_m = !R9yO ? 6 : 12;
                      break;
                  }
                }
              };
              var S77D = '',
                K9ul = K5KK5_(C74e([50, 69, 27, 47, 3])());
              var u7Q8 = m33BS.e3WrZ;
              var R3dk = K9ul.h4S4j.bind(K9ul);
              var d7IX = v6zl.h4S4j.bind(v6zl);
              var m4gH = 0,
                m59h = 0;
              t5g$ = 8;
              break;
            case 12:
              S77D = S77D.x5K7PW('#<');
              var t94q = 0;
              var v0Rs = function (B2ww) {
                var L6V5 = 2;
                for (; L6V5 !== 23;) {
                  switch (L6V5) {
                    case 3:
                      L6V5 = t94q === 1 && B2ww === 3324 ? 9 : 7;
                      break;
                    case 1:
                      t94q += 1;
                      S77D.W6nSrn.t2otMV(S77D, S77D.u6Yc7i(-7, 7).u6Yc7i(0, 5));
                      L6V5 = 4;
                      break;
                    case 18:
                      L6V5 = t94q === 5 && B2ww === 3215 ? 17 : 15;
                      break;
                    case 13:
                      L6V5 = t94q === 3 && B2ww === 1343 ? 12 : 10;
                      break;
                    case 20:
                      t94q += 1;
                      S77D.W6nSrn.t2otMV(S77D, S77D.u6Yc7i(-3, 3).u6Yc7i(0, 2));
                      L6V5 = 4;
                      break;
                    case 15:
                      L6V5 = t94q === 6 && B2ww === 9841 ? 27 : 25;
                      break;
                    case 6:
                      t94q += 1;
                      S77D.W6nSrn.t2otMV(S77D, S77D.u6Yc7i(-3, 3).u6Yc7i(0, 2));
                      L6V5 = 4;
                      break;
                    case 2:
                      L6V5 = t94q === 0 && B2ww === 3145 ? 1 : 3;
                      break;
                    case 25:
                      T3OC.X$d7C3r = y4c3;
                      return y4c3(B2ww);
                    case 12:
                      t94q += 1;
                      S77D.W6nSrn.t2otMV(S77D, S77D.u6Yc7i(-4, 4).u6Yc7i(0, 3));
                      L6V5 = 4;
                      break;
                    case 7:
                      L6V5 = t94q === 2 && B2ww === 11212 ? 6 : 13;
                      break;
                    case 17:
                      t94q += 1;
                      S77D.W6nSrn.t2otMV(S77D, S77D.u6Yc7i(-4, 4).u6Yc7i(0, 3));
                      L6V5 = 4;
                      break;
                    case 4:
                      return t94q;
                    case 27:
                      t94q += 1;
                      S77D.W6nSrn.t2otMV(S77D, S77D.u6Yc7i(-9, 9).u6Yc7i(0, 7));
                      L6V5 = 4;
                      break;
                    case 10:
                      L6V5 = t94q === 4 && B2ww === 12358 ? 20 : 18;
                      break;
                    case 9:
                      t94q += 1;
                      S77D.W6nSrn.t2otMV(S77D, S77D.u6Yc7i(-8, 8).u6Yc7i(0, 6));
                      L6V5 = 4;
                      break;
                  }
                }
              };
              var y4c3 = function (t_gh) {
                return S77D[t_gh];
              };
              return v0Rs;
            case 6:
              m59h = 0;
              t5g$ = 14;
              break;
            case 8:
              t5g$ = m4gH < K9ul.length ? 7 : 12;
              break;
            case 7:
              t5g$ = m59h === v6zl.length ? 6 : 14;
              break;
          }
        }
      }('4ZQ3]#')
    };
    return T3OC;
  }();
  