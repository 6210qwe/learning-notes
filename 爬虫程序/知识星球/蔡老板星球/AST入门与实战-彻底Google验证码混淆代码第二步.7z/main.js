﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./encode.js";  //默认的js文件
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");



const constantFold = {//请使用学员专版babel库
    "BinaryExpression|UnaryExpression|MemberExpression|CallExpression"(path) {
        if (path.isUnaryExpression({ operator: "-" }) ||
            path.isUnaryExpression({ operator: "void" })) {
            return;
        }
        const { confident, value } = path.evaluate();
		
        if (!confident || typeof value == "function")
            return;

        if (typeof value == 'number' && (!Number.isFinite(value))) {
            return;
        }

		console.log(path.toString(),"--->",value);

        path.replaceWith(types.valueToNode(value));
    },
}

traverse(ast, constantFold);



const reStoreArrayExpression =
{
	AssignmentExpression(path) {
		let {parentPath, scope, node } = path;
		let { left, operator, right } = node;

		if (!types.isIdentifier(left) || operator != "=" || !types.isArrayExpression(right)) {
			return;
		}

		let { elements } = right;


		if (elements.length != 3 || !elements.every(element => types.isLiteral(element))) {
			return;
		}

		let binding = scope.getBinding(left.name);

		if (!binding) return;

		let { constantViolations, referencePaths } = binding;



		if (constantViolations.length != 1) {
			return;
		}

		let changeEnd = constantViolations[0].node.end;

		let canRemoved = true;
		for (let referPath of referencePaths) {
			let { parentPath, node } = referPath;
			if (!parentPath.isMemberExpression({ "object": node })) {
				canRemoved = false;
				break;
			}

			let { property } = parentPath.node;
			if (!types.isNumericLiteral(property) || property.value > 2) {
				canRemoved = false;
				break;
			}


			if (node.end > changeEnd) {
				parentPath.replaceWith(elements[property.value]);
			}
		}

		if (!canRemoved) {
			return;
		}

		if (parentPath.isExpressionStatement() || parentPath.isSequenceExpression()) {
			console.log(path.toString());
			path.remove();
			return;
		}
	},
	VariableDeclarator(path)
	{
		let {scope, node } = path;
		let { id, init } = node;

		if (!types.isIdentifier(id) || !types.isArrayExpression(init)) {
			return;
		}

		let { elements } = init;


		if (elements.length != 3 || !elements.every(element => types.isLiteral(element))) {
			return;
		}

		let binding = scope.getBinding(id.name);

		if (!binding || !binding.constant) return;

		let {referencePaths } = binding;


		let canRemoved = true;
		for (let referPath of referencePaths) {
			let { parentPath, node } = referPath;
			if (!parentPath.isMemberExpression({ "object": node })) {
				canRemoved = false;
				break;
			}

			let { property } = parentPath.node;
			if (!types.isNumericLiteral(property) || property.value > 2) {
				canRemoved = false;
				break;
			}

			parentPath.replaceWith(elements[property.value]);

		}

		canRemoved && (console.log(path.toString()),path.remove());

	
	}
}

for (let i=0; i<3; i++)
{
	traverse(ast, reStoreArrayExpression);
	ast = parser.parse(generator(ast).code);
}




console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

fs.writeFile(decodeFile, code, (err) => { });