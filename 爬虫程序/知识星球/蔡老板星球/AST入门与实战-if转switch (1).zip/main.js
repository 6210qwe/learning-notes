﻿const files     = require('fs');  //导入文件库，防止与fs变量名冲突
const types     = require("@babel/types");
const parser    = require("@babel/parser");
const template  = require("@babel/template").default;
const traverse  = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath  = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");


const simplifyLiteral = {
	NumericLiteral({ node }) {
	  if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
		node.extra = undefined;
	  }
	},
	StringLiteral({ node }) {
	  if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
		node.extra = undefined;
	  }
	},
  }
  
  traverse(ast, simplifyLiteral);




function collectSwitchCase(ForStatement,name)
{
	let ifNodes = [];
	
	ForStatement.traverse({
			"IfStatement"(path)
			{//遍历所有的ifStatement;
				let {test,consequent,alternate} = path.node; //获取子节点
				
				let {left,operator,right} = test; // 必定是BinaryExpression
				
				if (!types.isIdentifier(left,{name:name}) || operator != '<' || !types.isNumericLiteral(right)) 
				{//条件过滤
					return;
				}

				let value      = right.value;
				
				ifNodes[right.value-1] = consequent.body;   //保存整个body，记得生成switchCase节点的时候加上break节点。
				
				if (!types.isIfStatement(alternate))
				{
					ifNodes[right.value] = alternate.body;  //最后一个else，其实就是上一个else-if 的 test.right的值
				}				
			},
		})
	
	return ifNodes;
} 




const IfToSwitchNode = {
	"ForStatement"(path)
	{
		let {init,test,update,body} = path.node;
		
		if (init != null || test != null || update != null || body.body.length != 1) 
		{//条件过滤
			return;
		}

	
		
		let blockBody = body.body;
		
		if (!types.isIfStatement(blockBody[0]))
		{//条件过滤
			return;
		}

		let prevsibling = path.getPrevSibling();

		if (!prevsibling.isVariableDeclaration())
		{
			return;
		}
		
		
		
		let name = prevsibling.node.declarations[0].id.name;   //变量名
		
		let ifNodes = collectSwitchCase(path,name);   //收集case
		
		if (ifNodes.length == 0) return;   //无case，直接返回。
		
		let len = ifNodes.length;
		
		for (let i=0; i < len; i++)
		{
			ifNodes[i].push(types.BreakStatement());  //每一个case最后都加break
			ifNodes[i] = types.SwitchCase(test = types.valueToNode(i),consequent = ifNodes[i]);  //生成SwitchCase节点
		}
		
		let switchNode = types.SwitchStatement(prevsibling.node.declarations[0].id,ifNodes);   //生成SwitchCase节点
		
		path.node.body.body = [switchNode]; //最后的while节点只有一个Switch Node;
		
	},
}


traverse(ast, IfToSwitchNode);

console.timeEnd("处理完毕，耗时");


let {code} = generator(ast,opts = {jsescOption:{"minimal":true}});

files.writeFile(decodeFile, code, (err) => {});