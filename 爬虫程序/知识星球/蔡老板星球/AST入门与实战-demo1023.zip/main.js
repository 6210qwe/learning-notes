const files     = require('fs');  //导入文件库，防止与fs变量名冲突
const types     = require("@babel/types");
const parser    = require("@babel/parser");
const { callExpression } = require('babel-types');
const template  = require("@babel/template").default;
const traverse  = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath  = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");





function ot(){}
ot.prototype.a = function (a, b) {
	return a + b;
};
ot.prototype.b = function (a, b) {
	return a - b;
};
ot.prototype.c = function (a, b) {
	return a * b;
};
ot.prototype.d = function (a, b) {
	return a / b;
};
ot.prototype.e = function (a, b) {
	return a % b;
};
ot.prototype.f = function (a, b) {
	return Math.pow(a, b);
};
ot.prototype.g = function (a) {
	return Math.sqrt(a);
};
ot.prototype.h = function (a) {
	return Math.sin(a);
};
ot.prototype.i = function (a, b) {
	return a >> b;
};
ot.prototype.j = function (a, b) {
	return a << b;
};
ot.prototype.k = function (a, b) {
	return a & b;
};
ot.prototype.l = function (a, b) {
	return a | b;
};
ot.prototype.m = function (a, b) {
	return a ^ b;
};
ot.prototype.n = function (a) {
	return ~a;
};
ot.prototype.o = function (a, b) {
	return a >>> b;
};
ot.prototype.p = function (a, b) {
	return a << b;
};
ot.prototype.q = function (a, b) {
	return a < b;
};
ot.prototype.r = function (a, b) {
	return a <= b;
};
ot.prototype.s = function (a, b) {
	return a > b;
};
ot.prototype.t = function (a, b) {
	return a >= b;
};
ot.prototype.u = function (a, b) {
	return a == b;
};
ot.prototype.v = function (a, b) {
	return a != b;
};
ot.prototype.w = function (a, b) {
	return a === b;
};
ot.prototype.x = function (a, b) {
	return a !== b;
};
ot.prototype.y = function (a, b) {
	return a && b;
};
ot.prototype.z = function (a, b) {
	return a || b;
};
ot.prototype.aa = function (a) {
	return !a;
};
ot.prototype.ab = function (a, b) {
	return a[b];
};
ot.prototype.ac = function (a, b, c, d) {
	return a(c, d) ? null : b();
};
ot.prototype.ad = function (a) {
	return Number(a);
};
ot.prototype.af = function(a){
	return String.fromCharCode(a);
}
var cv = new ot();

const callToLiteral = 
{
	CallExpression(path)
	{
		let {callee,arguments} = path.node;

		if (!types.isMemberExpression(callee) || callee.object.name != "cv")
		{
			return;
		}

		try
		{
			let value = eval(path.toString());

			if (typeof value == "undefined")
			{
				return;
			}

			console.log(path.toString(),"--->",value);

			path.replaceWith(types.valueToNode(value));
		}catch{};
	},
}

traverse(ast, callToLiteral);


let OpMap = {"a":"+","b":"-","c":"*","d":"/",} //后面的自己添加吧，纯苦力活。


const shiftCallToBin = 
{
	CallExpression(path)
	{
		let {callee,arguments} = path.node;
		if (!types.isMemberExpression(callee) || callee.object.name != "cv" || arguments.length != 2)
		{
			return;
		}
		let name = callee.property.name;

		

		if (!OpMap.hasOwnProperty(name))
		{
			return;
		}

		let operator = OpMap[name];

		switch (name) {
			case "||":
			case "&&":
				path.replaceWith(types.LogicalExpression(operator, arguments[0], arguments[1]));
				break;
			default:
				path.replaceWith(types.BinaryExpression(operator, arguments[0], arguments[1]));
				break;
		}


	}
}

traverse(ast,shiftCallToBin);




const simplifyLiteral = {
	/**  @param  {NodePath} path */  //每个插件前都要加哈。
	NumericLiteral(path) {
		let {node} = path;
		if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
	/**  @param  {NodePath} path */
	StringLiteral(path) {
		let {node} = path;
		if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
}


//traverse(ast, simplifyLiteral);


console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });