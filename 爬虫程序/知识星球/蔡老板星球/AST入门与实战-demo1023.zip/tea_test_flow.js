// // Tiny Encryption Algorithm JS原版及混淆版本
function tea_core(v, k) {
	var TEA_DELTA = 0x9e3779b9;
	var v0 = v[0];
	var v1 = v[1];
	var sum = 0;
	for (var i = 0; i < 32; i++) {
		sum += TEA_DELTA;
		v0 += ((v1 << 4) + k[0]) ^ (v1 + sum) ^ ((v1 >> 5) + k[1]);
		v1 += ((v0 << 4) + k[2]) ^ (v0 + sum) ^ ((v0 >> 5) + k[3]);
	}
	v[0] = v0;
	v[1] = v1;
}
function utf8To32BitArray(str) {
	var utf8 = unescape(encodeURIComponent(str));
	var arr = [];
	for (var i = 0; i < utf8.length; i += 4) {
		arr.push(
			(utf8.charCodeAt(i) << 24) |
			(utf8.charCodeAt(i + 1) << 16) |
			(utf8.charCodeAt(i + 2) << 8) |
			utf8.charCodeAt(i + 3)
		);
	}
	return arr;
}

function btoa(input) {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk1mnopqrstuvwxyz0l23456789+/=';
    var str = '';
    var i = 0;
    while (i < input.length) {
        var byte1 = input.charCodeAt(i++) & 0xff;
        var byte2 = i < input.length ? input.charCodeAt(i++) & 0xff : 0;
        var byte3 = i < input.length ? input.charCodeAt(i++) & 0xff : 0;
        var enc1 = byte1 >> 2;
        var enc2 = ((byte1 & 3) << 4) | (byte2 >> 4);
        var enc3 = ((byte2 & 15) << 2) | (byte3 >> 6);
        var enc4 = byte3 & 63;
        if (isNaN(byte2)) {
            str += chars.charAt(enc1) + chars.charAt(enc2) + '==';
        } else if (isNaN(byte3)) {
            str += chars.charAt(enc1) + chars.charAt(enc2) + chars.charAt(enc3) + '=';
        } else {
            str += chars.charAt(enc1) + chars.charAt(enc2) + chars.charAt(enc3) + chars.charAt(enc4);
        }
    }
    return str;
}

function arrToBase64(arr) {
    var byteArray = new Uint8Array(arr.length * 4);
    arr.forEach((int, index) => {
        byteArray[index * 4] = (int >> 24) & 0xFF;
        byteArray[index * 4 + 1] = (int >> 16) & 0xFF;
        byteArray[index * 4 + 2] = (int >> 8) & 0xFF;
        byteArray[index * 4 + 3] = int & 0xFF;
    });
    var base64String = btoa(String.fromCharCode(...byteArray));
    return base64String;
}

function hexStrToBase64(hex){
	strmap = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	var base64 = '';
	for (var i = 0; i < hex.length / 2; i++) {
		var num = hex.substr(i * 2, 2);
		base64 += strmap[parseInt(num, 16)];
	}
	return base64;
}

function tea(key, plaintext) {
	var k1 = utf8To32BitArray(key);
	var v1 = utf8To32BitArray(plaintext);
	tea_core(v1, k1);
	var d1 = arrToBase64(v1);
	return d1;
}
/******************************分割线 上面是混淆前代码 下面是混淆后代码**************************************/
function me(data) {
	this.data = data ? data : [];
}
me.prototype.a = function (indexOf, value) {
	this.data[indexOf] = value;
};
me.prototype.b = function (indexOf) {
	return this.data[indexOf];
};
function ot(){}
ot.prototype.a = function (a, b) {
	return a + b;
};
ot.prototype.b = function (a, b) {
	return a - b;
};
ot.prototype.c = function (a, b) {
	return a * b;
};
ot.prototype.d = function (a, b) {
	return a / b;
};
ot.prototype.e = function (a, b) {
	return a % b;
};
ot.prototype.f = function (a, b) {
	return Math.pow(a, b);
};
ot.prototype.g = function (a) {
	return Math.sqrt(a);
};
ot.prototype.h = function (a) {
	return Math.sin(a);
};
ot.prototype.i = function (a, b) {
	return a >> b;
};
ot.prototype.j = function (a, b) {
	return a << b;
};
ot.prototype.k = function (a, b) {
	return a & b;
};
ot.prototype.l = function (a, b) {
	return a | b;
};
ot.prototype.m = function (a, b) {
	return a ^ b;
};
ot.prototype.n = function (a) {
	return ~a;
};
ot.prototype.o = function (a, b) {
	return a >>> b;
};
ot.prototype.p = function (a, b) {
	return a << b;
};
ot.prototype.q = function (a, b) {
	return a < b;
};
ot.prototype.r = function (a, b) {
	return a <= b;
};
ot.prototype.s = function (a, b) {
	return a > b;
};
ot.prototype.t = function (a, b) {
	return a >= b;
};
ot.prototype.u = function (a, b) {
	return a == b;
};
ot.prototype.v = function (a, b) {
	return a != b;
};
ot.prototype.w = function (a, b) {
	return a === b;
};
ot.prototype.x = function (a, b) {
	return a !== b;
};
ot.prototype.y = function (a, b) {
	return a && b;
};
ot.prototype.z = function (a, b) {
	return a || b;
};
ot.prototype.aa = function (a) {
	return !a;
};
ot.prototype.ab = function (a, b) {
	return a[b];
};
ot.prototype.ac = function (a, b, c, d) {
	return a(c, d) ? null : b();
};
ot.prototype.ad = function (a) {
	return Number(a);
};
ot.prototype.af = function(a){
	return String.fromCharCode(a);
}
cv = new ot();
function ar(fn) {
	var args = Array.prototype.slice.call(arguments, 1);
	return Promise.resolve().then(function () {
		return fn.apply(null, args);
	});
}
function tc(t1, t2, t3) {
	if (typeof t3 === 'undefined') {
		t3 = cv.ad(cv.aa(cv.aa()));
	}
	if (t3 === cv.ad(cv.aa(cv.aa()))) {
		eg = new me([cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa(cv.aa())), cv.af(120)), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa()))), cv.af(101)), cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa()))), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa()))), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa()))), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa()))), cv.af(98)), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())))), cv.ad(cv.aa(cv.aa())), cv.ad(cv.aa()), cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa()))]);
		gn = cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa()));
		fe = cv.ad(cv.aa(cv.aa()));
	}
	if (cv.t(t3, cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())))) {
		t1[cv.ad(cv.aa(cv.aa()))] = eg.b(gn);
		t1[cv.ad(cv.aa())] = eg.b(cv.a(gn, cv.ad(cv.aa())));
		return Promise.resolve();
	}
	var fl = [function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), gn).then(c => [a, b, c]);
	}, function ([a, b, c, d, e, f]) {
		var e = cv.a(gn, -cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		return ar(eg.b.bind(eg), e).then(f => [a, f, b, c, d]);
	}, function (a) {
		var b = cv.a(gn, cv.ad(cv.aa()));
		return ar(eg.b.bind(eg), b).then(c => [a, c]);
	}, function ([a, b, c, d, e, f]) {
		return Promise.resolve().then(function () {
			t1[cv.ad(cv.aa(cv.aa()))] = eg.b(gn);
			var c = cv.a(gn, cv.ad(cv.aa()));
			t1[cv.ad(cv.aa())] = eg.b(c);
			return tc(t1, t2, cv.a(t3, cv.ad(cv.aa())));
		});
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), cv.a(gn, cv.ad(cv.aa()))).then(c => [a, b, c]);
	}, function ([a, b, c, d, e, f]) {
		var c = cv.j(b, cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		var d = cv.ab(t2, cv.ad(cv.aa(cv.aa())));
		var e = cv.a(c, d);
		var f = cv.a(gn, cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		return ar(eg.a.bind(eg), f, e).then(() => [a, e]);
	}, function (a) {
		fe++;
		return ar(cv.ab, t1, cv.ad(cv.aa())).then(b => [a, b]);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.a.bind(eg), cv.a(gn, fe), d).then(() => [a, b, c]);
	}, function ([a, b, c, d, e, f]) {
		var d = cv.a(gn, cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())));
		return ar(eg.b.bind(eg), d).then(e => [a, b, c, e]);
	}, function ([a, b, c, d, e, f]) {
		var f = cv.a(e, d);
		var g = cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		return ar(eg.a.bind(eg), g, f).then(() => [a, b]);
	}, function ([a, b, c, d, e, f]) {
		fe++;
		return Promise.resolve(cv.ad(cv.aa(cv.aa()))).then(c => [a, b, c]);
	}, function ([a, b, c, d, e, f]) {
		var c = cv.a(a, b);
		var d = cv.a(gn, cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())));
		return ar(eg.a.bind(eg), d, c).then(() => c);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.a.bind(eg), cv.a(gn, fe), b).then(() => [a, b]);
	}, function ([a, b, c, d, e, f]) {
		var d = cv.a(gn, cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())));
		return ar(eg.b.bind(eg), d).then(e => [a, b, c, e]);
	}, function ([a, b, c, d, e, f]) {
		var c = cv.j(b, cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		var d = cv.ab(t2, cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())));
		var e = cv.a(c, d);
		var f = cv.a(gn, cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		return ar(eg.a.bind(eg), f, e).then(() => [a, e]);
	}, function () {
		return ar(cv.ab, t1, cv.ad(cv.aa(cv.aa())));
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), cv.a(gn, cv.ad(cv.aa()))).then(e => [a, b, c, d, e]);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), cv.a(gn, cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())))).then(d => [a, b, c, d]);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), gn).then(e => [a, b, c, d, e]);
	}, function (a) {
		return ar(eg.a.bind(eg), cv.a(gn, fe), a).then(() => a);
	}, function ([a, b, c, d, e, f]) {
		var g = cv.m(d, e);
		var h = cv.m(g, f);
		var i = cv.a(c, h);
		var j = cv.a(gn, cv.ad(cv.aa()));
		return ar(eg.a.bind(eg), j, i).then(() => [a, i]);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())))).then(f => [a, b, c, d, e, f]);
	}, function ([a, b, c, d, e, f]) {
		var d = cv.i(c, cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		var e = cv.ab(t2, cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())));
		var f = cv.a(d, e);
		var g = cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		return ar(eg.a.bind(eg), g, f).then(() => [a, b]);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())))).then(e => [a, b, c, d, e]);
	}, function ([a, b, c, d, e, f]) {
		var d = cv.i(c, cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		var e = cv.ab(t2, cv.ad(cv.aa()));
		var f = cv.a(d, e);
		var g = cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		return ar(eg.a.bind(eg), g, f).then(() => [a, b]);
	}, function ([a, b, c, d, e, f]) {
		var f = cv.a(e, d);
		var g = cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())));
		return ar(eg.a.bind(eg), g, f).then(() => [a, b]);
	}, function ([a, b, c, d, e, f]) {
		var g = cv.m(d, e);
		var h = cv.m(g, f);
		var i = cv.a(c, h);
		return ar(eg.a.bind(eg), gn, i).then(() => [a, i]);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.b.bind(eg), gn).then(c => [a, c]);
	}, function ([a, b, c, d, e, f]) {
		return Promise.all([ar(eg.b.bind(eg), cv.a(gn, cv.ad(cv.aa()))), ar(eg.b.bind(eg), cv.a(gn, cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())))), ar(eg.b.bind(eg), cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())))), ar(eg.b.bind(eg), cv.a(gn, cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa()))))]).then(ae => [a, b, ae[cv.ad(cv.aa(cv.aa()))], ae[cv.ad(cv.aa())], ae[cv.a(cv.ad(cv.aa()), cv.ad(cv.aa()))], ae[cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa()))]]);
	}, function ([a, b, c, d, e, f]) {
		return ar(eg.a.bind(eg), cv.a(gn, fe), c).then(() => [a, b, c]);
	}, function ([a, b, c, d, e, f]) {
		fe++;
		return Promise.resolve(cv.ad(cv.aa(cv.aa()))).then(d => [a, b, c, d]);
	}, function ([a, b, c, d, e, f]) {
		fe++;
		var d = cv.a(gn, cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())));
		return ar(eg.b.bind(eg), d).then(e => [e, a, b, c]);
	}];
	var runlist = [cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa()), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.ad(cv.aa())), cv.a(cv.a(cv.ad(cv.aa()), cv.ad(cv.aa())), cv.ad(cv.aa()))];
	var event = Promise.resolve();
	var i = 0;
	while (i < runlist.length) {
		event = event.then(fl[runlist[i]]);
		i++;
	}
	return event;
}
function tea_async(key, plaintext) {
	var k2 = utf8To32BitArray(key);
	var v2 = utf8To32BitArray(plaintext);
	return tc(v2, k2).then(function () {
		return arrToBase64(v2);
	});
}
// 测试代码
var key = "testkey";
var str1 = '{"cd":[534776073,"Google Inc. (NVIDIA)",0,"iframe",';
var str2 = '[[353,292,441],[-14,-2,8],[-20,0,8],[-20,-1,8],[-22,0,8],[-24,0,8],[-23,0,8],[-19,0,8],[-14,0,8],[-12,0,8],[-8,0,8],[-5,0,8],[-3,0,8],[-3,0,8],[-3,0,9],[-2,-1,7],[-3,0,8],[-4,0,8],[-5,0,8],[-6,0,8],[-2,0,8],[-4,0,8],[-4,0,8],[-3,0,8],[-1,0,8],[-1,0,8],[-1,0,16],[-1,0,24],[-1,0,16],[-3,-2,16],[-1,0,8],[0,0,16],[-3,0,16],[-1,0,8],[-2,0,8],[-2,1,8],[-2,0,8],[-3,1,8],[-2,1,8],[-1,0,8],[-2,0,8],[-2,0,8],[-2,0,8],[-2,1,8],[-2,0,8],[-1,0,8],[-1,0,8],[0,0,8],[-2,0,8],[-1,0,8],[-1,1,18],[-3,1,6],[-2,0,17],[-1,1,7],[-2,1,8],[1,0,136],[5,0,8],[6,0,8],[6,-1,8],[10,-1,8],[1,1,12]]';
var str3 = ',0,"GgoAAAANSUhEUgAAASwAAACWCAYAAAs0MThd3Xn7gFX0ZK46nKuigd4DiPeJDADJ8P4nxW8gAAAABJRU5ErkJggg==",1682247325,1023,1682247323,"https://007.qq.com/online.html",864,12,"https://captcha.gtimg.com/1/template/drag_ele.html?rand=1519713624347","ANGLE (NVIDIA, NVIDIA GeForce RTX 3050 Laptop GPU Direct3D11 vs_5_0 ps_5_0, D3D11)",727763872,1681382692,["zh-CN","zh"],0,1536,24,"98k",0,"1536-864-824-24-*-*-|-*","","+08",[],"Win32",0,1,2,1,"",0,"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36","",[360,360],"UTF-8"],';
var str4 = '"sd":{"od":"C","ft":"qf_7P___H"}}';
// 调用同步的tea加密
var res1 = tea(key, str1) + tea(key, str2) + tea(key, str3) + tea(key, str4);
console.log("混淆前加密结果:", res1);
// 调用异步的tea加密
[str1, str2, str3, str4].reduce(function (promise, str) {
	return promise.then(function (result) {
		return tea_async(key, str).then(function (encrypted) {
			return result + encrypted;
		});
	});
}, Promise.resolve('')).then(function (res2) {
	console.log("混淆后加密结果:", res2);
	console.log("混淆前后结果是否相同: " + (res1 === res2));
});
