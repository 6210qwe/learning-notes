const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const { variableDeclarator } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");

const DeclaratorToDeclaration =
{
	VariableDeclaration(path) {
		let { parentPath, node } = path;
		if (!parentPath.isBlock()) {
			return;
		}
		let { declarations, kind } = node;

		if (declarations.length == 1) {
			return;
		}

		let newNodes = [];

		for (const varNode of declarations) {
			let newDeclartionNode = types.VariableDeclaration(kind, [varNode]);
			newNodes.push(newDeclartionNode);
		}

		path.replaceWithMultiple(newNodes);

	},
}

traverse(ast, DeclaratorToDeclaration);


const varDeclarToFuncDeclar =
{
	VariableDeclaration(path) {
		let { parentPath, node, scope } = path;
		if (!parentPath.isBlock()) {//过滤掉部分特殊情况，例如for循环里的变量定义
			return;
		}
		let { declarations, kind } = node;
		if (declarations.length != 1) {
			return;
		}

		let { id, init } = declarations[0];
		if (!types.isFunctionExpression(init, { id: null })) {
			return;
		}

		let { params, body } = init;
		let newNode = types.FunctionDeclaration(id, params, body);
		path.replaceWith(newNode);
		scope.crawl();
	}
}

traverse(ast, varDeclarToFuncDeclar);




const standardLoop =
{
	"ForStatement|WhileStatement|ForInStatement|ForOfStatement|DoWhileStatement"({ node }) {
		if (!types.isBlockStatement(node.body)) {
			node.body = types.BlockStatement([node.body]);
		}
	},
	IfStatement(path) {
		const consequent = path.get("consequent");
		const alternate = path.get("alternate");
		if (!consequent.isBlockStatement()) {
			consequent.replaceWith(types.BlockStatement([consequent.node]));
		}
		if (alternate.node !== null && !alternate.isBlockStatement()) {
			alternate.replaceWith(types.BlockStatement([alternate.node]));
		}
	},
}

traverse(ast, standardLoop);


const resolveSequence =
{
	SequenceExpression:
	{
		/**  @param  {NodePath} path */
		exit(path) {

			let statementPath = path.getStatementParent();
			if (!statementPath) return;

			let canVisitFlag = true;

			statementPath.traverse({
				"LogicalExpression|ConditionalExpression"(_path) {
					if (!_path.isAncestor(path)) {

						return;
					}

					let key = _path.isLogicalExpression() ? "left" : "test";

					let execPath = _path.get(key);

					if (execPath != path && !execPath.isAncestor(path)) {
						canVisitFlag = false;
						_path.stop();
					}
				},
			})

			if (!canVisitFlag) return;

			if (statementPath.isLoop()) {//循环表达式内的test节点，不能随意插在该表达式前面

				let initPath = statementPath.get('init');

				if (initPath.node == undefined || (initPath != path && !initPath.isAncestor(path))) {
					return
				}
			}

			let expressions = path.node.expressions;
			let lastNode = expressions.pop();

			for (let expression of expressions) {
				statementPath.insertBefore(types.ExpressionStatement(expression = expression));
			}

			path.replaceWith(lastNode);

		}
	}
}

traverse(ast, resolveSequence);


ast = parser.parse(generator(ast).code);



//判断节点是否为字面量，插件地址 https://t.zsxq.com/09CvEE1FY
function isNodeLiteral(node) {
	if (Array.isArray(node)) {
		return node.every(ele => isNodeLiteral(ele));
	}
	if (types.isLiteral(node)) {
		if (node.value == null) {
			return false;
		}
		return true;
	}
	if (types.isBinaryExpression(node)) {
		return isNodeLiteral(node.left) && isNodeLiteral(node.right);
	}
	if (types.isUnaryExpression(node, {
		"operator": "-"
	}) || types.isUnaryExpression(node, {
		"operator": "+"
	})) {
		return isNodeLiteral(node.argument);
	}

	if (types.isObjectExpression(node)) {
		let { properties } = node;
		if (properties.length == 0) {
			return true;
		}

		return properties.every(property => isNodeLiteral(property));

	}
	if (types.isArrayExpression(node)) {
		let { elements } = node;
		if (elements.length == 0) {
			return true;
		}
		return elements.every(element => isNodeLiteral(element));
	}

	return false;
}




function isReferPath(nextSibling, referencePaths) {
	let isReferPath = false;

	for (let referPath of referencePaths) {//假装判断一下，删除也行
		if (nextSibling.isAncestor(referPath)) {
			isReferPath = true;
			break;
		}
	}

	return isReferPath;
}



function isObfuscatorInitArray(path) {//判断是否未ob混淆的特征，对于变种的ob代码，可以更改此代码

	let { parentPath, node } = path;
	let { id, body } = node;
	if (body.body.length < 2) {
		return false;
	}

	let firstNode = body.body.at(0);
	let lastNode = body.body.at(-1);
	if (!types.isVariableDeclaration(firstNode) ||
		!types.isReturnStatement(lastNode)) {
		return false;
	}
	let { init } = firstNode.declarations[0];
	if (!types.isArrayExpression(init) || init.elements.length == 0 ||
		!init.elements.every(element => types.isStringLiteral(element))) {
		return false;
	}

	let binding = parentPath.scope.getBinding(id.name);
	if (!binding) {
		return false;
	}


	let { constantViolations } = binding;

	if (constantViolations.length != 1 || !path.isAncestor(constantViolations[0])) {
		return false;
	}

	return true;
}


function callAndReplaceWith(obfuscatorCode,scope, decodePath) {

	let funcName = decodePath.node.id.name;
	let binding = scope.getBinding(funcName);

	if (!binding) return;

	require = undefined; //防止恶意格盘
	eval(obfuscatorCode);

	let canRemoved = true;

	for (let referPath of binding.referencePaths) {
		if (decodePath.isAncestor(referPath)) {
			continue;
		}

		let { parentPath, node } = referPath;

		if (!parentPath.isCallExpression({ "callee": node })) {
			canRemoved = false;
			continue;
		}

		let { arguments } = parentPath.node;

		if (arguments.length == 0 || !isNodeLiteral(arguments)) {
			canRemoved = false;
			continue;
		}


		let value = eval(parentPath.toString());
		console.log(parentPath.toString(), "-->", value);
		parentPath.replaceWith(types.valueToNode(value));
	}
}


const CallExpressToLiteral =
{
	/**  @param  {NodePath} path */  //每个插件前都要加哈。
	FunctionDeclaration(path) {

		let { parentPath, node } = path;

		if (!isObfuscatorInitArray(path)) {
			return;//如果不是ob混淆的代码，直接退出
		}

		let obfuscatorPaths = [path];

		let scope = parentPath.scope;

		let binding = scope.getBinding(node.id.name);

		if (!binding) return;

		let { referencePaths } = binding;

		let siblingPaths = parentPath.get('body');

		let decodePath = undefined;

		for (let siblingPath of siblingPaths) {
			if (siblingPath == path) {
				continue;
			}
			if (isReferPath(siblingPath, referencePaths)) {
				obfuscatorPaths.push(siblingPath);
				if (siblingPath.isFunctionDeclaration()) {
					decodePath = siblingPath;
				}
			}

		}

		if (obfuscatorPaths.length != 3) {
			return;
		}

		let obfuscatorCode = "";
		obfuscatorPaths.forEach(eachPath => { obfuscatorCode += eachPath.toString() });


		let funcAst = parser.parse(obfuscatorCode);
		obfuscatorCode = generator(funcAst, opts = { "compact": true }).code;


		callAndReplaceWith(obfuscatorCode,scope, decodePath);

	},
}


traverse(ast, CallExpressToLiteral);







const simplifyLiteral = {
	/**  @param  {NodePath} path */  //每个插件前都要加哈。
	NumericLiteral(path) {
		let { node } = path;
		if (node.extra && /^0[obx]/i.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
	/**  @param  {NodePath} path */
	StringLiteral(path) {
		let { node } = path;
		if (node.extra && /\\[ux]/gi.test(node.extra.raw)) {
			node.extra = undefined;
		}
	},
}


traverse(ast, simplifyLiteral);


console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });