const { asmCompile, asmRun } = require('./js2asm');

jscodeTest = `
var request = {
    data: "a=a&b=b&c=c&d=d",
    url: "/api/v2/xxxx/xxxx"
}
var ua = navigator.userAgent;
var string = request.data + request.url + ua;
function myhash(string, goon) {
    var salt = "asm+ollvm+v0.0.1";
    var inputString = string + salt;
    var hash = 0;
    var hashString = '';
    for (var i = 0; i < inputString.length; i++) {
        hash = (hash << 5) - hash + inputString.charCodeAt(i);
        hash = hash & hash;
    }
    hashString = hash.toString(16).split('-').join('');
    if (!goon) {
        for (;hashString.length < 56;) {
            hashString += myhash(hashString, true);
        }
        if (hashString.length > 56) {
            hashString = hashString.substring(0, 56);
        }
    }
    hashString = hashString.split('').reverse().join('');
    return hashString;
}
var sign = myhash(string, '');
console.log(sign);
`

asmCode = asmCompile(jscodeTest);
console.log('编译后结果:');
console.log(asmCode);
console.log('------------------------------------');
navigator = {userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"};
console.log('虚拟机运行结果:');
asmRun(asmCode);
console.log('------------------------------------');
console.log('控制台运行结果:');
eval(jscodeTest);