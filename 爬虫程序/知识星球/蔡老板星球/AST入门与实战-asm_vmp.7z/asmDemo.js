function asmRun(il_langauge) {
    function parseInstructions(instructionString) {
        const lines = instructionString.split('\n');
        const instructions = lines.map(line => {
            let [op, ...args] = line.split(' ');
            switch (op) {
                case 'PUSH':
                    args = [args.join(' ')];
                    break;
                case 'OBJECT':
                    args = [args[0].split(',')]
                    break;
                case 'FUNC':
                    args = args[0].split(',');
                    args[1] = args.slice(1);
                    args.splice(2);
            }
            function switchToNumber(arg) {
                if (Array.isArray(arg)) {
                    return arg.map(switchToNumber);
                } else if (typeof arg === 'string' && arg.startsWith('vm0xi')) {
                    return parseInt(arg.slice(5), 16);
                } else {
                    return arg;
                }
            }
            args = args.map(switchToNumber);
            return { op, args };
        });
        return instructions;
    }
    function run_zhiling(il_zhiling, functions = {}, localVars = globalThis) {
        const stack = [];
        const variables = globalThis;
        let ip = 0;
    
        while (ip < il_zhiling.length) {
            const instr = il_zhiling[ip];
            switch (instr.op) {
                case 'VAR':
                    localVars[instr.args[0]] = 0;
                    break;
                case 'PUSH':
                    stack.push(instr.args[0]);
                    break;
                case 'STORE':
                    localVars[instr.args[0]] = stack.pop();
                    break;
                case 'LOAD':
                    stack.push(localVars[instr.args[0]]);
                    break;
                case 'ADD':
                    right = stack.pop();
                    left = stack.pop();
                    stack.push(left + right);
                    break;
                case 'SUB':
                    const subtrahend = stack.pop();
                    const minuend = stack.pop();
                    stack.push(minuend - subtrahend);
                    break;
                case 'CALL':
                    switch (instr.args[0]) {
                        case 'log':
                            stack.pop()
                            console.log(stack.pop());
                            break;
                        case 'charCodeAt':
                            stack.push(stack.pop().charCodeAt(stack.pop()));
                            break;
                        case 'toString':
                            stack.push(stack.pop().toString(stack.pop()));
                            break;
                        case 'split':
                            stack.push(stack.pop().split(stack.pop()));
                            break;
                        case 'join':
                            stack.push(stack.pop().join(stack.pop()));
                            break;
                        case 'reverse':
                            stack.push(stack.pop().reverse());
                            break;
                        case 'substring':
                            str = stack.pop();
                            end = stack.pop();
                            start = stack.pop();
                            stack.push(str.substring(start, end));
                            break;
                        default:
                            if (functions[instr.args[0]]) {
                                const func = functions[instr.args[0]];
                                const args = [];
                                for (let i = 0; i < func.params.length; i++) {
                                    args.push(stack.pop());
                                }
                                const newLocalVars = {};
                                for (const varName in localVars) {
                                    newLocalVars[varName] = localVars[varName];
                                }
                                for (let i = 0; i < func.params.length; i++) {
                                    newLocalVars[func.params[i]] = args.pop();
                                }
                                stack.push(run_zhiling(func.body, functions, newLocalVars));
                            } else {
                                throw new Error(`Unsupported function: ${instr.args[0]}`);
                            }
                    }
                    break;
                case 'FUNC':
                    functions[instr.args[0]] = { params: instr.args[1], body: [] };
                    while (il_zhiling[++ip].op !== 'ENDFUNC') {
                        functions[instr.args[0]].body.push(il_zhiling[ip]);
                    }
                    break;
                case 'OBJECT':
                    const obj = {};
                    arg_len = instr.args[0].length;
                    for (let i = 0; i < arg_len; i++) {
                        obj[instr.args[0].pop()] = stack.pop();
                    }
                    stack.push(obj);
                    break;
                case 'JMP':
                    ip += instr.args[0];
                    break;
                case 'JMP_IF_FALSE':
                    if (!stack.pop()) {
                        ip += instr.args[0] - 1;
                    }
                    break;
                case 'INC':
                    localVars[instr.args[0]]++;
                    break;
                case 'UNARY':
                    const arg = stack.pop();
                    switch (instr.args[0]) {
                        case '-':
                            stack.push(-arg);
                            break;
                        case '+':
                            stack.push(+arg);
                            break;
                        case '!':
                            stack.push(!arg);
                            break;
                        case '~':
                            stack.push(~arg);
                            break;
                        default:
                            throw new Error(`Unsupported unary operator: ${instr.args[0]}`);
                    }
                    break;
                case 'LOAD_MEMBER':
                    stack.push(stack.pop()[instr.args[0]]);
                    break;
                case 'LT':
                    const b = stack.pop();
                    const a = stack.pop();
                    stack.push(a < b);
                    break;
                case 'SHL':
                    const shiftAmount = stack.pop();
                    const value = stack.pop();
                    stack.push(value << shiftAmount);
                    break;
                case 'ANDB':
                    const andbRight = stack.pop();
                    const andbLeft = stack.pop();
                    stack.push(andbLeft & andbRight);
                    break;
                case 'RETURN':
                    return stack.pop();
                case 'GT':
                    const gtRight = stack.pop();
                    const gtLeft = stack.pop();
                    stack.push(gtLeft > gtRight);
                    break;
                case 'ENDFUNC':
                    break;
                default:
                    throw new Error(`Unsupported operation: ${instr.op}`);
            }
            ip++;
        }
    }
    let op_list = parseInstructions(il_langauge);
    return run_zhiling(op_list);
}

jsCode = `var request = {
    data: "a=a&b=b&c=c&d=d",
    url: "/api/v2/xxxx/xxxx"
}
var ua = navigator.userAgent;
var string = request.data + request.url + ua;
function myhash(string, goon) {
    var salt = "asm_v0.0.1_未混淆版本";
    var inputString = string + salt;
    var hash = 0;
    var hashString = '';
    for (var i = 0; i < inputString.length; i++) {
        hash = (hash << 5) - hash + inputString.charCodeAt(i);
        hash = hash & hash;
    }
    hashString = hash.toString(16).split('-').join('');
    if (!goon) {
        for (;hashString.length < 56;) {
            hashString += myhash(hashString, true);
        }
        if (hashString.length > 56) {
            hashString = hashString.substring(0, 56);
        }
    }
    hashString = hashString.split('').reverse().join('');
    return hashString;
}
var sign = myhash(string, '');
console.log(sign);`

asmCode = `VAR request
PUSH a=a&b=b&c=c&d=d
PUSH /api/v2/xxxx/xxxx
OBJECT data,url
STORE request
VAR ua
LOAD navigator
LOAD_MEMBER userAgent
STORE ua
VAR string
LOAD request
LOAD_MEMBER data
LOAD request
LOAD_MEMBER url
ADD 
LOAD ua
ADD 
STORE string
FUNC myhash,string,goon
VAR salt
PUSH asm_v0.0.1_未混淆版本
STORE salt
VAR inputString
LOAD string
LOAD salt
ADD 
STORE inputString
VAR hash
PUSH vm0xi0
STORE hash
VAR hashString
PUSH 
STORE hashString
VAR i
PUSH vm0xi0
STORE i
LOAD i
LOAD inputString
LOAD_MEMBER length
LT 
JMP_IF_FALSE vm0xi12
LOAD hash
PUSH vm0xi5
SHL 
LOAD hash
SUB 
LOAD i
LOAD inputString
CALL charCodeAt
ADD 
STORE hash
LOAD hash
LOAD hash
ANDB 
STORE hash
LOAD i
INC i
JMP vm0xi-16
PUSH 
PUSH -
PUSH vm0xi10
LOAD hash
CALL toString
CALL split
CALL join
STORE hashString
LOAD goon
UNARY !
JMP_IF_FALSE vm0xi17
LOAD hashString
LOAD_MEMBER length
PUSH vm0xi38
LT 
JMP_IF_FALSE vm0xi8
LOAD hashString
LOAD hashString
PUSH true
CALL myhash
ADD 
STORE hashString
JMP vm0xi-c
LOAD hashString
LOAD_MEMBER length
PUSH vm0xi38
GT 
JMP_IF_FALSE vm0xi6
PUSH vm0xi0
PUSH vm0xi38
LOAD hashString
CALL substring
STORE hashString
PUSH 
PUSH 
LOAD hashString
CALL split
CALL reverse
CALL join
STORE hashString
LOAD hashString
RETURN 
ENDFUNC myhash
VAR sign
LOAD string
PUSH 
CALL myhash
STORE sign
LOAD sign
LOAD console
CALL log`

navigator = {userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"};
console.log('虚拟机运行结果:');
asmRun(asmCode);
console.log('------------------------------------');
console.log('控制台运行结果:');
eval(jsCode);