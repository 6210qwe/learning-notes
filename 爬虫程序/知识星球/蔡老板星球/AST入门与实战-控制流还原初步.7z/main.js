const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const t         = require("@babel/types");
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");

const addBreakStatement = 
{
	SwitchCase(path)
	{
		let {consequent} = path.node;
		if (!types.isBreakStatement(consequent[consequent.length-1]))
		{
			consequent.push(t.BreakStatement());
		}
	}
}

traverse(ast, addBreakStatement);


const findSingleCase =
{
	/**  @param  {NodePath} path */  
	ForStatement(path) {
		let { body } = path.node;

		if (body.body.length != 1 || !types.isSwitchStatement(body.body[0])) {
			return;
		}

		let { cases } = body.body[0];

		if (cases.length != 1) {
			return;
		}

		let prevSibing = path.getPrevSibling();

		let stopValue = prevSibing.node.declarations[0].init.value;

		let {consequent} = cases[0];

		consequent.pop();

		if (!types.isReturnStatement(consequent.at(-1)))
		{
			consequent.pop();
		}
		

		path.replaceWithMultiple(consequent);

		prevSibing.remove();
		

	}
}


traverse(ast,findSingleCase);



function getItemFromTestValue(path, number)
{
	let {cases} = path.node;
	for (let index =0; index<cases.length;index++)
	{
		let item = cases[index];
		if (item.test.value == number)
		{
			return [item,index];
		}
	}
}


function getPrevItemCounts(path, number)
{
	let counts = 0;
	let {cases} = path.node;
	
	for (let i=0; i<cases.length;i++)
	{
		let item = cases[i];
		let {test,consequent} = item;
		let len = consequent.length;
		if (!t.isExpressionStatement(consequent[len - 2])) 
		{
			continue;
		}
	  let {right} = consequent[len - 2].expression;
	  if (t.isNumericLiteral(right,{value:number}))
	  {
	  	counts++;
	  	continue;
	  }
	  if (t.isConditionalExpression(right))
	  {
	  	if (right.consequent.value == number || 
	  	    right.alternate.value  == number)
	  	{
	  		counts++;
	  	}
	  }
	}

	return counts;
}


function isCombinCases(path,item,countsMap)
{
	let {test,consequent} = item;
	let len = consequent.length;
	let {left,operator,right} = consequent[len-2].expression;
	
	let nextNumber = right.value;
	
	let counts = countsMap.get(nextNumber);
	
	if (counts == 1)
	{
		let data = getItemFromTestValue(path, nextNumber);
		let nextItem = data[0];
		consequent.splice(consequent.length - 2, 2);
		consequent.push(...nextItem.consequent);
		
		path.node.cases.splice(data[1], 1);
		countsMap.set(nextNumber,0);
		
		return true;
	}
	
	return false;
}


function savePrevsCountsToMap(path)
{
	let countsMap = new Map();
	let {cases} = path.node;
	for (const singleCase of cases)
	{
		let {test} = singleCase;
		if (test == undefined)
		{
			continue;
		}
		let value = test.value;
		let prevItemCounts = getPrevItemCounts(path, value);
		countsMap.set(value,prevItemCounts);
	}
	
	return countsMap;
}

const dealWithSwitch = 
{
	SwitchStatement(path)
	{
		
		let {scope,node} = path;

		if (!types.isIdentifier(node.discriminant))
		{
			return;
		}
		
		let countsMap = savePrevsCountsToMap(path);

		if (countsMap.size != path.node.cases.length)
		{
			return;
		}

		for (let i=0; i < path.node.cases.length;i++)
		{
			let item = path.node.cases[i];
			let {test,consequent} = item;
			
			let len = consequent.length;
			if (!t.isExpressionStatement(consequent[len-2]))
			{//过滤掉return语句
				continue;
			}
			
			let {left,operator,right} = consequent[len-2].expression;

			if (t.isNumericLiteral(right))
			{
				if (isCombinCases(path,item,countsMap))
				{
					i = -1;
					continue;
				}
			}
		}
	},
}


traverse(ast, dealWithSwitch);




console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
	"compact": false,  // 是否压缩代码
	"comments": false,  // 是否保留注释
	"jsescOption": { "minimal": true },  //Unicode转义
});

files.writeFile(decodeFile, code, (err) => { });