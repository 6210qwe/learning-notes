﻿const fs = require('fs');
const types = require("@babel/types");
const parser = require("@babel/parser");
const { callExpression } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;


//js混淆代码读取
process.argv.length > 2 ? encodeFile = process.argv[2] : encodeFile = "./step2.js";  //默认的js文件
process.argv.length > 3 ? decodeFile = process.argv[3] : decodeFile = "./step3.js";

//将源代码解析为AST
let sourceCode = fs.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");

/***************************************************************

let enObj = TT; //这里的TT需要修改

let deObj = new Object();

for (let key of Object.keys(enObj)) {
    try {
        deObj[key] = enObj[key].apply(null,);
    } catch { }
}

copy(JSON.stringify(deObj))


 ****************************************************************/





let enObjName = ""; //复制网站上的object名称
let deObj = ;//上面的代码在控制台运行后，复制到这里。

const callToStringLiteral =
{
    CallExpression(path) {
        let { callee } = path.node;

        if (!types.isMemberExpression(callee)) {
            return;
        }

        let { object, property, compute } = callee;

        if (types.isIdentifier(object, { "name": enObjName })) {
            let proName = compute ? property.value : property.name;

            if (deObj.hasOwnProperty(proName)) {
                console.log(path.toString(),"-->",deObj[proName]);
                path.replaceWith(types.valueToNode(deObj[proName]));
                return;
            }
        }

        if (types.isMemberExpression(object)) {
            let proName = compute ? property.value : property.name;
            if (!['apply', "call"].includes(proName)) {
                return;
            }

            if (object.object.name == enObjName) {
                let proName = object.compute ? object.property.value : object.property.name;
                if (deObj.hasOwnProperty(proName)) {
                    
                    path.replaceWith(types.valueToNode(deObj[proName]));
                    return;
                }
            }
        }
    }
}


traverse(ast,callToStringLiteral);




console.timeEnd("处理完毕，耗时");
let { code } = generator(ast, opts = {
    "compact": false,  // 是否压缩代码
    "comments": false,  // 是否保留注释
    "jsescOption": { "minimal": true },  //Unicode转义
});

fs.writeFile(decodeFile, code, (err) => { });