tD > 43 && (tD += xM.length > 42 ? 8 : -42, !0) || 42 < tD-- && (tD += iW.length < 32 ? -29 : 30, !undefined) || (41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1)) && (tD < 40 || ((nD = 0, tD += 26), "")) && (tD -= wK.length < 32 ? 10 : -10);

分割1-- ->

if (tD > 43 && (tD += xM.length > 42 ? 8 : -42, !0) || 42 < tD-- && (tD += iW.length < 32 ? -29 : 30, !undefined)) { }

else {
    (41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1)) && (tD < 40 || ((nD = 0, tD += 26), "")) && (tD -= wK.length < 32 ? 10 : -10);
}

分割2-- ->

if (tD > 43 && (tD += xM.length > 42 ? 8 : -42, !0)) { }
else if (42 < tD-- && (tD += iW.length < 32 ? -29 : 30, !undefined)) { }

else {
    (41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1)) && (tD < 40 || ((nD = 0, tD += 26), "")) && (tD -= wK.length < 32 ? 10 : -10);
}


分割3-- ->

if (tD > 43) { (tD += xM.length > 42 ? 8 : -42, !0); }
else if (42 < tD-- && (tD += iW.length < 32 ? -29 : 30, !undefined)) { }

else {
    (41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1)) && (tD < 40 || ((nD = 0, tD += 26), "")) && (tD -= wK.length < 32 ? 10 : -10);
}

分割4-- ->


if (tD > 43) { (tD += xM.length > 42 ? 8 : -42, !0); }
else if (42 < tD--) { (tD += iW.length < 32 ? -29 : 30, !undefined); }

else {
    (41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1)) && (tD < 40 || ((nD = 0, tD += 26), "")) && (tD -= wK.length < 32 ? 10 : -10);
}

分割5-- ->

if (tD > 43) { (tD += xM.length > 42 ? 8 : -42, !0); }
else if (42 < tD--) { (tD += iW.length < 32 ? -29 : 30, !undefined); }

else {
    if ((41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1)) && (tD < 40 || ((nD = 0, tD += 26), ""))) {
        (tD -= wK.length < 32 ? 10 : -10);
    }
}

分割6-- ->

if (tD > 43) { (tD += xM.length > 42 ? 8 : -42, !0); }

else if (42 < tD--) { (tD += iW.length < 32 ? -29 : 30, !undefined); }

else {
    if ((41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1))) {
        if ((tD < 40 || ((nD = 0, tD += 26), ""))) {
            (tD -= wK.length < 32 ? 10 : -10);
        }
    }
}

分割7-- ->

if (tD > 43) { (tD += xM.length > 42 ? 8 : -42, !0); }

else if (42 < tD--) { (tD += iW.length < 32 ? -29 : 30, !undefined); }

else {
    if ((41 > tD || (tD += "".indexOf.prototype ? 5 : 2, !1))) {
        if (tD < 40) {
            tD -= wK.length < 32 ? 10 : -10;
        }
        else {
            nD = 0, tD += 26;
        }
    }
}

分割8-- ->

if (tD > 43) { (tD += xM.length > 42 ? 8 : -42, !0); }

else if (42 < tD--) { (tD += iW.length < 32 ? -29 : 30, !undefined); }

else {
    if (41 > tD) {
        if (tD < 40) {
            tD -= wK.length < 32 ? 10 : -10;
        }
        else {
            nD = 0, tD += 26;
        }
    }
    else {
        tD += "".indexOf.prototype ? 5 : 2;
    }
}