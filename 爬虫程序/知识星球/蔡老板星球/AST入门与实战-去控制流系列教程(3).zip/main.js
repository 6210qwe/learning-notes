﻿const files = require('fs');  //导入文件库，防止与fs变量名冲突
const types = require("@babel/types");
const parser = require("@babel/parser");
const { switchStatement, assignmentExpression, ifStatement, variableDeclarator, forStatement } = require('babel-types');
const template = require("@babel/template").default;
const traverse = require("@babel/traverse").default;
const generator = require("@babel/generator").default;
const NodePath = require("@babel/traverse").NodePath; //智能提示所需

//js混淆代码读取
const encodeFile = process.argv.length > 2 ? process.argv[2] : "./encode.js";  //默认的js文件
const decodeFile = process.argv.length > 3 ? process.argv[3] : encodeFile.slice(0, encodeFile.length - 3) + "_ok.js";


//将源代码解析为AST
let sourceCode = files.readFileSync(encodeFile, { encoding: "utf-8" });
let ast = parser.parse(sourceCode);
console.time("处理完毕，耗时");



const changeInitNode =
{
	VariableDeclarator(path) {
		let { node, parentPath } = path;

		let { id, init } = node;

		if (!types.isLogicalExpression(init)) {
			return;
		}

		let { left, operator, right } = init;

		if (!types.isIdentifier(left, { "name": "d" }) || operator != "||" || !types.isNumericLiteral(right)) {
			return;
		}

		let nextSibling = parentPath.getNextSibling();

		if (nextSibling == null || !nextSibling.isForStatement()) {
			return;
		}


		path.node.init = right;

	}
}


traverse(ast, changeInitNode);

const combinEmptyCase =
{
	SwitchStatement(path) {
		let { cases, discriminant } = path.node;

		if (!types.isIdentifier(discriminant)) {
			return;
		}

		let name = discriminant.name;

		for (let i = 0; i < cases.length; i++) {
			let { test, consequent } = cases[i];

			if (!types.isNumericLiteral(test) || consequent.length != 2 || !types.isExpressionStatement(consequent[0]) || !types.isAssignmentExpression(consequent[0].expression)) {
				continue;
			}

			let testValue = test.value;

			let { left, operator, right } = consequent[0].expression;

			if (!types.isIdentifier(left, { "name": name }) || operator != "=" || !types.isNumericLiteral(right)) {
				continue;
			}

			let nextValue = right.value;

			for (let j = 0; j < cases.length; j++) {
				
				if (j == i) {
					continue;
				}

				let { consequent } = cases[j];

				if (!types.isExpressionStatement(consequent.at(-2)) || !types.isAssignmentExpression(consequent.at(-2).expression)) {
					continue;
				}

				let { left, operator, right } = consequent.at(-2).expression;

				if (!types.isIdentifier(left, { "name": name }) || operator != "=") {
					continue;
				}

				if (types.isNumericLiteral(right, { "value": testValue })) {
					cases[j].consequent[consequent.length - 2].expression.right.value = nextValue;
					continue;
				}
				if (types.isConditionalExpression(right)) {
					if (right.consequent.value == testValue) {
						cases[j].consequent[consequent.length - 2].expression.right.consequent.value = nextValue;
					}
					if (right.alternate.value == testValue) {
						cases[j].consequent[consequent.length - 2].expression.right.alternate.value = nextValue;
					}
					continue;
				}




			}


		}





	}
}


traverse(ast, combinEmptyCase);


function getItemFromTestValue(path, number) {
	let { cases } = path.node;
	for (let index = 0; index < cases.length; index++) {
		let item = cases[index];
		if (item.test.value == number) {
			return item;
		}
	}
}

function getPrevItemCounts(path, number) {
	let counts = 0;
	let { cases } = path.node;

	for (let i = 0; i < cases.length; i++) {
		let item = cases[i];
		let { test, consequent } = item;
		let len = consequent.length;
		if (!types.isExpressionStatement(consequent[len - 2])) {
			continue;
		}
		let { right } = consequent[len - 2].expression;
		if (types.isNumericLiteral(right, { value: number })) {
			counts++;
			continue;
		}
		if (types.isConditionalExpression(right)) {
			if (right.consequent.value == number ||
				right.alternate.value == number) {
				counts++;
			}
		}
	}

	return counts;
}



const removeEmptySwitchCase =
{

	ForStatement(path) {
		let { init, test, update, body } = path.node;

		if (init != null || test != null || update != null || body.body.length != 1 ||
			!types.isSwitchStatement(body.body[0])) {
			return;
		}
		let PrevSibling = path.getPrevSibling();

		if (!PrevSibling.isVariableDeclaration()) {
			return;
		}

		if (!types.isNumericLiteral(PrevSibling.node.declarations[0].init)) {
			return;
		}

		let initValue = PrevSibling.node.declarations[0].init.value;

		let switchPath = path.get('body.body.0');

		

		for (let i = 0; i < switchPath.node.cases.length; i++) {

			let item = switchPath.node.cases[i];

			let { test, consequent } = item;

			let value = test.value;



			if (value == initValue) {
				continue;
			}

			let count = getPrevItemCounts(switchPath, value);

			if (count == 0) {
				switchPath.node.cases.splice(i, 1);
				i = -1;
				continue;
			}


		}


	}

}

ast = parser.parse(generator(ast).code);

traverse(ast, removeEmptySwitchCase);





console.timeEnd("处理完毕，耗时");


let { code } = generator(ast, opts = { jsescOption: { "minimal": true } });

files.writeFile(decodeFile, code, (err) => { });