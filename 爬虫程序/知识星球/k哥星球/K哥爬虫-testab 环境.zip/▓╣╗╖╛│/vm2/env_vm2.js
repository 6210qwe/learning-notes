const {VM, VMScript} = require("vm2");
const fs = require('fs');
const vm = new VM()

var code = fs.readFileSync('./enviroment.js')
code += fs.readFileSync('./code.js')

debugger;

function get_encrypt() {
    var res = vm.run(code)
    console.log(res)
    return res
}

get_encrypt();
debugger;