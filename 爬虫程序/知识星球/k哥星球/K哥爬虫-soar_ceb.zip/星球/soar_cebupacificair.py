import re
import json
import httpx
import subprocess


class MySubprocessPopen(subprocess.Popen):
    def __init__(self, *args, **kwargs):
        # 在调用父类（即 subprocess.Popen）的构造方法时，将 encoding 参数直接置为 UTF-8 编码格式
        super().__init__(encoding='UTF-8', *args, **kwargs)


subprocess.Popen = MySubprocessPopen
import execjs
from loguru import logger
from curl_cffi import requests

with open('v2AccessToken.js', 'r', encoding='utf-8') as f:
    js = execjs.compile(f.read())


class CebupacificAir:
    def __init__(self):
        self.session = requests.Session(impersonate="chrome110")
        self.headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "cache-control": "no-cache",
            "pragma": "no-cache",
            "priority": "u=0, i",
            "referer": "https://www.cebupacificair.com/",
            "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"128\", \"Edge\";v=\"128\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "same-origin",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/128.0.0.0"
        }
        self.proxies = None

    def first_html(self):
        url = "https://www.cebupacificair.com/en-PH/"
        response = self.session.get(url, headers=self.headers, proxies=self.proxies)
        __eccha_str = re.findall(r'var val = (.*?);', response.text)[0]
        __ecbmchid = re.findall(r'__ecbmchid=(.*?)\"', response.text)[0]
        __eccha = execjs.eval(__eccha_str)
        logger.info(__eccha)
        logger.info(__ecbmchid)

        cookies = {
            '__eccha': str(__eccha),
            '__ecbmchid': __ecbmchid
        }

        self.session.cookies.update(cookies)

    def second_html(self):
        url = "https://www.cebupacificair.com/en-PH/"
        response = self.session.get(url, headers=self.headers, proxies=self.proxies)
        logger.info(response.status_code)

    def get_main_js_name(self):
        url = "https://www.cebupacificair.com/"
        response = self.session.get(url, headers=self.headers, proxies=self.proxies)
        main_js_name = re.findall(r'<script src="main.(.*?).js" type="module">', response.text)[0]
        logger.info(main_js_name)
        return main_js_name

    def get_v2_access_token_contents(self, main_js_name):
        url = f"https://www.cebupacificair.com/main.{main_js_name}.js"
        response = self.session.get(url, headers=self.headers)

        park = re.findall(r'PARK:"(.*)",SECR', response.text)[0]
        secr = re.findall(r'SECR:"(.*)",XAT', response.text)[0]
        xat = re.findall(r'XAT:"(.*)"};var', response.text)[0]

        v2_access_token_contents = js.call('get_v2_accessToken_contents', secr, xat, park)
        logger.info(v2_access_token_contents)
        return v2_access_token_contents, park, xat

    def ceb_omnix_proxy(self, v2_access_token_contents, park, xat):
        cookies = self.session.cookies.get_dict()
        headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "authorization": "Bearer " + xat,
            "cache-control": "no-cache",
            "content": v2_access_token_contents['headers_content'],
            "content-type": "application/json",
            "origin": "https://www.cebupacificair.com",
            "pragma": "no-cache",
            "priority": "u=1, i",
            "referer": "https://www.cebupacificair.com/",
            "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"128\", \"Edge\";v=\"128\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "uniqueid": v2_access_token_contents['uniqueid'],
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/128.0.0.0"
        }
        url = "https://soar.cebupacificair.com/ceb-omnix_proxy"
        data = {
            "content": v2_access_token_contents['body_content']
        }
        with httpx.Client(proxies=self.proxies) as client:
            data = json.dumps(data, separators=(',', ':'))
            # 发送 POST 请求
            response = client.post(url, headers=headers, content=data, cookies=cookies)

        status = response.status_code
        if status == 403:
            logger.info(response.status_code)
            logger.info(response.text)
        else:
            v2_accessToken_res = response.json()
            logger.debug(v2_accessToken_res)
            authorization = v2_accessToken_res['Authorization']
            xAuthToken = v2_accessToken_res['X-Auth-Token']

            body = {
                "ssrs": [],
                "routes": [
                    {
                        "origin": "HKG",
                        "destination": "MEL",
                        "beginDate": "10/28/2024",
                        "daysToLeft": 6,
                        "daysToRight": 0
                    }
                ],
                "daysToLeft": 6,
                "daysToRight": 0,
                "adultCount": 1,
                "childCount": 0,
                "infantCount": {
                    "lap": 0,
                    "seat": 0
                },
                "promoCode": "",
                "currency": "HKD",
                "version": 2,
                "lffMode": False,
                "rebook": False
            }

            availability_contents = js.call('get_availability_contents', authorization, xAuthToken, park, body)
            logger.info(availability_contents)

            headers = {
                "accept": "application/json, text/plain, */*",
                "accept-language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
                "authorization": "Bearer " + authorization,
                "cache-control": "no-cache",
                "content": availability_contents['headers_content'],
                "content-type": "application/json",
                "origin": "https://www.cebupacificair.com",
                "pragma": "no-cache",
                "priority": "u=1, i",
                "referer": "https://www.cebupacificair.com/",
                "sec-ch-ua": "\"Chromium\";v=\"130\", \"Google Chrome\";v=\"130\", \"Not?A_Brand\";v=\"99\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-site",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
                "x-auth-token": xAuthToken
            }

            url = "https://soar.cebupacificair.com/ceb-omnix_proxy"
            data = {
                "content": availability_contents['body_content']
            }
            with httpx.Client(proxies=self.proxies) as client:
                data = json.dumps(data, separators=(',', ':'))
                # 发送 POST 请求
                response = client.post(url, headers=headers, content=data, cookies=cookies)
                logger.success(response.text)

    def main(self):
        self.first_html()
        self.second_html()
        main_js_name = self.get_main_js_name()
        v2_access_token_contents, park, xat = self.get_v2_access_token_contents(main_js_name)
        self.ceb_omnix_proxy(v2_access_token_contents, park, xat)


if __name__ == '__main__':
    CebupacificAir().main()
