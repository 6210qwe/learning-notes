import re
import execjs
import requests
from loguru import logger


def run_js(js, func_name):
    t = {
        'config': {}
    }
    n = {
    }
    try:
        context = execjs.compile(js)
        result = context.call(func_name, t, n)
        return True, result
    except Exception as e:
        logger.error(e)
        func3_name = re.findall('ReferenceError: (.*?) is not defined', str(e))[0]
        if func3_name == 'dispatchEvent':
            return False, js.replace('dispatchEvent', '1')
        else:
            func3 = "function " + func3_name + "(){return \"\"}"
            return False, func3 + js


def get_js(StaticPath):
    headers = {
        "sec-ch-ua": "\"Chromium\";v=\"128\", \"Not;A=Brand\";v=\"24\", \"Google Chrome\";v=\"128\"",
        "sec-ch-ua-mobile": "?0",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "sec-ch-ua-platform": "\"Windows\""
    }
    print("StaticPath:", StaticPath)
    url = f"https://g.alicdn.com/captcha-frontend/dynamicJS/{StaticPath}.js"
    response = requests.get(url, headers=headers)
    with open('static.js', 'w', encoding='utf-8') as f:
        f.write(response.text)
    func1, func2 = re.findall('18,0,0],\w}\(\)\);function (.*?)function (.*?)function ', response.text)[0]
    func1 = 'function ' + func1
    func2 = 'function ' + func2

    func2_name = re.findall('function (.*?)\(', func2)[0]
    test_list = re.findall('(\w)\[.*?\]=', func2)
    js = "window=global;" + func1 + func2
    while True:
        test, result = run_js(js, func2_name)
        if test:
            break
        else:
            js = result

    for var in test_list:
        js = list(js)
        js[-2] = var
        js = ''.join(js)
        test, result = run_js(js, func2_name)
        if type(result) != dict:
            continue
        key = result.get('key')
        if key:
            return key

    # try:
    #     result = re.findall('1,1,1,4,7,0,0];function(.*?)\);function', response.text)[0]
    #     run_js = 'function' + result + ')'
    #     var_name = re.findall('\),(\w+)=', run_js)[0]
    #     print('var_name:', var_name)
    #     over_js = r'function result() {' + run_js + ' ;return ' + var_name + ' }'
    #     context = execjs.compile(over_js)
    #     info = context.call('result')
    # except Exception as e:
    #     result = re.findall('1,1,1,4,7,0,0];function(.*?)\)}function', response.text)[0]
    #     run_js = 'function' + result + ')' + '}'
    #     var_name = re.findall('\),(\w+)=', run_js)[0]
    #     print('var_name:', var_name)
    #     over_js = r'function result() {' + run_js + ' ;return ' + var_name + ' }'
    #     context = execjs.compile(over_js)
    #     info = context.call('result')
    # print(info)
    # return info
