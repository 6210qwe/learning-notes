const fs = require('fs');       // fs用来读写本地文件，通过require函数加载后赋值给fs
const parser = require("@babel/parser");    // @babel/parser用来将JS代 码转换成AST, 通过require函数加载后赋值给parser
const traverse = require("@babel/traverse").default;    // @babel/ traverse用来遍历AST中 的节点，通过require函数加载后把其中的 default赋值给traverse
const types = require("@babel/types");  // @babel/types用来判断节点类型、生成新的节点等，通过require函数加载后赋值给t
const { variableDeclarator } = require('babel-types');
const generator = require("@babel/generator").default;  // @babel/generator用来把AST转换成JS代码，通过require函数加载后把其中的 default赋值给generator

// AST处理JS文件的基本步骤为：首先读取JS 文件，解析成AST,再对节点进行一系列的增、删、改、查操作，接着生成JS代码，最后保存 到新文件中
const jscode = fs.readFileSync('./sg.js', {
    encoding: "utf-8"
});
console.time('处理完毕，耗时');
let ast = parser.parse(jscode);



decodefunc = '';
decodefunc_name = '';
key_name = '';


const Getdecodefunc = {
    ExpressionStatement(path) {
        let {expression} = path.node;
        if (!expression.expressions){
            return;
        }
        let expressions = expression.expressions;
        let expressions_end = expressions[expressions.length - 1]

        if (!types.isAssignmentExpression(expressions_end)) {
            return
        };
        let {left, right, operator} = expressions_end;
        if (!types.isMemberExpression(left) || !types.isArrayExpression(right) || operator !== '=') {
            return
        };
        elements = right.elements;
        if (elements.length < 20) {
            return
        };
        containers = path.container
        let nextSibling = path.getNextSibling();
        if (!types.isFunctionDeclaration(nextSibling)) return;
        // console.log(nextSibling.toString().length);
        if (nextSibling.toString().length < 500){
            decodefunc += nextSibling.toString() + '\n';
        }
        let nextSibling2 = nextSibling.getNextSibling();
        if (nextSibling2.toString().length < 500){
            decodefunc += nextSibling2.toString() + '\n';
        }
        let nextSibling3 = nextSibling2.getNextSibling();
        if (!types.isFunctionDeclaration(nextSibling3)){
            decodefunc += nextSibling3.toString() + '\n';
        }
        let nextSibling4 = nextSibling3.getNextSibling();
        if (!types.isFunctionDeclaration(nextSibling4)){
            decodefunc += nextSibling4.toString() + '\n';
        }
    }
}

traverse(ast, Getdecodefunc);

let ast2 = parser.parse(decodefunc);

const Getdecodefun_name = {
    Identifier(path){
        let {scope} = path;
        let {name} = path.node;
        if (types.isMemberExpression(path.parent) && path.key == 'property') return;
        if (name == 'isNaN' || name == 'open' || name == 'Math'|| name == 'window' || name == 'parseInt'|| name == 'String' || name == 'document'|| name == 'Set'|| name == 'history' || name == 'Intl') return;
        let binding = scope.getBinding(name);
        if (binding){
            return;
        }
        console.log(name);
        decodefunc_name = name;
        path.stop();
    }
}


const Getdecodefun_key_name = {
    VariableDeclaration(path){
        let {declarations} = path.node;
        let {id} = declarations[declarations.length - 1];
        key_name = id.name;

    }
}


traverse(ast2, Getdecodefun_name);
traverse(ast2, Getdecodefun_key_name);



const Getdecodefunc2_0 = {
    FunctionDeclaration(path) {
        let {id} = path.node;
        if (id.name == decodefunc_name){
            decodefunc += path.toString() + '\n';
            decodefunc += "return " + key_name + "";

        }

    }
  
}

traverse(ast, Getdecodefunc2_0);


eval("window=global;history={};function print(){};function open(){};function Option(){};function get_v2_key_base64(){" + decodefunc + "}")


function get_v2_key(){
    key = get_v2_key_base64();
    return atob(key)
}

console.log(get_v2_key());
