import cv2
import numpy as np
import time


def cvshow(img):
    cv2.imshow("img", img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()




def split_circle(que_image, radius):
    """基于给定半径切割图片中的圆"""
    height, width, _ = que_image.shape
    center = (width // 2, height // 2)
    mask = np.zeros_like(que_image)
    cv2.circle(mask, center, radius, (255, 255, 255), -1)
    que_result = cv2.bitwise_and(que_image, mask)
    return que_result


def get_auto_radius(image):
    """根据图像尺寸自动计算半径"""
    height, width = image.shape[:2]
    return min(height, width) // 2


def large_img(que_result, scale_factor):
    """调整图片大小"""
    circle_height, circle_width = que_result.shape[:2]
    new_height = int(circle_height * scale_factor)
    new_width = int(circle_width * scale_factor)
    que_result = cv2.resize(que_result, (new_width, new_height), interpolation=cv2.INTER_LINEAR)
    return que_result


def merge_img(que_result, bg_image, radius, angle1, angle2):
    """合并旋转后的图片"""
    que_height, que_width = que_result.shape[:2]

    # 内圈（que_result）顺时针旋转，使用负的 angle2
    rotation_matrix_inner = cv2.getRotationMatrix2D((que_width / 2, que_height / 2), -angle2, 1)
    xuanzhuan_inner_result = cv2.warpAffine(que_result, rotation_matrix_inner, (que_width, que_height))

    # 外圈（bg_image）逆时针旋转，使用正的 angle1
    rotation_matrix_outer = cv2.getRotationMatrix2D((bg_image.shape[1] / 2, bg_image.shape[0] / 2), angle1, 1)
    xuanzhuan_outer_result = cv2.warpAffine(bg_image, rotation_matrix_outer, (bg_image.shape[1], bg_image.shape[0]))

    # 画圈遮罩
    center = (bg_image.shape[1] // 2, bg_image.shape[0] // 2)
    cv2.circle(xuanzhuan_outer_result, center, radius, (0, 0, 0), -1)

    # 合并图片
    bg_height, bg_width = xuanzhuan_outer_result.shape[:2]
    circle_height, circle_width = xuanzhuan_inner_result.shape[:2]
    x = (bg_width - circle_width) // 2
    y = (bg_height - circle_height) // 2

    # 创建遮罩并合并
    overlay = np.zeros_like(xuanzhuan_outer_result)
    overlay[y:y + circle_height, x:x + circle_width] = xuanzhuan_inner_result
    result = cv2.bitwise_or(xuanzhuan_outer_result, overlay)

    return result


def calculate_gradient_difference(result):
    """计算内外圆的梯度差异"""
    center_x = result.shape[1] // 2
    center_y = result.shape[0] // 2
    circle_radius = 85

    # 创建内外圆遮罩
    circle_inner_mask = np.zeros_like(result, dtype=np.uint8)
    cv2.circle(circle_inner_mask, (center_x, center_y), circle_radius, 255, -1)
    circle_outer_mask = np.zeros_like(result, dtype=np.uint8)
    cv2.circle(circle_outer_mask, (center_x, center_y), circle_radius + 30, 255, -1)

    # 分别计算内外圆的梯度
    inner_pixels = cv2.bitwise_and(result, circle_inner_mask)
    outer_pixels = cv2.bitwise_and(result, circle_outer_mask)

    inner_sobel_x = cv2.Sobel(inner_pixels, cv2.CV_64F, 1, 0)
    inner_sobel_y = cv2.Sobel(inner_pixels, cv2.CV_64F, 0, 1)
    inner_gradient_magnitude = cv2.magnitude(inner_sobel_x, inner_sobel_y)

    outer_sobel_x = cv2.Sobel(outer_pixels, cv2.CV_64F, 1, 0)
    outer_sobel_y = cv2.Sobel(outer_pixels, cv2.CV_64F, 0, 1)
    outer_gradient_magnitude = cv2.magnitude(outer_sobel_x, outer_sobel_y)

    gradient_diff = np.sum(outer_gradient_magnitude) - np.sum(inner_gradient_magnitude)
    return gradient_diff


def find_best_angle(que_result, bg_image, radius, initial_step=15, fine_step=1):
    """多步优化寻找最佳旋转角度"""
    min_diff = float('inf')
    best_angles = (0, 0)

    # 第一步，粗略查找
    for angle1 in range(0, 180, initial_step):
        angle2 = angle1  # 内圈的角度与外圈相同
        result = merge_img(que_result, bg_image, radius, angle1, angle2)
        gradient_diff = calculate_gradient_difference(result)
        if gradient_diff < min_diff:
            min_diff = gradient_diff
            best_angles = (angle1, angle2)

    # 第二步，细致查找
    start_angle1, start_angle2 = best_angles
    for angle1 in range(start_angle1 - initial_step, start_angle1 + initial_step, fine_step):
        angle2 = angle1
        result = merge_img(que_result, bg_image, radius, angle1, angle2)
        gradient_diff = calculate_gradient_difference(result)
        if gradient_diff < min_diff:
            min_diff = gradient_diff
            best_angles = (angle1, angle2)

    return best_angles, min_diff


if __name__ == '__main__':
    import requests
    headers = {
        "accept": "*/*",
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-US;q=0.7,zh-TW;q=0.6",
        "cache-control": "no-cache",
        "origin": "https://rmc.bytedance.com",
        "pragma": "no-cache",
        "priority": "u=1, i",
        "referer": "https://rmc.bytedance.com/",
        "sec-ch-ua": "\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "cross-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36"
    }
    url = "https://verify.snssdk.com/captcha/get"
    params = {
        "aid": "2039",
        "lang": "zh",
        "subtype": "whirl",
        "detail": "qXRCyvYyj4jJfeTbxcCHQd-toH9LcYmtgwYjMIXviultGwNzfxinHK7Av6ZjN9CAh1uUePv5EuIFrlBH7c6LSeo0ZaXGA7JY3lqu4XkX4nlvilqfPxI2d0XPwSJGrigvZYAS5AZCOBnDvkabYF7xzJlnnJeGFX3kgUs1yCLIB3aLELmuGAY0c5u2nXw6qL5UiPmTkhUCf8lyOgQYixHeXmn0gljJrsvaLuoNOle13xd02taA9EmE5998t13pVlTXs-oZdxoWjMAYyRLoQmCfIqXwQeRSZuJ4J1gOfRA0jq65oZpomxUMukBaw9T0FkZ1wGNKz9fKgTuMf790PZKIaEudMOY09qefxaxt-MVgZxRXG5HPqREl*4V8YQTW8ebkvmNcpGSpnOATkHBt",
        "server_sdk_env": "\\{\"idc\":\"hl\",\"region\":\"CN\",\"server_type\":\"business\"\\}",
        "mode": "whirl",
        "fp": "verify_b84f071cd9cc61f8c0ff07447ebf6a62",
        "region": "CN",
        "os_type": "3",
        "cookie_enabled": "true",
        "subapp": "101",
        "group": "test-verify",
        "verify_type": "verify"
    }
    response = requests.get(url, headers=headers, params=params).json()
    bk=response["data"]["question"]["url1"]
    que=response["data"]["question"]["url2"]
    bk_img_array = np.asarray(bytearray(requests.get(bk).content), dtype=np.uint8)
    bk_img_cv = cv2.imdecode(bk_img_array, cv2.IMREAD_COLOR)  # 转换为 OpenCV 格式

    que_img_array = np.asarray(bytearray(requests.get(que).content), dtype=np.uint8)
    que_img_cv = cv2.imdecode(que_img_array, cv2.IMREAD_COLOR)  # 转换为 OpenCV 格式
    que_result =que_img_cv
    bg_image = bk_img_cv

    start_time = time.time()

    # 自动计算半径
    radius = get_auto_radius(que_result)-8
    que_result = split_circle(que_result, radius)
    scale_factor = 1.1
    que_result = large_img(que_result, scale_factor)
    min_diff = float('inf')
    best_angles = (0, 0)

    # 测试不同的旋转角度
    for angle1 in range(0, 180, 4):  # 外圈的角度
        angle2 = angle1  # 内圈的角度与外圈相同
        result = merge_img(que_result, bg_image, radius, angle1, angle2)
        gradient_diff = calculate_gradient_difference(result)
        if gradient_diff < min_diff:
            min_diff = gradient_diff
            best_angles = (angle1, angle2)

    print(f"最佳旋转角度: {best_angles}, 梯度差异: {min_diff}")
    result = merge_img(que_result, bg_image, radius, best_angles[0], best_angles[1])
    cvshow(result)

    # 使用梯度差异自动选择最佳旋转角度

