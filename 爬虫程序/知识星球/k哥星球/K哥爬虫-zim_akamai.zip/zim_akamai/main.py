# -*- coding: utf-8 -*-
# ZIMUSNH86013421
import json
import re
import requests
import execjs
from loguru import logger


with open('jssss.js', 'r', encoding='utf-8') as f:
    js = execjs.compile(f.read())



UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "priority": "u=0, i",
    "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Microsoft Edge\";v=\"126\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1",
    "user-agent": UA
}

url = "https://www.zimchina.com/tools/track-a-shipment"
response = requests.get(url, headers=headers)

bm_sz = response.cookies.get('bm_sz')

cookies = {
    '_abck': response.cookies.get('_abck'),
    'bm_sz': bm_sz,
    'ak_bmsc': response.cookies.get('ak_bmsc')
}

js_url = 'https://www.zimchina.com' + re.findall('type="text/javascript"  src="(.*?)"></', response.text)[0]
print(js_url)

headers = {
    "accept": "*/*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "priority": "u=2",
    "referer": "https://www.zimchina.com/tools/track-a-shipment",
    "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Microsoft Edge\";v=\"126\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "script",
    "sec-fetch-mode": "no-cors",
    "sec-fetch-site": "same-origin",
    "user-agent": UA
}

response = requests.get(url=js_url, headers=headers, cookies=cookies)

_abck = response.cookies.get('_abck')
cookies['_abck'] = _abck
logger.info(cookies)

sensor_data = js.call('get_send_data', UA, _abck, bm_sz)
logger.info(sensor_data)
logger.info(len(sensor_data))

headers = {
    "accept": "*/*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "cache-control": "no-cache",
    "content-type": "text/plain;charset=UTF-8",
    "origin": "https://www.zimchina.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://www.zimchina.com/tools/track-a-shipment",
    "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Microsoft Edge\";v=\"126\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "user-agent": UA,
}

data = {
    "sensor_data": sensor_data
}
data = json.dumps(data, separators=(',', ':'))
response = requests.post(url=js_url, headers=headers, cookies=cookies, data=data)

logger.debug(response.text)
logger.debug(response.cookies)

one_abck = response.cookies.get('_abck')
logger.success(one_abck)
cookies['_abck'] = one_abck

headers = {
    "accept": "*/*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "access-control-allow-origin": "*",
    "cache-control": "no-cache",
    "csrftoken": "null",
    "culture": "en-US",
    "expires": "0",
    "pageid": "1220",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://www.zimchina.com/tools/track-a-shipment?consnumber=ZIMUSNH86013421",
    "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Microsoft Edge\";v=\"126\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "user-agent": UA,
    "x-dtreferer": "https://www.zimchina.com/tools/track-a-shipment"
}

url = "https://www.zimchina.com/api/v2/trackShipment/GetTracing"
params = {
    "consnumber": "ZIMUSNH86013421"
}
response = requests.get(url, headers=headers, cookies=cookies, params=params)

print(response.text)
print(response)