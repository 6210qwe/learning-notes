window = global;

Object.assign(window, {
    innerHeight: 911,
    innerWidth: 1699,
    outerWidth: 1707,
    bmak: {
        startTs: "",
    }
});

navigator = {
    plugins: {
        length: 3
    },

};
screen = {
    availHeight: 1019,
    availWidth: 1707,
    height: 1067,
    width: 1707
};




var LM4 = function vC4(mC4, AC4) {
    'use strict';

    var EI4 = vC4;
    switch (mC4) {
      case 9:
        var HI4 = AC4[0];
        var RI4 = AC4[1];
        var MI4 = AC4[2];
        // v3(1, [EI4, 0]);
        // if (H4.p4[0] > 0) {
        //   v3(Gv[0] - JI4[0]);
        // }
        var bI4;
        var kI4;
        var H04;
        var XI4 = !zv[8];
        var hI4 = ",";
        var rI4 = MI4 ? 2 : 3;
        if (!H04 && (H04 = "abcdefghijklmnopaqrstuvxyzABCDEFGHIJKLMNOPAQRSTUVXYZ!@#%&-_=;:<>,~", RI4 >= 0 && RI4 <= 9)) for (bI4 = 0; bI4 <= 9; ++bI4) if (bI4 !== RI4) for (kI4 = 0; kI4 < 20; ++kI4) H04 += bI4["toString"]();
        for (;;) {
          for (hI4 = ",", XI4 = true, bI4 = 0; bI4 < window["Math"]["floor"](window["Math"]["random"]() * rI4) + rI4; ++bI4) {
            for (kI4 = 0; kI4 < window["Math"]["floor"](window["Math"]["random"]() * rI4) + rI4; ++kI4) hI4 += H04[window["Math"]["floor"](window["Math"]["random"]() * H04["length"])];
            hI4 += ",";
          }
          for (bI4 = 0; bI4 < HI4["length"]; ++bI4) if (-1 !== HI4[bI4]["toString"]()["indexOf"](hI4)) {
            XI4 = false;
            break;
          }
          if (XI4) {
            var pI4;
            return pI4 = hI4, pI4;
          }
        }
        ;
        break;
      case 29:
        var ZI4 = Math.random();
        ZI4 *= ZI4;
        return ZI4 > 0.1 ? ZI4 : 0;
        break;
    }
  };


function random_(min, max) {
    return Math.ceil(Math.random() * (min - max + 1) + max - 1)
};

function PA() {
  var j04;
  return j04 = Date.now(), j04;
};


function cR4(Qr4) {
    for (var zr4 = 0, gr4 = 0; gr4 < Qr4["length"]; gr4++) {
      var sr4 = Qr4["charCodeAt"](gr4);
      sr4 < 128 && (zr4 += sr4);
    }
        var Gr4;
    return Gr4 = zr4,  Gr4;
}


function Ux(GCk) {
    for (var jCk = Math['floor'](1e5 * Math['random']() + 1e4), YCk = String(GCk * jCk), HCk = 0, ACk = [], LCk = YCk['length'] >= 18; ACk['length'] < 6;)
        ACk['push'](parseInt(YCk['slice'](HCk, HCk + 2), 10)),
            HCk = LCk ? HCk + 3 : HCk + 2;
    var lCk;
    return lCk = [jCk, function UCk(R4k) {
        var k4k = R4k[0] - R4k[1];
        var C4k = R4k[2] - R4k[3];
        var I4k = R4k[4] - R4k[5];
        var t4k = Math['sqrt'](k4k * k4k + C4k * C4k + I4k * I4k);
        var K4k = Math['floor'](t4k)
        return K4k
    }(ACk)],
        lCk;
};

function z04(s04, G04) {
    return s04 >>> G04 | s04 << 32 - G04;
};

function mA(R04) {
  for (var M04 = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298], J04 = 1779033703, b04 = 3144134277, k04 = 1013904242, X04 = 2773480762, h04 = 1359893119, r04 = 2600822924, p04 = 528734635, Z04 = 1541459225, W04 = function t04(w04) {
      var V04;
      return V04 = window["unescape"](window["encodeURIComponent"](w04)),  V04;
    }(R04), T04 = 8 * W04["length"], B04 = (W04 += window["String"]["fromCharCode"](128))["length"] / 4 + 2, N04 = window["Math"]["ceil"](B04 / 16), d04 = new window["Array"](N04), c04 = 0; c04 < N04; c04++) {
    d04[c04] = new window["Array"](16);
    for (var O04 = 0; O04 < 16; O04++) d04[c04][O04] = W04["charCodeAt"](64 * c04 + 4 * O04) << 24 | W04["charCodeAt"](64 * c04 + 4 * O04 + 1) << 16 | W04["charCodeAt"](64 * c04 + 4 * O04 + 2) << 8 | W04["charCodeAt"](64 * c04 + 4 * O04 + 3) << 0;
  }
  var n04 = T04 / window["Math"]["pow"](2, 32);
  d04[N04 - 1][14] = window["Math"]["floor"](n04), d04[N04 - 1][15] = T04;
  for (var Y04 = 0; Y04 < N04; Y04++) {
    for (var U04 = new window["Array"](64), l04 = J04, C04 = b04, I04 = k04, x04 = X04, F04 = h04, f04 = r04, K04 = p04, P04 = Z04, D04 = 0; D04 < 64; D04++) {
      var S04,
        Q04,
        q04 = void 0,
        L04 = void 0;
      D04 < 16 ? U04[D04] = d04[Y04][D04] : (q04 = z04(U04[D04 - 15], 7) ^ z04(U04[D04 - 15], 18) ^ U04[D04 - 15] >>> 3, L04 = z04(U04[D04 - 2], 17) ^ z04(U04[D04 - 2], 19) ^ U04[D04 - 2] >>> 10, U04[D04] = U04[D04 - 16] + q04 + U04[D04 - 7] + L04), S04 = P04 + (L04 = z04(F04, 6) ^ z04(F04, 11) ^ z04(F04, 25)) + (F04 & f04 ^ ~F04 & K04) + M04[D04] + U04[D04], Q04 = l04 & C04 ^ l04 & I04 ^ C04 & I04, P04 = K04, K04 = f04, f04 = F04, F04 = x04 + S04 >>> 0, x04 = I04, I04 = C04, C04 = l04, l04 = S04 + ((q04 = z04(l04, 2) ^ z04(l04, 13) ^ z04(l04, 22)) + Q04) >>> 0;
    }
    J04 += l04, b04 += C04, k04 += I04, X04 += x04, h04 += F04, r04 += f04, p04 += K04, Z04 += P04;
  }
  var g04;
  return g04 = [J04 >> 24 & 255, J04 >> 16 & 255, J04 >> 8 & 255, 255 & J04, b04 >> 24 & 255, b04 >> 16 & 255, b04 >> 8 & 255, 255 & b04, k04 >> 24 & 255, k04 >> 16 & 255, k04 >> 8 & 255, 255 & k04, X04 >> 24 & 255, X04 >> 16 & 255, X04 >> 8 & 255, 255 & X04, h04 >> 24 & 255, h04 >> 16 & 255, h04 >> 8 & 255, 255 & h04, r04 >> 24 & 255, r04 >> 16 & 255, r04 >> 8 & 255, 255 & r04, p04 >> 24 & 255, p04 >> 16 & 255, p04 >> 8 & 255, 255 & p04, Z04 >> 24 & 255, Z04 >> 16 & 255, Z04 >> 8 & 255, 255 & Z04],  g04;
};


function zR4(Zr4) {
  for (var Wr4 = "", tr4 = 0; tr4 < Zr4["length"]; tr4++) Wr4 += 2 === Zr4[tr4]["toString"](16)["length"] ? Zr4[tr4]["toString"](16) : "0"["concat"](Zr4[tr4]["toString"](16));
  var wr4;
  return wr4 = Wr4,  wr4;
};

function NH4() {
  return function Yp4(Up4) {
    var lp4 = Up4["totVel"] || function Cp4() {
      var Ip4;
      return Ip4 = window["Math"]["floor"](zv[9] * window["Math"]["random"]() + zv[10]), Ip4;
    }();
    var xp4;
    return xp4 = [zR4(mA(lp4)), lp4]["join"]("|"),  xp4;
  };
};

var wk4 = function (Vk4, Tk4, Bk4, Nk4) {
  Vk4 > Tk4 && Vk4 <= Bk4 && (Vk4 += Nk4 % (Bk4 - Tk4)) > Bk4 && (Vk4 = Vk4 - Bk4 + Tk4);
  return Vk4;
};

function RJ4(pO4, ZO4) {
  // try {
    pO4 = window["String"](pO4), ZO4 = window["String"](ZO4);
    var tO4 = [],
      wO4 = ZO4["length"];
    if (wO4 > 0) {
      for (var VO4 = 0; VO4 < pO4["length"]; VO4++) {
        var TO4 = pO4["charCodeAt"](VO4),
          BO4 = pO4["charAt"](VO4);
        (TO4 = wk4(TO4, 47, zv[35], ZO4["charCodeAt"](VO4 % wO4))) !== pO4["charCodeAt"](VO4) && (BO4 = window["String"]["fromCharCode"](TO4)), tO4["push"](BO4);
      }
      if (tO4["length"] > 0) {
        var NO4;
        return NO4 = tO4["join"](""),  NO4;
      }
    }
  // } catch (dO4) {
  //   sF = WO4.slice();
  // }
  var cO4;
  return cO4 = pO4,  cO4;
};

function XJ4(bm_sz) {
    var hJ4 = zv[17];
    var rJ4 = zv[18];
  var zZ4 = [hJ4, rJ4];
  var gZ4 = bm_sz;
  // if (false !== gZ4) try {
  //   var sZ4 = sF.slice();
var GZ4 = window["decodeURIComponent"](gZ4)["split"]("~");
if (GZ4["length"] >= 4) {
  var jZ4 = window["parseInt"](GZ4[2], zv[19]),
    vZ4 = window["parseInt"](GZ4[3], zv[19]);
  zZ4 = [jZ4 = window["isNaN"](jZ4) ? hJ4 : jZ4, vZ4 = window["isNaN"](vZ4) ? rJ4 : vZ4];
}
  // } catch (mZ4) {
  //   sF = sZ4.slice();
  // }
  var AZ4;
  return AZ4 = zZ4, AZ4;
};



SI = window['screen'] ? window['screen']['availWidth'] : 1707;
DI = window['screen'] ? window['screen']['availHeight'] : 1019;
hI = window['screen'] ? window['screen']['width'] : 1707;
lI = window['screen'] ? window['screen']['height'] : 1067;
YI = window['innerWidth'];
UI = window['innerHeight'];
cI = window['outerWidth'];
joinedNumbers = [SI, DI, hI, lI, YI, UI, cI].map(String).join(',');

function get_send_data(UA, _abck, bm_sz){
    window.bmak["startTs"] = PA();

    zv = [
        4095,
        1276,
        300000,
        2,
        1,
        3,
        8,
        127,
        0,
        100000,
        10000,
        4,
        15,
        28,
        29,
        33,
        34,
        8888888,
        7777777,
        10,
        1000,
        150,
        47,
        112,
        123,
        9,
        4294967296,
        999999,
        6,
        32,
        65535,
        65793,
        4294967295,
        8388607,
        4282663,
        57,
        4064256,
        7,
        3600000,
        2048,
        3540,
        25,
        3000,
        100
    ];

    hX4 = parseInt(window.bmak["startTs"] / zv[36], 10);
    xk4 = cR4(UA);
    Fk4 = window.bmak["startTs"] / zv[3];
    rX4 = window["Math"]["random"]();
    pX4 = window["parseInt"](zv[20] * rX4 / 2, 10);
    WX4 = ""["concat"](rX4);
    WX4 = WX4["slice"](zv[8], 11) + pX4;

    W44 = UA + ',uaend,12147,20030107,zh-CN,Gecko,' + navigator['plugins']['length'] + ',0,0,0,' + hX4 + ',0,' + joinedNumbers + ',,cpen:0,i1:0,dm:0,cwen:0,non:1,opc:0,fc:0,sc:0,wrc:1,isc:0,vib:1,bat:1,x11:0,x12:1,' + xk4 + ',' + WX4 + ',' + Fk4 + ',0,0,loc:'

    IM4 = "";
    hH4 = "";
    B44 = "";
    rH4 = "";
    pH4 = "";
    xM4 = "";
    N44 = "";
    FM4 = "";
    ZH4 = "";
    fM4 = "";
    O44 = "0,0";

    list_25_1 = 1;
    list_25_2 = 32;
    list_25_3 = 32;
    list_25_4 = 0;
    list_25_5 = 0;
    list_25_6 = 0;
    list_25_7 = 0;
    list_25_8 = PA() - window.bmak['startTs'];    // 注意
    list_25_9 = 0;
    list_25_10 = window.bmak['startTs'];
    list_25_11 = -999999;
    list_25_12 = parseInt(hX4 / 23, 10);
    list_25_13 = 0;
    list_25_14 = 0;
    list_25_15 = parseInt(list_25_12 / 6, 10);
    list_25_16 = 0;
    list_25_17 = 0;
    list_25_18 = PA() - window.bmak['startTs'];    // 注意
    list_25_19 = 0;
    list_25_20 = 0;
    list_25_21 = _abck;
    list_25_22 = cR4(_abck);
    list_25_23 = -1;
    list_25_24 = -1;
    list_25_25 = 30261693;
    list_25_26 = 'PiZtE';
    lx = Ux(window.bmak['startTs']);
    list_25_27 = lx[0];
    list_25_28 = lx[1];
    list_25_29 = 0;
    list_25_30 = "0";
    list_25_31 = 0;
    list_25_32 = ",";
    list_25_33 = "";
    list_25_34 = 0;

    //'1,32,32,0,0,0,0,7,0,1720775972778,-999999,18408,0,0,3068,0,0,3849,0,0,D1windowB378806D5C42B79F92459F44E6F4~-1~YAAQXv6YcxAmoJeQAQAAJo49pgwh4LNr8loyTDQKMeu+5UapcAp+hzHqrEo9frL3Ib03RATS3iDz9WzG26ibdWJ1UDl3KD+0aud2xHkmEH/zXliwUNNNFLR76zmnZ6f4yXhLeER33Fc8aMSCbccHmMrfVEITTx2qURvjAOwRFp/+MpGErPcKH0nVgp/AB5fNntA/Z7ySZ9On8/8x4kyvAtU6OhcdWPdNBYpkxLY+B8AoEfnTOm2HYG3eX1tQYaXgEAUYw3goGlHApEFSSdqWf8253ATwA8TkQa1tiBJDLQ42MVZAklJ8LPtAlM989WJxML5bM4tBuyyAsH60iaYz8e9zNyUxHStSnc/2S4/6Wcs2VVGAQNxOkjYVHJnMSmja7/rSbMlzhOk4l/WIxg==~-1~-1~-1,36850,-1,-1,30261693,PiZtE,72653,32,0,0,0,,,,0'
    BR4 = [list_25_1, list_25_2, list_25_3, list_25_4, list_25_5, list_25_6, list_25_7, list_25_8, list_25_9, list_25_10, list_25_11, list_25_12, list_25_13, list_25_14, list_25_15, list_25_16, list_25_17, list_25_18, list_25_19, list_25_20, list_25_21, list_25_22, list_25_23, list_25_24, list_25_25, list_25_26, list_25_27, list_25_28, list_25_29, list_25_30, list_25_31, list_25_32, list_25_33, list_25_34].join(',')
    console.log(BR4)

    c44 = "https://www.zimchina.com/tools/track-a-shipment";
    KM4 = "-1";
    mR4 = "0,0,0,0,1,0,0";
    hM4 = "";
    rM4 = "";
    pM4 = "";
    PM4 = 8;
    VM4 = ",,";
    dM4 = ",,,,,,,,,0,,,1,1";
    UM4 = ",,,1,";
    DM4 = "";
    lR4 = cR4("-1").toString();
    BH4 = NH4()({
        'startTimestamp': window.bmak['startTs'],
        'deviceData': W44,
        'mouseMoveData': rH4,
        'totVel': list_25_7,
        'deltaTimestamp': list_25_8,
    });
    console.log(BH4);
    SM4 = 0;
    X44 = ["-100", W44, "-105", IM4, "-108", hH4, "-101", B44, "-110", rH4, "-117", pH4, "-109", xM4, "-102", N44, "-111", FM4, "-114", ZH4, "-103", fM4, "-106", O44, "-115", BR4, "-112", c44, "-119", KM4, "-122", mR4, "-123", hM4, "-124", rM4, "-126", pM4, "-127", PM4, "-128", VM4, "-131", dM4, "-132", UM4, "-133", DM4, "-70", "-1", "-80", lR4, "-90", BH4, "-116", SM4]
    jR4 = ",,0,";
    X44['push']('-129', jR4);
    // return X44;

    k44 = LM4(9, [X44, 2, false])
    console.log(k44);
    zM4 = X44["join"](k44)
    console.log(zM4);

    ZJ4 = ""["concat"]("0evu98WT4WRfT9GmT5X8wg==");    // 注意
    HJ4 = RJ4("0a46G5m17Vrp4o4c", "afSbep8yjnZUjq3aL010jO15Sawj2VZfdYK8uY90uxq")["slice"](0, 16),
    MJ4 = window["Math"]["floor"](PA() / 3600000),
    JJ4 = PA(),
    bJ4 = HJ4 + RJ4(MJ4, HJ4);
    JJ4 = PA() - JJ4;
    zM4 = zv[3] + k44 + 2 + k44 + (zM4 = bJ4 + ZJ4 + k44 + (24 ^ cR4(zM4)) + k44 + zM4);
    console.log(zM4);

    var kJ4 = XJ4(bm_sz);

    console.log(kJ4);

    var tJ4 = PA();
    zM4 = function wJ4(VJ4, TJ4) {
      var BJ4;
      var NJ4;
      var dJ4;
      var cJ4;
      var OJ4 = VJ4["split"](",");
      for (cJ4 = 0; cJ4 < OJ4["length"]; cJ4++) BJ4 = (TJ4 >> 8 & zv[30]) % OJ4["length"], TJ4 *= zv[31], TJ4 &= zv[32], TJ4 += 4282663, NJ4 = ((TJ4 &= zv[33]) >> 8 & zv[30]) % OJ4["length"], TJ4 *= zv[31], TJ4 &= zv[32], TJ4 += zv[34], TJ4 &= 8388607, dJ4 = OJ4[BJ4], OJ4[BJ4] = OJ4[NJ4], OJ4[NJ4] = dJ4;
      var nJ4;
      return nJ4 = OJ4["join"](","),  nJ4;
    }(zM4, kJ4[1]), tJ4 = PA() - tJ4;
    var YJ4 = PA();

    FJ4 = new window["Array"](zv[7]);
    IJ4 = "";
    zM4 = function UJ4(lJ4, CJ4) {
      if (!IJ4) for (var xJ4 = zv[8]; xJ4 < zv[7]; ++xJ4) xJ4 < zv[29] || 39 === xJ4 || 34 === xJ4 || 92 === xJ4 ? FJ4[xJ4] = -1 : (FJ4[xJ4] = IJ4["length"], IJ4 += window["String"]["fromCharCode"](xJ4));
      for (var fJ4 = "", KJ4 = 0; KJ4 < lJ4["length"]; KJ4++) {
        var PJ4 = lJ4["charAt"](KJ4),
          DJ4 = CJ4 >> 8 & 65535;
        CJ4 *= zv[31], CJ4 &= zv[32], CJ4 += zv[34], CJ4 &= zv[33];
        var SJ4 = FJ4[lJ4["charCodeAt"](KJ4)];
        if ("function" == typeof PJ4["codePointAt"]) {
          var QJ4 = PJ4["codePointAt"](zv[8]);
          QJ4 >= 32 && QJ4 < 127 && (SJ4 = FJ4[QJ4]);
        }
        SJ4 >= 0 && (SJ4 += DJ4 % IJ4["length"], SJ4 %= IJ4["length"], PJ4 = IJ4[SJ4]), fJ4 += PJ4;
      }
      var qJ4;
      return qJ4 = fJ4, qJ4;
    }(zM4, kJ4[0]), YJ4 = PA() - YJ4;


    console.log(zM4)

    GJ4 = ";";
    // 569823,0,0,1478,9,0
    LJ4 = ""["concat"](random_(1,5), ",")["concat"](0, ",")["concat"](JJ4, ",")["concat"](tJ4, ",")["concat"](YJ4, ",")["concat"](0);
    zM4 = "2;" + 0 + GJ4 + kJ4[0] + GJ4 + kJ4[1] + GJ4 + LJ4 + GJ4 + zM4;
    return zM4
    // var QO4 = "{\"sensor_data\":\""["concat"](zM4, "\"}")
    // console.log(QO4)
};




UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0';
_abck = 'D1windowB378806D5C42B79F92459F44E6F4~-1~YAAQXv6YcxAmoJeQAQAAJo49pgwh4LNr8loyTDQKMeu+5UapcAp+hzHqrEo9frL3Ib03RATS3iDz9WzG26ibdWJ1UDl3KD+0aud2xHkmEH/zXliwUNNNFLR76zmnZ6f4yXhLeER33Fc8aMSCbccHmMrfVEITTx2qURvjAOwRFp/+MpGErPcKH0nVgp/AB5fNntA/Z7ySZ9On8/8x4kyvAtU6OhcdWPdNBYpkxLY+B8AoEfnTOm2HYG3eX1tQYaXgEAUYw3goGlHApEFSSdqWf8253ATwA8TkQa1tiBJDLQ42MVZAklJ8LPtAlM989WJxML5bM4tBuyyAsH60iaYz8e9zNyUxHStSnc/2S4/6Wcs2VVGAQNxOkjYVHJnMSmja7/rSbMlzhOk4l/WIxg==~-1~-1~-1'
bm_sz = "97CEA90D3AD811E340FD82B996337126~YAAQXg1x3zDc9IeQAQAAQLYSqhi0EHAY0Mo674tknF5uGbBI6PXX1C8a3J1nEBxhn+xDRdWu5Vpd55e8a4Rbp5M0jlKQ8jytX61Ua2Neve9FbyEjO8IDjnVnhvbEPRm0g8mQx8Z7DAN0ZsVH6Mb/dlkMCUrohHmvleYOq33l664HA3Rse0s5GQfO+ThidDn++P1hHNCIb1HFI/N+vryyZ2btpSg/SsL0qAGdhJaDVjvBDjUhtird5uyWlIp2BJf3TTwrCq3T0OiEgyaqpNnWoJ/rndXh+2MGtjYj9qSEP/5u2iCgQAtYtJ9AtHOh3tQim7F1qBgNOU+UV2NxPugehJEMoIKaaR4dufgs58bx2gpeWACQdmuybg==~3555910~3486786"
console.log(get_send_data(UA, _abck, bm_sz))




