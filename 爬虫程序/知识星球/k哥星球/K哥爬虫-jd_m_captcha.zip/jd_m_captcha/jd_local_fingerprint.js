x64Add = function (a, b) {
    a = [a[0] >>> 16, a[0] & 65535, a[1] >>> 16, a[1] & 65535];
    b = [b[0] >>> 16, b[0] & 65535, b[1] >>> 16, b[1] & 65535];
    var c = [0, 0, 0, 0];
    c[3] += a[3] + b[3];
    c[2] += c[3] >>> 16;
    c[3] &= 65535;
    c[2] += a[2] + b[2];
    c[1] += c[2] >>> 16;
    c[2] &= 65535;
    c[1] += a[1] + b[1];
    c[0] += c[1] >>> 16;
    c[1] &= 65535;
    c[0] += a[0] + b[0];
    c[0] &= 65535;
    return [c[0] << 16 | c[1], c[2] << 16 | c[3]]
}

x64Multiply = function (a, b) {
    a = [a[0] >>> 16, a[0] & 65535, a[1] >>> 16, a[1] & 65535];
    b = [b[0] >>> 16, b[0] & 65535, b[1] >>> 16, b[1] & 65535];
    var c = [0, 0, 0, 0];
    c[3] += a[3] * b[3];
    c[2] += c[3] >>> 16;
    c[3] &= 65535;
    c[2] += a[2] * b[3];
    c[1] += c[2] >>> 16;
    c[2] &= 65535;
    c[2] += a[3] * b[2];
    c[1] += c[2] >>> 16;
    c[2] &= 65535;
    c[1] += a[1] * b[3];
    c[0] += c[1] >>> 16;
    c[1] &= 65535;
    c[1] += a[2] * b[2];
    c[0] += c[1] >>> 16;
    c[1] &= 65535;
    c[1] += a[3] * b[1];
    c[0] += c[1] >>> 16;
    c[1] &= 65535;
    c[0] += a[0] * b[3] + a[1] * b[2] + a[2] * b[1] + a[3] * b[0];
    c[0] &= 65535;
    return [c[0] << 16 | c[1], c[2] << 16 | c[3]]
}

x64Rotl = function (a, b) {
    b %= 64;
    if (32 === b)
        return [a[1], a[0]];
    if (32 > b)
        return [a[0] << b | a[1] >>> 32 - b, a[1] << b | a[0] >>> 32 - b];
    b -= 32;
    return [a[1] << b | a[0] >>> 32 - b, a[0] << b | a[1] >>> 32 - b]
}

x64LeftShift = function (a, b) {
    b %= 64;
    return 0 === b ? a : 32 > b ? [a[0] << b | a[1] >>> 32 - b, a[1] << b] : [a[1] << b - 32, 0]
}

x64Xor = function (a, b) {
    return [a[0] ^ b[0], a[1] ^ b[1]]
}

x64Fmix = function (a) {
    a = x64Xor(a, [0, a[0] >>> 1]);
    a = x64Multiply(a, [4283543511, 3981806797]);
    a = x64Xor(a, [0, a[0] >>> 1]);
    a = x64Multiply(a, [3301882366, 444984403]);
    return a = x64Xor(a, [0, a[0] >>> 1])
}


x64hash128 = function (c, a) {
    c = c || "";
    a = a || 0;
    var b = c.length % 16
        , d = c.length - b
        , e = [0, a];
    a = [0, a];
    for (var h, q, B = [2277735313, 289559509], C = [1291169091, 658871167], A = 0; A < d; A += 16)
        h = [c.charCodeAt(A + 4) & 255 | (c.charCodeAt(A + 5) & 255) << 8 | (c.charCodeAt(A + 6) & 255) << 16 | (c.charCodeAt(A + 7) & 255) << 24, c.charCodeAt(A) & 255 | (c.charCodeAt(A + 1) & 255) << 8 | (c.charCodeAt(A + 2) & 255) << 16 | (c.charCodeAt(A + 3) & 255) << 24],
            q = [c.charCodeAt(A + 12) & 255 | (c.charCodeAt(A + 13) & 255) << 8 | (c.charCodeAt(A + 14) & 255) << 16 | (c.charCodeAt(A + 15) & 255) << 24, c.charCodeAt(A + 8) & 255 | (c.charCodeAt(A + 9) & 255) << 8 | (c.charCodeAt(A + 10) & 255) << 16 | (c.charCodeAt(A + 11) & 255) << 24],
            h = x64Multiply(h, B),
            h = x64Rotl(h, 31),
            h = x64Multiply(h, C),
            e = x64Xor(e, h),
            e = x64Rotl(e, 27),
            e = x64Add(e, a),
            e = x64Add(x64Multiply(e, [0, 5]), [0, 1390208809]),
            q = x64Multiply(q, C),
            q = x64Rotl(q, 33),
            q = x64Multiply(q, B),
            a = x64Xor(a, q),
            a = x64Rotl(a, 31),
            a = x64Add(a, e),
            a = x64Add(x64Multiply(a, [0, 5]), [0, 944331445]);
    h = [0, 0];
    q = [0, 0];
    switch (b) {
        case 15:
            q = x64Xor(q, x64LeftShift([0, c.charCodeAt(A + 14)], 48));
        case 14:
            q = x64Xor(q, x64LeftShift([0, c.charCodeAt(A + 13)], 40));
        case 13:
            q = x64Xor(q, x64LeftShift([0, c.charCodeAt(A + 12)], 32));
        case 12:
            q = x64Xor(q, x64LeftShift([0, c.charCodeAt(A + 11)], 24));
        case 11:
            q = x64Xor(q, x64LeftShift([0, c.charCodeAt(A + 10)], 16));
        case 10:
            q = x64Xor(q, x64LeftShift([0, c.charCodeAt(A + 9)], 8));
        case 9:
            q = x64Xor(q, [0, c.charCodeAt(A + 8)]),
                q = x64Multiply(q, C),
                q = x64Rotl(q, 33),
                q = x64Multiply(q, B),
                a = x64Xor(a, q);
        case 8:
            h = x64Xor(h, x64LeftShift([0, c.charCodeAt(A + 7)], 56));
        case 7:
            h = x64Xor(h, x64LeftShift([0, c.charCodeAt(A + 6)], 48));
        case 6:
            h = x64Xor(h, x64LeftShift([0, c.charCodeAt(A + 5)], 40));
        case 5:
            h = x64Xor(h, x64LeftShift([0, c.charCodeAt(A + 4)], 32));
        case 4:
            h = x64Xor(h, x64LeftShift([0, c.charCodeAt(A + 3)], 24));
        case 3:
            h = x64Xor(h, x64LeftShift([0, c.charCodeAt(A + 2)], 16));
        case 2:
            h = x64Xor(h, x64LeftShift([0, c.charCodeAt(A + 1)], 8));
        case 1:
            h = x64Xor(h, [0, c.charCodeAt(A)]),
                h = x64Multiply(h, B),
                h = x64Rotl(h, 31),
                h = x64Multiply(h, C),
                e = x64Xor(e, h)
    }
    e = x64Xor(e, [0, c.length]);
    a = x64Xor(a, [0, c.length]);
    e = x64Add(e, a);
    a = x64Add(a, e);
    e = x64Fmix(e);
    a = x64Fmix(a);
    e = x64Add(e, a);
    a = x64Add(a, e);
    return ("00000000" + (e[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (e[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (a[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (a[1] >>> 0).toString(16)).slice(-8)
}

function jdFingerprint() {
    let c = [];
    let userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"
    c.push(userAgent)
    let language = "zh-CN"
    c.push(language)
    let browser = "applewebkit_chrome"
    c.push(browser)
    let browserVersion = "537.36"
    c.push(browserVersion)
    let os = "windows"
    c.push(os)
    let osVersion = "NT"
    c.push(osVersion)
    let screenColorDepth = 24
    c.push(screenColorDepth)
    let screenResolution = "1080x1920"
    c.push(screenResolution)
    let timezoneOffset = (new Date).getTimezoneOffset()
    c.push(timezoneOffset)
    let sessionStorageKey = "sessionStorageKey"
    c.push(sessionStorageKey)
    let localStorageKey = "localStorageKey"
    c.push(localStorageKey)
    let indexedDbKey = "indexedDbKey"
    c.push(indexedDbKey)
    let cpu = "NA"
    c.push(cpu)
    let platform = "Win32"
    c.push(platform)
    let hardwareConcurrency = "12"
    c.push(hardwareConcurrency)
    // navigator.doNotTrack ? navigator.doNotTrack : "NA"
    // Navigator.doNotTrack 属性返回用户的请勿追踪设置, 该设置指示用户是否请求网站和广告商不要追踪他们
    let track = "NA"
    c.push(track)
    let plugins = "PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf;Chrome PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf;Chromium PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf;Microsoft Edge PDF Viewer::Portable Document Format::application/pdf~pdf,text/pdf~pdf;WebKit built-in PDF::Portable Document Format::application/pdf~pdf,text/pdf~pdf"
    c.push(plugins)
    let canvas = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAAIABJREFUeF7tnQl4FdXZx/9zs5GQELLvOwmELYR9E9lkkcWKohaQgALa0sVqv7q0Wm1ttf2qXelnXaqggBQUBURlFYjIprImrCF7AtkTyH7vfH3PZCb33twkNwuGIe88j4+aOTNz5n/e+d33vOc950jggxVgBVgBnSgg6aSeXE1WgBVgBcDAYiNgBVgB3SjAwNJNU3FFWQFWgIHFNsAKsAK6UYCBpZum4oqyAqwAA4ttgBVgBXSjAANLN03FFWUFWAEGFtsAK8AK6EYBBpZumoorygqwAl0GLBmQWX5WgBWwrYAEzpG0pQwDi78YVuAmVICB1SzIu6a12MPqGt35qfpQgIHFwNKHpXItWQGI/mCX9X5u5gboMlHYw7qZzYLr1tUKMLDYw+pqG+TnswJ2K8DAYmDZbSxckBXoagUYWAysrrZBfj4rYLcCDCwGlt3GwgVZga5WgIHFwOpqG+TnswJ2K8DAYmDZbSxckBXoagUYWAysrrZBfj4rYLcCDCwGlt3GwgVZga5WgIHFwOpqG+TnswJ2K8DAYmDZbSxckBXoagUYWAysrrZBfj4rYLcCDCwGlt3GwgVZga5WgIHFwOpqG+TnswJ2K8DAYmDZbSxckBXoagUYWAysrrZBfn4bFDDCAANM3XZRKAYWA6sNnwsX7SoFCuGJA0jEJYRgMbbDHyVdVZUufS4Di4HVpQbID29ZgevogQ8wCWkI0QoO7X0Fs6t2wVBT1e3kY2AxsLqd0evphWkLpb0Yhv1IBMLCgMBAOLk5Y2nVRgQf2a6nV+mUujKwGFidYki34k2q4Yw6OHbo1ZxQjx6o7dA9yuKHY3XAQyiWPQBJWb17qGsmZh95FYaiwg7dW28XM7BuIWBVwQUZCIQJBptvFYqr6IXrN8RG6ZmZCEAleljcnz7YSOSB/q23YzNuxwnEdqjaCbiAu7GvQ/eAiwuOTX8M28oHafdxkoxYWvMBgg9u6di9dXY1A+sWAlYufPE2ZjfrFcQhE/Ox54bAoxZOWIdpSEeQhaKeuIZl2AIPVOrs0wAEsHxGA47t97JGuaVjptNR4Pz5Dr1/ZeIYrA1YjJxqD+0+I+neh/8MqaioQ/fW08UMrFsNWH5LUeftr3UdrF9vtukAhp//uNNtVADLfR7SAxMtPnBPpxosC/0GHqcOA9nZnf7cG3lDAawRC4CePdv9mKnRRRjveh5YtUrcowJueBNzUQb3tt9z4EDAx6exbU0mIDMTSE+3+17k7S7ADtHZ1ePBwLrVgBX9E9SFRgIG291CD2MFll76K7xzz3aqvQpg+S1Eep/bQF0Y9fB0qceygZfgsWsLcOJEpz7zRt/sc4xGyrhFgLv9cKmqN6DW2Ki9AJZTCvCvf3UcWL6+QFwc4Ozc+OoVFcDx44DRaJccDCy7ZNJdIV3uSyi6hK0AC7KMIaZzmHPg93CAqdMa5lYElhBn5UrAz89unXan+eBAppdWfl78FQy+fgJYs6YRWMGPoix6cIe6mnZXyKpgZO8qLIg4B+ctHwCXL7f3Nl12HXtY3czDoteVjPWYX7YZ/U92XtfwlgXW8uUAeTZ2HpvPB+FEQW/Nw/3+oDz0LTvVLLAkyPBwMd6wzHVKi6iocYDc8AQGlp0NqbNit66H1dAQvsYiLE59Fb0KMzqlaW5ZYLVRHRH3SrwP8PQUVwpg5R0GNm2y6WEJgAzKg7ND53m75lWm7um6U0FIL3UVf2ZgtbFBdVL8lgIWvQz90locsozRdccx/eArnfLrfisD61OMwWEM0OS7H7sQj6aBbkrt2IRJSBlxnwjUOxlMWJqYg+ALXwFblPQDEXQ36xIKgAzIgbNcC+qud/YhgJUSivQKdxGsZ2B1tsI3x/1uKWANDSrHxWI3lNdYDs9L9XVYVLwOMSk7O6z6rQws63ys72MH+iKziWZaaseIuW0D1g2MKVm3CwOrw6Z+U97glgLW5Kgi1Bsl7M/0biJ2iPEKFh55AW415R1qiFsVWLVwxPuYhrRhcwAPD+E1LUnMQcilw8BHH1lopqV2DJgKuLrCxcGEpYMzEXh8N7B3b/MeFgPLbtvjoLttqW4pYCUEVGCKeyrWZA1CYa0Sy9AOWcaUmi8x/tBrHeoa3rrAakiIbcFrUrWkLP+3fZJQEDdSpHaIlI4hGfA48gUDy24ktVyQgdVNgHW362GklPtgY/EQbcRIfXUnYw2S8t9C6IWD7TarWxVY1+CKt7yTUNJ3hCWEju4D9uyx0EvEp7yXoqzv0MayCenwOLwX2KdMz7EZw2IPy267Y2B1F2D5nobx4FfYGrUYx4ubDtPH1Gfg/qMvwbnmmt3GY16wq4BFz62Bk1YVV9TAEfYlUdrzotYQ8upRh4cTMuB+ZJ/mNan3EWUDV6AsJgFwcoKfWy2W9k+D286tWtKsNbB83WoxwScLjnt3Atk59lSpTWXq4YD9PlNRGKcAl2NYbZJPN4W/8y5h8Nh9qyDhQXdjpcc9V3fg92l/brNYzSWOUpfwbt/TYnpI6ewHsLpuGkpqzLKl6UkmE6ZV7sXYY2/bfO4zMT/DJr/p4ty9Vz9vUr/vAli02ibNVTyFPmIhO/r4bR2U20QL3NHcySG4AG+Utbu7KzQNeBh1sfEi0VN88HHpcP58W5PM/QL0xr+DVqAqpn+zZa2BJepfUwOkpgKlpW1uc7su6N0biI9nYNkllj4LfafAaoDVD82lSsr7qM3QsgdYlLV9cvIKfHglvknLuBmvY0nGP+GfaTmFhmC1OvB7FuWt63cjgUUeFK0HdQT9bU/spg/SbDoQKisBmrLScPiiFLNwEJHIbTO4hKaBy1DXp5+AULRXJR7okw7nz7YCp05ZaGJdVsCtTxqcP90CnDkjytoEVl0dUFIifjRuyEHTtLy8hNfHHtYNUbjLb9ohYE3KeGeABMMnACJsvEmNBPnJ3RFJf6VzkzNWfwxIc229cZ+UDPxr5rMtivHhQ9Pw+tMPoM7ZERG7snA5ZRRiC4wIzizQrjP3sOiPxuEj8WHoIpwptRo1lGUMkNMwb/8LYtoO3fudx+ch50N/5H/uY1GPnsZKnD80U/vbjQAWrVx+BtHYhvFaty953gQYgoKQeCYXrtTzo4+xYY0oiwpSTlN9PQS8CgqAvDzEGy9hFr6EO+xfqfMcwrE+cgUQHi6eJbQMuQBs3txkaosAVsRK1IVHAw4OGORfgXmhFyCZlbUGVmGgF3LD/SEbmjc5z+IKXPPsCefqWsSdsj3R+fygSNT2cEbE+Rx4lFkuIZQb4Y+CIKWtfcMkJNwj45AxE+UlV/HsylUYsc8SvOY6PvvmY7jUPxy/X/IKIs837bK2dr6zv+S2xrCmZKz+qQzpBQnyr9VvrrPrpN5vUvq7r0iS/LjZ/TNkmGbtjVii/FrZOCZmrhluqHco2BO9MGPaxTX+RicskQGyBmdZlnbtiXxQBJbNy9m6TycBSz6xJyLpLvMHNADqdlnC/XvDF39O/19X6DQ3+4/+qMlujMX0HFyFfiszEJR1tUVoPfLpb8XtCWyfjhmPP459vlVgUfmrc5PwTuUkVNZbLZ1iNGLetW0Y/O3GBmDdg7TNISj5rHFZE7qeul3ZX068YcCidILtGIvjiFOe4e0NREYqE5GbmdjdoiGSF3PlCrzST2FB/Sfwg33dr1REYkPkMg1Yo0JKMTMgDfjgAyDDcpbABYRhbeQjLcLNGlihvapB8w2dGjLdP7tvgniNGf/Zb/E6B+4ciSshPhj/2TEEZjX+GFGh/DA/JM8YjoCcIty2/YjFdXVGA/5sHIpUyUfAbJBUqM0lfPaXd+Ho7YOx4qX3Me/fO2zK1xqQWjvf2XC4WYGlwkqWpVf3Rj74hJnTguagNSVjdZIJUrQBiDRB+kSCPNVRxks7Ihdfnnj57SEGg+FpSTKcA/CNbJInwCA7yfWGf+yNfpD+ZnHcMGBNylwzXZKxQZalt+jFBLCKHGdn/yHAYA4sqs3/TPk39tw3ptlfwfS4EDzzzhOIScnEb5f9pU3Aoq7hsck/xLYrTReo8zKVIinlT9gzNw5vP34PLtsAlruxEudukIdFK31uwW1IQZTS1YuJUebzWYHK1dGIiN7V6OmkBNnrTRKyynuguKoR/BatSl5XdTV8ss7gwdw30RutDzAkIwG7+i4CgpR1vqyXizG/v01vzO8M8MYbSpyquVFCs6k52xZOEuVmr1XyttQjNTEGX48fiJCMK5i05ZDFuWMTBuFsQjSGJZ9G/LeXLM5RpvvvakbgjNwUWDT5mX7wKv7rvbXXg2JgKXJPyVj9Lf17d0RSotoALXl309LXRNVJIG/jiEFGAiR4Osj4H4KVev3kjNXPA9JYQD4ISJ4SpDpAvrY7YvFvuhRY9cWOd2a9HOBoDaz5y3cgbXiYTWAdvX0QfrtqJa57KIHnnhWVmP7KfmzyfkjzsKpdnXG5XxgCh7kg5s46fFxxTpRTuwG1427HvyOXYq9/X9S6KB+5ZJIRnHkVM7L3oyb2ON5+4l6kbw4SHpbXjAr4f78Ecp2E+j9JePXiy1odTHUSTJs8MWx/FXpVNq61ZL28DBn4wTuGimcF5BQiJP0Kyr3chYdI7/Sbv69E2ItZ8P/PFaB3b5SNGoqsQTHwLihDcMZVZMaHIHJyDyzPPISzk+KRFW25YCDd1zO/FNF/O4pdl3xRZpXdT12w7HA/VIZeQ92MHAw/dhrnBkdhyasfijpR9/p7q3fh0RfXif//Z8J8fDB5JWKKa+FReh3+PwtFH7csvOFVKrrhTrX1wkP5dmx/7IoZDaftIQiqd0TU2SzMDsoTa2E9MjtQ3Ive0WZaQ9QFOB/cJ2BKbUoHtZH1Idrb3RU/eW6N0IIO6u797TeL0fNalc1raLLPhofnoWTWNEzdcQIh2QVwrSrRuqlqt5/e35aX1RqQ1PMu1bXIjAnW2tUagATGi/2VCImqmfo8OpfRJ0Tz9NQfYiprfZ/JmWtmmP/gU5kG7+ZhtdfS6N3IJyRgD3UJAfkYIE1p0NQiLGN2D7PunLxF7R2pTgZkeTsk6U4yMeU+jWWaNJYCsWa7o+RdyRKGS7IUJAMugHxpT0TSY+b3ofcC5P6ShHTIiJckHJRlRMHk8BR1Ic3L3jAPi0gsQ4oy7xLWlzlMy/pdYA/rLmHMj3Iw/KtTwnuydbTmYVFcg475V0+JUcKjp/eLDyIoq0B8PHT9urffQspWT4SeyEKPqlqk9w3FtV5uiDibgYSob7H+kRhkfRgg7kOwun7SFdmv+GGs53E4/cqoeXcUw7rnyTVwvRaM/meytOqaA+vZH0/CidH9NGCq8FJjdQSsX/zsCbi/WoZhp3OAPn1QEeSHjLgQeF8txfjydPg8HoHqyF6Y8tFB9C6qAKird+0aUFuLAzNH4OToeEzcn4IBpzJRa3LA9gu+OJ7fS9SHPAm6l3t5JSLPpCPG+yQ2/j4OtS7O4mMZmnxGeKwUA1Jjh4/OfxbpYdMw4JKydnrIU6EwhFVg3MKfitiP+iGO3fkN7ly2G+tv+zFyRw8Rz1hWd8Ji8T5RB1tzCc3ysMy7+NZt/tqvFuCjpKkWXTg1hmkOWevr1r7yU9QsuB8zPjuugK68XIvBqT98d76/X4O0+fX2AIt+gOj9yU5Vm1Q1tAUfuqd5V9S6zFu/mG9hJ1YfpmTtzTR8U/FqbNgcFAIrkP5APWe1a2YrLANIWphGAxTkfQStxv8HNCgq8aqV5vFoC9g09KQkyJfNvS7zMmpcyiTJQZLB9JhkdHjS4GAMqw8POyRlZvQFDIslSYqFbCoyubr+DNXV/dR4l3UbdxKwbAbdy9SXpoe2FHTvfbAcH3z/RzZhRX9sDVjqheZBd/MPgoz906eSMH69CZf3Nn3l2nBHpDwuIyfVGR4jKjVYCQiGfI6058KRcOisMNTWgu6ZJSl4+vE7YP5hWBv3F+NH4McTnkSfw4VIKIOIV6mQGeRQhCcdj+KreSNR5NsLE/+5Cb4ff6qkAwAi3mbhHYWEAGPGwNgnDtszQvF1Xi8B4yo3F+H9EJxpVNRzWjo2PxCrQYA+JhWqw/adwbSnX4NHaQwSUvNwvbcbwp8Lg1/JaTwwZal4LkFk+wMTBIRr9hnw8fDlyLxtGFwra/BI/XGMqftGW1qmo8Cy1ovu1xpQqMwbv16M44tm4Ycv/QcDvr6oQP7SJdFN7QxgWQflzb02ej4N3Jh7cNZ2a95+ERdzhCc2/43PbAKUYljmHhVdK8mg1RFzALmQANPwTSUQoAyQphKwZFlaRSEYKm8ONBPkXTRAJsvSB+p5KmPjGRvQADBx3iq0YwtWAEpbC7qr103OXLMWsjwRkHwl4H0ZmKZ4cvJBg8nw4q6oB79oFgQiptyBw9wltQ66W9+WxDXVGMZkPBvkRx4WBdtDflKI2gJHVD/hiK+P3tthYDnMCYLnUnfRJaRD9WjUj+3F177G1xnDkVFhuRQwdZ/K7nFH7kjF+yze3gtX31MWp3vt3PM48nKC1r1zLa7CqEcvw2iItbni6BH3Avx1/hALw1U/uKshPsKjeWfoXLw0+iGMvFKHmMJqMfpHwCoaFYIlA3Mw8ZsT+GzGEOx3vYYV85/URq3Uj06Fp4VgkZGonj4H6/MHY2e4ksphPtIWNKISO5ZIWPjKRtElMgff4P2pWDntaSSecUV4Xhmqvd0Q/kI4ok/sw4xFwvabAGvL2B8hY9RAAaynnY9arIXVUWCpeqlA9csrtohhNmco5lC1HhHsDGCp7ac+3/ye9DcV6ObPJtBaX2ftcdt6HwEsBRarJcgvURkZePS/3b0DAKY1QOo9Gcikb89Wt8wCWJJ0lrqYjd08i6cK56IBilrcuTVgWfeiWkPJ5Mx3JkiyYYZJwj4JCIKMH0CWNsowFdO1BgkerY1wfqfAkk1SYvpTwWFql1CNFdXkOuG57/0D04uTbb5zax4WdQmrevZAVD8TflqyExE/+6XowtBBgFAN+bnHXoef5xisKR4Fo9y4vG9mSDCKwzwgDypDvmsp3OKrkfM3X+FpnToyF9515AZB/Eq/8JcfoXhvBPxyPNHnYr42tK52CcnD+vXKiViwaqtFrEQ13D/P/B2ej12B/TNnY1CxESHZysYK13r3RODPQzGxNhPDt32Jv4z2wZFQVy22YcvraCKWnx8u3rEUv/adK1ZwMQeWMdYdlY9JGPfKKq1eqkYDvriAd53nYfyxKnhWGSEH9kD4ixEITN6FWUuebgKs7H3e+GrcImSMNANW6Ung3Xe1KjXXJTy58VscyPXHxhUzRNn5r39ms80zY4Kw855xiP82TZxPTYzGHR98ifBLec1+F9RlMy8XhiuYi/1wRr0A9LqVc/Dk46/bTG9ozYOzBR57gGWr66t2rym22dwggACWljYkawmDsiT9kzwtGXhVAp4hmNFH3hqwFOBZemDWQtrypprzsFryvMzvOzn93aGA6UeQDE6yJNf8F5r0a+oIyPkyDGsBeYAE+T5ZlvLpdxsyLkKSQyQYMozhoc98IU2y2IbqOwUWICVkPBeUW3XReYz6UqFPFMB9WCV6fliJLT97tM3A8iir1GI/M6sviRhW+s6PLGI05q773QcuY++QZdhf0LjD8JnwWNQHOMJYC1yqK4L/j68Kzy/8BzlYf0bxMNSDuoR/GPUEjo2/CwGFFVpQWAVWxYVD+PlTM7WYl3qdarhPznwNL0cmIePuGYgortaudx7sgeCnwxF/6hxGPfMnPPvoeIu8oNZGudTnVPfpj6fu+zPyqnppXUI6lx/pD7+fuCLxH7/VgEUg33/ncBhKjLiyPQLjvqkQXmOtryvcHgmF9+GDmPirv4lbb3h0FvbPHI4fvLgO1486I3XcXRqwFlaeQkj2t3Db+ynCcQUGmJqNYR35z2nsygtFc6OE5lqrZdS/WY8oWhsLjSJeGBiB2z85InQ1X9fdHBy2vC1bQDK/vy2gtadLSJpvXD4Dkz/+CocnJ2ihBut3UdMaGrp9owBUS5D/3AAnMVJnHiNuDVgmzcNS4lW2PrQbAaxJ6WvmGWgQwAFbZVleDll2lyDlK/WXaclasXyKDFmSIHso56RNgHwvHORndocmWWyV9J0DK+dvPm9WHHJX3B8ALqF1CP2FMhL0yKPrsfDo1iZatuRhqcCi4O9dpakCWDRaRfEBtUto7Z1cnzoHL0cvQ6pnEHrlXsMVJx84+9WjpsAB9VUyCiZmwPvOcgxeexYLPt8qAvjmMawfP/C/yA8ZZdPDok0oXpszwCJorBop1ee+mR9je+z3kDFrEhwkgwaVXj8Kh8/UXgj8ZA+mL3zcImZDwdnW8ojMRXt/0QvYFDgD7hVViDyXrcXH+k4GJn35Bqa++IYorn64pXUeCPt1FWKLHESWOHVPL8cGwTHlHPpvpx4IYA2Dqom3IT0xTnQJ6RmUsDro3HbMw14RZ2jOwxLA8pmBsxOHifv2O26ZnmD+HgXBPsiJDBCm7J9bhJDLws6bPXKiAlEU0FvUp1fJNUR6VmFBeCr+frsPdg4LazI6Zx0wV9NmbD1A7cZ1JOhu3aW3NbigPlsFVgOIKJhebT6ARUnYEuTjaqC7NWAR6BrgN908gN7QrfOiLiYkQ2iTkckWYlgtNobZycmZa5bIJtkgGRC/Jzzpf0QagyTlm4yG444Gk6MJcpJjnfTLOifDIAmmQZIkeUMybdodlnTSBsjtfWzTcm2NYZGHRcKcWxC1679hEWUMnEblFpUIQOAysHPSEhhky6kbrXUJ1SzqsMEOIq3hzOEd8M8pshiBUe9xJcQXTpIBw/MiUfqXcuRU+KPW10kAi7yq2mIDyqQquD1+Hj2Ca4WR06Fm2VNaQ91mHww+XAv/wsb8Juu0BhVSdC2lWBBQexZXYuLsA7gQOxkV/eOEZ2h0MMDBEVg05iqKh/aGy7oNWPjEXzVgLfjHVrz+zP1aWod5KzTXpUiLHIc/jfgF8qOCtcxy+ji9h7tifulmjHtChETEQZ7H5R7BiP95Mbxc/cS0HAJWemwweqZnI/q0ki5zaUAE8sL90P/ri2Iksyo0COmDohuBVV6O/IXh6D+hHD+Z8WNUFFU1XXE04hwEsPxn4fwEJY2nuYx2Oqemq9B/qwMILVmreaY7lVOz3U+Un8OK5S9bdAWt02Vam21hK63B1jXNpTU0l8JA5fPC/Jqk9KjAUr8xCXKJFZyaDbCrcSBbELMx+KVlqd8ID4vaYWr6mniTJFH39dTuiMV/nCjvdZQys9+UZJMJkuQuyfL/7Y5M2ksZ8PVO8u8kSAXG8LDnrLuDdK8OeVjtRV3w+H1PQsbLtq5feGUb/njxf1u8tV1zCVupnGngIPxmxCv4qkjJqTE/JBcT5hx7FSsvv9PkXGujhM1t80WGWVftgIS7T6AkcYK2Fjo9QKx2kJgDt8upwDolL6ojRwk88NawF3DNw1+7DUHdNMoHP63Yir7P/U77O9WrLNcN/Z6/pmTYOzi0+9EiO97rrEggpQ0hmiyRbAYsmvMnID8sCx7OjatOJGd6YVeaMj3K1jrwm1MDcOKKMhtBjArHX7Gor/l5Pc8nbGume7sbTWcXdgmwSKOxw9bJ6T0a40jmuv0i8y38NEvZLsrW0RnA+mvYYhy6++eoKXTE9WuWHp2LsRrP5f8Fw79+r1OBVV3mhP4rslDVPxHo0bjVvZhoHJ8D56/2N1nKpT329OSqn+PU1TsRf7xMDAqonopnTyNeLdgE93f+Txvq/8OrK3D3X3Yg8ZwbMHRom4CVU+6CL7Mat/oyz45vsUvoP0tMUmZgNd+6DCzb2nQZsLb4TpIf7ft8sy3WErQ6CiyC1R/DH4aXpxPG9PdC1gWjxb4IcVXpiKzOsrkRa0c8rMpiF/R7vEhbwkV9eeEpRKYD27Zpqx20B1TqNVTHhb98H7X14TA0TJh2vV6NEecvYllsCjw+2QiaX2eeCIk5cxRg2Zpg3UxlzhX1xPpTjRn45pup2g0sq81nxRShhGUCaLY8JPNdqq0nu1M1zc+zh9URK7o5r+0yYMmA/GTME3gv0OYCDkIt6h6+fOmVJjGt9gLLJBnwVMwTWBswW2uNAbHu8O/hhoJcpVsSUFuI6OpssbOLrY1Y2wssurf1KgcWwKKVEWxMNG6P2Yg6hj6E9MgxFpuYCo9mwEV47Py4yZIxGDIEiIpq0+O+Kg7B5xX9gV5Khr353oTWwBJeZMR5HNmgxLA0D4uBZVNz9rBuMg+LgEVVumvwKhzzGNjshxJXmY6nMt6wyNFqD7A+9x6PlyOW47ybMo3H/Jgy0gfleRIcK65h4PUL2inJaMQ9ZZsx8GTjJgwdBpaNHatteQptIodV4Y7UsS3PtZ4w3RKw1OVqktenMLDsEJmBdZMCK9slEPcPfBXNxbPUak8sOYLF+R8LcLUFWASqNYF34Quvkc2aiU9vJ0zr4wink+lwoX3zzA7rjVg7AoO21NsOm262CC0EuNZ3ETJjx9vMxm9uYKCtzxT7GA7+vlgSxyDJWDIkB+GXDoq9Ca1XJdWAte40dgXMYQ+rFbEZWDcpsKha5PUsjf99q9CisoG1BRhVcBx1blHoHdALLqiHo6x05/oHVeG2wBx8ufYrHOk1CLu9RiPf2a/V7zCyOgdrXTfgqO8Um4v9ja4/julfKhuxdgRY4iOOeQxVIdEWS8iIWEvgSTi/9vdW62pPAev12dVrWlr22J77WpcR8aKEewV8rDdTtV6VVIwg9k5F8qpkLUZlnQpC9+cYlqIyA+smBhZVjTytlX2fbbF7qL6CsVaCn4MbgvxcIJkFiYPDHBEc7YB3Psy1+/sbXnEaq879FqE1+c0u9me+EWtHgCV2pol9HCVBNEG9cWqQ2PAh/DjcXxeLs3b4yIc33vZOQk3fgRYellgZNCYT0vbtTdZpb+mhtG5XETyRCz+kIxA+KMdEfKPs/jzsXrGPodibMCELgaf3ATt2IA0heDd8BeSqWAP0AAAO30lEQVQIJVVCHUFkYNnXvAysmxxYavVaC8RTuc4C1qL8LfjDpVcalWlhsT91I1bHmiqs81uI9D63tbm7JTYrjV2JtEDL9AHRnepzDuG71jZZjtg+87YsdQ4RWB+wCIiNtQi6T4kqwm1eGTaXPSYQk2dGXmAefHEF3siBn80NMKbiKEYiBeswDekN+xha701ovcjf7LirGC6dQ/K/DmkelodzPRb2S0fPvduBU6fFSxxFPPYnLBFem1ilNPQinD75WFv1lLqhKSPuEztO9/e7puR9vf66JoD5eR4lbI/13NzXdOkoYXPSbPWdJALkzcW1Ogos6gJSIH9OoeVql1QfWuxvg88DuFRuuVQyjRrSRqwjD72F9e0EFt1/d9R8HAiZZQES+vvE4HxMPLW66ehdG+2HRjI+xVgciZgJRERonhw19IMJuYg2Zmorg2YhAJswGWWwXL3C5iN9fJTRQHd3TI0rwwiPbKzdVI7MAVPE7s8CWGZ7E4quXewCIDhYpEqoAfnkNSc0YInn0Hr0Fy6IZZ21IyFB2UyCDls77YwYIYAljuvXgaNHLavccJ6B1Ubj0UHxmxJYqm6rQhfgzaD5uOpsuYlEe4HlX1uMZXkbsTK75WzynO8tx7sV41FttMz6po1Yv5+3GsllUUjrM6HNHha9V1rISLwb/ghk891vaBqJaw2W1G6G++5tHTIbgs9qzEIxbYgaGKjlVWnZ9NkXgdWrxTNERjzmgrqq4qBdeWgtefrH1RVwdlb+sdoA4/4BeQgtPos3P++hbaZqHR8TAfm+88SSy9q297knIUYJG/KsxDONRiAzU6xCqh0EOc+GxS5raxXvisCmHgRit4atz2jzDas15wWo3dx0vXMOdwltfwY3NbDUKm/wn4mP/KZif+/hio23MYY1ofQYvlewC/df/dQuGMhRUUgesRy7r4Y3KR9nSofj+VSkRE1uF7AoHvTe+BeR7dh0StAUtzMYv/2lDs2XEp6Nw2iIvCqPRi9xYmQxJkYUKd4IxbDIuYEDNgx8DBd6D1Iy3G0kjYq9D3vWItyzGpFeVQj1qIa7ixHXz2fhzR2uKI8b0rgPYMM+hvUnTmMDpuJCwmzhKbk71+PhxBx4pR5G8pYMS2DZ1SLtK8QeVvt0u5mv0gWwVAGLnTzxpedQ7HMbhhO+U+Ea5Id6B9r/WPGEwsMkxIdX4uia/ehXmYahFSkYV/aNtp5VWxqietJ0rHef12SxP0k2wZCXC6OPX7uARXU4Nm4Ztjne3gQQTqZaJF19B6FnLXeSsbfeFHN6FzNRHRShbGjhqOwU5OZkFCkH/oayJtn0u/stwgG/OwSwnB1MIm4U1qsaUV5VCHSvQQ9H23sI5h66iLePh2r7GJpvC1Z5OQ9vYxYKhk0V0BTe3eBMuB3Zj+Q9RRqwejgacUdMEVzNnpFa0BOnriqgFbtFR5TA0SBS9sRxONsTGWWKRxjhWYVRocpaZbbOM7DstRz9lNMVsFRZv5N8JhcXZMxZjjVFtNiflUxVDfv9Ubep4bA1RN+cGVT2GYC10T9ETm1Dt8esYI/yQiw8/QrCahvXi7fHnIrRC2sxXYzmwTwGREvlRhdhfHgJJOo6vW2543V5cB9U3DkffkGuAlg2D9r4lLpsZWXK3ocZGchMr8I7znfD1CdOwM4cWAWXS/DvXgu1OZOx3tdxf1wmHPfsRPKRGsu0Bp78bFNy7hLaNkUGVgs0kGNjmyz2J4rTcp50mHWh2gIsuvTSnEfxXsU4WoTNsgYmExyyMzE57T9iJM4JFgsuNqkt1YRSCD7AJFSihzK9JixMC7bTlJj7BuSjh1wD7NsHJNtY1fXhh5Vr6FA3ZaXt5HNzgbQ04Pz5Js+1HgUUI5Bu54FVqyD2LfRbBMTFifW1RA5WaJbw7pLPOFoCiwL1mWe17cGSi0Kxq3pQYwyKdpTOuKjFsDbnxuKEoa/wbgUkQy8qdWw4zM+zh2XPT52+yjCwWmkvWuxvtdNduFrVuLqCrUvaCiw5Ph4HE5OwMze06e3Io8nORs+0FIzCGfRDOrxRDur80mGEAdfghgsIxUEMBnlX4qANKQhYDV1BqhONzlHXjvbmw/vva2CweCjFu2gUkD58KmfHcQz9sC0mCQgNFeA2X6lhN4bjQNgcbbka2kB1sEsWsHEjknN8OXHUDn3Zw2IPyw4zsVHExQWX5v4A7xUMa+oNmRVvK7AEeGbOEvGjLzJ9mz6YvDjycgggtF1VSwcFzKOjlVHBhvWsKG61aHAugj1qlOu3blXSBzrpOIAh2N13obbxqkhbKD+N+tXvKQH3uCnKCKGDjCWJOQi5lg78618Wmeyc6d58YzCwGFjt/lRpsb/t/R7CscLmp/m0B1jUrTHd9wCOOA/B55d8bQORhv0rKoDiYqCkRPlvOmhYn4b+yTOidIQGr4pOUbD6/oH5Itgt8pi++gr4osXdk9qkDXVDP8QknBp4l7JTtdlKDSVrNiupEoljRf20dIpzJ4BNmxhYdirNwGJg2WkqtouVT7sbaxxmo7DKxWaBdgGL7uTnB8yejQLfPvjobAByKlruerb0EpSCMDasFBOjiuFEI2u0Lx/Bas+eDr279cWUt/UOZqEw4fYm8whPbknBhx5zgAEDxCKFlI1+b99cGA4mi3qYzxVkD4s9rLYaJsew7FXMxwcpU5dj45UBNj2hdgOLnk8Z5HPmwBQdg4zynth92QfZ5faDi9IDEgMrMDa8pHG5YRrJpAD7l1/a+4Z2lauDIygp9BuH/sCwYcLTE3Mhh2bD7dQxfLi1HKdDJihdVAcHiCk5Xle0dAoGll0y8+TnZmTSJbDEu0yaBIwf33RJXxp2X7XKPqtoa6nERGDaNCUL3NZB3a82Tiy2uA29z5gxYtpJvUkS0Lpc4orSaifkVLigzqhMmA7yqIGnSx3CPKtF3pRnj/rGsUYK2NPo3meficC9vUc5emIN7gQBiUYmQ3BVC/Kr96Ck10sIBf0b/v7KXEUnJwwJLMddsXko/eJrvHXAC9f6DxPntRUc6vKAtWuBoiL2sOxsEO4S3kJdwi4DFj347ruBQYMsVlvQpO0osFRva9w4pUtF8+XsXbKY0hFoPt6RI21aiUGtu1iFgiYzo3HJ42a/LfIIKWXB3R0ONHE7MQdhzqU4sjEF23MjFH3UqTGD8uB8MRVYv17cjj0s+4jFwLrVgGVfu+u7FKUp0MdPc+vIq6M5fuqyNDSHjpI5CwuVuXgnT9pOWWiDApujluJE8AQFkjRKSfP41Jwz9T70fNpAo6Eed0QXia5oVW4R1v47FzkBA7XuoEh1CClUuqZ7lYnmHQXW5xiNlHGLhBYUH5vumap51JVwwVrMQM6IOwXsOQ+rDY2vk6L67RLqRGA9VfNA0EzsjrzXYspRc/Wn9a/m9L2KAf7XQEtJn96Zhk2HXBXA+viA4moPJebA31hosZxNa8CipNOzk5cCAYHwdqvFKI8sOH78oZYfRjlo6Yt+gRrPhlQQGj1dv17Mi/wWcbiMYKBhtQaRYR9+3uJ6vbQHe1jsYenFVrusnrTw37ezn0C9R+PWXRRLo/hZL5d6ePWoFyDq412J8N7VojsoPLDLl1G64RO823sBimISxQoPVOb+gXlwSr8ErGncsq01YImXX7xY8dLooByyzZstElqT5/wKu0r6KOfJ0/zmm0bNKM2CuqvOzhATvr3Tba7/1WUi2/lgBhYDy05T6ebFkpLs3z2H4mYpKcAnn4juaModK7Cx7jYxinpv/3wM9C5VpgMdULa7t6dLKArRlmOUQU8HrXe1ezeQk6PdI803Ae96LYBsvekrdVMpN83FBbQ4IG1O611TIDLsza/XQwszsBhYerDTrq/j7bcD/fpZDioQCCh+RnldlC5B/yaAHDumTIZuOOThw5Hc936cLffCwsF5cLteJJJFzUcr7fKwWlHB1s7W5pdQ4iztCB1CWf42Jnx3vcit14CBxcBq3Uq4RIcVqL7rXhRGDUWoZw1w+rSy16LZQUswF8xNEpOtnRxMiHQthdNnn7RpZJNSL9JvfwB1AxIsRlEprkbzJt2cjUqaBw0akHd2+HCH3+u7vgEDi4H1Xdtc93weraT6wANKnhbtZJ2a2lQH8xhVe1NBRo4Epk5VVkS1dZAnSIsVdnKW/3fVqAwsBtZ3ZWv8HEooDQ9XvBtbB+WZEdDooDjYt9+2KclVXEcxLkrkNZtDKf6uLqlME70Jhjo9GFgMLJ2aLle7OyrAwGJgdUe753fWqQIMLAaWTk2Xq90dFWBgMbC6o93zO+tUAQYWA0unpsvV7o4KMLAYWN3R7vmddaoAA4uBpVPT5Wp3RwUYWAys7mj3/M46VYCBxcDSqelytbujAgwsBlZ3tHt+Z50qwMBiYOnUdLna3VEBBhYDqzvaPb+zThVgYDGwdGq6XO3uqAADi4HVHe2e31mnCjCwGFg6NV2udndUgIHFwOqOds/vrFMFGFgMLJ2aLle7OyrAwGJgdUe753fWqQIMLAaWTk2Xq90dFWBgMbC6o93zO+tUAQbWTQYsndoRV5sVYAW6UAGxfRsfrAArwAroQQEGlh5aievICrACQgEGFhsCK8AK6EYBBpZumoorygqwAgwstgFWgBXQjQIMLN00FVeUFWAFGFhsA6wAK6AbBRhYumkqrigrwAowsNgGWAFWQDcKMLB001RcUVaAFWBgsQ2wAqyAbhRgYOmmqbiirAArwMBiG2AFWAHdKMDA0k1TcUVZAVaAgcU2wAqwArpRgIGlm6biirICrAADi22AFWAFdKMAA0s3TcUVZQVYAQYW2wArwAroRgEGlm6aiivKCrACDCy2AVaAFdCNAgws3TQVV5QVYAUYWGwDrAAroBsFGFi6aSquKCvACjCw2AZYAVZANwowsHTTVFxRVoAVYGCxDbACrIBuFGBg6aapuKKsACvAwGIbYAVYAd0owMDSTVNxRVkBVoCBxTbACrACulGAgaWbpuKKsgKsAAOLbYAVYAV0owADSzdNxRVlBVgBBhbbACvACuhGAQaWbpqKK8oKsAIMLLYBVoAV0I0CDCzdNBVXlBVgBRhYbAOsACugGwX+H6jn/f+sAbzuAAAAAElFTkSuQmCC"
    c.push(canvas)
    let webglFp = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAADOFJREFUeF7tnV2IJUcVx0/dmSUPQdSHICpBFwxBJH6FgJAHe/QhiIKKiAr6EFQQVCQoKCjMbfRB8hBBQQUFRVACgoqI+AHOiApC3A9mlh3ZWRyzg+NqxCzZuEvcOO3W/WDuzNw7t++93VXnVP3mdfpWnfP/H35Un67qdsIfCqAAChhRwBmJkzBRAAVQQAAWRYACKGBGAYBlxioCRQEUAFjUAAqggBkFAJYZqwgUBVAAYFEDKIACZhQAWGasIlAUQAGARQ2gAAqYUQBgmbGKQFEABQAWNYACKGBGAYBlxioCRQEUAFjUAAqggBkFAJYZqwgUBVAAYFEDKIACZhQAWGasIlAUQAGARQ2gAAqYUQBgmbGKQFEABQAWNYACKGBGAYBlxioCRQEUAFjUQOMKVJUUIlI4J93GB2fArBUAWFnb307yA2CticiKc7LeziyMmqMCACtH11vOuarEw8qvssQ5vhvQstxZDQ+wsrI7TLKjwLrNrJJbwzC65zALwMrB5cA57ldSHSksoBXYg1SnA1ipOhspr1uVFEsia2MKC2hF8iSlaQFWSm4qyOX5StY6/gnh+FhowivwyHIIAMuyewpjnwIsmvAKPbMUEsCy5JaBWJ+vpOr4p4OTY113TlYMpEKIChUAWApNsRqS71856d0STtvLQD/LqsmR4wZYkQ1IafpbVa/ZXtQAlk8baKVkfqBcAFYgoXOYZkZgeUlowudQGA3mCLAaFDP3oW4N9l/VXGH15GInfO5VM1v+AGs2vbh6ggI3KymWB/uvZgHW7SM8NOGpqtoKAKzaUnHhSQo8V0m3I7LqC2pGYNHPorRqKwCwakvFhScp8N9Bw31OYAEtyquWAgCrlkxcNE2B50b2X82xwhoOz5PDaUJn/n+AlXkBNJG+7191RvZfLQAsmvBNGJLwGAArYXNDpfafSrrLIqtDUC0CLJrwoVyzOQ/AsumbqqhvDg48NwQs+lmq3NUVDMDS5YfJaG4O+lcNAgtomayE9oMGWO1rnPQM1wf7rzysGgYW0Eq6cuZLDmDNpxu/Gijg+1d+/1VLwKIJT6UdUgBgURALKXBj5MBzCyssHxs74RdyKK0fA6y0/AyezY2R84MtAYtbw+Cu6p0QYOn1Rn1kvn81fH97W7eEIyKwqVR9RbQfIMBqX+NkZ7heSXdp5PxgiyusoYZAK9lqqpcYwKqnE1eNUeDZkQ9OBFhhDSPgHVoZVyPAytj8RVN/9sj5wQArLJrwi5pm/PcAy7iBscJ/upLi1JHzg4GARRM+lukK5gVYCkywGEJkYAEti0XTQMwAqwERcxzimTHnBwOusGjC51h007/GlKkqpD1VgWfGnB+MACwfJ034qW6lcwErrHS8DJaJvx30+6+OPhmMBCyO7wRzPv5EACu+B+Yi0AYsvnForoTmDhhgzS1dvj+8NtK/Gl1VxVphDZxgU2kGJQmwMjC56RSvjfSvFAGLJ4dNG61wPICl0BTNIfnbQTfSv1IGLJrwmoungdgAVgMi5jSEAWDRhE+4IAFWwua2kdrTR95/pXCF5dPmHVptmK9gTIClwARLIRgBFv0sS0U1Q6wAawaxcr/0qcH724dfd9ayD+sEX3hymFjRAqzEDG0zHYPAognfZkFEGBtgRRDd6pT/HvSvDK2welI7J9S51aI7EjdGJmJkiDSsAosmfIjqCDMHwAqjs/lZ/O1gZ8z7r5Q+JRynN/0s81UoLJUT8DBICgkAiyeHQSql3UlYYbWrbzKjPzXh/VeGVlhDL1hpGa5KgGXYvJChJwQsmvAhC6fhuQBWw4KmOJy/HZQJ778yuMLyFrET3mihAiyjxoUMO0Fg0c8KWUANzgWwGhQz1aH87eDtVYl/SihHV1RGV1j0s4wWK8AyalzIsBMGFiutkIXUwFwAqwERUx/in5VUo7vbre10n+YPO+GnKaTn/wBLjxcqI/n74IMTKQOLJrzK0hsbFMCy41WUSK/uy1qn/5bRXv8qsR7WqKalW5JuFJGZtLYCAKu2VHleePVWNsASqaR0dwAtzZUOsDS7oyC2qzekmvQk0MD7sGZX0EPrTqA1u3BhfgGwwuhscpbd61KcGnPgObWm+xhzVtwLZN2kaYkHDbASN3iR9Pau9b7u3Nt/lUEPa1SqdfciWVlEO37bjgIAqx1dkxh171/ZAqvfz7qLW0NthQywtDmiKJ69f/T7VxmusIYulO4lQEtRSfI+LE1maIpld1eKpU5vhZUzsET2pXR3Ay0ttckKS4sTyuLYuzL5/GAGTffDbvxPVtxpmvAaShRgaXBBYQx7OwBr1BZ3mrsRDWUKsDS4oDCGv21PPj+Y3Qqr70/p7uHWMHapAqzYDiicf3dLio6TtUlbGTIFVv/J4auBVsySBVgx1Vc695Ob0l12sgqwxhjkoXUf0IpVugArlvKK593dOPn8YLYrrKFn+7Li3kATPkYJA6wYqiufc/fsyecHsweW3/n/RprwMcoYYMVQXfGcO09Isdz/pNfE4zgAqyfOunuA4zuhSxlghVZc+Xw7f5DuckdWAVYNo/ym0gfpZ9VQqrFLAFZjUqYx0JXf9Z4OnnjgmRXWiNceWm8GWqGqH2CFUtrIPE+uTz8/CLCOmFnJiluhCR+ixAFWCJWNzLHzayk6Nc4PAqxjhpburayyQpQ5wAqhspE5dn4p3Y70+1f0sGqbVrqHgFVttRa8EGAtKGBKP9/5+cH7rwDWFGf9BtK3A6rQ9Q+wQiuueL6dnx70rwDWBKM8qN4JqGKVMcCKpbyyeXd+LIUM3t/OLeFYc0r3bkAVu2wBVmwHlMy/80MpxB28sI8V1sAYv6J6L6BSUqYcL9BiROw4dh4//P6r7IHlQfUBQBW7Lo/OzwpLmyOR4vnL9w+//ypbYPmNoB8CVJHKcOq0AGuqROlfsP2d/vvb6+yvSvZT9ftSeqfdw8BKc8UDLM3uBIqtB6wqY2D5278PA6pA5bbQNABrIfnS+PHlb/X3X2W4wirdRwGVpSoGWJbcainWy984/v6rpHtYvk/1cUDVUjm1OizAalVe/YNvf00KN9jOkPwKy9/6fRJQ6a/KyRECLMvuNRD79lcyAJYH1SOAqoFyiT4EwIpuQdwAth+TNVcdf/9VIreEpfs0oIpbYc3ODrCa1dPcaJceHf/+K9PA8iuqzwIqc8VYI2CAVUOkVC/Z+qIUS0sHx3HM97CqwV6qzwOrVGsWYKXqbI28esAaOfBsGlj+yd8qoKphu+lLAJZp+xYL/tLq4fODJoHlpHRdQLVYJdj5NcCy41XjkV76gmlgle5LgKrxolA+IMBSblBb4W19ToqOO3wcx8QKyzfUvwyo2qoL7eMCLO0OtRTf1meMAcvf+j0KqFoqBzPDAiwzVjUb6NYjstZxh88PKl1hle4xQNWs+3ZHA1h2vVso8q1PyVqnUg2s0n0VUC1kcoI/BlgJmjotpc1PSLFc9fdfja6qVKywhnupvg6spvmY4/8BVoaub35MiuXB/itlwCrdNwFVhiVZO2WAVVuqdC68+JHe08FC0QqrdN8GVOlUWHuZAKz2tFU78sWHlQDLb1H4LqBSWygKAwNYCk1pM6TND/a3M0z79mCrh5/9FoXvAao2fU51bICVqrMT8tp8vxSdTjRgle4HgCqzkms0XYDVqJz6B7vwvoPbwWA9LL+iehxQ6a8O/RECLP0eNRrhhfcEBJbvUf0IUDVqYOaDAazMCuDCuw5/MLWNbQ1OpOyt3n4CrDIrr9bTBVitS6xngnPvkOKUTD7w3MTG0ducKk/9DFDpcT2tSABWWn6emM3G245/f7CxFVYl5R2/AFQZlVOUVAFWFNnjTLrx0MnnB+dZYfnbvzt/BajiOJrfrAArI8833nL8g6nzrrA8qF74G0CVUfmoSBVgqbCh/SDOFVIsTTnwXGuF5aR88Tqgat8xZhinAMDKpC7OP9jvX829g91JedfvAVUm5aI2TYCl1ppmAzv/pvmA5W/9XvpHQNWsG4w2rwIAa17ljP3u/APjP5g6qYclVX8v1cv/BKyMWZ10uAAraXv7yZ17vRSuxoHnIbw8rF5xHlBlUBrmUgRY5iybPeAzr5XuksjqtDc0+Nu/0xuAanaF+UUoBQBWKKUjznPuNbLmqn7DfVzT3YPqnouAKqJFTF1TAYBVUyjLl52996B/dQhYTsp7/wyoLHubW+wAK3HHn3iVFEuD97cPV1iVSHnfZUCVuPVJpgewkrT1IKkzr5SuG/Sv/K3f6/4KqBK3POn0AFbS9oqcvVvWKie/vf8KoErc6izSA1iJ23zmZdK9fw9YJW5zNukBrGysJlEUsK8AwLLvIRmgQDYKAKxsrCZRFLCvAMCy7yEZoEA2CgCsbKwmURSwrwDAsu8hGaBANgoArGysJlEUsK/A/wHYKgq1SuJ76QAAAABJRU5ErkJggg==§extensions:ANGLE_instanced_arrays;EXT_blend_minmax;EXT_clip_control;EXT_color_buffer_half_float;EXT_depth_clamp;EXT_disjoint_timer_query;EXT_float_blend;EXT_frag_depth;EXT_polygon_offset_clamp;EXT_shader_texture_lod;EXT_texture_compression_bptc;EXT_texture_compression_rgtc;EXT_texture_filter_anisotropic;EXT_texture_mirror_clamp_to_edge;EXT_sRGB;KHR_parallel_shader_compile;OES_element_index_uint;OES_fbo_render_mipmap;OES_standard_derivatives;OES_texture_float;OES_texture_float_linear;OES_texture_half_float;OES_texture_half_float_linear;OES_vertex_array_object;WEBGL_blend_func_extended;WEBGL_color_buffer_float;WEBGL_compressed_texture_s3tc;WEBGL_compressed_texture_s3tc_srgb;WEBGL_debug_renderer_info;WEBGL_debug_shaders;WEBGL_depth_texture;WEBGL_draw_buffers;WEBGL_lose_context;WEBGL_multi_draw;WEBGL_polygon_mode§extensions:ANGLE_instanced_arrays;EXT_blend_minmax;EXT_clip_control;EXT_color_buffer_half_float;EXT_depth_clamp;EXT_disjoint_timer_query;EXT_float_blend;EXT_frag_depth;EXT_polygon_offset_clamp;EXT_shader_texture_lod;EXT_texture_compression_bptc;EXT_texture_compression_rgtc;EXT_texture_filter_anisotropic;EXT_texture_mirror_clamp_to_edge;EXT_sRGB;KHR_parallel_shader_compile;OES_element_index_uint;OES_fbo_render_mipmap;OES_standard_derivatives;OES_texture_float;OES_texture_float_linear;OES_texture_half_float;OES_texture_half_float_linear;OES_vertex_array_object;WEBGL_blend_func_extended;WEBGL_color_buffer_float;WEBGL_compressed_texture_s3tc;WEBGL_compressed_texture_s3tc_srgb;WEBGL_debug_renderer_info;WEBGL_debug_shaders;WEBGL_depth_texture;WEBGL_draw_buffers;WEBGL_lose_context;WEBGL_multi_draw;WEBGL_polygon_mode§w1[1, 1]§w2[1, 1024]§w38§w4yes§w58§w624§w78§w816§w932§w1016384§w111024§w1216384§w1316§w1416384§w1530§w1616§w1716§w184096§w19[32767, 32767]§w208§w21WebKit WebGL§w22WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)§w230§w24WebKit§w25WebGL 1.0 (OpenGL ES 2.0 Chromium)§wuv:Google Inc. (AMD)§wur:ANGLE (AMD, AMD Radeon(TM) Graphics (0x00001681) Direct3D11 vs_5_0 ps_5_0, D3D11)"
    c.push(webglFp)
    return x64hash128(c.join("~~~"), 31)
}

// 测试样例
// console.log(jdFingerprint())