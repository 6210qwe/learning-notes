function safeToString(obj) {
    try {
        if (obj === undefined) {
            return '对象为undefined';
        }
        return obj.toString();
    } catch {
        return '无法转换为字符串';
    }
}

function printLog(objName, action, prop, value) {
    // 检查是否跳过打印
    if (skipCount > 0) {
        skipCount--;
    } else {
        console.log('计数:', count, '[' + objName + ']', action, prop, '=>', value);
    }
}

let count = 0;
let skipCount = 21;
// let ignoreList = ["document", "navigator", "location", "localStorage", "sessionStorage"];
let ignoreList = [];
proxy = function proxy(obj, objName) {
    let printedProps = new Set();
    let handler = {
        get(target, prop, receiver) {
            if (ignoreList.includes(prop)) return Reflect.get(target, prop, receiver);

            let result = Reflect.get(target, prop, receiver);
            let resultString = safeToString(result);

            if (!printedProps.has(prop)) {
                count++;

                // 判断是否访问了 toString 方法
                if (prop === 'toString') {
                    printLog('计数:', count, '[' + objName + ']', '调用 toString 方法');
                } else {
                    printLog(objName, '获取属性', prop, resultString.length <= 600 ? resultString : 'toString值太长');
                }

                if (typeof result === 'object' && result !== null) {
                    result = proxy(result, objName + '.' + prop);
                }
                printedProps.add(prop);
            }
            return result;
        },
        set(target, prop, value, receiver) {
            if (ignoreList.includes(prop)) return Reflect.set(target, prop, value, receiver);

            let valueString = safeToString(value);
            if (!printedProps.has(prop)) {
                count++;
                printLog(objName, '设置属性', prop, valueString.length <= 60 ? valueString : 'toString值太长');
                printedProps.add(prop);
            }

            // 对设置的新对象也应用代理
            if (typeof value === 'object' && value !== null) {
                value = proxy(value, objName + '.' + prop);
            }

            return Reflect.set(target, prop, value, receiver);
        }
    };

    return new Proxy(obj, handler);
}