window = global;

let c = [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 24, 3, -1, 20, -1, 17, 8, -1, 30, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 12, 22, 10, -1, -1, 15, 14, 6, -1, 5, -1, -1, 7, 18, -1, 25, 9, -1, 28, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 21, -1, 31, 13, 16, -1, 26, -1, 27, -1, 0, 19, -1, 11, 4, -1, -1, 23, -1, 29, -1, -1, -1, -1, -1, -1],
    l = "#"
    , u = "@?"
    , d = "*&%"
    , f = "<$|>";

function decodeCaptchaImg(e) {
    var t = e.length;
    if (t % 8 != 0)
        return null;
    for (var n = [], r = 0; r < t; r += 8) {
        var o = c[e["charCodeAt"](r)]
            , i = c[e["charCodeAt"](r + 1)]
            , a = c[e["charCodeAt"](r + 2)]
            , p = c[e["charCodeAt"](r + 3)]
            , h = c[e["charCodeAt"](r + 4)]
            , m = c[e["charCodeAt"](r + 5)]
            , v = c[e["charCodeAt"](r + 6)]
            , g = (31 & o) << 3 | (31 & i) >> 2
            , b = (3 & i) << 6 | (31 & a) << 1 | (31 & p) >> 4
            , y = (15 & p) << 4 | (31 & h) >> 1
            , w = (1 & h) << 7 | (31 & m) << 2 | (31 & v) >> 3
            , x = (7 & v) << 5 | 31 & c[e["charCodeAt"](r + 7)];
        n["push"](String["fromCharCode"]((31 & g) << 3 | b >> 5)),
            n["push"](String["fromCharCode"]((31 & b) << 3 | y >> 5)),
            n["push"](String.fromCharCode((31 & y) << 3 | w >> 5)),
            n["push"](String["fromCharCode"]((31 & w) << 3 | x >> 5)),
            n["push"](String["fromCharCode"]((31 & x) << 3 | g >> 5))
    }
    var _ = n.join("");
    return (_ = (_ = (_ = _["replace"](l, ""))["replace"](u, ""))["replace"](d, ""))["replace"](f, "")
}

var b = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g, y = function (e) {
    switch (e.length) {
        case 4:
            var t = ((7 & e.charCodeAt(0)) << 18 | (63 & e.charCodeAt(1)) << 12 | (63 & e.charCodeAt(2)) << 6 | 63 & e.charCodeAt(3)) - 65536;
            return String.fromCharCode(55296 + (t >>> 10)) + String.fromCharCode(56320 + (1023 & t));
        case 3:
            return String.fromCharCode((15 & e.charCodeAt(0)) << 12 | (63 & e.charCodeAt(1)) << 6 | 63 & e.charCodeAt(2));
        default:
            return String.fromCharCode((31 & e.charCodeAt(0)) << 6 | 63 & e.charCodeAt(1))
    }
};

function decodeCaptchaTitle(title_pic) {
    return window.atob(decodeCaptchaImg(title_pic)).replace(b, y);
}

// 测试样例

// 背景图片
// b64_pic = 'picture[0]'
// console.log(decodeCaptchaImg(b64_pic))

// 标题
// title_pic = "iMfZKVyt"
title_pic = "4ntGHUqMtltGiVfsOSqLiVwLO4qFSsiK4lqHXHOMOFfLnUGsORG94HKF6sRMqlwLiG2pjVyt"
console.log(decodeCaptchaTitle(title_pic))