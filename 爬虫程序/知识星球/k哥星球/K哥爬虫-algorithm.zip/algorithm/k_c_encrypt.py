# ======================
# -*-coding: Utf-8 -*-
# ======================
from loguru import logger


def get_key_iv(e):
    Ba = "bN3%cH2$H1@*jCo$"
    za = "gl3-w^dN)3#h6E1%"
    t = {
        "aes_key": Ba,
        "aes_iv": za
    }

    # 如果 e 为空或长度不为 9, 则返回默认的 t
    if not e or len(e) != 9:
        return t

    n = e[:1]
    r = e[1:]
    o = r[:4]
    i = r[4:]
    a = list(i)  # 将字符串转换为列表
    c = (Ba if n in ["a", "b"] else za)[:8]
    l = "aes_key" if n in ["a", "b"] else "aes_iv"
    s = ""

    # 根据 n 的值不同来设置 t[l]
    if n in ["a", "c"]:
        t[l] = c + r
    elif n in ["b", "d"]:
        for u in range(4):
            s += a[int(o[u])]
        t[l] = c + s + i

    return t


if __name__ == '__main__':
    salt = 'a43a4101b'
    key_iv = get_key_iv(salt)
    logger.info(key_iv)
