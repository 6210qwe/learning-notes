import time
from DrissionPage import ChromiumPage, ChromiumOptions
import random
import requests
from loguru import logger




def single_choose(div_id, page):
    inputs = page.eles(f'xpath://*[@id="{div_id}"]/div[2]//input')
    if inputs:
        selected_input = random.choice(inputs)
        input_element_id = selected_input.attr('id')
        page.run_js(f"document.getElementById('{input_element_id}').checked = true;")
        page.run_js(f"document.getElementById('{input_element_id}').click()")



def multiple_choose(div_id, min_choices, max_choices, page):
    inputs = page.eles(f'xpath://*[@id="{div_id}"]/div[2]//input')
    if inputs:
        num_choices = random.randint(min_choices, max_choices)
        selected_inputs = random.sample(inputs, num_choices)
        for input_element in selected_inputs:
            input_element_id = input_element.attr('id')
            page.run_js(f"document.getElementById('{input_element_id}').checked = true;")
            page.run_js(f"document.getElementById('{input_element_id}').click()")


if __name__ == '__main__':
    for _ in range(260):
        #proxy_ip = get_proxies()
        #co = ChromiumOptions().set_proxy(proxy_ip)
        page = ChromiumPage()
        page.get('https://www.wjx.cn/vm/wpAhWP2.aspx')
        js_code = """
        var cancelButton = document.querySelector('.layui-layer-btn1');
        if (cancelButton) {
            cancelButton.click();
        } else {
            console.log('找不到取消按钮');
        }
        """
        page.run_js(js_code)
        page.scroll.to_bottom()

        # Single-Choice Questions
        for i in range(1, 10):
            time.sleep(0.7)
            single_choose(f"div{i}", page)

        # Multiple-Choice Questions
        for i in range(10, 16):
            time.sleep(0.7)
            multiple_choose(f"div{i}", 2, random.randint(3, 4), page)

        time.sleep(1)
        page.run_js("document.getElementById('ctlNext').click()")
        time.sleep(1)
        try:
            click = page.run_js("document.querySelector('.layui-layer-btn0').click()")
            time.sleep(4)
            aa = page.run_js("document.getElementById('rectMask').click()")
            time.sleep(3)
        except Exception as e:
            print(e)

        page.quit()
        time.sleep(2)
