import time
import execjs

from loguru import logger
from curl_cffi import requests

with open('jssss.js', encoding='utf-8') as f:
    js = execjs.compile(f.read())

with open('webpack_jssss.js', encoding='utf-8') as f:
    js2 = execjs.compile(f.read())


class VietJet:
    def __init__(self):
        self.session = requests.Session(impersonate="chrome110")
        self.session.proxies.update({"http": "http://127.0.0.1:7890", "https": "http://127.0.0.1:7890"})

    def main(self):
        ss_data = js.call("ta")
        temp_data = js.call("ta")
        logger.info(f'{ss_data}, {temp_data}')

        sd_data = js.call("V", temp_data) + "-" + js.call("V", ss_data) + "-" + "-".join(ss_data.split('-')[2:])
        ls_data = temp_data + '-' + str(int(time.time() * 1000))

        logger.info(f'{sd_data}, {ls_data}')

        de_data = {
            "currency": "USD",
            "departureDate": "2024-09-02",
            "daysBeforeDeparture": 0,
            "daysAfterDeparture": 0,
            "departurePlace": "PKX",
            "arrival": "BKK",
            "oneway": 1,
            "adultCount": 1,
            "childCount": 0,
            "infantCount": 0,
            "requestId": "V8CDS18QC2EM-" + str(int(time.time() * 1000)),
            "sessionId": "",
            "x-power-web-s-d": sd_data,
            "user-agent-ls-data": ls_data
        }

        sorted_keys = sorted(de_data.keys())
        query_string = "&".join(
            f"{key}={value}" for key, value in ((k, de_data[k]) for k in sorted_keys)
        )

        logger.info(query_string)

        _signature = js.call('SHA256_Encrypt', query_string)
        de_data['_signature'] = _signature
        # "_signature": "3fcdb1e77a1d56d19e30495f9ea8932243fba4367a98ec20a20cb38c0a43cb53"
        logger.info(de_data)

        encrypted = js2.call('rsa_encrypt', de_data)
        logger.info(encrypted)

        headers = {
            "accept": "application/json",
            "accept-language": "zh-cn",
            "cache-control": "no-cache",
            "content-language": "zh-cn",
            "content-type": "application/json",
            "origin": "https://www.vietjetair.com",
            "pragma": "no-cache",
            "priority": "u=1, i",
            "referer": "https://www.vietjetair.com/",
            "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        }
        url = "https://vietjet-api.vietjetair.com/booking/api/v1/search-flight"
        data = {
            "encrypted": encrypted
        }
        response = self.session.patch(url, headers=headers, json=data)

        # {"message":"Forbidden"} -> 找不到適合您選擇的航班。返回選擇另一天。-> 当前 ip 无法访问
        logger.info(response.text)


if __name__ == '__main__':
    VietJet().main()
