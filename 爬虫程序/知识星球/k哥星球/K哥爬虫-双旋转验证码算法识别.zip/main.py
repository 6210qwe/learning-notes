import cv2
import numpy as np


def Img_show(img):
    cv2.imshow("dx", img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def remove_green_edge(image_bytes):
    que_image = cv2.imdecode(np.frombuffer(image_bytes[0], np.uint8), cv2.IMREAD_COLOR)
    background_image = cv2.imdecode(np.frombuffer(image_bytes[1], np.uint8), cv2.IMREAD_COLOR)

    def remove_rang(que_result):
        lower_green = np.array([35, 50, 50])
        upper_green = np.array([90, 255, 255])
        img_hsv = cv2.cvtColor(que_result, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(img_hsv, lower_green, upper_green)
        que_result = cv2.bitwise_and(que_result, que_result, mask=~mask)
        return que_result

    def large_img(que_result, scale_factor):
        circle_height, circle_width = que_result.shape[:2]
        new_height = int(circle_height * scale_factor)
        new_width = int(circle_width * scale_factor)
        que_result = cv2.resize(que_result, (new_width, new_height), interpolation=cv2.INTER_LINEAR)
        return que_result

    def split_circle(que_image, radius):
        height, width, _ = que_image.shape
        center = (width // 2, height // 2)
        mask = np.zeros_like(que_image)
        cv2.circle(mask, center, radius, (255, 255, 255), -1)
        que_result = cv2.bitwise_and(que_image, mask)
        return que_result

    def merge_img(que_result, bg_image, angle):
        que_height, que_width = que_result.shape[:2]
        rotation_matrix = cv2.getRotationMatrix2D((que_width / 2, que_height / 2), angle, 1)
        xuanzhuan_result = cv2.warpAffine(que_result, rotation_matrix, (que_width, que_height))
        bg_height, bg_width = bg_image.shape[:2]
        circle_height, circle_width = xuanzhuan_result.shape[:2]
        x = (bg_width - circle_width) // 2
        y = (bg_height - circle_height) // 2
        overlay = np.zeros_like(bg_image)
        overlay[y:y + circle_height, x:x + circle_width] = xuanzhuan_result
        result = cv2.add(bg_image, overlay)
        return result

    que_result = remove_rang(que_image)
    radius = 74
    que_result = split_circle(que_result, radius)
    scale_factor = 1.1
    question_result = large_img(que_result, scale_factor)

    min_difference = 9999999999
    min_angle_index = 0
    for current_angle in range(0, 360):
        processed_result = merge_img(question_result, background_image, current_angle)
        center_x_coord = processed_result.shape[1] // 2
        center_y_coord = processed_result.shape[0] // 2
        radius_of_circle = 70
        inner_circle_mask = np.zeros_like(processed_result, dtype=np.uint8)
        cv2.circle(inner_circle_mask, (center_x_coord, center_y_coord), radius_of_circle, 255, -1)
        outer_circle_mask = np.zeros_like(processed_result, dtype=np.uint8)
        cv2.circle(outer_circle_mask, (center_x_coord, center_y_coord), radius_of_circle + 16, 255, -1)
        inner_region_pixels = cv2.bitwise_and(processed_result, inner_circle_mask)
        outer_region_pixels = cv2.bitwise_and(processed_result, outer_circle_mask)
        inner_sobel_gradient_x = cv2.Sobel(inner_region_pixels, cv2.CV_64F, 1, 0)
        inner_sobel_gradient_y = cv2.Sobel(inner_region_pixels, cv2.CV_64F, 0, 1)
        magnitude_inner_gradient = cv2.magnitude(inner_sobel_gradient_x, inner_sobel_gradient_y)
        outer_sobel_gradient_x = cv2.Sobel(outer_region_pixels, cv2.CV_64F, 1, 0)
        outer_sobel_gradient_y = cv2.Sobel(outer_region_pixels, cv2.CV_64F, 0, 1)
        magnitude_outer_gradient = cv2.magnitude(outer_sobel_gradient_x, outer_sobel_gradient_y)
        difference_in_gradient = np.sum(magnitude_outer_gradient) - np.sum(magnitude_inner_gradient)
        current_gradient_sum = difference_in_gradient
        if current_gradient_sum < min_difference:
            min_difference = current_gradient_sum
            min_angle_index = current_angle

    result = merge_img(que_result, background_image, min_angle_index)
    Img_show(result)
    print(min_angle_index, min_difference)
    _, result_bytes = cv2.imencode('.png', result)
    #return  min_i
    return result_bytes.tobytes()

# 读取图片字节集
with open("images/que_1.png", "rb") as file:
    que_bytes = file.read()

with open("images/bg_1.png", "rb") as file:
    bg_bytes = file.read()

# 处理图片字节集
image_bytes = [que_bytes, bg_bytes]
result_image_bytes = remove_green_edge(image_bytes)

# 保存处理后的图片字节集
with open("result/result_1.png", "wb") as file:
    file.write(result_image_bytes)
