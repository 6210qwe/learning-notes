var b = {
    MqNjR: function (j, k) {
        return j(k);
    },
    wQDKX: function (j, k) {
        return j > k;
    },
    xhTOe: ".css",
    ejdRo: "link",
    ohpsT: function (j, k) {
        return j(k);
    },
    OoDJX: function (j, k) {
        return j !== k;
    },
    rMQqK: function (j, k) {
        return j >= k;
    },
    YaCsA: "yxoDg",
    GZROK: "IlXgP",
    quYeN: function (j) {
        return j();
    },
    QeyWD: "ngtkY",
    kmXCi: function (j, k) {
        return j(k);
    },
    EUOxi: function (j, k) {
        return j == k;
    },
    IzoJa: function (j, k) {
        return j + k;
    },
    HtRvV: "KysWa",
    FtWbk: "LfpCH",
    reXvh: "#tianai-captcha-slider-bg-img",
    yMsDD: "src",
    PXLiB: "#tianai-captcha-scrape-tip-img",
    GnNvk: "#tianai-captcha-slider-img-div",
    GYsqM: "transform",
    TeRBn: function (j, k) {
        return j + k;
    },
    rzkYM: "load",
    NFnAt: function (j, k) {
        return j === k;
    },
    LqLkL: function (j, k) {
        return j !== k;
    },
    shPBC: "NokVd",
    dZXSU: function (j, k) {
        return j(k);
    },
    BXTBT: function (j, k) {
        return j - k;
    },
    cKrDG: function (j, k) {
        return j - k;
    },
    fKLep: function (j, k) {
        return j - k;
    },
    xwoDK: function (j, k) {
        return j !== k;
    },
    QtzAk: "oFIlg",
    uhBSx: "wjqpI",
    qXThI: "UkhYj",
    OitBT: "cXPCP",
    lJPkt: function (j, k) {
        return j / k;
    },
    XhmEh: function (j, k) {
        return j < k;
    },
    pCyDc: function (j, k) {
        return j * k;
    },
    MlyGq: function (j, k) {
        return j * k;
    },
    BlKkk: function (j, k, l) {
        return j(k, l);
    },
    eexIJ: "down",
    WKmPQ: "mousemove",
    QqUNT: "touchend",
    OGTiF: function (j, k) {
        return j === k;
    },
    dXcKM: "QyNuL",
    cjCXy: "#tianai-captcha-tips",
    kQNKE: "tianai-captcha-tips-error",
    kIDYJ: "tianai-captcha-tips-success",
    YOWHe: "PZsvf",
    hsexy: "object",
    NzTMS: "string",
    wFetG: "mXcbj",
    BgVTz: "touchstart",
    cYGQL: function (j, k, l, m, o, p) {
        return j(k, l, m, o, p);
    },
    lbrWX: "efMvy",
    aqOJu: "SLIDER",
    GstqO: function (j, k) {
        return j < k;
    },
    oLAzM: "CzUgf",
    bwDHQ: function (j, k, l, m, o) {
        return j(k, l, m, o);
    },
    azhJT: "#a9ffe5",
    NkjVH: function (j, k) {
        return j + k;
    },
    XFied: function (j, k) {
        return j + k;
    },
    kmxNx: "#tianai-captcha-slider-move-track-mask",
    awFNm: "border-color",
    OsnJG: "background-color",
    CYHDx: "Invalid content type",
    qBtMZ: "sqhwS",
    vWJGA: "cTJYc",
    mNDnH: "wPqlv",
    EAJum: "#tianai-captcha",
    OWoVJ: "#tianai-captcha-slider-move-btn",
    dNBwg: function (j, k) {
        return j(k);
    },
    ntwWo: "iilIH",
    jKcYu: function (j) {
        return j();
    },
    LmmGQ: function (j, k) {
        return j + k;
    },
    FUYjQ: function (j, k) {
        return j + k;
    },
    sMWOz: "#00f4ab",
    wXlqt: ".slider-move .slider-move-btn",
    zpePJ: "background-image",
    pWnCW: "url(",
    jkdsk: function (j) {
        return j();
    },
    sQDzx: "JOenF",
    coHkS: "#tianai-captcha-slider-move-img",
    RpnXu: "gbwuQ",
    ChRiA: "OoSCO",
    PpFzm: "BGxJs",
    xumAf: "click-span",
    ffOhp: "<span class='click-span' style='left:",
    dzxmJ: "px;top: ",
    pUigV: "px'>",
    FwkVA: "#bg-img-click-mask",
    bVMqe: ".click-confirm-btn",
    UOZvT: "WORD_ORDER_IMAGE_CLICK",
    KWTUl: "declined",
    WxLVW: function (j, k) {
        return j === k;
    },
    znFwE: "itdyF",
    xeqNQ: "display",
    uBiut: ".tianai-captcha-slider-bg-img-mask",
    ccBZB: ".bg-img-div",
    wqDdv: "#tianai-captcha-slider-bg-degree-canvas",
    uBKQD: "hjolk",
    VMuFW: function (j, k) {
        return j / k;
    },
    GkLtj: function (j, k) {
        return j + k;
    },
    UPsdo: "translate(",
    kGGfB: "px, 0px)",
    gPENo: "[TAC] 必须配置 [requestCaptchaDataUrl]请求验证码接口",
    CnAZR: function (j, k) {
        return j === k;
    },
    ErDTx: function (j, k) {
        return j === k;
    },
    byull: "dfIGr",
    HakRl: function (j, k) {
        return j !== k;
    },
    fiBNa: "validCaptcha",
    MhfnT: function (j, k) {
        return j < k;
    },
    oYESA: "phrFe",
    RQcaJ: "BOxny",
    WXZoJ: "wIyOn",
    ckwpH: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-~",
    XuSSO: function (j, k) {
        return j % k;
    },
    PcAnX: function (j, k) {
        return j - k;
    },
    RwScm: "ZPLQp",
    ekfXx: "MgqEk",
    HgJPz: "WggCx",
    LDoRS: "#tianai-captcha-curve-bg-canvas",
    gIyyf: "rgba(255,255,255,0.75)",
    EDARY: "CURVE",
    HVbBj: function (j, k, l, m, o) {
        return j(k, l, m, o);
    },
    wvAnt: function (j, k, l) {
        return j(k, l);
    },
    JCdHn: "style",
    JBhDS: function (j, k) {
        return j === k;
    },
    unxyP: "mNgnM",
    kjhOy: function (j) {
        return j();
    },
    QdVtq: "width",
    cJyep: function (j, k, l, m, o) {
        return j(k, l, m, o);
    },
    XLvFY: "MHyYR",
    IvCJr: `
    <div id="tianai-captcha-parent">
        <div id="tianai-captcha-bg-img"></div>
        <div id="tianai-captcha-box">
            <div id="tianai-captcha-loading" class="loading"></div>
        </div>
        <!-- 底部 -->
        <div class="slider-bottom">
            <img class="logo" id="tianai-captcha-logo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAAMFBMVEVHcEz3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkX3tkVmTmjZAAAAD3RSTlMASbTm8wh12hOGoCNiyTV98jvOAAABB0lEQVR42nVT0aIFEQiMorD0/397Lc5a7J0n1UylgIniLRKyDcbBDudZH2DYCAabn3PmTrjeUX+7rJGWx0SqVpzReAfTtKU5fgVCNfxWjB69USUDGwoOiauHpZEpSr0tCx8ILb3Dm3WgBbAlifAJk6+Ww6wqEUmpmIorQVZ1JtqKnDMjkb7AgIpO/wMCaQbuBuEtsBUxhuD9daUaZnApiQB8NAKotMwirGGr6mbXpPnHLHDmy6oy3FgP+1j8IBdVklFc01xUJwv3NR0rIeXV5zpzdlruiijzNq/ufOeKWzZLP3160u5P8RjT1M+HHFtx+PwGyOZqT/D8ROOfjOInTLBIHjy/hvwHxkwPu5cCE1QAAAAASUVORK5CYII="></img>
            <div class="close-btn" id="tianai-captcha-slider-close-btn"></div>
            <div class="refresh-btn" id="tianai-captcha-slider-refresh-btn"></div>
        </div>
    </div>
    `,
    IaNRn: "#tianai-captcha-parent",
    uKXRB: "#tianai-captcha-slider-refresh-btn",
    XcoFc: "#tianai-captcha-slider-close-btn",
    zVmoP: function (j, k) {
        return j === k;
    },
    uLDFM: "SCRAPE",
    RKWLf: "[TAC] 未知的验证码类型[",
    yiogk: function (j, k) {
        return j !== k;
    },
    wcWQy: "ZjiDK",
    SIkby: function (j, k) {
        return j === k;
    },
    EkLPm: "ZYZbT",
    jylhB: "EMSIs",
    gDlZY: "CXSxM",
    PYuuP: "不支持的类型",
    WicEz: "(?!\\S)",
    tJKCC: "PfMnk",
    nxAIj: "exwNn",
    jbuDb: function (j, k) {
        return j == k;
    },
    ukQnM: ".tianai-captcha-slider-concat-bg-img",
    qXSOe: "dom不存在: [",
    kOQeH: "WoIGo",
    rLGQv: "DLTKC",
    bFvdX: "dWjzj",
    YyEVU: "Failed to fetch update manifest ",
    Spynm: "IAZWY",
    lNyzq: "data-href",
    uWaIQ: function (j, k, l, m, o) {
        return j(k, l, m, o);
    },
    VCegz: "transform-origin",
    lYrlb: "wOJXr",
    Patce: "ROTATE",
    LPkwB: "#tianai-captcha-curve2-bg-canvas",
    PAhVG: function (j, k) {
        return j * k;
    },
    IuVbJ: "rgb(0,0,0)",
    EWKuQ: "YyPbo",
    jtNzG: "LajUe",
    cfSyc: function (j, k) {
        return j + k;
    },
    gBjTu: "background-position-x",
    AUmUe: "background-position",
    TNsfR: "moewW",
    sHQoX: function (j, k) {
        return j + k;
    },
    PAqnX: "</span>",
    PEhxX: function (j, k) {
        return j !== k;
    },
    RWtew: "ztito",
    fivee: function (j, k) {
        return j !== k;
    },
    xPZAm: function (j, k, l, m, o) {
        return j(k, l, m, o);
    },
    MsnrV: "baGSo",
    mItVV: function (j, k) {
        return j != k;
    },
    yqIdL: function (j, k) {
        return j(k);
    },
    MQNkl: "deg)",
    GoGwH: "DhCOo",
    yyBTv: "dtrDN",
    XZicz: function (j, k) {
        return j < k;
    },
    NkjbC: function (j, k) {
        return j - k;
    },
    hwmIA: function (j, k) {
        return j + k;
    },
    esEHH: "JUqri",
    KPUIK: "QxIgG",
    divKE: "HodRf",
    vgBlt: "#tianai-captcha-bg-img",
    bpJpZ: "ZcLiP",
    Zhdig: "\\.js$",
    vDZFG: function (j, k) {
        return j(k);
    },
    dBMVI: function (j, k) {
        return j(k);
    },
    KajvG: function (j, k) {
        return j(k);
    },
    xsPLs: function (j, k) {
        return j(k);
    },
    iZFBv: function (j, k) {
        return j(k);
    },
    zfVWt: "#0298f8",
    LEBFO: "验证成功,耗时%s秒",
    AzzcU: "拖动滑块完成拼图",
    LLjqz: "拖动滑块出现完整的",
    zgpvv: "15px",
    BqciP: function (j, k) {
        return j + k;
    },
    koUli: "UHDNW",
    fKGLb: function (j, k) {
        return j === k;
    },
    kyHeg: "nSWKL",
    nhVKv: "xhqst",
    yjngI: function (j, k) {
        return j === k;
    },
    gdgzm: "coVBM",
    MMxRQ: "atMTQ",
    eadaO: "ZjDZw",
    vHghk: function (j, k) {
        return j > k;
    },
    eivhG: "return this",
    ELyzW: "SxgXr",
    moLUr: function (j, k) {
        return j + k;
    },
    lZHUa: "PKhIv",
    WcXsc: function (j, k) {
        return j(k);
    },
    HYXVH: "script",
    jmSpD: "data-webpack",
    XtsPu: "timeout",
    TkQal: function (j, k) {
        return j(k);
    },
    VmHAg: function (j, k) {
        return j === k;
    },
    rlIkL: "ready",
    juugH: "idle",
    oabpm: "KWnRt",
    SVgCU: function (j, k) {
        return j !== k;
    },
    rPwBF: "check() is only allowed in idle status",
    kbxjl: function (j, k) {
        return j(k);
    },
    GPZkB: "check",
    HmnlT: function (j, k) {
        return j + k;
    },
    DXyKk: function (j, k) {
        return j !== k;
    },
    ZceJw: "NvGZP",
    uHBlL: function (j, k) {
        return j + k;
    },
    jRNtE: function (j, k) {
        return j + k;
    },
    AYxcQ: function (j, k) {
        return j / k;
    },
    Eogtp: "rotate(",
    ZtHvW: "YAkFr",
    tWvGA: "tdVon",
    YDoWA: function (j, k) {
        return j(k);
    },
    kxvBq: function (j, k) {
        return j || k;
    },
    PDPJh: function (j, k) {
        return j(k);
    },
    ygYEV: "dispose",
    ZsQnq: "apply",
    cBaZJ: function (j) {
        return j();
    },
    JEAlH: "upEFE",
    HjfWj: "Cgtzq",
    UaqKY: function (j, k) {
        return j === k;
    },
    lGZJo: function (j, k) {
        return j == k;
    },
    yWdHY: "function",
    JINou: function (j, k) {
        return j >= k;
    },
    cPBnd: "apply() is only allowed in ready status (state: ",
    wgkdy: "EJwrs",
    dQxcd: function (j, k) {
        return j !== k;
    },
    cEePn: "Automatic publicPath is not supported in this browser",
    xteFH: "stylesheet",
    FiKhO: "Bioml",
    daOmP: function (j, k) {
        return j < k;
    },
    LFLAR: function (j, k) {
        return j !== k;
    },
    LQgnX: function (j, k) {
        return j !== k;
    },
    bhIoA: "uJTOi",
    AqgSV: function (j, k) {
        return j != k;
    },
    WaaSG: "undefined",
    GXciw: "AzccW",
    ZdzWn: "agDLS",
    IKOtt: function (j, k) {
        return j === k;
    },
    uwZpk: function (j, k) {
        return j + k;
    },
    eKOWM: "MAbev",
    OaEwI: function (j, k) {
        return j + k;
    },
    eFMQu: "fxkFv",
    QuFVi: function (j, k) {
        return j instanceof k;
    },
    TKDnH: "TFllf",
    VldRF: "EoTni",
    BdZIP: "accept-error-handler-errored",
    nEmXl: "accept-errored",
    aFbPD: function (j, k) {
        return j + k;
    },
    Jvqkq: " -> ",
    OsXUu: "Aborted because of self decline: ",
    SeadM: function (j, k) {
        return j + k;
    },
    UfXUP: "Aborted because of declined dependency: ",
    czQha: "hZQwb",
    PBNuj: "rlgFR"
};
const a9 = {
    preRequest(ac, ad, ae, af) {
        if (b.fiBNa !== ac) {
            return true;
        }
        const ag = ad.data.data;
        const ah = [];
        ah.push('ptJITSbptJIUBO');
        // ah.push(this.pretreatment(ag.startTime, 7, true));
        // ah.push(this.pretreatment(ag.stopTime, 7, true));
        ah.push(this.pretreatment(ag.bgImageWidth, 3, true));
        ah.push(this.pretreatment(ag.bgImageHeight, 3, true));
        ah.push(this.pretreatment(ag.templateImageWidth, 3, true));
        ah.push(this.pretreatment(ag.templateImageHeight, 3, true));
        ah.push(this.pretreatment(ag.left, 3, true));
        ah.push(this.pretreatment(ag.top, 3, true));
        ah.push(this.pretreatment(ag.trackList.length, 3, true));
        ah.push(this.encryptTrack(ag.trackList));
        if (ag.data) {
            ah.push(this.encodeStr(JSON.stringify(ag.data)));
        }
        return ah.join("");
        ;
    },
    encodeStr(ac) {
        const ad = [];
        for (let ae = 0; b.MhfnT(ae, ac.length); ae++) {
            let af = ac.charCodeAt(ae);
            ad.push(af);
        }
        return ad.join(",");
    },
    encryptTrack(ac) {
        if (b.oYESA === "phrFe") {
            const ad = [];
            for (let ae = 0; ae < ac.length; ae++) {
                if (b.RQcaJ !== "ZbLvL") {
                    let af = ac[ae];
                    let ag = 0;
                    switch (af.type) {
                        case "down":
                            ag = 0;
                            break;
                        case "move":
                            ag = 1;
                            break;
                        case "up":
                            ag = 2;
                            break;
                        case "click":
                            ag = 3;
                    }
                    if (ae === 0) {
                        ad.push(this.pretreatment(af.x, 3, false));
                        ad.push(this.pretreatment(af.y, 3, false));
                        ad.push(this.pretreatment(af.t, 4, true));
                        ad.push(ag);
                    } else {
                        let ah = ac[ae - 1];
                        ad.push(this.pretreatment(af.x - ah.x, 3, false));
                        ad.push(this.pretreatment(b.cKrDG(af.y, ah.y), 3, false));
                        ad.push(this.pretreatment(b.fKLep(af.t, ah.t), 4, true));
                        ad.push(ag);
                    }
                } else {
                    a0.currentCaptchaData = O(W.width(), G.height(), L.width(), P.height());
                    q.currentCaptchaData.currentCaptchaId = J.id;
                    H(ac.captcha, this.el.find(B.jyfrl), this.el.find("#tianai-captcha-slider-bg-img"), 50);
                }
            }
            return ad.join("");
        } else {
            K(this.el, M);
        }
    },
    string10to64(ac) {
        var ad = {
            zHwVt: "#tianai-captcha-slider-move-btn",
            OeOlv: function (ae, af) {
                return b.dNBwg(ae, af);
            }
        };
        if (b.WXZoJ !== "wIyOn") {
            this.destroy();
            this.boxEl.append(function (af) {
                return `
<div id="tianai-captcha" class="tianai-captcha-slider">
    <div class="slider-tip">
        <span id="tianai-captcha-slider-move-track-font" style="font-size: ` + af.i18n.slider_title_size + "\">" + af.i18n.slider_title + `</span>
    </div>
    <div class="content">
        <div class="bg-img-div">
            <img id="tianai-captcha-slider-bg-img" src="" alt/>
            <canvas id="tianai-captcha-slider-bg-canvas"></canvas>
            <div id="tianai-captcha-slider-bg-div"></div>
        </div>
        <div class="slider-img-div" id="tianai-captcha-slider-img-div">
            <img id="tianai-captcha-slider-move-img" src="" alt/>
        </div>
        <div class="tianai-captcha-tips" id="tianai-captcha-tips"></div>
    </div>
    <div class="slider-move">
        <div class="slider-move-track">
            <div id="tianai-captcha-slider-move-track-mask"></div>
            <div class="slider-move-shadow"></div>
        </div>
        <div class="slider-move-btn" id="tianai-captcha-slider-move-btn">
        </div>
    </div>

</div>
`;
            }(this.styleConfig));
            this.el = this.boxEl.find("#tianai-captcha");
            this.loadStyle();
            this.el.find(ad.zHwVt).mousedown(X.bind(null, this));
            this.el.find("#tianai-captcha-slider-move-btn").touchstart(N.bind(null, this));
            this.loadCaptchaForData(this, z);
            this.endCallback = j;
            if (a0) {
                ad.OeOlv(O, this);
            }
            return this;
        } else {
            let af = b.ckwpH.split("");
            let ag = af.length;
            let ah = +ac;
            let ai = [];
            do {
                let aj = b.XuSSO(ah, ag);
                ah = b.PcAnX(ah, aj) / ag;
                ai.unshift(af[aj]);
            } while (ah);
            return ai.join("");
        }
    },
    prefixInteger: (ac, ad) => (Array(ad).join(0) + ac).slice(-ad),
    pretreatment(ac, ad, ae) {
        if (b.RwScm !== "QmDRs") {
            const af = this.string10to64(Math.abs(ac));
            let ag = "";
            if (!ae) {
                ag += ac >= 0 ? "1" : "0";
            }
            ag += this.prefixInteger(af, ad);
            return ag;
        } else {
            return !!/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(Y);
        }
    }
};


function get_code_sold(id, trackList) {
    let arg1 = 'validCaptcha';
    let arg2 = {
    "headers": {
        "Content-Type": "application/json;charset=UTF-8",
        "x-referer": "https://captcha.tianai.cloud/"
    },
    "data": {
        "id": id,
        "data": {
            "bgImageWidth": 300,
            "bgImageHeight": 180,
            "templateImageWidth": 55,
            "templateImageHeight": 180,
            "startTime": "2025-06-15T02:27:44.468Z",
            "stopTime": "2025-06-15T02:27:45.371Z",
            "trackList": trackList,
            "left": 735,
            "top": 543
        }
    },
    "method": "POST",
    "url": "//api.captcha.tianai.cloud/check3"
}
    return a9.preRequest(arg1, arg2)
}
// aq = [
//     {
//         "x": 781,
//         "y": 574,
//         "type": "down",
//         "t": 0
//     },
//     {
//         "x": 782,
//         "y": 574,
//         "type": "move",
//         "t": 140
//     },
//     {
//         "x": 783,
//         "y": 574,
//         "type": "move",
//         "t": 232
//     },
//     {
//         "x": 784,
//         "y": 574,
//         "type": "move",
//         "t": 484
//     },
//     {
//         "x": 785,
//         "y": 574,
//         "type": "move",
//         "t": 557
//     },
//     {
//         "x": 786,
//         "y": 574,
//         "type": "move",
//         "t": 596
//     },
//     {
//         "x": 787,
//         "y": 574,
//         "type": "move",
//         "t": 636
//     },
//     {
//         "x": 788,
//         "y": 574,
//         "type": "move",
//         "t": 665
//     },
//     {
//         "x": 789,
//         "y": 574,
//         "type": "move",
//         "t": 693
//     },
//     {
//         "x": 790,
//         "y": 574,
//         "type": "move",
//         "t": 791
//     },
//     {
//         "x": 791,
//         "y": 574,
//         "type": "move",
//         "t": 847
//     },
//     {
//         "x": 792,
//         "y": 574,
//         "type": "move",
//         "t": 897
//     },
//     {
//         "x": 793,
//         "y": 574,
//         "type": "move",
//         "t": 930
//     },
//     {
//         "x": 794,
//         "y": 574,
//         "type": "move",
//         "t": 978
//     },
//     {
//         "x": 795,
//         "y": 574,
//         "type": "move",
//         "t": 1007
//     },
//     {
//         "x": 795,
//         "y": 575,
//         "type": "move",
//         "t": 1032
//     },
//     {
//         "x": 796,
//         "y": 575,
//         "type": "move",
//         "t": 1069
//     },
//     {
//         "x": 797,
//         "y": 575,
//         "type": "move",
//         "t": 1146
//     },
//     {
//         "x": 798,
//         "y": 575,
//         "type": "move",
//         "t": 1188
//     },
//     {
//         "x": 799,
//         "y": 575,
//         "type": "move",
//         "t": 1206
//     },
//     {
//         "x": 799,
//         "y": 576,
//         "type": "move",
//         "t": 1208
//     },
//     {
//         "x": 800,
//         "y": 576,
//         "type": "move",
//         "t": 1230
//     },
//     {
//         "x": 801,
//         "y": 576,
//         "type": "move",
//         "t": 1246
//     },
//     {
//         "x": 802,
//         "y": 576,
//         "type": "move",
//         "t": 1294
//     },
//     {
//         "x": 803,
//         "y": 576,
//         "type": "move",
//         "t": 1323
//     },
//     {
//         "x": 804,
//         "y": 576,
//         "type": "move",
//         "t": 1349
//     },
//     {
//         "x": 805,
//         "y": 577,
//         "type": "move",
//         "t": 1371
//     },
//     {
//         "x": 806,
//         "y": 577,
//         "type": "move",
//         "t": 1400
//     },
//     {
//         "x": 807,
//         "y": 577,
//         "type": "move",
//         "t": 1447
//     },
//     {
//         "x": 808,
//         "y": 577,
//         "type": "move",
//         "t": 1546
//     },
//     {
//         "x": 809,
//         "y": 577,
//         "type": "move",
//         "t": 1578
//     },
//     {
//         "x": 810,
//         "y": 577,
//         "type": "move",
//         "t": 1604
//     },
//     {
//         "x": 811,
//         "y": 577,
//         "type": "move",
//         "t": 1624
//     },
//     {
//         "x": 812,
//         "y": 577,
//         "type": "move",
//         "t": 1635
//     },
//     {
//         "x": 813,
//         "y": 577,
//         "type": "move",
//         "t": 1649
//     },
//     {
//         "x": 814,
//         "y": 577,
//         "type": "move",
//         "t": 1667
//     },
//     {
//         "x": 815,
//         "y": 577,
//         "type": "move",
//         "t": 1673
//     },
//     {
//         "x": 816,
//         "y": 577,
//         "type": "move",
//         "t": 1678
//     },
//     {
//         "x": 817,
//         "y": 577,
//         "type": "move",
//         "t": 1683
//     },
//     {
//         "x": 818,
//         "y": 577,
//         "type": "move",
//         "t": 1689
//     },
//     {
//         "x": 819,
//         "y": 577,
//         "type": "move",
//         "t": 1698
//     },
//     {
//         "x": 820,
//         "y": 577,
//         "type": "move",
//         "t": 1703
//     },
//     {
//         "x": 821,
//         "y": 577,
//         "type": "move",
//         "t": 1708
//     },
//     {
//         "x": 822,
//         "y": 577,
//         "type": "move",
//         "t": 1712
//     },
//     {
//         "x": 823,
//         "y": 577,
//         "type": "move",
//         "t": 1717
//     },
//     {
//         "x": 824,
//         "y": 577,
//         "type": "move",
//         "t": 1721
//     },
//     {
//         "x": 825,
//         "y": 577,
//         "type": "move",
//         "t": 1731
//     },
//     {
//         "x": 826,
//         "y": 577,
//         "type": "move",
//         "t": 1734
//     },
//     {
//         "x": 827,
//         "y": 577,
//         "type": "move",
//         "t": 1739
//     },
//     {
//         "x": 828,
//         "y": 577,
//         "type": "move",
//         "t": 1744
//     },
//     {
//         "x": 829,
//         "y": 577,
//         "type": "move",
//         "t": 1748
//     },
//     {
//         "x": 830,
//         "y": 577,
//         "type": "move",
//         "t": 1753
//     },
//     {
//         "x": 831,
//         "y": 577,
//         "type": "move",
//         "t": 1764
//     },
//     {
//         "x": 832,
//         "y": 577,
//         "type": "move",
//         "t": 1768
//     },
//     {
//         "x": 833,
//         "y": 577,
//         "type": "move",
//         "t": 1772
//     },
//     {
//         "x": 834,
//         "y": 578,
//         "type": "move",
//         "t": 1777
//     },
//     {
//         "x": 835,
//         "y": 578,
//         "type": "move",
//         "t": 1782
//     },
//     {
//         "x": 836,
//         "y": 578,
//         "type": "move",
//         "t": 1787
//     },
//     {
//         "x": 837,
//         "y": 578,
//         "type": "move",
//         "t": 1798
//     },
//     {
//         "x": 838,
//         "y": 578,
//         "type": "move",
//         "t": 1802
//     },
//     {
//         "x": 839,
//         "y": 578,
//         "type": "move",
//         "t": 1809
//     },
//     {
//         "x": 840,
//         "y": 578,
//         "type": "move",
//         "t": 1814
//     },
//     {
//         "x": 841,
//         "y": 578,
//         "type": "move",
//         "t": 1819
//     },
//     {
//         "x": 842,
//         "y": 578,
//         "type": "move",
//         "t": 1825
//     },
//     {
//         "x": 842,
//         "y": 579,
//         "type": "move",
//         "t": 1831
//     },
//     {
//         "x": 843,
//         "y": 579,
//         "type": "move",
//         "t": 1839
//     },
//     {
//         "x": 844,
//         "y": 579,
//         "type": "move",
//         "t": 1848
//     },
//     {
//         "x": 845,
//         "y": 579,
//         "type": "move",
//         "t": 1856
//     },
//     {
//         "x": 846,
//         "y": 579,
//         "type": "move",
//         "t": 1865
//     },
//     {
//         "x": 847,
//         "y": 579,
//         "type": "move",
//         "t": 1878
//     },
//     {
//         "x": 848,
//         "y": 579,
//         "type": "move",
//         "t": 1895
//     },
//     {
//         "x": 849,
//         "y": 579,
//         "type": "move",
//         "t": 1918
//     },
//     {
//         "x": 850,
//         "y": 579,
//         "type": "move",
//         "t": 1924
//     },
//     {
//         "x": 851,
//         "y": 579,
//         "type": "move",
//         "t": 1937
//     },
//     {
//         "x": 852,
//         "y": 579,
//         "type": "move",
//         "t": 1945
//     },
//     {
//         "x": 853,
//         "y": 579,
//         "type": "move",
//         "t": 1962
//     },
//     {
//         "x": 854,
//         "y": 579,
//         "type": "move",
//         "t": 1985
//     },
//     {
//         "x": 855,
//         "y": 579,
//         "type": "move",
//         "t": 1991
//     },
//     {
//         "x": 856,
//         "y": 580,
//         "type": "move",
//         "t": 2005
//     },
//     {
//         "x": 857,
//         "y": 580,
//         "type": "move",
//         "t": 2016
//     },
//     {
//         "x": 858,
//         "y": 580,
//         "type": "move",
//         "t": 2029
//     },
//     {
//         "x": 859,
//         "y": 580,
//         "type": "move",
//         "t": 2041
//     },
//     {
//         "x": 860,
//         "y": 580,
//         "type": "move",
//         "t": 2068
//     },
//     {
//         "x": 861,
//         "y": 580,
//         "type": "move",
//         "t": 2085
//     },
//     {
//         "x": 862,
//         "y": 580,
//         "type": "move",
//         "t": 2095
//     },
//     {
//         "x": 863,
//         "y": 580,
//         "type": "move",
//         "t": 2116
//     },
//     {
//         "x": 864,
//         "y": 580,
//         "type": "move",
//         "t": 2132
//     },
//     {
//         "x": 865,
//         "y": 580,
//         "type": "move",
//         "t": 2156
//     },
//     {
//         "x": 866,
//         "y": 580,
//         "type": "move",
//         "t": 2199
//     },
//     {
//         "x": 866,
//         "y": 581,
//         "type": "move",
//         "t": 2212
//     },
//     {
//         "x": 867,
//         "y": 581,
//         "type": "move",
//         "t": 2217
//     },
//     {
//         "x": 868,
//         "y": 581,
//         "type": "move",
//         "t": 2234
//     },
//     {
//         "x": 869,
//         "y": 581,
//         "type": "move",
//         "t": 2251
//     },
//     {
//         "x": 870,
//         "y": 581,
//         "type": "move",
//         "t": 2265
//     },
//     {
//         "x": 871,
//         "y": 581,
//         "type": "move",
//         "t": 2281
//     },
//     {
//         "x": 872,
//         "y": 581,
//         "type": "move",
//         "t": 2314
//     },
//     {
//         "x": 873,
//         "y": 581,
//         "type": "move",
//         "t": 2332
//     },
//     {
//         "x": 874,
//         "y": 581,
//         "type": "move",
//         "t": 2355
//     },
//     {
//         "x": 875,
//         "y": 581,
//         "type": "move",
//         "t": 2376
//     },
//     {
//         "x": 876,
//         "y": 581,
//         "type": "move",
//         "t": 2393
//     },
//     {
//         "x": 877,
//         "y": 581,
//         "type": "move",
//         "t": 2408
//     },
//     {
//         "x": 878,
//         "y": 581,
//         "type": "move",
//         "t": 2434
//     },
//     {
//         "x": 879,
//         "y": 581,
//         "type": "move",
//         "t": 2446
//     },
//     {
//         "x": 880,
//         "y": 581,
//         "type": "move",
//         "t": 2459
//     },
//     {
//         "x": 881,
//         "y": 581,
//         "type": "move",
//         "t": 2472
//     },
//     {
//         "x": 882,
//         "y": 581,
//         "type": "move",
//         "t": 2488
//     },
//     {
//         "x": 883,
//         "y": 581,
//         "type": "move",
//         "t": 2526
//     },
//     {
//         "x": 884,
//         "y": 581,
//         "type": "move",
//         "t": 2553
//     },
//     {
//         "x": 885,
//         "y": 581,
//         "type": "move",
//         "t": 2580
//     },
//     {
//         "x": 886,
//         "y": 581,
//         "type": "move",
//         "t": 2595
//     },
//     {
//         "x": 887,
//         "y": 581,
//         "type": "move",
//         "t": 2616
//     },
//     {
//         "x": 888,
//         "y": 581,
//         "type": "move",
//         "t": 2633
//     },
//     {
//         "x": 889,
//         "y": 581,
//         "type": "move",
//         "t": 2666
//     },
//     {
//         "x": 890,
//         "y": 581,
//         "type": "move",
//         "t": 2682
//     },
//     {
//         "x": 891,
//         "y": 581,
//         "type": "move",
//         "t": 2698
//     },
//     {
//         "x": 892,
//         "y": 581,
//         "type": "move",
//         "t": 2712
//     },
//     {
//         "x": 893,
//         "y": 581,
//         "type": "move",
//         "t": 2740
//     },
//     {
//         "x": 894,
//         "y": 581,
//         "type": "move",
//         "t": 2760
//     },
//     {
//         "x": 895,
//         "y": 581,
//         "type": "move",
//         "t": 2806
//     },
//     {
//         "x": 896,
//         "y": 581,
//         "type": "move",
//         "t": 2837
//     },
//     {
//         "x": 897,
//         "y": 581,
//         "type": "move",
//         "t": 2875
//     },
//     {
//         "x": 898,
//         "y": 581,
//         "type": "move",
//         "t": 2936
//     },
//     {
//         "x": 899,
//         "y": 581,
//         "type": "move",
//         "t": 2975
//     },
//     {
//         "x": 900,
//         "y": 581,
//         "type": "move",
//         "t": 3008
//     },
//     {
//         "x": 901,
//         "y": 581,
//         "type": "move",
//         "t": 3061
//     },
//     {
//         "x": 902,
//         "y": 581,
//         "type": "move",
//         "t": 3085
//     },
//     {
//         "x": 903,
//         "y": 581,
//         "type": "move",
//         "t": 3109
//     },
//     {
//         "x": 904,
//         "y": 581,
//         "type": "move",
//         "t": 3126
//     },
//     {
//         "x": 905,
//         "y": 581,
//         "type": "move",
//         "t": 3159
//     },
//     {
//         "x": 906,
//         "y": 581,
//         "type": "move",
//         "t": 3186
//     },
//     {
//         "x": 907,
//         "y": 581,
//         "type": "move",
//         "t": 3324
//     },
//     {
//         "x": 908,
//         "y": 581,
//         "type": "move",
//         "t": 3412
//     },
//     {
//         "x": 909,
//         "y": 581,
//         "type": "move",
//         "t": 3467
//     },
//     {
//         "x": 910,
//         "y": 581,
//         "type": "move",
//         "t": 3504
//     },
//     {
//         "x": 911,
//         "y": 581,
//         "type": "move",
//         "t": 3564
//     },
//     {
//         "x": 912,
//         "y": 581,
//         "type": "move",
//         "t": 3628
//     },
//     {
//         "x": 913,
//         "y": 581,
//         "type": "move",
//         "t": 3875
//     },
//     {
//         "x": 914,
//         "y": 581,
//         "type": "move",
//         "t": 4081
//     },
//     {
//         "x": 915,
//         "y": 581,
//         "type": "move",
//         "t": 4253
//     },
//     {
//         "x": 915,
//         "y": 581,
//         "type": "up",
//         "t": 4339
//     }
// ]
// ids = 'SLIDER_56381ad37a014ca1b01dade9c59522d7'
// console.log(get_code_sold(ids, aq));

//ptJITSbptJIUBO04I02Q00T02Q05F08v02c
//ptJITSbptJIUBO04I02Q00T02Q05F08v02c10cd108-0000010011000002c110011000001s110011000003Y1100110000019110011000000D110011000000E110011000000t110011000000s110011000001y110011000000U110011000000O110011000000x110011000000M110011000000t110001001000p110011000000B110011000001d110011000000G110011000000i1100010010002110011000000m110011000000g110011000000M110011000000t110011000000q110011001000m110011000000t110011000000L110011000001z110011000000w110011000000q110011000000k110011000000b110011000000e110011000000i1100110000006110011000000511001100000051100110000006110011000000911001100000051100110000005110011000000411001100000051100110000004110011000000a11001100000031100110000005110011000000511001100000041100110000005110011000000b11001100000041100110000004110011001000511001100000051100110000005110011000000b1100110000004110011000000711001100000051100110000005110011000000611000100100061100110000008110011000000911001100000081100110000009110011000000d110011000000h110011000000n1100110000006110011000000d1100110000008110011000000h110011000000n1100110000006110011001000e110011000000b110011000000d110011000000c110011000000r110011000000h110011000000a110011000000l110011000000g110011000000o110011000000H110001001000d1100110000005110011000000h110011000000h110011000000e110011000000g110011000000x110011000000i110011000000n110011000000l110011000000h110011000000f110011000000q110011000000c110011000000d110011000000d110011000000g110011000000C110011000000r110011000000r110011000000f110011000000l110011000000h110011000000x110011000000g110011000000g110011000000e110011000000s110011000000k110011000000K110011000000v110011000000C110011000000Z110011000000D110011000000x110011000000R110011000000o110011000000o110011000000h110011000000x110011000000r110011000002a110011000001o110011000000T110011000000B110011000000Y1100110000010110011000003T110011000003e110011000002I110001000001m2
//ptJITSbptJIUBO04I02Q00T02Q0bv08v02c10cd108-0000010011000002c110011000001s110011000003Y1100110000019110011000000D110011000000E110011000000t110011000000s110011000001y110011000000U110011000000O110011000000x110011000000M110011000000t110001001000p110011000000B110011000001d110011000000G110011000000i1100010010002110011000000m110011000000g110011000000M110011000000t110011000000q110011001000m110011000000t110011000000L110011000001z110011000000w110011000000q110011000000k110011000000b110011000000e110011000000i1100110000006110011000000511001100000051100110000006110011000000911001100000051100110000005110011000000411001100000051100110000004110011000000a11001100000031100110000005110011000000511001100000041100110000005110011000000b11001100000041100110000004110011001000511001100000051100110000005110011000000b1100110000004110011000000711001100000051100110000005110011000000611000100100061100110000008110011000000911001100000081100110000009110011000000d110011000000h110011000000n1100110000006110011000000d1100110000008110011000000h110011000000n1100110000006110011001000e110011000000b110011000000d110011000000c110011000000r110011000000h110011000000a110011000000l110011000000g110011000000o110011000000H110001001000d1100110000005110011000000h110011000000h110011000000e110011000000g110011000000x110011000000i110011000000n110011000000l110011000000h110011000000f110011000000q110011000000c110011000000d110011000000d110011000000g110011000000C110011000000r110011000000r110011000000f110011000000l110011000000h110011000000x110011000000g110011000000g110011000000e110011000000s110011000000k110011000000K110011000000v110011000000C110011000000Z110011000000D110011000000x110011000000R110011000000o110011000000o110011000000h110011000000x110011000000r110011000002a110011000001o110011000000T110011000000B110011000000Y1100110000010110011000003T110011000003e110011000002I110001000001m2